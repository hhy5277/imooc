﻿using UnityEngine;
using System.Collections;
using GDGeek;
// http://gdgeek.com mit 

public class Ctrl : MonoBehaviour {
	private FSM fsm_ = new FSM();
	public View _view = null;
	public Model _model = null;
	public void fsmPost(string msg){
		fsm_.post (msg);
	}
	State beginState ()
	{
		StateWithEventMap state = new StateWithEventMap ();
		state.onStart += delegate {
			_view.begin.gameObject.SetActive(true);
		};
		state.onOver += delegate {
			_view.begin.gameObject.SetActive(false);
		};

		state.addEvent("begin", "input");
		return state;
	}

	public void refreshModel2View (){
		for (int x =0; x <_model.width; ++x) {
			for(int y = 0; y<_model.height; ++y){
				Square s = _view.play.getSquare(x, y);
				Cube c = _model.getCube(x, y);
				if(c.isEnabled){
					s.number = c.number;
					s.show();
				}else{
					s.hide();
				}
			}		
		}
	}

	State playState ()
	{

		
		StateWithEventMap state = new StateWithEventMap ();

		state.onStart += delegate {
			refreshModel2View();
		
		};
		state.onOver += delegate {
			_view.play.gameObject.SetActive(false);
		};
		return state;
	}

	State endState ()
	{
		StateWithEventMap state = new StateWithEventMap ();
		state.addEvent("end", "begin");
		state.onStart += delegate {
			_view.end.gameObject.SetActive(true);
		};
		state.onOver += delegate {
			_view.end.gameObject.SetActive(false);
		};
		return state;
	}
	private void input(int x){
		for (int y = _model.height-1; y >= 0 ; --y) {
			Cube c = _model.getCube(x, y);
			if(!c.isEnabled){
				c.isEnabled = true;
				c.number = Random.Range(3, 8);
				break;
			}
		}
		refreshModel2View ();
	}
	State inputState ()
	{
		StateWithEventMap state = new StateWithEventMap ();
		state.onStart += delegate {
			Debug.LogWarning("in input!");
		};
		state.addAction("1", delegate(FSMEvent evt) {
			Debug.Log ("I get one~");
			input(0);
			return "fall";
		});

		
		state.addAction("2", delegate(FSMEvent evt) {
			Debug.Log ("I get two~");
			input(1);
			return "fall";
		});


		
		state.addAction("3", delegate(FSMEvent evt) {
			Debug.Log ("I get 3~");
			input(2);
			return "fall";
		});


		
		state.addAction("4", delegate(FSMEvent evt) {
			Debug.Log ("I get 4~");
			input(3);
			return "fall";
		});
		return state;
	}

	State fallState ()
	{
		StateWithEventMap state = TaskState.Create(delegate {
			TaskWait tw = new TaskWait();
			tw.setAllTime(0.3f);
			return tw;
		}, fsm_, "remove");


		state.onStart += delegate {
			Debug.LogWarning("in fall!");
		};
		return state;
	}

	State removeState ()
	{
		StateWithEventMap state = TaskState.Create(delegate {
			TaskWait tw = new TaskWait();
			tw.setAllTime(0.3f);
			return tw;
		}, fsm_, "input");
		state.onStart += delegate {
			Debug.LogWarning("in remove!");
		};
		return state;
	}

	// Use this for initialization
	void Start () {
		fsm_.addState ("begin", beginState());
		fsm_.addState ("play", playState ());

		fsm_.addState ("input", inputState(), "play");
		fsm_.addState ("fall", fallState(), "play");
		fsm_.addState ("remove", removeState(), "play");

		fsm_.addState ("end", endState ());
		fsm_.init ("input");
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
