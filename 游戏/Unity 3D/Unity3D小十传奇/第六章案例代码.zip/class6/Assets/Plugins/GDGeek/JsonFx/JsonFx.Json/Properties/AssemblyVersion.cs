/*------------------------------------------------------------------*\
	This is auto-generated code.  All changes will be overwritten.
\*------------------------------------------------------------------*/

#region 1.4.1003.3008

using System.Reflection;

[assembly: AssemblyVersion("1.4.1003.3008")]
[assembly: AssemblyFileVersion("1.4.1003.3008")]

#endregion 1.4.1003.3008
