﻿using UnityEngine;
using System.Collections;

public class View : MonoBehaviour {


	public GameObject begin = null;
	public Play play = null;
	public GameObject end = null;


}
