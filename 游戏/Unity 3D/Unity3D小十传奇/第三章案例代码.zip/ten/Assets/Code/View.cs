﻿using UnityEngine;
using System.Collections;

public class View : MonoBehaviour {
	public GameObject begin = null;
	public GameObject play = null;
	public GameObject end = null;


}
