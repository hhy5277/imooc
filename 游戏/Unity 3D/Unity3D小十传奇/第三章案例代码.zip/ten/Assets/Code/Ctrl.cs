﻿using UnityEngine;
using System.Collections;
using GDGeek;
// http://gdgeek.com mit 

public class Ctrl : MonoBehaviour {
	private FSM fsm_ = new FSM();
	public View _view = null;
	public void fsmPost(string msg){
		fsm_.post (msg);
	}
	State beginState ()
	{
		StateWithEventMap state = new StateWithEventMap ();
		state.onStart += delegate {
			_view.begin.gameObject.SetActive(true);
		};
		state.onOver += delegate {
			_view.begin.gameObject.SetActive(false);
		};

		state.addEvent("begin", "play");
		return state;
	}

	State playState ()
	{
		StateWithEventMap state = TaskState.Create (delegate {
			TaskWait tw = new TaskWait();
			tw.setAllTime(3f);
			return tw;
				}, fsm_, "end");

		state.onStart += delegate {
			_view.play.gameObject.SetActive(true);
		};
		state.onOver += delegate {
			_view.play.gameObject.SetActive(false);
		};
		return state;
	}

	State endState ()
	{
		StateWithEventMap state = new StateWithEventMap ();
		state.addEvent("end", "begin");
		state.onStart += delegate {
			_view.end.gameObject.SetActive(true);
		};
		state.onOver += delegate {
			_view.end.gameObject.SetActive(false);
		};
		return state;
	}

	// Use this for initialization
	void Start () {
		fsm_.addState ("begin", beginState());
		fsm_.addState ("play", playState ());
		fsm_.addState ("end", endState ());
		fsm_.init ("begin");
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
