﻿using UnityEngine;
using System.Collections;
using System;
public class Sound : MonoBehaviour {
	
	public AudioSource fall;
	public AudioSource remove;
	public AudioSource error;
	public AudioSource end;

}
