﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class End : MonoBehaviour {
	public CanvasGroup _cg;
	public Text _score;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
