﻿using UnityEngine;
using System.Collections;

public class Play : MonoBehaviour {

	private Square[] list_ = null;
	void Awake(){
		list_ = this.GetComponentsInChildren<Square> ();
		foreach (Square square in list_) {
			square.hide();
		}
		//Debug.Log (list_.Length);
	}
	// Use this for initialization
	void Start () {
		//list_ [0].gameObject.SetActive (false);

	}
	

	
	public Square getSquare (int x, int y){

		int n = x + y * 4;
		return list_[n];
	}

}
