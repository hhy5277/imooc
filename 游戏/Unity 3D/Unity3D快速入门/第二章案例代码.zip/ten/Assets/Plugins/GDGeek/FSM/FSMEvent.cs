﻿using UnityEngine;
using System.Collections;

namespace GDGeek{
	public class FSMEvent {

		public string msg = null;
		public object obj = null;

	}
}