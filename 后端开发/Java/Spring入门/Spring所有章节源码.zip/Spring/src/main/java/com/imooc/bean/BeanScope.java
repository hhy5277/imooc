package com.imooc.bean;

public class BeanScope {
	
	public void say() {
		System.out.println("BeanScope say : " + this.hashCode());
	}
	
}
