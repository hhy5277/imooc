package com.imooc.beanannotation.multibean;

public interface BeanInterface {

}
