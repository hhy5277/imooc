package com.imooc.beanannotation.javabased;

public interface Store<T> {

}
