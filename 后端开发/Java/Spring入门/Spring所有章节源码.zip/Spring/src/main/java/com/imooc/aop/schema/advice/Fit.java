package com.imooc.aop.schema.advice;

public interface Fit {
	
	void filter();

}
