package com.imooc.beanannotation.javabased;

public class IntegerStore implements Store<Integer> {

}
