package com.imooc.beanannotation.injection.dao;

public interface InjectionDAO {
	
	public void save(String arg);
	
}
