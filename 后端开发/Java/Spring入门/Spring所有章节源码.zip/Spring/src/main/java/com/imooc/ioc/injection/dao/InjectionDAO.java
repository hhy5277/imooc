package com.imooc.ioc.injection.dao;

public interface InjectionDAO {
	
	public void save(String arg);
	
}
