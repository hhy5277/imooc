package com.imooc.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class TaskTest3 {

	@Test
	public void test() {
		System.out.println("this is TaskTest3...");
	}

}
