package com.pxy.l7;

public class UserInfo {
	public static String account = "C78464758";
	public static String pwd = "2b76e1836707e4d536b7d87197514ce8";
}
