package com.imooc.drdc.model;

public class ImportData {

	private String importid;
	
	private String importDataType;
	
	private String importDate;
	
	private String importStatus;
	
	private String handleDate;
	
	private String handleStatus;
	
	public String getImportid() {
		return importid;
	}

	public void setImportid(String importid) {
		this.importid = importid;
	}

	public String getImportDataType() {
		return importDataType;
	}

	public void setImportDataType(String importDataType) {
		this.importDataType = importDataType;
	}

	public String getImportDate() {
		return importDate;
	}

	public void setImportDate(String importDate) {
		this.importDate = importDate;
	}

	public String getImportStatus() {
		return importStatus;
	}

	public void setImportStatus(String importStatus) {
		this.importStatus = importStatus;
	}

	public String getHandleDate() {
		return handleDate;
	}

	public void setHandleDate(String handleDate) {
		this.handleDate = handleDate;
	}

	public String getHandleStatus() {
		return handleStatus;
	}

	public void setHandleStatus(String handleStatus) {
		this.handleStatus = handleStatus;
	}

}
