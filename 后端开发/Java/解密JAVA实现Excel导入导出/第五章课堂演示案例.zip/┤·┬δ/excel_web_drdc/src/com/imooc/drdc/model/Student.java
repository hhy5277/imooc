package com.imooc.drdc.model;

public class Student {

	private int sid ;
	private String stunum;
	private String stuname;
	private String stuage;
	private String stusex;
	private String stubirthday;
	private String stuhobby;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getStunum() {
		return stunum;
	}
	public void setStunum(String stunum) {
		this.stunum = stunum;
	}
	public String getStuname() {
		return stuname;
	}
	public void setStuname(String stuname) {
		this.stuname = stuname;
	}
	public String getStuage() {
		return stuage;
	}
	public void setStuage(String stuage) {
		this.stuage = stuage;
	}
	public String getStusex() {
		return stusex;
	}
	public void setStusex(String stusex) {
		this.stusex = stusex;
	}
	public String getStubirthday() {
		return stubirthday;
	}
	public void setStubirthday(String stubirthday) {
		this.stubirthday = stubirthday;
	}
	public String getStuhobby() {
		return stuhobby;
	}
	public void setStuhobby(String stuhobby) {
		this.stuhobby = stuhobby;
	}
}
