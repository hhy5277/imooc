package com.sunny.project;
/**
 * ʥ��ϵ�е�Ů��
 * @author Administrator
 *
 */
public class MCGirl implements Girl {

	@Override
	public void drawWomen() {
		// TODO Auto-generated method stub
		System.out.println("-----------------ʥ��ϵ�е�Ů����--------------------");
	}

}
