package com.sunny.project;
/**
 * �к�
 * @author Administrator
 *
 */
public interface Boy {

	
	public void drawMan();
}
