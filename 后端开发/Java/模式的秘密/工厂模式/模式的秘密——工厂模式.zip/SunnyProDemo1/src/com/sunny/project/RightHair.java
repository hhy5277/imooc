package com.sunny.project;
/**
 * ��ƫ�ַ���
 * @author Administrator
 *
 */
public class RightHair implements HairInterface {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("-----------------��ƫ�ַ���-------------------");
	}

}
