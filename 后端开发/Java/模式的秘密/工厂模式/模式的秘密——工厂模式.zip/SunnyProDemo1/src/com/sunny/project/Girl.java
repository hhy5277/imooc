package com.sunny.project;
/**
 * Ů����
 * @author Administrator
 *
 */
public interface Girl {

	public void drawWomen();
}
