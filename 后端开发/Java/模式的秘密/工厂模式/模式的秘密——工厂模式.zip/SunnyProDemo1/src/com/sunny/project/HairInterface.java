package com.sunny.project;
/**
 * ���ͽӿ�
 * @author Administrator
 *
 */
public interface HairInterface {

	/**
	 * ��ͼ
	 */
	public void draw();
}
