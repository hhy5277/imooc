package com.sunny.project;
/**
 * �зַ���
 * @author Administrator
 *
 */
public class InHair implements HairInterface {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("-----------------�зַ���-------------------");
	
	}

}
