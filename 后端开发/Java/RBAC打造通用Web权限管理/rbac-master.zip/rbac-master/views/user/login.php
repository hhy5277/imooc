<div>
	<p style="color: red;">请登录，本实例没有登录页面，请使用伪登录，地址：http://<?=$host;?>/user/vlogin?uid=xxx(将xx换成user表中的id值)</p>
    <p>如果你user表中已有超级管理员信息，直接访问<a href="http://<?=$host;?>/user/vlogin?uid=1">http://<?=$host;?>/user/vlogin?uid=1</a>进行登录</p>
</div>