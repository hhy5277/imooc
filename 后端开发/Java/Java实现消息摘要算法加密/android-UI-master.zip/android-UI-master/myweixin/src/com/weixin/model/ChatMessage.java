package com.weixin.model;

public class ChatMessage {
	public String sendTime;
	public String name;
	public String message;
	/**
	 * 是否为别人发送的消息
	 */
	public boolean isFromMessage;
}
