@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.wstest", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package wstest.server;
