package org.jbpm.casemgmt.role;

public interface Role {
    
    String getName();
    
    Integer getCardinality();

}
