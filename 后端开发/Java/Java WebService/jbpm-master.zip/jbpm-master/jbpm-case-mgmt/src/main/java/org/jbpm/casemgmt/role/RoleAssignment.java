package org.jbpm.casemgmt.role;

public interface RoleAssignment {
    
    String getUserId();

}
