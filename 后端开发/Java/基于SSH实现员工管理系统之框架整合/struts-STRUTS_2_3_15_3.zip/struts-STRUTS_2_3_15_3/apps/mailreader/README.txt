README.txt - mailreader 

The MailReader demonstrates a localized application with a master/child 
CRUD workflow. 

This rendition also demonstrates using wildcards to "normalize" an 
application. 

See the Sandbox for other MailReader examples using other architectures. 

* http://svn.apache.org/viewvc/struts/sandbox/trunk/struts2/apps/

For more about the MailReader applicaton genneraly, visit Struts University.

* http://www.StrutsUniversity.org/


----------------------------------------------------------------------------