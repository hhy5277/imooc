README.txt - portlet

This is a simple example of using the portlet API with Struts applications. 

For more on getting started with Struts, see 

* http://cwiki.apache.org/WW/home.html

WARNING - Additional configuration required for deployment

Due to difference in portlet container implementations, the portlet
WAR is not ready-to-run. Extract the portlet WAR, and then copy the
contents of apps/portlet/src/main/etc/<your_portal_server>/ into the
WAR's WEB-INF directory.


----------------------------------------------------------------------------