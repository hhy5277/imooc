README.txt - blank

This is an "empty" application that you can deploy as the basis of your own 
application. 

For more on getting started with Struts, see 

* http://cwiki.apache.org/WW/home.html

----------------------------------------------------------------------------