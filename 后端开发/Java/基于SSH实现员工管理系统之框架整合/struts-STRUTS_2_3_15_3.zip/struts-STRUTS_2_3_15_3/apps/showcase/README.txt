README.txt - showcase

Showcase is a collection of examples with code that you might be adopt and 
adapt in your own applications. 

For more on getting started with Struts, see 

* http://cwiki.apache.org/WW/home.html

----------------------------------------------------------------------------