README.txt - JBoss Blank

This is an "empty" application that you can deploy as the basis of your own 
application. This specially dedicated to JBoss server as it includes the Javassist library.

For more on getting started with Struts, see 

* http://cwiki.apache.org/WW/home.html

----------------------------------------------------------------------------