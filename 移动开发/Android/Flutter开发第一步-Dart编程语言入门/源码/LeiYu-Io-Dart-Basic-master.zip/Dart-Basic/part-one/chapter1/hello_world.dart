/**
 * @Author: 雷◕‿◕宇
 * @Description:
 * @Date: 2018/7/8
 */
//Main程序入口
void main(){
  //控制台打印
  print("Hello World!");
}
