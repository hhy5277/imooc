/**
 * @Author: 雷◕‿◕宇
 * @Description:
 * @Date: 2018/7/8
 */
void main(){
  bool isTrue = true;
  bool isFalse = false;

  print("Hello".isEmpty);
}
