/**
 * @Author: 雷◕‿◕宇
 * @Description:
 * @Date: 2018/7/9
 */
void main(){
  var a;
  a = 10;
  a = "Dart";

  dynamic b = 20;
  b = "JavaScript";

  var list = new List<dynamic>();
  list.add(1);
  list.add("hello");
  list.add(true);
  print(list);
}
