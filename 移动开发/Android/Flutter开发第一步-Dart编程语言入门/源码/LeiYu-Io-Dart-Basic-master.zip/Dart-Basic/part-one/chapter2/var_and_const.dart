/**
 * @Author: 雷◕‿◕宇
 * @Description:
 * @Date: 2018/7/8
 */
void main(){
  var a;
  print(a);

  a = 10;
  print(a);

  a = 'Hello Dart';
  print(a);

  var b = 20;
  print(b);

  final c = 30;
//  c = 50;

  const d = 20;
//  d = 50;

}
