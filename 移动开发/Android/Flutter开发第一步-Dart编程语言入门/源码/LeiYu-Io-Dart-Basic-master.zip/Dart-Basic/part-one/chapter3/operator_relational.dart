/**
 * @Author: 雷◕‿◕宇
 * @Description:
 * @Date: 2018/7/14
 */
void main(){
  int a = 5;
  int b = 3;

  print(a == b);
  print(a !=b );
  print(a > b);
  print(a < b);
  print(a >= b);
  print(a <= b);

  String strA = "123";
  String strB = "123";
  print(strA == strB);
}
