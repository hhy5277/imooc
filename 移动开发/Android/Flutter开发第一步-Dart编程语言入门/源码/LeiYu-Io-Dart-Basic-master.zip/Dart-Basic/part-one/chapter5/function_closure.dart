/**
 * @Author: 雷◕‿◕宇
 * @Description:
 * @Date: 2018/7/15
 */
void main(){
  var func = a();
  func();
  func();
  func();
  func();

}

a(){
  int count = 0;

//  printCount(){
//    print(count++);
//  }

  return (){
    print(count++);
  };
}
