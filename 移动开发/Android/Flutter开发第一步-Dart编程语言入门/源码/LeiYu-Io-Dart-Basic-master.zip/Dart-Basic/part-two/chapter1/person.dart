/**
 * @Author: 雷◕‿◕宇
 * @Description:
 * @Date: 2018/10/27
 */
class Person {
  String name;
  int age;
  final String address = "";

  void work(){
    print("Name is $name,Age is $age,He is working...");
  }
}
