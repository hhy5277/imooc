[haoqicat.com](http://haoqicat.com) Source code here

`onestep` is codename.

### Install

- <https://github.com/happypeter/onestep/wiki/Deploy>
