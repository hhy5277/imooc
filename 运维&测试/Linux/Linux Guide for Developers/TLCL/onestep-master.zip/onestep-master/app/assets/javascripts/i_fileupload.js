//= require jquery-ui/widget
//= require jquery-fileupload/basic
//= require jquery-fileupload/vendor/tmpl
