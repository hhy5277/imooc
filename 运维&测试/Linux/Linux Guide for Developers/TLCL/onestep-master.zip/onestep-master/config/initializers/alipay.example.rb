#Alipay.sign_type = 'MD5' # Available values: MD5, RSA. Default is MD5
#Alipay.debug_mode = true # Enable parameter check. Default is true.

Alipay.pid = 'YOUR_PID'
Alipay.key = 'YOUR_KEY'
