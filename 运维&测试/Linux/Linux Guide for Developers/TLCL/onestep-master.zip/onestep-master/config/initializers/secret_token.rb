# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Onestep::Application.config.secret_token = '798fb3270b4dd1da232ad5e774c4a2188cec31f850bfc8b64ae8a38dbef2ad16fb64cd9bd24c8dab30534401d08af6a454233faec3efa87b1c57dd3279c013a0'
