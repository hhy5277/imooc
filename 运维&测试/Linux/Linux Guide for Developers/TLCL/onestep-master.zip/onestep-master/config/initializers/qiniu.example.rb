require 'qiniu'
::Qiniu.establish_connection! :access_key => "your access key",
                              :secret_key => "your secret key"
