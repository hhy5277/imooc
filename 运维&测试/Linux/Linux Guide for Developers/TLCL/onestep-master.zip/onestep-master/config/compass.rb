# Require any additional compass plugins here.
project_type = :rails
