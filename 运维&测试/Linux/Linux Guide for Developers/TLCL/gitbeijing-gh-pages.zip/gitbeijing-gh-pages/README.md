这个项目仓库是用 [Jekyll](http://jekyllrb.com/) 写的书稿，最终的书在 [Gitbeijing.com](http://gitbeijing.com) 。
