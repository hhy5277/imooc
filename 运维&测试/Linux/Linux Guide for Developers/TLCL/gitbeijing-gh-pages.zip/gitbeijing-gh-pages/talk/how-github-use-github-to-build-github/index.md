---
layout: book
title: How github use github to build github
---

Zach Holman 的演讲：[腾讯视频](http://v.qq.com/page/y/d/h/y0150mikydh.html)

我的中文翻译过来的版本：[coming soon...](xx)