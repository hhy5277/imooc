[Github Flow](https://guides.github.com/introduction/flow/) into Chinese.
