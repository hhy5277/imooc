---
title: Goodbye
---

https://www.youtube.com/user/GitHubGuides
https://help.github.com/articles/good-resources-for-learning-git-and-github/

http://gitimmersion.com/lab_01.html
http://gitreal.codeschool.com/levels/1
