Swiftype.configure do |config|
  config.api_key = ENV['SWIFTYPE_API_KEY']
end
