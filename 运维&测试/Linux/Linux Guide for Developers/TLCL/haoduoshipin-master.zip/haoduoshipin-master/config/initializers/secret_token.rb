# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Happycasts::Application.config.secret_token = 'ae32a91e9a29e65f4510a96ea09535b4c12698369eb0032a32d5db78deb17414bc23e620bbdad5e6a078d94a8c13aef586841c6c145d0f478106b6b234c535d2'
Happycasts::Application.config.secret_key_base = 'ssae32a91e9a29e65f4510a96ea09535b4c12698369eb0032a32d5db78deb17414bc23e620bbdad5e6a078d94a8c13aef586841c6c145d0f478106b6b234c535d2'
