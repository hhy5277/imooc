
本项目是 The Linux Command Line 一书的中文翻译，为方便大家阅读，源码中有两个版本，中文版，和双语版。有帮忙翻译的朋友修改双语版就好了，中文版是自动生成的。谢谢！

阅读，请移步到 <http://billie66.github.io/TLCL/>
