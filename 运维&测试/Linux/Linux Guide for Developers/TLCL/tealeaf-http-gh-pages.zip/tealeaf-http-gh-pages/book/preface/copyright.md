---
layout: book
title: 版权声明
---

# 版权声明

Copyright © 2014 Tealeaf Academy 保留所有权利

若未经 Tealeaf Academy 事先允许，本书内容不得用任何方式，电子、机械、影印、录音等抄袭、翻印、
储存在检索系统上或传输。
