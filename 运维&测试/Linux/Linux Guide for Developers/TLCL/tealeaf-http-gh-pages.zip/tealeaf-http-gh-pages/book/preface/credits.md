---
layout: book
title: 致谢
---

# 致谢

这本书是由 Tealeaf Academy 团队共同协作完成的。

### 贡献者

若没有 Aarti Parikh 和 Albert Agram 两位朋友的辛勤付出，这本书是不可能问世的。

特别感谢那些花费大量心血来打磨本书终稿的技术审阅者以及其他贡献者。

最后，感谢为本书提供无数建议和校正的学生们。是你们成就了这本书!

### 奉献爱心

亲爱的读者，若您在阅读本书的时候，发现任何错别字、错误或者对本书的内容安排有任何建议的话，都请告诉我们。

我们的邮箱 <a href="mailto:books@gotealeaf.com">books@gotealeaf.com</a>。
