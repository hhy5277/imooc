amplify.request({
    resourceId: "statusExample1"
}).done(function (data, status) {
}).fail(function (data, status) {
}).always(function (data, status) { });
