

var exports: any;
var assert: any;
var MockRenderer: any = null;
var JavaScriptMode: any = null;

/// <reference path="tests/ace-default-tests.ts" />
/// <reference path="tests/ace-background_tokenizer-tests.ts" />
/// <reference path="tests/ace-document-tests.ts" />
/// <reference path="tests/ace-edit_session-tests.ts" />
/// <reference path="tests/ace-editor1-tests.ts" />
/// <reference path="tests/ace-editor_highlight_selected_word-tests.ts" />
/// <reference path="tests/ace-editor_navigation-tests.ts" />
/// <reference path="tests/ace-editor_text_edit-tests.ts" />
/// <reference path="tests/ace-multi_select-tests.ts" />
/// <reference path="tests/ace-placeholder-tests.ts" />
/// <reference path="tests/ace-range_list-tests.ts" />
/// <reference path="tests/ace-range-tests.ts" />
/// <reference path="tests/ace-search-tests.ts" />
/// <reference path="tests/ace-selection-tests.ts" />
/// <reference path="tests/ace-token_iterator-tests.ts" />
/// <reference path="tests/ace-virtual_renderer-tests.ts" />



