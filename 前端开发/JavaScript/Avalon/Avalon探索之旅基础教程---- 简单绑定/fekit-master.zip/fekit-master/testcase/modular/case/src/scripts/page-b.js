var helper = require("core.dom.helper")

console.info( helper )