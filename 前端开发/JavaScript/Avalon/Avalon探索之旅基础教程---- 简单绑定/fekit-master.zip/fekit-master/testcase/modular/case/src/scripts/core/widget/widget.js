require('core.dom.helper')
// this is core.widget.widget