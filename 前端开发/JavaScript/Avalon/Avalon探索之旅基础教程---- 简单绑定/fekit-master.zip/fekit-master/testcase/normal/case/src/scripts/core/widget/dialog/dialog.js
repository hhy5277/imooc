require('core.dom.helper')
require('../widget')
require('./dialog.mustache')
// this is core.widget.dialog.dialog.js