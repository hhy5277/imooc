//this is component A
//this is a.js
//this is b.js
//this is c.js




// this is page-a.js