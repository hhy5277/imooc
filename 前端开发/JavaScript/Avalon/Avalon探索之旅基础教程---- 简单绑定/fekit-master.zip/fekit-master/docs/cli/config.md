config
=====================

### Usage

    fekit config 查看fekit全局配置项
    
    fekit config -s,--set <key> <value> 增加一个配置项
    
    fekit config -d,--delete <key> 删除一个配置项
    
    fekit config -h,--help 查看帮助
    
### description 
    
   配置fekit的环境变量，写入`.fekitrc`文件，文件要求json格式。
    
   可能需要在指定（用户根目录下）新建`.fekitrc`文件
