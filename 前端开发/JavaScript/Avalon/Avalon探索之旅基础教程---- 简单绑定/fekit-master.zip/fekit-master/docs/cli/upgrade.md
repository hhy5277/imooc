upgrade
============

###usage

    [sudo] fekit upgrade    更新自身及更新已安装扩展
     
###description

是全局安装，所以*nix用户需要使用`sudo`命令

而且似乎mac上未更新成功会回滚失败，需要重装一遍fekit？