pack
=============

###usage
    fekit pack  合并项目文件
    
    
###description

把`fekit.config`文件中`export`内的文件合并打包到`dev`目录中
    