plugin
===========

###usage

    fekit plugin -i <name>  npm install 的一个包装,实际安装插件名为‘fekit-extension-name’  
    
    fekit plugin -u <name>  等效于 npm uninstall fekit-extension-name
    
###description

   此方法为npm install/uninstall 的一个包装，安装时需确保 fekit-extension-name 在npm中存在