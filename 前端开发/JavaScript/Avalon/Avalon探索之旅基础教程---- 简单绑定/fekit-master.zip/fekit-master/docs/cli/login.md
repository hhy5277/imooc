login
=======

###usage

    fekit login
    
###description

需要先去fekit源进行注册，然后按提示输入用户名和密码

注册地址: http://l-registry.fe.dev.cn6.qunar.com/signup


