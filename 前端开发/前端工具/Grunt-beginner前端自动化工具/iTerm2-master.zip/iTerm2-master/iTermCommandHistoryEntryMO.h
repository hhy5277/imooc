//
//  iTermCommandHistoryEntryMO.h
//  iTerm2
//
//  Created by George Nachman on 10/12/15.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class iTermCommandHistoryCommandUseMO, iTermHostRecordMO;

NS_ASSUME_NONNULL_BEGIN

@interface iTermCommandHistoryEntryMO : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "iTermCommandHistoryEntryMO+CoreDataProperties.h"
