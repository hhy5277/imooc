//
//  ProfilesTerminalPreferencesViewController.h
//  iTerm
//
//  Created by George Nachman on 4/17/14.
//
//

#import "iTermProfilePreferencesBaseViewController.h"

@interface ProfilesTerminalPreferencesViewController : iTermProfilePreferencesBaseViewController

@end
