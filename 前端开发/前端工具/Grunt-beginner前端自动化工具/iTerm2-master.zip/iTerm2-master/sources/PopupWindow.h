//
//  PopupWindow.h
//  iTerm
//
//  Created by George Nachman on 12/27/13.
//
//

#import <Cocoa/Cocoa.h>

@interface PopupWindow : NSWindow

- (void)shutdown;

@end
