//
//  PasswordTrigger.h
//  iTerm
//
//  Created by George Nachman on 5/15/14.
//
//

#import "Trigger.h"

@interface PasswordTrigger : Trigger

+ (NSString *)title;

@end
