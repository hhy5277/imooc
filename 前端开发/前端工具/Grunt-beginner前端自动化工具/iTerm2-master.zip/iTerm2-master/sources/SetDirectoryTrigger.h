//
//  SetDirectoryTrigger.h
//  iTerm2
//
//  Created by George Nachman on 11/9/15.
//
//

#import "Trigger.h"

@interface SetDirectoryTrigger : Trigger

+ (NSString *)title;

@end
