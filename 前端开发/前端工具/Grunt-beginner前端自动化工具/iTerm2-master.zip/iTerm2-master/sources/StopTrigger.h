//
//  StopTrigger.h
//  iTerm2
//
//  Created by George Nachman on 5/15/15.
//
//

#import "Trigger.h"

@interface StopTrigger : Trigger

@end
