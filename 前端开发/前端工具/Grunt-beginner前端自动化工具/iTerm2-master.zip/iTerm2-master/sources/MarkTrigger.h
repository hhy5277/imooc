//
//  MarkTrigger.h
//  iTerm
//
//  Created by George Nachman on 4/22/14.
//
//

#import "Trigger.h"

@interface MarkTrigger : Trigger

+ (NSString *)title;

@end
