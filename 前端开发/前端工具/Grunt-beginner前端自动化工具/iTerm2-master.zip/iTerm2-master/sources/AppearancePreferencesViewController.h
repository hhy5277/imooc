//
//  AppearancePreferencesViewController.h
//  iTerm
//
//  Created by George Nachman on 4/6/14.
//
//

#import "iTermPreferencesBaseViewController.h"

@interface AppearancePreferencesViewController : iTermPreferencesBaseViewController

@end
