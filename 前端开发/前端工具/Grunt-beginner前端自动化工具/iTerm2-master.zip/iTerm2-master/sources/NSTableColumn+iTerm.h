//
//  NSTableView_iTerm.h
//  iTerm2
//
//  Created by George Nachman on 12/2/14.
//
//

#import <Cocoa/Cocoa.h>

@interface NSTableColumn (iTerm)

- (CGFloat)suggestedRowHeight;

@end
