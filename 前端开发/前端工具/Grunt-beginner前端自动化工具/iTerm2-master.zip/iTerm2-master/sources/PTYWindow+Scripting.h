#import "PTYWindow.h"

// This class has methods exposed in the .sdef file.
@interface PTYWindow (Scripting)

@end

