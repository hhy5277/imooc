//
//  AppleScriptTest.h
//  iTerm
//
//  Created by Alberto Miguel Pose on 28/12/13.
//
//

#import <Foundation/Foundation.h>

@interface AppleScriptTest : NSObject

@end
