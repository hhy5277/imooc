//
//  RoundedRectView.h
//  iTerm
//
//  Created by George Nachman on 3/13/13.
//
//

#import <Cocoa/Cocoa.h>

@interface RoundedRectView : NSView {
    NSColor *color_;
    NSColor *borderColor_;
}

@end
