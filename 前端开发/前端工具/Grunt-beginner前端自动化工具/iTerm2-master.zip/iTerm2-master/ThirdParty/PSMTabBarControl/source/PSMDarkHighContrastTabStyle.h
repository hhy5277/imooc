//
//  PSMDarkHighContrastTabStyle.h
//  iTerm2
//
//  Created by George Nachman on 3/25/16.
//
//

#import <Foundation/Foundation.h>
#import "PSMTabStyle.h"
#import "PSMDarkTabStyle.h"

@interface PSMDarkHighContrastTabStyle : PSMDarkTabStyle

@end
