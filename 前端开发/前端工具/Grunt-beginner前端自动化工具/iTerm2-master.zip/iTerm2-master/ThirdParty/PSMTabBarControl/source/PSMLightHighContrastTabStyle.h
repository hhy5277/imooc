//
//  PSMLightHighContrastTabStyle.h
//  iTerm2
//
//  Created by George Nachman on 3/25/16.
//
//

#import <Foundation/Foundation.h>
#import "PSMTabStyle.h"
#import "PSMYosemiteTabStyle.h"

@interface PSMLightHighContrastTabStyle : PSMYosemiteTabStyle<PSMTabStyle>

@end
