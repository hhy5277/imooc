#!/usr/bin/env bash

bundle config build.nokogiri --use-system-libraries
