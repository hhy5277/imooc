//
//  iTermCommandHistoryCommandUseMO.h
//  iTerm2
//
//  Created by George Nachman on 10/12/15.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class iTermCommandHistoryEntryMO;

NS_ASSUME_NONNULL_BEGIN

@interface iTermCommandHistoryCommandUseMO : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "iTermCommandHistoryCommandUseMO+CoreDataProperties.h"
