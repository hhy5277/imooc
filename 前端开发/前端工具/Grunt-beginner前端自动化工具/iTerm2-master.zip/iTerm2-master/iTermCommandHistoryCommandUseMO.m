//
//  iTermCommandHistoryCommandUseMO.m
//  iTerm2
//
//  Created by George Nachman on 10/12/15.
//
//

#import "iTermCommandHistoryCommandUseMO.h"
#import "iTermCommandHistoryEntryMO.h"

@implementation iTermCommandHistoryCommandUseMO

// Insert code here to add functionality to your managed object subclass

@end
