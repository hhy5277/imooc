//
//  iTermHostRecordMO.m
//  iTerm2
//
//  Created by George Nachman on 10/12/15.
//
//

#import "iTermHostRecordMO.h"
#import "iTermCommandHistoryEntryMO.h"
#import "iTermRecentDirectoryMO.h"

@implementation iTermHostRecordMO

// Insert code here to add functionality to your managed object subclass

@end
