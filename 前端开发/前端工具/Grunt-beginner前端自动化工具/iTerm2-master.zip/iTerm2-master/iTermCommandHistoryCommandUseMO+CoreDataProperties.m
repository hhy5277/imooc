//
//  iTermCommandHistoryCommandUseMO+CoreDataProperties.m
//  iTerm2
//
//  Created by George Nachman on 10/12/15.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "iTermCommandHistoryCommandUseMO+CoreDataProperties.h"

@implementation iTermCommandHistoryCommandUseMO (CoreDataProperties)

@dynamic code;
@dynamic command;
@dynamic directory;
@dynamic markGuid;
@dynamic time;
@dynamic entry;

@end
