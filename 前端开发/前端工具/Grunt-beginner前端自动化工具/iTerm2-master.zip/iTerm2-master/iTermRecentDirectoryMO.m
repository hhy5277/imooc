//
//  iTermRecentDirectoryMO.m
//  iTerm2
//
//  Created by George Nachman on 10/12/15.
//
//

#import "iTermRecentDirectoryMO.h"
#import "iTermHostRecordMO.h"

@implementation iTermRecentDirectoryMO

// Insert code here to add functionality to your managed object subclass

@end
