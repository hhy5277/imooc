//
//  iTermRecentDirectoryMO+CoreDataProperties.m
//  iTerm2
//
//  Created by George Nachman on 10/12/15.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "iTermRecentDirectoryMO+CoreDataProperties.h"

@implementation iTermRecentDirectoryMO (CoreDataProperties)

@dynamic path;
@dynamic useCount;
@dynamic lastUse;
@dynamic starred;
@dynamic remoteHost;

@end
