#import "CPKFlippedView.h"

@implementation CPKFlippedView

- (BOOL)isFlipped {
    return YES;
}

@end
