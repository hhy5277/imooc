#import <Cocoa/Cocoa.h>

/** A view that returns YES for -isFlipped. */
@interface CPKFlippedView : NSView

@end
