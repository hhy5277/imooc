#import <Cocoa/Cocoa.h>
#import "CPKColorWell.h"
#import "CPKMainViewController.h"
#import "CPKPopover.h"

//! Project version number for ColorPicker.
FOUNDATION_EXPORT double ColorPickerVersionNumber;

//! Project version string for ColorPicker.
FOUNDATION_EXPORT const unsigned char ColorPickerVersionString[];


