//
//  BPStyle.h
//  
//
//  Created by Marek Hrusovsky on 25/08/15.
//
//

#import <Foundation/Foundation.h>

@interface BPStyle : NSObject

@end
