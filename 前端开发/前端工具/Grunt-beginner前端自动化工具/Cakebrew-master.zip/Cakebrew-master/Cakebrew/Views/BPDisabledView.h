//
//  BPDisabledView.h
//  
//
//  Created by Marek Hrusovsky on 26/08/15.
//
//

#import <Cocoa/Cocoa.h>

@interface BPDisabledView : NSView

@end
