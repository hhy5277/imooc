//
//  BPDoctorViewController.h
//  Cakebrew
//
//  Created by Marek Hrusovsky on 24/08/14.
//  Copyright (c) 2014 Bruno Philipe. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface BPDoctorViewController : NSViewController

- (IBAction)runStopDoctor:(id)sender;

@end
