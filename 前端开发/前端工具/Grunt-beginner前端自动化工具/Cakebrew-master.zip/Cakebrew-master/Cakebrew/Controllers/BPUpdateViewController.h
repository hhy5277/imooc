//
//  BPUpdateViewController.h
//  Cakebrew
//
//  Created by Marek Hrusovsky on 24/08/14.
//  Copyright (c) 2014 Bruno Philipe. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface BPUpdateViewController : NSViewController

- (IBAction)runStopUpdate:(id)sender;

@end
