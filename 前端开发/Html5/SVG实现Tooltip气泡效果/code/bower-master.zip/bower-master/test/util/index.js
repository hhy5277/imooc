describe('util', function () {
    require('./removeIgnores');
    require('./analytics');
});
