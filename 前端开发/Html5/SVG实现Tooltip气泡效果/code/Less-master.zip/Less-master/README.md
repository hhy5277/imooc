Less
====

A simple minimal WordPress theme built with only what is needed to survive

![Less screenshot](https://github.com/alliswell/Less/blob/master/dev/less-screenshot.png?raw=true)

Less is a super minimal theme, both front end and back end. adding no bloat whatesover. It only uses the minimum requirements that WordPress has, a stylesheet, screenshot and the index page. 

I did use LESS (http://lesscss.org/) for all the styles, if you know how to use it you will be able to change a few viarables to customize the site with no problem!

We also used JSLint'ed JavaScript to make sure it's the squeky-cleanest JavaScript your brain can imagine. It's also minified using [JSMin](http://www.crockford.com/javascript/jsmin.html) so it's small, but if you like reading minified JavaScript, then this is just for you.

Finally, the theme has been localized so if you dislike English or want to read these posts in another language, you can translate it!

![Code Screenshot](https://github.com/alliswell/Less/blob/master/dev/less-screen-code.png?raw=true)