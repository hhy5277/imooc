/**
 * @file node-ral
 * @author hefangshi@baidu.com
 * http://fis.baidu.com/
 * 2014/9/11
 */

'use strict';

module.exports = {
    idc: 'tc'
};
