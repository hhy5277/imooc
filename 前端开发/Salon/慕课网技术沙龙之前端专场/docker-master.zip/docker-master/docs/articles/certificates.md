<!--[metadata]>
+++
title = "Using certificates for repository client verification"
description = "How to set up and use certificates with a registry to verify access"
keywords = ["Usage, registry, repository, client, root, certificate, docker, apache, ssl, tls, documentation, examples, articles,  tutorials"]
[menu.main]
parent = "mn_docker_hub"
weight = 7
+++
<![end-metadata]-->

# Using certificates for repository client verification

The original content was deprecated. For information about configuring
certificates, see  [deploying a registry
server](http://docs.docker.com/registry/deploying). To reach an older version
of this content, refer to an older version of the documentation. 
