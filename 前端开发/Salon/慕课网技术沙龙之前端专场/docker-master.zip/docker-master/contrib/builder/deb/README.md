# `dockercore/builder-deb`

This image's tags contain the dependencies for building Docker `.deb`s for each of the Debian-based platforms Docker targets.

To add new tags, see [`contrib/builder/deb` in https://github.com/docker/docker](https://github.com/docker/docker/tree/master/contrib/builder/deb), specifically the `generate.sh` script, whose usage is described in a comment at the top of the file.
