package main

import (
	_ "github.com/docker/docker/autogen/winresources"
)
