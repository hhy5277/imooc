// +build daemon

package main

// notifySystem sends a message to the host when the server is ready to be used
func notifySystem() {
}
