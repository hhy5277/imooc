// +build !linux,!darwin,!freebsd,!windows

package daemon

func setupDumpStackTrap() {
	return
}
