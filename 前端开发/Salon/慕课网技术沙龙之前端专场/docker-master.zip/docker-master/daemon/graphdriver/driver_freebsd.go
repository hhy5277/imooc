package graphdriver

var (
	// Slice of drivers that should be used in an order
	priority = []string{
		"zfs",
	}
)
