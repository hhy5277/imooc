// Good
if (condition) {
    doSomething();
}

if (condition)
    doSomething();
    doSomethingElse();
