// Bad
var person;
console.log(person === undefined);    //true

// Good
console.log(typeof person);    // "undefined"