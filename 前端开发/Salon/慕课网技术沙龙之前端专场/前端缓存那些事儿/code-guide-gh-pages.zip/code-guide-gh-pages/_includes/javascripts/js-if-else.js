if (condition) {
    doSomething();
} else {
    doSomethingElse();
}
