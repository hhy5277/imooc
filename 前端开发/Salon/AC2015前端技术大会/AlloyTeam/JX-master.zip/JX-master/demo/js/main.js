

;(function(){
    var navTree = [
        {
            id: 'Core',
            name: 'Core',
            url: '',
            children: [
                {
                    id: 'Loader'
                }
            ]

        },
    ];

    var jxDemo = {
        init: function(){

        }
    };

    jxDemo.init();
});
