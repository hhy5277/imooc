//AlloyRenderingEngine
var ARE={};

ARE.DefaultCursor = "default";

ARE.Cache = {};