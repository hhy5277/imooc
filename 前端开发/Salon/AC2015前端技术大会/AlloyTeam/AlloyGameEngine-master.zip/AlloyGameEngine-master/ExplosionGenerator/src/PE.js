﻿//Particle Editor
var PE = {};