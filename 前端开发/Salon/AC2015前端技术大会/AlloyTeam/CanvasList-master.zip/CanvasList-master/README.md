CanvasList
===============

CanvasList.js is a lib to draw list in canvas element,which require zepto.

