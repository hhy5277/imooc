模拟原生效果实践
====

1. [使用border-image实现类似物理1像素](./border-1px.md)
2. [ios] [Web App Icon与启动图片实践(1)](https://gist.github.com/tfausak/2222823)
2. [ios] [Web App Icon与启动图片实践(2)](http://mobile.51cto.com/web-395063.htm)
