## 代码结构规范

使用 [Mobile Boilerplate](http://html5boilerplate.com/mobile/)