module.exports = {
		log : {
			strategy : 'colorConsole',
			setting : {
				level : 'log'
			}
		},
		log_prd : {
			strategy : 'console',
			setting : {
				level : 'warn'
			}
		}
}