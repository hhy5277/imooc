module.exports = {
  data: true,
  root: './',
  template: './index.vm',
  context: './context.js',
  output: './new-context.js'
}
