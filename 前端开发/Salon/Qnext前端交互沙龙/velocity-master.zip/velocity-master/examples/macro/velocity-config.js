module.exports = {
  macro: './macro.vm',
  template: './index.vm',
  context: './context.js'
}
