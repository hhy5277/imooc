module.exports = {
  name: 'fool2fish',
  github: 'https://github.com/fool2fish',
  favorites: ['food', 'travel', 'comic', '...']
}
