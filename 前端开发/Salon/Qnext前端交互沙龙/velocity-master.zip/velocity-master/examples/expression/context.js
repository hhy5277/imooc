module.exports = {
  name: 'fool2fish',
  start: 1
}
