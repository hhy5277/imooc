module.exports = {
  root: ['./root1', './root2', './root3'],
  template: './root1/index.vm',
  context: './context.js'
}
