module.exports = {
  root: './',
  template: './index.vm',
  context: './context.js'
}
