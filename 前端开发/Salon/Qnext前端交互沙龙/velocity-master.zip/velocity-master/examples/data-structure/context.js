module.exports = {
  id: '000000001',
  user: {
    name: 'fool2fish',
    email: 'fool2fish@gmail.com',
    undefinedIsPreserved: undefined
  },
  employeeList: [
    { name: 'Bob' },
    { name: 'Sue'}
  ]
}