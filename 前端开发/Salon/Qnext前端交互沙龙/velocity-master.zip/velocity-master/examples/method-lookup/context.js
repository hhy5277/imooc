module.exports = {
  string: 'abcde',
  list: [1, 2, 3],
  map: {
    'a': 'value-a',
    'b': 'value-b',
    'enough': true
  }
}
