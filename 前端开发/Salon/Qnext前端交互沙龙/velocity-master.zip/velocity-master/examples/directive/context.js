module.exports = {
  name: 'fool2fish',
  github: 'https://github.com/fool2fish',
  favorites: ['food', 'travel', 'comic', '...'],
  date: {
    year: 2014,
    month: 5,
    day: 20
  },
  method: {
    foo: function(){return 'method.foo() is called!'},
    bar: function(){}
  },
  dataForEval: '@@$name@@'
}
