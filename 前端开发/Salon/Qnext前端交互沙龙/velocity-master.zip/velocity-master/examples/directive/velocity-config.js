module.exports = {
  template: './index.vm',
  context: './context.js'
}
