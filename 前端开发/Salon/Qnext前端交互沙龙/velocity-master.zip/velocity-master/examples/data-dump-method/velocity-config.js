module.exports = {
  template: './index.vm',
  output:'./data-dump.vm',
  dump:true
}
