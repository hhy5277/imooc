# _shared folder

Contains assets that are shared by examples, tutorials, and tests to prevent duplication, and simplify referencing.