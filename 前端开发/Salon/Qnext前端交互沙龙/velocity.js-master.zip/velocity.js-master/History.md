## 0.6.2

- feat: merge [47](https://github.com/shepherdwind/velocity.js/pull/47)

## 0.6.1

- feat: merge [46](https://github.com/shepherdwind/velocity.js/pull/46)

## [0.6](https://github.com/shepherdwind/velocity.js/milestones/0.6)

- change: remove Velocity.Parser, change to Velocity.parse [#43](https://github.com/shepherdwind/velocity.js/issues/43)
- feat: add custom blocks support [#44](https://github.com/shepherdwind/velocity.js/issues/44)

## 0.4

### 0.4.11 / 2015-01-24

- feat: self define macro context keep to origin object

### 0.4.10 / 2015-01-08

- fix: allow optional space after colon in map passed as parameter to macro
      ([#38](https://github.com/shepherdwind/velocity.js/pull/38) by @jamescookie)

### 0.4.9 / 2014-12-29

- feature: support friendly error stack #35
- chore: improve coverage

### 0.4.8 / 2014-12-20

- fix issue #32
- Remove useless code: Helper
- merge pull request #34

### 0.4.7 / 2014-12-18

- fix issue #32
