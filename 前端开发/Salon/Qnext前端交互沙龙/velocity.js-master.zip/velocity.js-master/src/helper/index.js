var Helper = {};
var utils = require('../utils');
require('./text')(Helper, utils);
module.exports = Helper;
