var x = "\n here is some \n new lined text";
