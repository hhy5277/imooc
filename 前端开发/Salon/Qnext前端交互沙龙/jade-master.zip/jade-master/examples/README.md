The examples in this directory can be run simply by something like. 

    node attributes.js

You can also open `browser.html` in a browser.
