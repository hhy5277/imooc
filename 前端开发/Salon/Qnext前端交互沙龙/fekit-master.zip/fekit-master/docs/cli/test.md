test
============

###usage

    fekit test
    
###descrption

用到了`mocha`框架，需要有`test.js`文件或`test`文件夹