uninstall
==============

###usage
    fekit uninstall <pkgName>  删除指定的包
    
    
###description

需要在fekit 项目目录中执行
