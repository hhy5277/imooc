logout
=======

###usage

    fekit logout
    