unpublish
=============

###usage

    fekit unpublish <name>@<version>  version需要写成`0.0.0`形式
    
###description
需要先登录再操作