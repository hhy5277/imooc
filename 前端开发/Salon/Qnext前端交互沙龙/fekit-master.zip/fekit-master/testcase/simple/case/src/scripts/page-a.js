require('./componentA');
require('./a.js');
require('b');
require('../scripts/c')
// this is page-a.js