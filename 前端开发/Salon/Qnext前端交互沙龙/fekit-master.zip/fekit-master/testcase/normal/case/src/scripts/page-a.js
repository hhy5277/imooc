require('core.dom.helper')
require('core.widget.dialog.dialog')
require('./page-a-part1.coffee')
// this is page-b.js
