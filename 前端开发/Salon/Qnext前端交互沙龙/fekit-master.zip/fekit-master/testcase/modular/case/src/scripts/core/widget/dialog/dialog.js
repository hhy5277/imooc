require('core.dom.helper')
require('../widget')
require('./dialog.mustache')
// this is core.widget.dialog.dialog.js

exports.version = "1.1.0"