// this is core.dom.helper.js

exports.version = "1.0"