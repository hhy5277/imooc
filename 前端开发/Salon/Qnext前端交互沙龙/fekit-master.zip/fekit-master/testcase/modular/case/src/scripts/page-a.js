require('core/template/hogan-2.0.0-fixed')

var helper = require('core.dom.helper');
var dialog = require('core.widget.dialog.dialog');
var part1 = require('./page-a-part1.coffee')
// this is page-a.js

alert( dialog.version )