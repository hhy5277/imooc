package pdcelluar;

//import com.borland.jbcl.layout.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Title:�������������̬��ͽ��������ģ�����
 * Description:���ฺ������ĵ���
 * Copyright:    Copyright (c) 2003
 * Company:http://agents.yeah.net
 * @author��jake
 * @version 1.0
 */

final public class CelluarControl extends Frame {
  pdcelluar localpd;//������ı��ؿ������Ա���Ը����������е�ֵ
  Button btnConfirm = new Button();
  Button btnCancel = new Button();
  Button btnDefault = new Button();
  Label label1 = new Label();
  TextField txtDensity = new TextField();
  Label label2 = new Label();
  TextField txtCoop = new TextField();
  Label label3 = new Label();
  Label label4 = new Label();
  Label label5 = new Label();
  Label label6 = new Label();
  Label label7 = new Label();
  TextField textField1 = new TextField();
  TextField textField2 = new TextField();
  TextField textField3 = new TextField();
  TextField txtValue = new TextField();
  TextField textField4 = new TextField();
  TextField textField5 = new TextField();
  TextField txtValue1 = new TextField();
  TextField text1 = new TextField();
  Label label8 = new Label();
  TextField txtSize = new TextField();
  Label label9 = new Label();
  TextField txtRefresh = new TextField();
  Choice choice1 = new Choice();
  Label label10 = new Label();
  public CelluarControl(pdcelluar pd) {
    super("��������");
    localpd=pd;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    //��ʼ������
    this.setLayout(null);
    this.setBounds(0,0,300,300);
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    label1.setText("��ҵ���ܱ�����");
    label1.setBounds(new Rectangle(147, 30, 84, 18));
    btnConfirm.setLabel("ȷ��");
    btnConfirm.setBounds(new Rectangle(89, 249, 59, 29));
    btnConfirm.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        btnConfirm_actionPerformed(e);
      }
    });

    btnCancel.setLabel("ȡ��");
    btnCancel.setBounds(new Rectangle(145, 249, 59, 29));
    btnCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        btnCancel_actionPerformed(e);
      }
    });
    btnDefault.setLabel("�ָ�");
    btnDefault.setBounds(new Rectangle(205, 248, 59, 29));
    btnDefault.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        btnDefault_actionPerformed(e);
      }
    });
    label2.setText("�����ߵı�����");
    label2.setBounds(new Rectangle(19, 65, 84, 18));
    label3.setText("���Ĺ�����趨��");
    label3.setBounds(new Rectangle(9, 152, 96, 18));
    label4.setText("����");
    label4.setBounds(new Rectangle(73, 191, 24, 18));
    label5.setText("������");
    label5.setBounds(new Rectangle(222, 160, 36, 18));
    label6.setText("����");
    label6.setBounds(new Rectangle(142, 163, 24, 18));
    label7.setText("������");
    label7.setBounds(new Rectangle(64, 222, 36, 18));
    textField1.setEnabled(false);
    textField1.setText("1");
    textField1.setBounds(new Rectangle(136, 189, 21, 22));
    textField2.setEnabled(false);
    textField2.setText("1");
    textField2.setBounds(new Rectangle(165, 189, 14, 22));
    textField3.setEnabled(false);
    textField3.setText("0");
    textField3.setBounds(new Rectangle(164, 221, 15, 22));
    textField4.setEnabled(false);
    textField4.setText("0");
    textField4.setBounds(new Rectangle(200, 221, 17, 22));
    textField5.setEnabled(false);
    textField5.setText("0");
    textField5.setBounds(new Rectangle(223, 220, 17, 22));
    text1.setEnabled(false);
    text1.setText("0");
    text1.setBounds(new Rectangle(199, 189, 17, 22));
    label8.setText("����ĳߴ磺");
    label8.setBounds(new Rectangle(19, 30, 72, 18));
    txtValue1.addTextListener(new java.awt.event.TextListener() {
      public void textValueChanged(TextEvent e) {
        txtValue1_textValueChanged(e);
      }
    });
    txtValue.addTextListener(new java.awt.event.TextListener() {
      public void textValueChanged(TextEvent e) {
        txtValue_textValueChanged(e);
      }
    });
    txtValue.setBounds(new Rectangle(106, 222, 50, 22));
    txtValue1.setBounds(new Rectangle(221, 188, 53, 22));
    label9.setText("ˢ�¼����");
    label9.setBounds(new Rectangle(24, 123, 80, 15));
    txtRefresh.setBounds(new Rectangle(109, 118, 82, 22));
    choice1.setBounds(new Rectangle(109, 96, 180, 17));
    label10.setText("�ھ����ͣ�");
    label10.setBounds(new Rectangle(22, 95, 61, 17));
    this.add(btnConfirm, null);
    this.add(btnCancel, null);
    this.add(btnDefault, null);
    this.add(label4, null);
    this.add(label7, null);
    this.add(label6, null);
    this.add(textField1, null);
    this.add(textField2, null);
    this.add(textField3, null);
    this.add(text1, null);
    this.add(textField4, null);
    this.add(textField5, null);
    this.add(label5, null);
    this.add(txtValue1, null);
    this.add(label3, null);
    this.add(txtValue, null);
    this.add(label8, null);
    this.add(txtSize, null);
    this.add(label9, null);
    choice1.addItem("���������ĸ��ھӣ���.Ť���ͣ�");
    choice1.addItem("����˷��˸��ھӣ�Ħ���ͣ�");
    //choice1.addItem("����˷�16���ھӣ�GN�ͣ�");
    this.add(label2, null);
    this.add(label10, null);
    this.add(label1, null);
    this.add(txtDensity, null);
    this.add(choice1, null);
    this.add(txtCoop, null);
    this.add(txtRefresh, null);
    reset();//���������ı����е���ֵΪ��ʼֵ
    this.pack();
  }
  public void reset(){
    //���������ı����е���ֵΪ��ʼֵ
    txtSize.setText(Integer.toString(localpd.max));
    txtSize.setBounds(new Rectangle(91, 29, 41, 22));
    txtDensity.setText(Double.toString(localpd.nonempty_p));
    txtDensity.setBounds(new Rectangle(236, 28, 48, 22));
    txtCoop.setText(Double.toString(localpd.coop_u));
    txtCoop.setBounds(new Rectangle(108, 65, 83, 22));
    txtValue.setText(Double.toString(localpd.m_value));
    txtValue1.setText(Double.toString(localpd.m_value));
    txtRefresh.setText(Integer.toString(localpd.refreshSteps));
    choice1.select(localpd.NeiType);
  }

  void btnConfirm_actionPerformed(ActionEvent e) {
      //���ı����еĲ�����ֵ�����������е���Ӧ����
      localpd.max=Integer.parseInt(txtSize.getText());
      if(localpd.max<=0)return;
      localpd.nonempty_p=Double.valueOf(txtDensity.getText()).doubleValue();
      if(localpd.nonempty_p>1||localpd.nonempty_p<=0)return;
      if((int)(localpd.max*localpd.max*localpd.nonempty_p)==0){
          return;
      }
      localpd.refreshSteps=Integer.parseInt(txtRefresh.getText());
      if(localpd.refreshSteps<=0)return;
      localpd.coop_u=Double.valueOf(txtCoop.getText()).doubleValue();
      if(localpd.coop_u>1||localpd.coop_u<0)return;
      localpd.m_value=Double.valueOf(txtValue.getText()).doubleValue();
      if(localpd.m_value<=1)return;
      localpd.NeiType=choice1.getSelectedIndex();
      localpd.reinit();
      localpd.running=true;
      localpd.pausebutton.setLabel("ֹͣ");
      //��ֹ�Ի���
      this.hide();
      this.dispose();
  }

  void btnCancel_actionPerformed(ActionEvent e) {
            //��������������в���ֹ�Լ�
            localpd.running=true;
            localpd.pausebutton.setLabel("ֹͣ");
            this.hide();
            this.dispose();
  }

  void btnDefault_actionPerformed(ActionEvent e) {
      reset();
  }

  void txtValue1_textValueChanged(TextEvent e) {
      //���������ı������ֵһ��
      String s1=txtValue1.getText();
      String s2=txtValue.getText();
      if(!s1.equals(s2))
        txtValue.setText(s1);
  }

  void txtValue_textValueChanged(TextEvent e) {
       //���������ı������ֵһ��
      String s1=txtValue1.getText();
      String s2=txtValue.getText();
      if(!s1.equals(s2))
         txtValue1.setText(s2);
  }

  void this_windowClosing(WindowEvent e) {
      localpd.running=true;
      localpd.pausebutton.setLabel("ֹͣ");
      this.hide();
      this.dispose();
  }
}