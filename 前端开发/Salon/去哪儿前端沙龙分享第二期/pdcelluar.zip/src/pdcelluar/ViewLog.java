package pdcelluar;

import java.awt.*;
import java.awt.event.*;

/**
 * Title:�������������̬��ͽ��������ģ�����
 * Description:����ʷ����
 * Copyright:    Copyright (c) 2003
 * Company:http://agents.yeah.net
 * @author:jake
 * @version 1.0
 */

public class ViewLog extends Frame implements Runnable {
  Panel view = new Panel();
  Thread runner1;//��������߳�
  Graphics gra;//��һ�����view�ϻ�ͼ
  int cycles=100;//ͼ����ʾ�ĺ�������Ŀ
  int cyclemax;//�������ж������ʷ������󳤶�
  int originx=40;//��ͼ����ԭ�������
  int originy=20;
  pdcelluar localpd;//������ı��ؿ���
  Button btnClose = new Button();
  Choice choicelen = new Choice();
  Label label1 = new Label();
  Button btnRefresh = new Button();

  public ViewLog(pdcelluar pd) {
    super("��������...");
    localpd=pd;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.setLayout(null);
    view.setBackground(Color.white);
    view.setBounds(new Rectangle(7, 25, 537, 316));
    btnClose.setLabel("�ر�");
    btnClose.setBounds(new Rectangle(352, 354, 80, 25));
    btnClose.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        btnClose_actionPerformed(e);
      }
    });
    this.setBackground(Color.gray);
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowOpened(WindowEvent e) {
        this_windowOpened(e);
      }
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    choicelen.setBounds(new Rectangle(71, 355, 94, 21));
    choicelen.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        choicelen_itemStateChanged(e);
      }
    });
    for(int i=0;i<20;i++){
       choicelen.addItem(Integer.toString((i+1)*100));
    }
    label1.setText("��ʾ���ȣ�");
    label1.setBounds(new Rectangle(6, 360, 60, 12));
    btnRefresh.setLabel("ˢ��");
    btnRefresh.setBounds(new Rectangle(207, 357, 65, 20));
    btnRefresh.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        btnRefresh_actionPerformed(e);
      }
    });
    this.add(btnClose, null);
    this.add(view, null);
    this.add(choicelen, null);
    this.add(btnRefresh, null);
    this.add(label1, null);
    this.pack();
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
  }

  void this_windowClosing(WindowEvent e) {
    this.hide();
    this.dispose();
  }
  void btnClose_actionPerformed(ActionEvent e) {
    this.hide();
    this.dispose();
  }
   void this_windowOpened(WindowEvent e) {
    gra=view.getGraphics();
    cyclemax=localpd.cyclemax;
    repaint();
    if(runner1==null){
      runner1=new Thread(this);
      runner1.start();
    }
  }
  public void paint(Graphics g) {
    /**@todo: Override this java.awt.Component method*/
    //��ͼ����
    int width=517-originx-25;
    int height=316-originy;
    int step=localpd.steps;
    int nStart=0;
    int nEnd=cycles;
    if(step-cycles>0){
        //������Ҫ���Ƶ���ʷ���������е���ʾ����
        nStart=step-cycles;
    }
    //��ջ�ͼ����
    gra.clearRect(0,0,517,316);

    //�趨ԭ������
    int x=0,y=0,y0=height-originy;
    //���趨��Ҫ���ĺ��������ѭ��
   for(int i=0;i<cycles;i++){
      //��ǰ������
      int x1=(int)((i*width)/cycles);
      int y1=(int)(localpd.HistoryData[(i+nStart)%cyclemax]*height/localpd.AgCount);
      //���ƺ����߱���
      if(y1>0){
        gra.setColor(Color.blue);
        gra.drawLine(x+originx,height-y,x1+originx,height-y1);
      }
      //���Ʋ������߱���
      int y2=height-(int)(localpd.HistoryData[(i+nStart)%cyclemax]*height/localpd.AgCount);
      if(y1>0){
        gra.setColor(Color.red);
        gra.drawLine(x+originx,height-y0,x1+originx,height-y2);
      }

      //ǰһ�������
      x=x1;
      y=y1;
      y0=y2;
    }

    //�������ἰ��˵������
    gra.setColor(Color.black);
    gra.drawLine(originx,height,width+originx,height);
    gra.drawLine(originx,height,originx,0);
    gra.drawString("ʱ��",width+originx,height);
    gra.drawString("����",originx+2,originy/2);
    for(int i=0;i<10;i++){
        int x3=(int)(i*width/10)+originx;
        int y3=height;
        gra.drawLine(x3,y3,x3,y3-2);
        String txt;
        if(step>cycles){
          txt=Integer.toString((int)(step-cycles+i*cycles/10));
        }else{
          txt=Integer.toString((int)(i*cycles/10));
        }
        gra.drawString(txt,x3,y3+12);
    }
    for(int i=1;i<=4;i++){
        int x3=originx;
        int y3=(int)((4-i)*height/4);
        gra.drawLine(x3,y3,x3+2,y3);
        String txt=Integer.toString((int)(i*localpd.AgCount/4));
        gra.drawString(txt,x3-30,y3+15);
    }
    gra.drawString("������",5,height-originy-15);
    gra.drawString("������",5,height-5);
    gra.setColor(Color.blue);
    gra.drawLine(2,height-originy-30,originx-5,height-originy-30);
    gra.setColor(Color.red);
    gra.drawLine(2,height-20,originx-5,height-20);
    super.paint(g);
  }
   void choicelen_itemStateChanged(ItemEvent e) {
    cycles=(choicelen.getSelectedIndex()+1)*100;
    repaint();
  }

  void btnRefresh_actionPerformed(ActionEvent e) {
    repaint();
  }
  public void stop() {
    if (runner1!=null)
    {
      // running = false;
        runner1.stop();
       runner1=null;
    }

  }
  public void run()   {
    while(true){
        repaint();
        try{Thread.sleep(1000);}catch(InterruptedException e){};
    }
  }
}