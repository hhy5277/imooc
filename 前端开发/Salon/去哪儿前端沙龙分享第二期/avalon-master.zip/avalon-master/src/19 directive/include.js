//ms-include绑定已由ms-attr绑定实现
