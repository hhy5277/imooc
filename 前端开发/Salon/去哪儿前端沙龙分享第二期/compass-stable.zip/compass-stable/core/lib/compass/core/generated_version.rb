module Compass
  module Core
    # This file intentionally does nothing.
    # The build process will generate a VERSION constant here.
  end
end
