See the [contributing docs](https://github.com/yeoman/yeoman/blob/master/contributing.md)
