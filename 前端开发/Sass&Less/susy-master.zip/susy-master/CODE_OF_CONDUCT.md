# Susy Contributor Code of Conduct

Susy is driven by the community of individuals that power its development and use every day. As a community, we want to embrace the very differences that have made our collaboration so powerful, and work together to provide the best environment for learning, growing, and sharing of ideas. It is imperative that we keep Sass a fun, welcoming, challenging, and fair place to play.

As contributors and maintainers of this project, and in the interest of fostering an open and welcoming community, we pledge to respect all people who contribute through reporting issues, posting feature requests, updating documentation, submitting pull requests or patches, and other activities.

We are committed to making participation in this project a harassment-free experience for everyone, regardless of level of experience, gender, gender identity and expression, sexual orientation, disability, personal appearance, body size, race, ethnicity, age, religion, or nationality.

[The full community guidelines can be found on the Sass website.][link]

[link]: http://sass-lang.com/community-guidelines
