Create New Item
- pinch apart to create

Navigation
- pinch inwards to close TodoCollection

Compatibility
- Android keyboard issues