Copyright (c) 2012 Yuxi Evan You

The interface design of the software is the intellectual property of the creators of the original iOS Clear app, Realmac Software, Helftone and Impending, Inc. The software open sourced here in this repository is intended to be used for technical reference only. Owners of copies of the software are free to use, copy, mofidy, merge and distribute the software, but are not permitted to engage in commercial acts such as publishing, sublicensing, and/or selling copies of the Software.

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.