exports.slot = require('./slot')
exports.partial = require('./partial')
