var Vue = require('../../../src/vue')
Vue.options.replace = false
Vue.config.silent = true
