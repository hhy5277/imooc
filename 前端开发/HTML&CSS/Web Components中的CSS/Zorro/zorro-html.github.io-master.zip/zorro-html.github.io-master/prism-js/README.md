prism-js
================

See the [component page](http://addyosmani.github.io/prism-js) for more information.
