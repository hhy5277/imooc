node build-info.js
vulcanize debug.html -o index.html
