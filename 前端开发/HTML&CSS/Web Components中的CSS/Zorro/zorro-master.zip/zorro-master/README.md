# Zorro

Hiding Goods in the Shadow

Zorro is a web components framework & gallery. It's just on the road!

- [z-typo](https://github.com/zorro-html/z-typo)
- [z-table](https://github.com/zorro-html/z-table)
- [z-icon](https://github.com/zorro-html/z-icon)
- [z-btn](https://github.com/zorro-html/z-btn)
- [z-menu](https://github.com/zorro-html/z-menu)
- [z-dropdown](https://github.com/zorro-html/z-dropdown)
- [z-btn-group](https://github.com/zorro-html/z-btn-group)
- [z-nav](https://github.com/zorro-html/z-nav)
- [z-panel](https://github.com/zorro-html/z-panel)
- [z-breadcrumb](https://github.com/zorro-html/z-breadcrumb)
- [z-pagination](https://github.com/zorro-html/z-pagination)
- [z-dock](https://github.com/zorro-html/z-dock)
- [z-grid](https://github.com/zorro-html/z-grid)
- [z-bar](https://github.com/zorro-html/z-bar)
- [z-input](https://github.com/zorro-html/z-input)
- [z-progress](https://github.com/zorro-html/z-progress)
- [z-rmb](https://github.com/zorro-html/z-rmb)
- [z-tag](https://github.com/zorro-html/z-tag)
- [z-time](https://github.com/zorro-html/z-time)
- [z-note](https://github.com/zorro-html/z-note)
- [z-phone](https://github.com/zorro-html/z-phone)
- [z-dialog](https://github.com/zorro-html/z-dialog)
- [z-tooltip](https://github.com/zorro-html/z-tooltip)
- [z-mask](https://github.com/zorro-html/z-mask)
- [z-script](https://github.com/zorro-html/z-script)
