# input-space

和表单整体相吻合的空结构，比如按钮或更多的控件扩展

## Example

```html
<z-input-space value="" label="..." placeholder="...">
  <z-btn ...>...</z-btn>
</z-input-space>
```
