# Zorro Script Utils

Easy to import

## `ext/link.html`

- `getBaseURI(doc)`: find BaseURI of a document
- `getFullURL(url, baseURI)`: join url and BaseURI together 
