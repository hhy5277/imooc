CREATE TABLE visits (
    uri VARCHAR(255) PRIMARY KEY,
    visits INT(8)
    );

