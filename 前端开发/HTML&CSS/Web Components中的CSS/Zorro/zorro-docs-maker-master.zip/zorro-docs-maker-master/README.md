# zorro-docs-maker

1. read `@element` comment block in `z-*.html`
    * find `@attribute`, `@property`, `@method`, `@event`, `@example`
2. generate demo page
    * convert description to markdown
    * show name, demo and code of each example
