// designList **
// transitionList **
// tplList **
// pageList **

// currentDesign **
// currentLayout **
// currentPage **
// currentLayout **
// currentItem **
// currentItemDataCopy *

// title **
// titleDisplay **
// editingTitle **

// clickTpl **
// clickDesign **
// clickPage **

// addPage **
// clonePage **
// removePage **
// nextPage **
// prevPage **
// moveUpPage **
// moveDownPage **

// editTitle **

// previewItem **
// previewAll **
// editItem **
// finishEdit *


requirejs(
    ['editor', 'player'],
    function (editor, player) {
        editor.init();
    }
);
