OTF and TTF: Suissnord
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Suissnord is a simple yet elegant display font with curvaceous styling. The lines are sleek and slender keeping the same weight throughout the entire alphabet. While the majority of characters are uppercase, you'll find lowercase versions of others like a, e, and n. Basic Latin, extended latin,
European accents, diacritics, and basic punctuation are included. Use Suissnord for a magazine, fashion ad, or company logo. 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for 
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 


visit www.sharkshock.net for more and take a bite out of BORING design!

tags: sans, sans serif, model, magazine, display, font, typeface, sports, illustration, Paris, France, project, rounded, straight, geo, san, publishing, logo, company, Sharkshock, Europe, diacritics, Polish, Czech, German, French, accents, Spanish, Latin, kerning, fashion, industry, perfume, ad
advertising, horizontal, shoot, red carpet, modeling

