

--- {PAPER BANNER} ---

     Version 1.0


Light // Regular // Bold // Black // Sans


--------------------------------------------------------------------------------------------------


+++ This font is FREE for PERSONAL USE only! +++

Please give credit and/or refer to the dafont link if you are sharing personal work including the font.



If you like my work, you can support me with a donation via PayPal (see below) :)

Enjoy!


--------------------------------------------------------------------------------------------------


+++ Commercial use & the use as webfont requires a one-time PayPal donation of $10 or more. +++

You can donate via 
- email to byjanam.info@gmx.de 
- or the "Donate to author" link on http://www.dafont.com/jana.d4548

If you are interested in a written permission by email, a license for more than 5 users, do not have PayPal, or have any further questions, please contact me!


--------------------------------------------------------------------------------------------------


Contact: Jana Matthaeus
Email: byjanam.info@gmx.de 
Blog: http://byjanam.blogspot.de


� 2014 byJanaM | ALL RIGHTS RESERVED
