Thanks for  downloading and using this font,  to use it you must agree to the following terms:

- This font can not be resold or modified for sale.

- This typeface has been designed and programmed by Manuel Ramos so that the author has all copyrights.

- Personal use, ie, if it will not get economic benefit from it, is "FREE", but as payment for work, 
a donation of any amount is always welcome to encourage the author to continue making new fonts. 
Manuel encourages you to please donate in this case even a small amount through the dafont.com donation button.

- Commercial use , this is when somehow you are going to get an economic benefit from the use of typography,
 requires a donation to the author. Please keep in contact with the author in this case through his website www.infinitismo.com


