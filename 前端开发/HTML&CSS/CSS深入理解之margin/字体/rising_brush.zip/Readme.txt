Hello There,

Thanks for download my free font. 
You can download full version here 
http://crtv.mk/uE5Z
 
Rising Brush Script is a chaotic beautiful script.Imperfect flow and grunge style combined with script create awesome elegant and grunge feel at the same time. Awesome for designing book covers, film covers, apparel, cards, logos, posters, etc. Opentype features gives you more alternatives in designing.

Files Include

.otf & ttf
Help file
Bonus swash
Features

Basic Latin A-Z and a-z
Numbers
Symbols
Stylistic Set
Ligature
PUA Encode


Visit For any premium Font
https://creativemarket.com/h_m
