FONT BY DENISE BENTULAN (c) 2015
http://douxiegirl.com
http://www.dafont.com/denise-bentulan.d2156
http://deathmunkey.deviantart.com
http://facebook.com/douxiegirl

-----------------------------------------------------------------------------------------

Free for personal use ONLY.
For commercial use, please email the designer at dnn.bntln@yahoo.com 

-----------------------------------------------------------------------------------------

PayPal donations are highly appreciated!
these help me through my further education, and help keep me motivated to make more fonts.

you may send them to my PayPal account, dnn.bntln@yahoo.com.

thank you

Denise
-----------------------------------------------------------------------------------------