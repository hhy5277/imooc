"Signarita Zhai" - True Type Font
Copyright (c) 2014 by Rimando Nillo, Jr. 
All rights reserved

These font is free but for PERSONAL USE ONLY.
That means that any such use by you is entirely at your 
own risk.

But donations are accepted and appreciated thank you.

The user agrees not to recreate, modify, rename, 
imitate or base own work on the product.

Do not use this font for commercial and for profit, email me
for permission.

You can download, share or distribute this font but all i ask
is send me an email or give some credit to the author 
and share me your links on how you used these Fonts.

This readme file must be included in the pack, unchanged.

You can contact/email me or send me links:
dondon_nillo@yahoo.com
dondonnillo@gmail.com

Please donate to

paypal
dondon_nillo@yahoo.com 