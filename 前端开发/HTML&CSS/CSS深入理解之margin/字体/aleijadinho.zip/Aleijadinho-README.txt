Terms Of Use: 

1. Don't upload it elsewhere claiming it is yours. Should you want to place it in a collection outside DA, dafont.com or fontspace.com, authorization is required and can be obtained at my user page, http://matiasromero.deviantart.com/ or sending me a request to matiasromero@gmail.com. Permission is most likely to be given, but it has to be asked for. Needless to say, a link back to http://matiasromero.deviantart.com/ is appreciated (yet not required) even with such authorization. 

2. No racist, homophobic, hatred, etc. works with this font. 

3. Credit and link to my user page, so that others may find this resource and the link to its source too, if there's one. 4. Send me a link, I always love to see what's being done with these fonts. 

5. USE OF THIS FONT IN COMMERCIAL PROJECTS SUBJECT TO DONATION. A link for donation can be found beside any of my fonts at Dafont.com, http://www.dafont.com/matias-romero.d3553