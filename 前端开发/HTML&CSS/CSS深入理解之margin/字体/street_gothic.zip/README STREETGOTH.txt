Copyright (c) 2016, ALY K. SALAZAR. 
--
This font is free for PERSONAL USE ONLY. I do not sell commercial licenses, but if you wish to use commercially you must donate $15-20 through my paypal account, which is found on my dafont page. Do not edit, resell, or otherwise reclaim my work as your own. DO NOT REDISTRIBUTE. Dafont.com is the only website permitted to host this font.
--
Thank you for downloading!