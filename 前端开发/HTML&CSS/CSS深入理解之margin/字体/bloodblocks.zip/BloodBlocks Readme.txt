BloodBlocks - Font by ModBlackmoon. 

INFO: 
Incl. English, European letters and Numbers. May 2010. 

LICENSE: 
Freeware. No modify.

WEB: 
modblackmoon.com
facebook.com/ModBlackmoon.Art