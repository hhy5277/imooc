Thanks for downloading Northwood High by AllencHIU cHIU

Free for personal use.
For commercial usage, please contact pealwah@hotmail.com

I love to see my fonts being used, so e-mail me!
(or contact me using your preferred method of contact)

e-mail: pealwah@hotmail.com
aim: alwaysbehappy135
site: http://asianpride7625.deviantart.com/




Sebastian 1>2