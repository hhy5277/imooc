TATTOO INK is a *FREE* font inspired by the multitude of tattoo-lettering styles drilled
into people's skin everyday worldwide.  

TATTOO INK contains letters only - no punctuation or numbers are provided.  Uppercase
letters contain a scratchfull, while lowercase letters contain angled fill.

Distribute as FREEWARE at will

Cheers
Ryan Splint