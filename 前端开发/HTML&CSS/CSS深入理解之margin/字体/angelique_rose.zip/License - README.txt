Para instalar o usar la tipograf�a "Angelique Rose" debe estar de acuerdo con las condiciones de uso.
By installing or using this font (Angelique Rose) you agree to the Product Usage Agreement:
http://defharo.com/product-usage-agreement-ffp/
========================================
Esta fuente es s�lo para uso personal, el uso comercial requiere una licencia.
This font is for PERSONAL USE ONLY and requires a license for commercial use. 
http://defharo.com/terms-and-conditions-commercial-fonts/
========================================
La licencia comercial est� disponible para la venta:
The font commercial license is avaliable for sale: 
http://wp.me/p11PzK-2pt

========================================
Por favor lea las condiciones de la licencia s�lo para uso personal:
Please read "Free for personal use License | Fonts by deFharo" for more info:
http://defharo.com/free-for-personal-use-license/
========================================
Si necesita m�s informaci�n contacte con el dise�ador:
For further information, please contact designer:
========================================
Fernando Haro
fernando@defharo.es
www.defharo.com