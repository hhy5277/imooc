webAudio
========

利用webAudio,canvas,CSS3制作的自适应的音乐可视化应用
PC端，移动端通用

https://passionate.herokuapp.com

欢迎加入前端高级群，探讨交流前端以及nodejs前沿的技术知识，群号：108873184
