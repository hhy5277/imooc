var path = require('path');
module.exports = {
	cookieSecret: "webpptdoving",
	db: 'webppt',
	host: 'localhost',
};