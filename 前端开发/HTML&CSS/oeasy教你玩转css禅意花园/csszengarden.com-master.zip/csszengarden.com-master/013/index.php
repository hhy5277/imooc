<?
header("Location: http://www.csszengarden.com/?cssfile=013/013.css");
?>
