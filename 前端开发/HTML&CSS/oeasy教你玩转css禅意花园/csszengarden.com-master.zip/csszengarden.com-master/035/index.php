<?
header("Location: http://www.csszengarden.com/?cssfile=035/035.css");
?>
