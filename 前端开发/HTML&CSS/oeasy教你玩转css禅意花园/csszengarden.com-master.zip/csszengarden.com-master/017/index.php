<?
header("Location: http://www.csszengarden.com/?cssfile=017/017.css");
?>
