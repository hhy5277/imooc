<?
header("Location: http://www.csszengarden.com/?cssfile=095/095.css");
?>
