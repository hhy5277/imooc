<?
header("Location: http://www.csszengarden.com/?cssfile=085/085.css");
?>
