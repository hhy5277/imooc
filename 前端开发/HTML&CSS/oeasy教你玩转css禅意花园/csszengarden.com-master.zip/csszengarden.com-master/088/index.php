<?
header("Location: http://www.csszengarden.com/?cssfile=088/088.css");
?>
