<?
header("Location: http://www.csszengarden.com/?cssfile=083/083.css");
?>
