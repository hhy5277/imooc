//
//  ShakingView.h
//  Git@OSC
//
//  Created by chenhaoxiang on 14-9-19.
//  Copyright (c) 2014年 chenhaoxiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShakingView : UIViewController <UIAlertViewDelegate>

@end
