//
//  IssueDescriptionCell.h
//  iOS-git-osc
//
//  Created by chenhaoxiang on 14-8-8.
//  Copyright (c) 2014年 chenhaoxiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IssueDescriptionCell : UITableViewCell <UIWebViewDelegate>

@property UIWebView *issueDescription;

@end
