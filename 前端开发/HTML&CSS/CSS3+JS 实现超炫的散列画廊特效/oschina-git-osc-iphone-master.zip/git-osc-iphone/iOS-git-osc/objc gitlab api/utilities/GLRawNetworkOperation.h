//
//  GLRawNetworkOperation.h
//  objc gitlab api
//
//  Created by Jeff Trespalacios on 1/29/14.
//  Copyright (c) 2014 Indatus. All rights reserved.
//

#import "GLNetworkOperation.h"

@interface GLRawNetworkOperation : GLNetworkOperation

@end
