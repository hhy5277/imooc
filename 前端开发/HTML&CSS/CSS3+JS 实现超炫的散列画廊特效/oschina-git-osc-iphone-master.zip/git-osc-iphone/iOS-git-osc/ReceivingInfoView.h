//
//  ReceivingInfoView.h
//  Git@OSC
//
//  Created by chenhaoxiang on 14-9-21.
//  Copyright (c) 2014年 chenhaoxiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReceivingInfoView : UIViewController <UITextFieldDelegate, UITextViewDelegate>

@end
