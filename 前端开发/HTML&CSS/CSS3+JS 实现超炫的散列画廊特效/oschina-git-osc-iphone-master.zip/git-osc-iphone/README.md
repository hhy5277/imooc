#**git-osc-iphone**
##**Git@OSC iPhone 客户端项目简析**


运行环境：Xcode 5 或以上版本，并安装CocoaPods
双击 Git@OSC.xcworkspace 即可运行

**本项目采用 GPL 授权协议，欢迎大家在这个基础上进行改进，并与大家分享。**

项目结构简介：<br/>

**1. GitAPI** ---- Git@OSC API 请求及返回对象的封装<br/>
**2. Share**  ---- 分享组件<br/>
**3. Utils**  ---- 辅助工具<br/>
**4. Controllers** ---- 所有视图控制器</br>
**5. Resource** ---- 项目资源</br>


