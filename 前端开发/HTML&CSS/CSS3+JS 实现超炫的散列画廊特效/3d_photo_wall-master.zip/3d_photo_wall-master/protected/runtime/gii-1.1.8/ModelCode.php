<?php
return array (
  'template' => 'default',
  'tablePrefix' => 'share_',
  'modelPath' => 'application.models',
  'baseClass' => 'CActiveRecord',
  'buildRelations' => '1',
);
