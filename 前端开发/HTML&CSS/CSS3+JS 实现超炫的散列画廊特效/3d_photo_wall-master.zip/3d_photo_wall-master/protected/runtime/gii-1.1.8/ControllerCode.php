<?php
return array (
  'template' => 'default',
  'baseClass' => 'Controller',
  'actions' => 'all,baidu,sina,163,pp',
);
