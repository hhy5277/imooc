<?php

return array (
  'Verification Code' => '验证码',
  'Body' => '正文',
  'Name' => '姓名',
  'Email' => '邮箱',
  'indexpage' => '首页',
  
);

?>