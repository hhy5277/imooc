<?php $this->beginContent('/layouts/share/main'); ?>
			<?php echo $content; ?>
<?php $this->endContent(); ?>