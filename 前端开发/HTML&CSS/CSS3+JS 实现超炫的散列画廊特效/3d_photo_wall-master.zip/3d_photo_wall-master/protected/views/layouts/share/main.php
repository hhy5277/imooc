<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh_cn" lang="zh_cn">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="language" content="zh_cn" />

	<title><?php echo CHtml::encode($this->pageTitle); ?></title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="keywords" content="3D,图片墙,新闻图片,自拍图片,最酷图片集,picture wall, cooliris without addon" />
  <meta name="description" content="晚霞居以更酷的3D图片墙方式浏览新闻图片和自拍图片。代替cooliris，不需安装插件。Thecloudliving helps you view pictures through 3d picture wall. It can replace cooliris, without installing plugins or addons." />
  <meta name="copywrite" content="liuliming2008@126.com" />
</head>

<body>

<div class="container" id="page">

	
	<?php echo $content; ?>

	

</div><!-- page -->

</body>
</html>