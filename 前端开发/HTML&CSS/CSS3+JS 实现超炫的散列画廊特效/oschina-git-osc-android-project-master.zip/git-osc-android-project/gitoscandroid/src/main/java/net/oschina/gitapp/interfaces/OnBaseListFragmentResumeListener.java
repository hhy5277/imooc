package net.oschina.gitapp.interfaces;

import net.oschina.gitapp.ui.basefragment.BaseFragment;

public interface OnBaseListFragmentResumeListener {
	public void onBaseListFragmentResume(BaseFragment baseFragment);
}