/**
 * 
 */
/**
 * @author yanghonghe
 *
 */
package net.biaobaiqiang.ument;