### Git@OSC 安卓[客户端](http://http://git.oschina.net/appclient)

android studio最近势头好猛，jar管理以及一些开源库的引用确实方便了好多，所以从1.2版本开始此项目开始转移到as进行开发

eclipse则仅支持到[V1.1.3版本](http://git.oschina.net/oschina/git-osc-android-project/blob/V1.1.3/.gitignore)，构建方式可见[REAMME_old.md](http://git.oschina.net/oschina/git-osc-android-project/blob/master/README_old.md)

本项目基于 [Android Studio](http://http://www.oschina.net/p/android-studio) v1.+，如果没有安装as，请先自行安装喔

### 引用到的开源库：
- [android-async-http:1.4.6](http://www.oschina.net/p/android-async-http)
- [universal-image-loader:1.9.3](ttp://www.oschina.net/p/android-universal-image-loader)
- [butterknife:6.1.0](hhttp://www.oschina.net/p/butterknife)
- [photoview:library:1.2.3](http://www.oschina.net/p/android-photo-view)
- [CodeMirror](http://www.oschina.net/p/codemirror)

### 开源协议
- [Apache Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.html)
