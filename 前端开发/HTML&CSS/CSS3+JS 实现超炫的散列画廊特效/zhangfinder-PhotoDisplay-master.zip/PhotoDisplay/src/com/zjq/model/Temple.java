package com.zjq.model;

public class Temple {
	private String descrptionZJQ;//ףԸ�����쿪��
	private String shortcuticonZJQ;//��ҳ����ͼ��
	private String titleContentZJQ;//��ҳ����
	private String photosZJQ[];//��ҳͼƬ
	private String contentOneZJQ;//����1,ͳһ��Ϊ��ҳ
	private String contentTwoZJQ;//����2
	private String contentThreeZJQ;//����3
	private String contentFourZJQ;//����4
	private String webSiteOneZJQ;//��ַ1
	private String webSiteTwoZJQ;//��ַ2
	private boolean hasRose;//�Ƿ�����õ��ҳ��
	public String getDescrptionZJQ() {
		return descrptionZJQ;
	}
	public void setDescrptionZJQ(String descrptionZJQ) {
		this.descrptionZJQ = descrptionZJQ;
	}
	public String getShortcuticonZJQ() {
		return shortcuticonZJQ;
	}
	public void setShortcuticonZJQ(String shortcuticonZJQ) {
		this.shortcuticonZJQ = shortcuticonZJQ;
	}
	public String getTitleContentZJQ() {
		return titleContentZJQ;
	}
	public void setTitleContentZJQ(String titleContentZJQ) {
		this.titleContentZJQ = titleContentZJQ;
	}
	public String[] getPhotosZJQ() {
		return photosZJQ;
	}
	public void setPhotosZJQ(String[] photosZJQ) {
		this.photosZJQ = photosZJQ;
	}
	public String getContentOneZJQ() {
		return contentOneZJQ;
	}
	public void setContentOneZJQ(String contentOneZJQ) {
		this.contentOneZJQ = contentOneZJQ;
	}
	public String getContentTwoZJQ() {
		return contentTwoZJQ;
	}
	public void setContentTwoZJQ(String contentTwoZJQ) {
		this.contentTwoZJQ = contentTwoZJQ;
	}
	public String getContentThreeZJQ() {
		return contentThreeZJQ;
	}
	public void setContentThreeZJQ(String contentThreeZJQ) {
		this.contentThreeZJQ = contentThreeZJQ;
	}
	public String getContentFourZJQ() {
		return contentFourZJQ;
	}
	public void setContentFourZJQ(String contentFourZJQ) {
		this.contentFourZJQ = contentFourZJQ;
	}
	public String getWebSiteOneZJQ() {
		return webSiteOneZJQ;
	}
	public void setWebSiteOneZJQ(String webSiteOneZJQ) {
		this.webSiteOneZJQ = webSiteOneZJQ;
	}
	public String getWebSiteTwoZJQ() {
		return webSiteTwoZJQ;
	}
	public void setWebSiteTwoZJQ(String webSiteTwoZJQ) {
		this.webSiteTwoZJQ = webSiteTwoZJQ;
	}
	public boolean isHasRose() {
		return hasRose;
	}
	public void setHasRose(boolean hasRose) {
		this.hasRose = hasRose;
	}


}
