test code-style by precommit
