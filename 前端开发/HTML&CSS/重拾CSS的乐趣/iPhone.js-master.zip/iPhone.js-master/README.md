#iPhone.js - Imageless iPhone 4 demo.

This rendering of iPhone 4 and its icons were made in pure CSS3. No images, no base64, no SVG, no canvas, just a lot of CSS3 lines of CSS code and a little bit of Javascript code (with jQuery, of course).

Viewed best with the latest versions of Safari and Chrome in Mac OS X.

##License

MIT

Copyright 2013 Vasiliy Zubach (aka TjRus) http://github.com/TjRus/iPhone.js
