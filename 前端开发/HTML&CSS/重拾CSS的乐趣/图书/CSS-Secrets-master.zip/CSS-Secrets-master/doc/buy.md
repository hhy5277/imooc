---
title: "购买方式"
issue: "#27"
---

## 签名书（预购） <a name="signature">&nbsp;</a>

如果你想希望收藏一本签名书，那千万别错过 “CSS魔法” 微信公众号的代购活动！在公众号内发送 “签名书” 三个字，然后按提示操作就可以了。

![weixin-qrcode](https://cloud.githubusercontent.com/assets/1231359/13040994/04966808-d3ee-11e5-8eb5-7e3bf8767f4e.png)

（扫码关注 “CSS魔法” 微信公众号）


## 纸质书 <a name="paper-book">&nbsp;</a>

* 定价： 99.00 元

* 购买渠道：
	* 京东（暂未上架）
	* 当当（暂未上架）
	* 亚马逊（暂未上架）
	* China-Pub（暂未上架）


## 电子版 <a name="e-book">&nbsp;</a>

* 定价： 49.99 元

* 购买渠道：[图灵官网](http://www.ituring.com.cn/book/1695) 独家发售。
