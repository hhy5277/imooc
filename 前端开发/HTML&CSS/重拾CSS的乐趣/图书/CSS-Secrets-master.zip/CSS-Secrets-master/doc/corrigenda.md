---
title: "勘误表"
issue: "#2"
---

## 中文版勘误

（待纸质书上市后更新）


## 英文原书勘误表

> by O’Reilly Media, Inc.

* [出版社已确认](http://www.oreilly.com/catalog/errata.csp?isbn=0636920031123)
* [待确认](http://www.oreilly.com/catalog/errataunconfirmed.csp?isbn=0636920031123)
