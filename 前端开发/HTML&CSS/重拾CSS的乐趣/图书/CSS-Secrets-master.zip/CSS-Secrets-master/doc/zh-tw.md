---
title: "《CSS Secrets》繁体中文版（台湾版）介绍与预览"
issue: "#24"
---

## 基本信息

#### 《CSS Secrets 中文版：解决网页设计问题的有效秘诀》

![[CSS Secrets 繁体中文版 - 封面]](http://www.gotop.com.tw/Waweb2004/WawebImages/BookXL/A447.jpg)

* 作者：Lea Verou
* 译者：郑巧玉
* 出版社：碁峰资讯股份有限公司
* 出版日期：2016/01/11
* ISBN：9789863478744
* 页数：392
* 价格：680 新台币

#### 详细报道

* [《CSS Secrets》繁体中文版深度测评](http://mp.weixin.qq.com/s?__biz=MzIyMjE0ODQ0OQ==&mid=402491044&idx=1&sn=7f7873060c1331e9cf4477b095aa7226#rd)

## 内页预览

（所有预览图片由 [碁峰资讯股份有限公司](http://books.gotop.com.tw/o_A447) 提供。）

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b1.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b2.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b3.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b4.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b5.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b6.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b7.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b8.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b9.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b10.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b11.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b12.jpg)

***

![[CSS Secrets 繁体中文版 - 预览]](http://www.gotop.com.tw/waweb2004/WawebImages/BookCom/A447/9789863478744_b13.jpg)

***

（完）
