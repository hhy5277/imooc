//
//  NotificationController.h
//  WaxWatchExample WatchKit Extension
//
//  Created by junzhan on 15/10/28.
//  Copyright © 2015年 test.jz.com. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface NotificationController : WKUserNotificationInterfaceController

@end
