//
//  AppDelegate.h
//  LuaCodeDebug
//
//  Created by junzhan on 15/10/15.
//  Copyright © 2015年 test.jz.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

