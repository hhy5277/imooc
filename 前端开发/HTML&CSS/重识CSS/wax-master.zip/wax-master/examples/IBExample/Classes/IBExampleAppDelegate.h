//
//  IBExampleAppDelegate.h
//  IBExample
//
//  Created by Corey on 1/3/11.
//  Copyright 2011 me. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IBExampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

