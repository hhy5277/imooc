require "wax.luaspec"

-- require "tests.someTest"

print("\nResults\n-------")
spec:report()
exitApp() -- Makes sure the app shuts down when run from the command line