To build wax framework, please follow these steps.

* `cd WAX_ROOT/tools/Framework`
* `rake package`
* then wax.framework will be here
