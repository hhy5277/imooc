//
//  WaxCGContext.h
//  EmpireState
//
//  Created by Corey Johnson on 10/5/09.
//  Copyright 2009 Probably Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "lua.h"

int luaopen_wax_CGContext(lua_State *L);