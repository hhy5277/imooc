//
// wax_lock.h
// wax
//
//  Created by junzhan on 14-5-22.
//  Copyright (c) 2014年 junzhan. All rights reserved.
//

#import <Foundation/Foundation.h>

NSRecursiveLock* wax_globalLock();
