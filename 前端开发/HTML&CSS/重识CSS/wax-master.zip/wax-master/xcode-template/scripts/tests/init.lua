require "wax.luaspec"

require "tests.someTest"

print("\nResults\n-------")
spec:report()