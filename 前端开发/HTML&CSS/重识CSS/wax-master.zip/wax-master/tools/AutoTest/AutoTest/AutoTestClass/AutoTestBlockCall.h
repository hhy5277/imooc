//
//  AutoTestBlockCall.h
//  
//
//  Created by junzhan on 15-1-7.
//  Copyright (c) 2015年 junzhan. All rights reserved.
//

#import "AutoTestBase.h"

@interface AutoTestBlockCall : AutoTestBase

@end
