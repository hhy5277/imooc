//
//  AutoTestGCD.h
//  
//
//  Created by junzhan on 15-4-16.
//  Copyright (c) 2015年 junzhan. All rights reserved.
//

#import "AutoTestBase.h"

@interface AutoTestGCD : AutoTestBase

@end
