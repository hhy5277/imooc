//
//  AutoTestBlockTransfer.h
//  
//
//  Created by junzhan on 15-1-6.
//  Copyright (c) 2015年 junzhan. All rights reserved.
//

#import "AutoTestBase.h"

@interface AutoTestBlockTransfer : AutoTestBase

@end
