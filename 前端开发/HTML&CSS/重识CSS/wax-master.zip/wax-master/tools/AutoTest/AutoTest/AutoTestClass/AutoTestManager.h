//
//  AutoTestManager.h
//  
//
//  Created by junzhan on 15-1-5.
//  Copyright (c) 2015年 junzhan. All rights reserved.
//

#import "AutoTestBase.h"

@interface AutoTestManager : NSObject

+ (void)autoTestStart;


@end
