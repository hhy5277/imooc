//
//  AutoTestUIKitFunction.h
//  
//
//  Created by junzhan on 15-4-21.
//  Copyright (c) 2015年 junzhan. All rights reserved.
//

#import "AutoTestBase.h"

@interface AutoTestUIKitFunction : AutoTestBase

@end
