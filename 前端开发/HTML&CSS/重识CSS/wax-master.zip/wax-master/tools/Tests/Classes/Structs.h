//
//  Structs.h
//  OinkTests
//
//  Created by ProbablyInteractive on 8/23/09.
//  Copyright 2009 Probably Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>

struct SimpleStruct {
    int number;
};

struct CustomStruct {
    double first;
    double second;
};

@interface Structs : NSObject {

}

@end
