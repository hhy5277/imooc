//
//  SimpleObject.h
//  Rentals
//
//  Created by ProbablyInteractive on 8/2/09.
//  Copyright 2009 Probably Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SimpleObject : NSObject {
    NSString *_value;
}

@end
