//
//  WaxWatchFramework.h
//  WaxWatchFramework
//
//  Created by junzhan on 15/10/28.
//  Copyright © 2015年 test.jz.com. All rights reserved.
//

#import <WatchKit/WatchKit.h>

//! Project version number for WaxWatchFramework.
FOUNDATION_EXPORT double WaxWatchFrameworkVersionNumber;

//! Project version string for WaxWatchFramework.
FOUNDATION_EXPORT const unsigned char WaxWatchFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WaxWatchFramework/PublicHeader.h>


