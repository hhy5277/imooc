//
//  WaxWatchLib.h
//  WaxWatchLib
//
//  Created by junzhan on 15/10/28.
//  Copyright © 2015年 test.jz.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WaxWatchLib : NSObject

@end
