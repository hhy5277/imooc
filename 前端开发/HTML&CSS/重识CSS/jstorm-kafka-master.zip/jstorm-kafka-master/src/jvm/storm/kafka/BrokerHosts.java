package storm.kafka;

import java.io.Serializable;

/**
 * Date: 11/05/2013 Time: 14:40
 */
public interface BrokerHosts extends Serializable {

}