jstorm-kafka
============

jstorm kafka connector

jstorm从0.9.6.1开始包含了kafkaspout的代码。本项目未继续维护。
