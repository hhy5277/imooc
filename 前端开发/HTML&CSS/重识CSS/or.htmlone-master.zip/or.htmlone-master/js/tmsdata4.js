var TMSDATA = {
  "tags": ["智能疯神榜", "美颜疯神榜", "亲子疯神榜", "乐活疯神榜", "型男疯神榜", "女神疯神榜"],
  "currentTag": "2",
  "tabs": [{
    "title": "型男",
    "stype": "item",
    "ltype": "item",
    "items": [{
      "id": "00000000",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "型男型男型男型男",
      "shopName": "肌肤天堂",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10"
    },
      {
      "id": "00000000",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "型男型男型男型男型男",
      "shopName": "肌肤天堂",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10"
    },
    {
      "id": "00000000",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "亲子亲子亲子亲子亲子",
      "shopName": "肌肤天堂",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10"
    }
  ]}, {
    "title": "疯了",
    "stype": "item",
    "ltype": "item",
    "items": [
      {
      "id": "00000000",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "疯了疯了疯了疯了",
      "shopName": "数码",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10"
    },
    {
      "id": "00000000",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "疯了疯了疯了疯了疯了疯了",
      "shopName": "数码",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10"
    },
    {
      "id": "00000000",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "疯了疯了疯了疯了",
      "shopName": "数码",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10"
    }
  ]}, {
    "title": "榜单",
    "stype": "item",
    "ltype": "item",
    "items": [
      {
        "id": "00000000",
        "link": "http://m.taobao.com",
        "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
        "itemName": "榜单榜单榜单榜单榜单榜单",
        "shopName": "数码",
        "shopLink": "http://m.taobao.com",
        "priceNew": "9999.00",
        "priceOld": "100000.00",
        "bonus": "10"
      },
      {
        "id": "00000000",
        "link": "http://m.taobao.com",
        "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
        "itemName": "榜单榜单榜单榜单榜单",
        "shopName": "数码",
        "shopLink": "http://m.taobao.com",
        "priceNew": "9999.00",
        "priceOld": "100000.00",
        "bonus": "10"
      }
      
    ]
  }]
};