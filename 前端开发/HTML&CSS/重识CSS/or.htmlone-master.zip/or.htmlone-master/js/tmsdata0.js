var TMSDATA = {
  "tags": ["智能疯神榜", "美颜疯神榜", "亲子疯神榜", "乐活疯神榜", "型男疯神榜", "女神疯神榜"],
  "currentTag": "0",
  "tabs": [{
    "title": "手机",
    "stype": "item",
    "ltype": "item",
    "items": [{
      "id": "35037919239",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "【让肌肤更年轻】美康粉黛六胜肽青春无纹4件套",
      "shopName": "肌肤天堂",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10",
      "count": "0"
    },
      {
      "id": "00000000",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "【让肌肤更年轻】美康粉黛六胜肽青春无纹4件套",
      "shopName": "肌肤天堂",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10",
      "count": "9"
    },
    {
      "id": "00000000",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "【让肌肤更年轻】美康粉黛六胜肽青春无纹4件套",
      "shopName": "肌肤天堂",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10"
    }
  ]}, {
    "title": "数码",
    "stype": "item",
    "ltype": "item",
    "items": [
      {
      "id": "00000000",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "数码数码烦撒放大声地方",
      "shopName": "数码",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10"
    },
    {
      "id": "00000000",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "数码数码烦撒放大声地方",
      "shopName": "数码",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10"
    },
    {
      "id": "00000000",
      "link": "http://m.taobao.com",
      "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
      "itemName": "数码数码烦撒放大声地方",
      "shopName": "数码",
      "shopLink": "http://m.taobao.com",
      "priceNew": "9999.00",
      "priceOld": "100000.00",
      "bonus": "10"
    }
  ]}, {
    "title": "家电",
    "stype": "item",
    "ltype": "item",
    "items": [
      {
        "id": "00000000",
        "link": "http://m.taobao.com",
        "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
        "itemName": "家电家电发射点发撒旦发射点发",
        "shopName": "数码",
        "shopLink": "http://m.taobao.com",
        "priceNew": "9999.00",
        "priceOld": "100000.00",
        "bonus": "10"
      },
      {
        "id": "00000000",
        "link": "http://m.taobao.com",
        "image": "http://gw.alicdn.com/tps/i3/TB1ARXmGFXXXXbIaXXXLj184XXX-327-326.jpg",
        "itemName": "家电家电发射点发撒旦发射点发",
        "shopName": "数码",
        "shopLink": "http://m.taobao.com",
        "priceNew": "9999.00",
        "priceOld": "100000.00",
        "bonus": "10"
      }

    ]
  }]
};