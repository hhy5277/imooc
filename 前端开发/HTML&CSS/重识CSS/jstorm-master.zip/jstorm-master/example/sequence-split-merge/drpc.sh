#!/bin/bash

jstorm jar target/sequence-split-merge-1.1.0-jar-with-dependencies.jar com.alipay.dw.jstorm.example.drpc.ReachTopology reach
