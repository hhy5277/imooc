"use security";

var aaa = '11';

"use strict";

console.log(aaa);