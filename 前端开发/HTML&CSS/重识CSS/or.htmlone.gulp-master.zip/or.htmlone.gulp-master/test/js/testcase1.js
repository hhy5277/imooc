//testcase 1
var testcase = '111';