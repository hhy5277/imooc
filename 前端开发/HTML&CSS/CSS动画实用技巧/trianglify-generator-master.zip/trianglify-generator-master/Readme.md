# trianglify-generator

Hi folks. This is just a little demo I'm not quite done with yet. 
It uses my [Trianglify](https://github.com/qrohlf/trianglify) library to generate colorful patterns.
Right now, it's least buggy in Safari or Chrome on OSX.
