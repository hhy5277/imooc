require('babel/register');
require('./gulpfile.es6');