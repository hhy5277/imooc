A Pen created at CodePen.io. You can find this one at http://codepen.io/bronsrobin/pen/LlyBK.

 Google Crome Cast Loader