A Pen created at CodePen.io. You can find this one at http://codepen.io/Vestride/pen/vHzyk.

 A css loader based on a gif (http://imgur.com/iWGr9AP). Try changing the `$blockSize`, and if you're using Firefox, uncomment the `vmin` variable for viewport based sizing!