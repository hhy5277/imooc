// A CSS Loader based on gif (http://imgur.com/iWGr9AP)

// A pen by @Vestride