A Pen created at CodePen.io. You can find this one at http://codepen.io/lbebber/pen/xrwja.

 A text filling with water animation, for preloaders and such.