A Pen created at CodePen.io. You can find this one at http://codepen.io/viduthalai1947/pen/JkhDK.

 Single Element pure CSS Spinners & Loaders