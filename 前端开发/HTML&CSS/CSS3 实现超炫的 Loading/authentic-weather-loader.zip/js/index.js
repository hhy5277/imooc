/* 
  Loading animation for Authentic Weather ~ http://authenticweather.com
  -- Made in collaboration with Tobias van Schneider :
  -- http://www.vanschneider.com/
*/