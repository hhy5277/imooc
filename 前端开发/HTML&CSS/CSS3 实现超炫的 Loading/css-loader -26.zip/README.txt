A Pen created at CodePen.io. You can find this one at http://codepen.io/CreativeJuiz/pen/vFBIh.

 I tried different animations for CSS loaders. Pick what you want ;)