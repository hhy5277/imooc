A Pen created at CodePen.io. You can find this one at http://codepen.io/ashleynolan/pen/owvcl.

 A selection of loaders all based around a line of 6 blocks.

Uses CSS3 animation and transforms to create a variety of subtle loading effects.

Inspired by the loading animation on the PSN mobile site (which uses the Flip Delay Up example for their loader).

For more info, see: http://ashleynolan.co.uk/blog/a-collection-of-animated-loaders