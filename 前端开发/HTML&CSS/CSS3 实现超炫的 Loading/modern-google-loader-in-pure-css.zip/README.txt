A Pen created at CodePen.io. You can find this one at http://codepen.io/jczimm/pen/vEBpoL.

 Modern Google spinning loader animating through four colors.