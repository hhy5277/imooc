A Pen created at CodePen.io. You can find this one at http://codepen.io/jackrugile/pen/JddmaX.

 Modification of a loading animation I did for a client.