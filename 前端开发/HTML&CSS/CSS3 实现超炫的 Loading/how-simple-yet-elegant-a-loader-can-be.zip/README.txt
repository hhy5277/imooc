A Pen created at CodePen.io. You can find this one at http://codepen.io/preeteshjain/pen/KpvygJ.

 A very simple and easily customizable loader based on CSS3 keyframe animations. Hide it in your code when done loading. See use case at http://preeteshjain.com