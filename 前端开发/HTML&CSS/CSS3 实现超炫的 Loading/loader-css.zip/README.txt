A Pen created at CodePen.io. You can find this one at http://codepen.io/mattiabericchia/pen/azNyBo.

 Loader make with css animation loop