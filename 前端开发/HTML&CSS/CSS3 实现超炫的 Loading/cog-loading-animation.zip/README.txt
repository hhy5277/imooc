A Pen created at CodePen.io. You can find this one at http://codepen.io/jcoulterdesign/pen/bNxeKY.

 A quick loading animation using CSS. This is taken from the dribbble shot https://dribbble.com/shots/946595-App-loader-GIF-animation