A Pen created at CodePen.io. You can find this one at http://codepen.io/Siddharth11/pen/xbGrpG.

 Fun with CSS3 Keyframes