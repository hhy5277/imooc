function HelloAngular($scope){
	$scope.greeting={text:'Hello'};
}