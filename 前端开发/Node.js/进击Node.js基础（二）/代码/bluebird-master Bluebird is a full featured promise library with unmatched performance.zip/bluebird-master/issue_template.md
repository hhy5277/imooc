(This issue tracker is only for bug reports or feature requests, if this is neither, please choose appropriate channel from http://bluebirdjs.com/docs/support.html)

Please answer the questions the best you can:

1) What version of bluebird is the issue happening on?

2) What platform and version? (For example Node.js 0.12 or Google Chrome 32)

3) Did this issue happen with earlier version of bluebird?

(Write description of your issue here, stack traces from errors and code that reproduces the issue are helpful)

