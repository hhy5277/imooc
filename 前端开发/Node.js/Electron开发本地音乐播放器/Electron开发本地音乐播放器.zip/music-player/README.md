# Simple music player

**本项目使用 Electron 完成了一个简单的本地音乐播放器**

使用本项目

第一步安装依赖

```bash
npm install
```

本地运行项目

```bash
npm start
```

项目打包成 App

```bash
npm run dist
```

