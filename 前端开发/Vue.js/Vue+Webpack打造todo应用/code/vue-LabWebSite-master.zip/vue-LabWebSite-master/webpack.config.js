/**
 * Created by lhy on 18-2-13.
 */
const webpack=require('webpack');
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');

const webpackConfig = module.exports = {};
// input
webpackConfig.entry = {
    lab: path.resolve(__dirname,'./src/lab.js') // main
};
// output
webpackConfig.output = {
    path: path.resolve(__dirname, 'dist'),
    filename: '[name].js'
};
// loader
// loader
webpackConfig.module = {
    rules: [
        {
            test: /\.css$/,
            use: ExtractTextPlugin.extract({
                fallback: "style-loader",
                use: "css-loader",
            }),
        },
        {
            test: /\.vue$/,
            loader: 'vue-loader',
        },
        {
            test: /\.js$/,
            loader: 'babel-loader',
            exclude: /node_modules/,
        },
        {
            test: /\.(eot(|\?v=.*)|woff(|\?v=.*)|woff2(|\?v=.*)|ttf(|\?v=.*)|svg(|\?v=.*))$/,
            loader: 'file-loader',
            options: { name: 'fonts/[name].[ext]' },
        },
        {
            test: /\.(png|jpg|gif)$/,
            loader: 'file-loader',
            options: {
                name: '[name].[ext]',
                outputPath: 'images/'
            }
        }
    ]
};

webpackConfig.plugins = [
    // make index.html
    new HtmlWebpackPlugin({
        template: './src/index.html',
        filename:'index.html',
        inject:'body',
        favicon: './src/images/titleLogo.ico'
    }),
    new ExtractTextPlugin({
        filename: 'lab.css'
        // disable: false,
        // allChunks: true
    })
];



