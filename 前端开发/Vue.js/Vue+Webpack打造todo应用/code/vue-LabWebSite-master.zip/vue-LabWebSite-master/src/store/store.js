/**
 * Created by lhy on 18-2-26.
 */
import Vue from 'vue'; // get vue
import Vuex from 'vuex';
Vue.use(Vuex);

//注意
//1:这里并不需要将axios添加到Vue原型上，直接使用axios这个对象发起请求即可
import axios from 'axios'

//2:如果画蛇添足的将axios添加到Vue的原型或者Vuex的原型或者说Vuex.Store的原型上即
// 添加到Vuex.Store的原型：Vuex.Store.prototype.axios1=axios;
// 添加到Vuex的原型：Vuex.prototype.axios1=axios;
// 利用vue-axios添加到Vue的原型：
// import VueAxios from 'vue-axios'
// Vue.use(VueAxios, axios);//https://www.npmjs.com/package/vue-axios
// 上述方法在get请求的时候要相应的调整代码获取axios这个对象

// 3：Vuex并非是Vue的实例，将alert(Vuex instanceof Vue);添加到getYears可得为false

const state={
    years:[],
    fronts:[],
    yearSelected:"2017年",
    yearDataStatus:true,
    yearDataContent:[],
    frontSelected:"空间光通信",
    frontDataStatus:true,
    frontDataContent:[]
};

const getters={

};

const mutations={
    updateYears(state,data){
        state.years=data;
    },
    updateFronts(state,data){
        state.fronts=data;
    },
    selectYear(state,data){
        state.yearSelected=data;
    },
    selectFront(state,data){
        state.frontSelected=data;
    },
    updateYearDataStatus(state,data){
        state.yearDataStatus=data;
    },
    updateFrontDataStatus(state,data){
        state.frontDataStatus=data;
    },
    updateYearDataContent(state,data){
        state.yearDataContent=data;
    },
    updateFrontDataContent(state,data){
        state.frontDataContent=data;
    }
};

const actions={
    getMenu(context,data){
        //与vue组件中的methods等等一样this指向store
        let menuPath='../statics/data/'+data+'.json';
        axios.get(menuPath).then((response)=>{
            context.commit(data=="years"?'updateYears':'updateFronts',response.data[data]);
        });
    },
    //利用axios获取学术论文或者科研前端页面的json数据
    getDataContent(context,data){
        //data参数数组，data[0]为json文件名，data[1]为选择的导航内容：学术论文或者科研前端
        let dataPath='../statics/data/'+data[0]+'.json';
        axios.get(dataPath).then((response)=>{
            if(response.data.status==404){
                context.commit(data[1]=='学术论文'?'updateYearDataStatus':'updateFrontDataStatus',false);
            }
            else{
                context.commit(data[1]=='学术论文'?'updateYearDataStatus':'updateFrontDataStatus',true);
                context.commit(data[1]=='学术论文'?'updateYearDataContent':'updateFrontDataContent',response.data);
            }
        })
    }
};

const store=new Vuex.Store({
    state,
    getters,
    mutations,
    actions
});

export default store;