/**
 * Created by lhy on 18-2-12.
 */
import Vue from 'vue';
import VueRouter from 'vue-router';

import Home from '../views/home/home.vue';
import Aboutus from '../views/aboutus/aboutus.vue';
import Direction from '../views/direction/direction.vue';
import Frontend from '../views/frontend/frontend.vue';
import Links from '../views/links/links.vue';
import Paperpatent from '../views/paperpatent/paperpatent.vue';
import Achievements from '../views/achievements/achievements.vue';
import News from '../views/news/news.vue';


Vue.use(VueRouter);
const routes=[
    {path:'/',component:Home},
    {path:'/aboutus',component:Aboutus},
    {path:'/direction',component:Direction},
    {path:'/frontend',component:Frontend},
    {path:'/links',component:Links},
    {path:'/paperpatent',component:Paperpatent},
    {path:'/achievements',component:Achievements},
    {path:'/news',component:News}
];
const router=new VueRouter({routes});

export default router;