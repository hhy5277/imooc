/**
 * Created by lhy on 18-2-10.
 */
import 'font-awesome/css/font-awesome.css';
import Vue from 'vue'; // get vue
import Lab from './lab.vue'; // get root module
import router from './router/router.js';
import store from './store/store.js';


import axios from 'axios'
//利用vue-axios进行全局注册，如果不想利用这个插件可以把'axios'加到'Vue'的原型中:Vue.prototype.$axios = axios;
//给Vue原型添加属性：Vue.prototype.[属性名]=value;
//如果不将axios添加到Vue的原型上，则需要在每个vue组件中都需要将axios对象import，而不能直接使用axios
//将axios添加到Vue的原型上的好处是，每个vue组件都是vue实例所以能够继承vue原型上的公有属性
import VueAxios from 'vue-axios'
Vue.use(VueAxios, axios);//https://www.npmjs.com/package/vue-axios


const lab = new Vue({
    //路由配置，作用：与render函数的关系
    router,
    store,
    render: h => h(Lab),
}).$mount('#lab');