<template>
    <div class="page-wrapper">
        <div class="page-nav">
        <h2>学术论文</h2>
        <ul>
            <li v-for="item in years"  @click="showPaperAndPosition(item.id)">
                <a href="javascript:">
                    <span class="fa fa-hand-o-right">&nbsp;&nbsp;{{item.year}}</span>
                </a>
            </li>
        </ul>
        </div>
        <div class="page-position"><p>学术论文&nbsp;&nbsp;&gt;&nbsp;&nbsp;{{position}}</p></div>
        <div class="page-content">
            <div v-if="paperGot">
              <h1>{{paperContent.message}}</h1>
              <div v-for="item in paperContent.papers">
                <hr>
                <strong>{{item.title}}</strong>
                <p>{{item.authors}}</p>
                <p>{{item.abstract}}</p>
              </div>
            </div>
            <div v-else>
              <h1>I'm sorry, the page is being maintained!!!</h1>
            </div>
        </div>
    </div>
</template>
<style>
.page-wrapper{
    width: 900px;
    height:572px;
    position:relative;
    margin: 20px auto;
    border: 1px solid #B2B9BD;
    background-color: #FFFFFF;
    overflow:hidden;
}
.page-nav{
    float:left;
    width:17.7%;
    height:500px;
    margin:6px;
    padding: 40px 20px 20px 20px;
    background-color: #B2B9BD;
}
.page-nav h2{
    text-align:center;
    background-color: #f2f2f2;
}
.page-nav ul{
    padding:0;
    margin:5px 0;
    background-color:#fff;
}
.page-nav li{
    list-style:none;
    font-size:1.3em;
    margin-top: 13px;
    padding-bottom: 8px;
    padding-top: 8px;
    padding-left: 28px;
}

.page-nav span:hover{
     font-size:1.2em;
     color:black;
 }

.page-position{
    float:left;
    width:73.3%;
    padding:0;
    margin:10px;
}
.page-position p{
    padding-left:10px;
    border-left: 10px solid #c2bbb9;
    border-bottom:2px solid #006389;
}
.page-content{
    float:left;
    width:73.3%;
    height:491px;
    padding:0;
    margin:10px;
    overflow-y:scroll;
}
.page-content p{
    text-align:justify
}
.page-content hr{
    display:block;
}
.page-content strong{
    display: block;
    margin-top: 28px;
    font-size: 18px;
}
</style>