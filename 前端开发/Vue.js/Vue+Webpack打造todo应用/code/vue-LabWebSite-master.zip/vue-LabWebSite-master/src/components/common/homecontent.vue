<template>
    	<div id="content">
    		<div class="post">
    			<h2 class="title"><a :href="paper.link" target="_blank">{{paper.title}}</a></h2>
    			<p class="posted">Author：{{paper.author}} </p>
    			<div class="entry">
    				<p class="img-margin"><img :src="paper.pic" width="540" height="145" alt="" /></p>
    				<strong>Abstract</strong>
    				<p>&nbsp;&nbsp;&nbsp;&nbsp;{{paper.abstract}}<p>
    				<div class="meta">
    					<p>
    						<span class="listed">Posted in&nbsp;<a :href="paper.publishlink" target="_blank">{{paper.publish}}</a></span>
    						<span class="tags">KeyWords:&nbsp;{{paper.keywords}}</span>
    						<span class="comments">引用数:&nbsp;{{paper.referencecount}}</span>
    					</p>
    				</div>
    			</div>
    		</div>
    	</div>
</template>
<script>
export default{
    data:()=>({
        paper:[]
    }),
    mounted:function(){
        this.$nextTick(function () {
            this.getData();
        })
    },
    methods:{
        getData:function(){
            this.$http.get('../statics/data/todayPaper.json').then((response) => {
              this.paper=(response.data.result)[0];
            })
        }
    }
}
</script>
<style>
#content {
	float: left;
	width: 540px;
	padding: 25px 30px 0px 30px;
}
.post {
	overflow: hidden;
}

.post .title {
	display: block;
	margin: 0px;
	padding: 0px 0px 0px 0px;
	letter-spacing: 2px;
	font-size: 25px;
	color: #2E2E2E;
	text-align:justify
}

.post .entry>p{
    margin-top:13px;
    text-align:justify
}

.post .img-style1 {
	margin-bottom: 20px;
}

.post .posted {
	margin-top: -5px;
	padding: 10px 0px 0px 0px;
	font-family: 'Abel', sans-serif;
	font-size: 16px;
	color: #A9A9A9;
}

.post .title a {
    text-decoration:none
}

.post .meta {
	overflow: hidden;
	display: block;
	height: 50px;
	margin-top: 30px;
	padding: 0px 20px;
	border: 1px solid #CDCDCD;
	box-shadow: inset 0px 0px 1px 1px rgba(255, 255, 255, 1);
	background: url(../../images/meta-bg.jpg) repeat-x left top;
	text-shadow: 1px 2px 0px rgba(255, 255, 255, 1);
	font-family: 'Abel', sans-serif;
	font-size: 13px;
	font-weight: 400;
	color: #535353;
}

.post .meta a {
	color: #535353;
}

.post .meta .listed {
	float: left;
	padding-right: 25px;
	line-height: 50px;
	background: url(../../images/meta-separator-bg.png) no-repeat right 50%;
}

.post .meta .tags {
	float: left;
	padding-left: 20px;
	line-height: 50px;
}

.post .meta .comments {
	float: right;
	line-height: 50px;
}

.post .img-margin {
	margin-bottom: 20px;
}
.post strong{
    font-size:16px
}
</style>