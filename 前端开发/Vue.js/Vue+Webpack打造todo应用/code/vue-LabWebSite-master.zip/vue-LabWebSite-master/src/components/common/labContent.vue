<template>
    <div class="content-wrapper">
        <div class="content-nav">
        <h2>{{menuContent}}</h2>
        <ul>
            <li v-for="item in menuMessage" @click="getContent([item.id,menuContent])">
                <a href="javascript:">
                    <span class="fa fa-hand-o-right">&nbsp;&nbsp;{{item.id}}</span>
                </a>
            </li>
        </ul>
        </div>
        <div class="content-position"><p>{{menuContent}}&nbsp;&nbsp;&gt;&nbsp;&nbsp;{{menuSelected}}</p></div>
        <div class="content-main">
            <div v-if="dataStatus">
              <h1>{{dataContent.message}}</h1>
              <div v-for="item in dataContent.papers">
                <hr>
                <strong>{{item.title}}</strong>
                <p>{{item.authors}}</p>
                <p>{{item.abstract}}</p>
              </div>
            </div>
            <div v-else>
              <h1>I'm sorry, the page is being maintained!!!</h1>
            </div>
        </div>
    </div>
</template>
<script>
export default{
    //menuContent:父组件传入的导航内容
    //menuMessage:父组件将vuex中的下拉列表内容传入该子组件
    //menuSelected:父组件将vuex中选择的下拉列表内容，用于记录位置
    //dataStatus：获取数据的完成情况
    //dataContent：数据内容
    props:['menuContent','menuMessage','menuSelected','dataStatus','dataContent'],
    mounted: function () {
          this.$nextTick(function () {
            // Code that will run only after the
            // entire view has been rendered
            this.getContent([this.menuSelected,this.menuContent]);
          })
    },
    methods:{
        getContent(data){
            this.$store.commit(data[1]=='学术论文'?'selectYear':'selectFront',data[0]);
            this.$store.dispatch('getDataContent',data);
        }
    }
}
</script>
<style>
.content-wrapper{
    width: 900px;
    height:572px;
    position:relative;
    margin: 20px auto;
    border: 1px solid #B2B9BD;
    background-color: #FFFFFF;
    overflow:hidden;
}
.content-nav{
    float:left;
    width:17.7%;
    height:500px;
    margin:6px;
    padding: 40px 20px 20px 20px;
    background-color: #B2B9BD;
}
.content-nav h2{
    text-align:center;
    background-color: #f2f2f2;
}
.content-nav ul{
    padding:0;
    margin:5px 0;
    background-color:#fff;
}
.content-nav li{
    list-style:none;
    font-size:1.3em;
    margin-top: 13px;
    padding-bottom: 8px;
    padding-top: 8px;
    padding-left: 28px;
}

.content-nav a:hover{
     font-size:1.1em;
     color:black;
 }

.content-position{
    float:left;
    width:73.3%;
    padding:0;
    margin:10px;
}
.content-position p{
    padding-left:10px;
    border-left: 10px solid #c2bbb9;
    border-bottom:2px solid #006389;
}
.content-main{
    float:left;
    width:73.3%;
    height:491px;
    padding:0;
    margin:10px;
    overflow-y:scroll;
}
.content-main p{
    text-align:justify
}
.content-main hr{
    display:block;
}
.content-main strong{
    display: block;
    margin-top: 28px;
    font-size: 18px;
}
</style>