<template>
    <div id="lab-header">
    	<div id="logo">
    		<h1><a href="#">空间光通信实验室</a></h1>
    		<p>411</p>
    	</div>
    	<div id="search">
    		<form method="get" action="">
   				<fieldset>
 					<input type="text" name="s" id="search-text" title="Search our website" size="15" value="" />
    				<input type="submit" id="search-submit" value="GO" />
   				</fieldset>
 			</form>
 		</div>
    </div>
</template>

<script>

</script>

<style>
#lab-header {
	overflow: hidden;
	width: 840px;
	height: 169px;
	margin: 0px auto;
	padding: 0px 30px;
	background: url(../../images/header-bg.jpg) no-repeat left top;
}
#logo {
	float: left;
	width: 500px;
	height: 69px;
	padding-top: 100px;
}

#logo h1, #logo p {
	float: left;
	margin: 0px;
	line-height: normal;
}

#logo h1 a {
	display: block;
	padding-right: 13px;
	letter-spacing: -1px;
	text-decoration: none;
	text-shadow: 1px 1px 1px #151A1D;
	font-size: 34px;
	color: #FFFFFF;
}

#logo p {
	display: block;
	padding-top: 10px;
	letter-spacing: -1px;
	text-shadow: 1px 1px 1px #2C373B;
	font-size: 18px;
	font-family: 'Abel', sans-serif;
	color: #778893;
}
#search {
	float: right;
	width: 270px;
	height: 175px;
}

#search form {
	margin: 0px;
	padding: 108px 0px 0px 0px;
}

#search fieldset {
	margin: 0;
	padding: 0;
	border: none;
}

#search input.blank {
	color: #7C7768;
}

#search-text {
	outline: none;
	width: 220px;
	height: 32px;
	border: none;
	padding: 0px 0px 0px 10px;
	background: none;
	line-height: 32px;
	font-family: 'Abel', sans-serif;
	font-size: 16px;
	font-weight: 400;
	color: #566B73;
}

#search-submit {
	display: none;
}
</style>