<template>
    <div id="page">
        <home-content></home-content>
        <home-sidebar></home-sidebar>
    </div>
</template>
<script>
import homecontent from "./homecontent.vue";
import homesidebar from "./homesidebar.vue";
export default{
    components:{
        'home-content':homecontent,
        'home-sidebar':homesidebar
    }
}
</script>
<style>
#page {
	overflow: hidden;
	width: 900px;
	margin: 0px auto;
	padding: 0px 0px 40px 0px;
	background: #FFFFFF url(../../images/page-content-bg.png) repeat-y center top;
	border: 1px solid #B2B9BD;
	box-shadow: 0px 0px 3px 2px rgba(0, 0, 0, .1);
	border-radius: 5px;
}
</style>