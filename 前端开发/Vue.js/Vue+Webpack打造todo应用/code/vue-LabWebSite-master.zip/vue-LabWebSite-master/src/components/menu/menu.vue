<template>
    <div id="lab-menu">
    	<ul>
    		<li :class={active:isHome}>
    		    <router-link to="/">
    		        <span><i class="fa fa-home">&nbsp;首页</i></span>
    		    </router-link>
    		</li>
    		<li :class={active:isDirection}>
    		    <router-link to="/direction">
    		        <span><i class="fa fa-send">&nbsp;科研方向</i></span>
    		    </router-link>
    		</li>
    		<li :class={active:isPaperpatent} @mouseover="downMenuBlock(2)" @mouseout="downMenuNone">
    		    <router-link to="/paperpatent">
    		        <span><i class="fa fa-file-o">&nbsp;学术论文</i></span>
    		    </router-link>
    		    <ul class="down-menu" :class="{'down-menu-none':!(menuNum[2]),'down-menu-block':menuNum[2]}">
    		        <li v-for="item in years" @click="getContent([item.id,'学术论文'])">
    		            <router-link to="/paperpatent" href="javascript:">{{item.id}}</router-link>
    		        </li>
    		    </ul>
    		</li>
    		<li :class={active:isFrontend} @mouseover="downMenuBlock(3)" @mouseout="downMenuNone">
    		    <router-link to="/frontend">
    		        <span><i class="fa fa-mortar-board">&nbsp;科研前端</i></span>
    		    </router-link>
    		    <ul class="down-menu" :class="{'down-menu-none':!(menuNum[3]),'down-menu-block':menuNum[3]}">
    		        <li v-for="item in fronts" @click="getContent([item.id,'科研前端'])">
    		            <router-link href="javascript:" to="/frontend">{{item.id}}</router-link>
    		        </li>
    		    </ul>
    		</li>
    		<li :class={active:isAboutus}>
    		    <router-link to="/aboutus">
    		        <span><i class="fa fa-user mortar-board">&nbsp;关于我们</i></span>
    		    </router-link>
    		</li>
    		<li :class={active:isLinks}>
    		    <router-link to="/links">
    		        <span><i class="fa fa-paperclip">&nbsp;相关链接</i></span>
    		    </router-link>
    		</li>
    	</ul>
    </div>
</template>

<script>
import { mapState } from 'vuex';
export default{
    data: ()=>({
        isHome:true,
        isDirection:false,
        isPaperpatent:false,
        isFrontend:false,
        isAboutus:false,
        isLinks:false,
        menuNum:[false,false,false,false,false,false],
    }),
    created:function(){
        this.getAllMenu('years');
        this.getAllMenu('fronts');
    },
    mounted: function () {
      this.$nextTick(function () {
        // Code that will run only after the
        // entire view has been rendered
        const uri=this.$route.path;
        switch(uri){
            case '/':{
                this.isHome=true;
                this.isDirection=false;
                this.isPaperpatent=false;
                this.isFrontend=false;
                this.isAboutus=false;
                this.isLinks=false;
                break;
            }
            case '/direction':{
                this.isHome=false;
                this.isDirection=true;
                this.isPaperpatent=false;
                this.isFrontend=false;
                this.isAboutus=false;
                this.isLinks=false;
                break;
            }
            case '/paperpatent':{
                this.isHome=false;
                this.isDirection=false;
                this.isPaperpatent=true;
                this.isFrontend=false;
                this.isAboutus=false;
                this.isLinks=false;
                break;
            }
            case '/frontend':{
                this.isHome=false;
                this.isDirection=false;
                this.isPaperpatent=false;
                this.isFrontend=true;
                this.isAboutus=false;
                this.isLinks=false;
                break;
            }
            case '/aboutus':{
                this.isHome=false;
                this.isDirection=false;
                this.isPaperpatent=false;
                this.isFrontend=false;
                this.isAboutus=true;
                this.isLinks=false;
                break;
            }
            case '/links':{
                this.isHome=false;
                this.isDirection=false;
                this.isPaperpatent=false;
                this.isFrontend=false;
                this.isAboutus=false;
                this.isLinks=true;
                break;
            }
        }
      })
    },
    methods:{
        downMenuBlock(n){
            this.menuNum=[false,false,false,false,false,false];
            this.menuNum[n]=true;
        },
        downMenuNone(){
            this.menuNum=[false,false,false,false,false,false];
        },
        getAllMenu(data){
            this.$store.dispatch('getMenu',data);
        },
        getContent(data){
            this.downMenuNone();//选择年份之后，应隐藏下拉列表
            this.$store.commit(data[1]=='学术论文'?'selectYear':'selectFront',data[0]);
            this.$store.dispatch('getDataContent',data);
        }
    },
    computed:mapState({
        years:state=>state.years,
        fronts:state=>state.fronts
    })
}

</script>

<style>
#lab-menu {
	width: 830px;
	height: 70px;
	margin: 0px auto;
	padding: 0px 40px;
	background: url(../../images/menu-bg.png) no-repeat left top;
}

#lab-menu>ul {
	margin: 0px;
	padding: 0px;
	list-style: none;
	line-height: normal;
}

#lab-menu>ul>li {
	float: left;
	margin-right: 10px;
	padding-left: 5px;
}

#lab-menu>ul>li>a {
	display: block;
	float: left;
	height: 67px;
	padding-right: 5px;
	line-height: 67px;
	text-decoration: none;
	text-shadow: 1px 1px 1px #171D21;
	font-family: 'Abel', sans-serif;
	font-size: 18px;
	font-weight: 400;
	color: #FFFFFF;
}

#lab-menu a:hover {
	text-decoration: underline;
}

#lab-menu span {
	display: inline-block;
	height: 67px;
	padding: 0px 15px 0px 15px;
}

#lab-menu li.active {
	background: url(../../images/menu-bgleft.png) no-repeat left top;
}

#lab-menu li.active>a {
	background: url(../../images/menu-bgright.png) no-repeat right top;
	text-shadow: 1px 1px 1px #04435D;
	color: #FFFFFF;
}

#lab-menu li.active span{
	background: url(../../images/menu-repeatbg.png) repeat-x left top;
}

.down-menu{
    width:120px;
    margin:67px 0 0 0;
    padding:0;
    z-index:1000;
    position:absolute;
    box-shadow: 0px 0px 3px 2px rgba(0, 0, 0, .1);
}

.down-menu-none{
    display:none;
}

.down-menu-block{
    display:block;
}

.down-menu li{
    list-style:none;
}
.down-menu li a{
    display: block;
    padding:0;
    margin:0;
    width:120px;
    height:50px;
	text-decoration: none;
	text-shadow: 1px 1px 1px #171D21;
	font-family: 'Abel', sans-serif;
	font-size: 18px;
	font-weight: 400;
	color: #FFFFFF;
	text-align:center;
	line-height:50px;
	background-color:#243238;
}

.down-menu li a:hover{

}
</style>