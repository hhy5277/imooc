<template>
    <div id="banner" @mouseover="stop" @mouseout="play">
    	<div class="image-border" :style="{left:imgLeft+'px'}">
    	    <a href="#">
    	        <img :src="imagesLast.picUrl" alt="" />
    	    </a>
    	    <a href="#" v-for="item in images">
    	        <img :src="item.picUrl" alt="" />
    	    </a>
    	    <a href="#">
    	        <img :src="imagesFirst.picUrl" alt="" />
    	    </a>
    	</div>
    	<div id="buttons">
            <span v-for="(item,index) in images" :key="index" @click="selectIndex(index)" :class="{on:indexArray[index]}" ></span>
        </div>
        <a id="prev" class="arrow" @click="prevImages" onselectstart="return false">&lt;</a>
        <a id="next" class="arrow" @click="nextImages" onselectstart="return false">&gt;</a>
        <div class="coverleft"></div>
        <div class="coverright"></div>
    </div>
</template>
<script>
export default{
    data:()=>({
        images:[],
        imgLeft:-900,
        imgIndex:1,
        indexArray:[],
        len:Number,
        scroll:false,
        timer:{},
        imagesLast:[],
        imagesFirst:[]
    }),
    created(){
        //created实例已经创建完成之后被调用
        //由于是getImages方法用到了axios，axios是异步的，所以务必将所有的数据获取操作放在this.$http.get().then里面，否则会出现undefined的情况
        //第5行可以改为:src="images[len-1]&&images[len-1].picUrl"用于解决axios还没返回数据出现undefined的情况
        this.getImages();
    },
    mounted(){
        this.$nextTick(function () {
            this.play();
        })
    },
    methods:{
        showButton(){
            for(let i=0;i<this.len;i++){
               this.indexArray[i]=false;
            }
            this.indexArray[this.imgIndex-1]=true;
        },
        prevImages(){
            if(this.scroll){return;}
            if(this.imgIndex==1){
                this.imgIndex=5;
            }
            else{
                this.imgIndex=this.imgIndex-1;
            }
            //this.changeLeft(900);//methods方法调用一个methods方法用this.FUNC
            this.scrollControl(900);
            this.showButton();
        },
        nextImages(){
            if(this.scroll){return;}
            if(this.imgIndex==5){
                this.imgIndex=1;
            }
            else{
                this.imgIndex=this.imgIndex+1;
            }
            //this.changeLeft(-900);//methods方法调用一个methods方法用this.FUNC
            this.scrollControl(-900);
            this.showButton();
        },
        selectIndex(index){
            if(this.scroll){return;}
            if(this.imgIndex==index+1){
                return ;
            }
            else{
            for(let i=0;i<this.len;i++){
               this.indexArray[i]=false;
            }
            this.indexArray[index]=true;
            this.imgLeft=-900*(index+1);
            }
        },
        scrollControl(offset){
            let time=800,interval=10,speed=offset/(time/interval),leftEnd=this.imgLeft+offset;
            this.scroll=true;
            let go=()=>{
                if((speed>0&&this.imgLeft<leftEnd)||(speed<0&&this.imgLeft>leftEnd)){
                    this.imgLeft=this.imgLeft+speed;
                    setTimeout(go,interval);
                }
                else{
                    this.imgLeft=leftEnd;
                    if(this.imgLeft>-900)
                    {
                        this.imgLeft=-4500;
                    }
                    if(this.imgLeft<-4500)
                    {
                        this.imgLeft=-900;
                    }
                    this.scroll=false;
                }
            }
            go();
        },
        play(){
            this.timer = setInterval(() =>{
                this.nextImages();
            }, 3000);
        },
        stop(){
            clearInterval(this.timer);
        },
        getImages(){
            this.$http.get('../statics/data/todayImages.json').then((response)=>{
                this.images=response.data.images;
                this.len=this.images.length;
                for(let i=0;i<this.len;i++){
                   this.indexArray[i]=false;
                }
                this.indexArray[this.imgIndex-1]=true;
                this.imagesLast=this.images[this.len-1];
                this.imagesFirst=this.images[0];
            });
        }
    }
}

</script>
<style>
#banner {
    overflow: hidden;
    width: 900px;
    height:283px;
    position:relative;
    margin: 20px auto;
    background-color: #FFFFFF;
    border: 1px solid #B2B9BD;
    border-radius: 5px;
    box-shadow: 0px 0px 3px 2px rgba(0, 0, 0, .1);
}
#banner .image-border {
    padding: 15px 0;
    width:6300px;
    height:253px;
    position:absolute;
    z-index:1;
}
#banner .image-border img{
    float:left;
    padding:0 15px;
}
#banner:hover .arrow { display: block;}
.arrow {
    cursor: pointer;
    display: none;
    line-height: 39px;
    text-align: center;
    font-size: 36px;
    font-weight: bold;
    width: 40px;
    height: 40px;
    position: absolute;
    z-index: 2;
    top: 122px;
    background-color: RGBA(0,0,0,.3);
    color: #fff;
    text-decoration: none;
}
.arrow:hover {
    background-color: RGBA(0,0,0,.7);
}
#prev { left: 20px;}
#next { right: 20px;}
#buttons {
    position: absolute;
    height: 10px;
    width: 100px;
    z-index: 2;
    bottom: 25px;
    left: 400px;
}
#buttons span {
    cursor: pointer;
    float: left;
    border: 1px solid #fff;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #333;
    margin-right: 5px;
}
#buttons .on {  background: orangered;}
#banner .coverleft{
    position:absolute;
    z-index:2;
    left:0;
    width:15px;
    height:283px;
    background-color:#fff;
}
#banner .coverright{
    position:absolute;
    z-index:2;
    right:0px;
    width:15px;
    height:283px;
    background-color:#fff;
}
</style>