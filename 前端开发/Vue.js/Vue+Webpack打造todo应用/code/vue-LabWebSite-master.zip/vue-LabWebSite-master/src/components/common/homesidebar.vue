<template>
    	<div id="sidebar">
    		<div>
    			<h2 class="title"><span class="fa fa-newspaper-o">&nbsp;&nbsp;新闻动态</span><router-link to="/news" class="more" href="#">more</router-link></h2>
    			<ul>
    				<li v-for="(ne,index) in news" :class="{first:(index==0)}">
    				    <a :href="ne.link" :title="ne.title">
    				        <span class="fa fa-caret-right">&nbsp;{{ne.title}}</span>
    				    </a>
    				</li>
    			</ul>
    		</div>
    		<div>
    			<h2 class="title"><span class="fa fa-book">&nbsp;&nbsp;成果</span><router-link to="/achievements" class="more" href="#">more</router-link></h2>
    			<ul>
    				<li v-for="(ach,index) in achievements" :class="{first:(index==0)}">
    				    <a :href="ach.link" :title="ach.title" >
    				        <span class="fa fa-caret-right">&nbsp;{{ach.title}}</span>
    				    </a>
    				</li>
    			</ul>
    		</div>
    		<div>
    			<h2 class="title"><span class="fa fa-link">&nbsp;&nbsp;友情链接</span></h2>
    			<div class="links">
                    <a href="http://www.bupt.edu.cn/" target="_blank"><img src="../../images/linksBUPThome.gif" alt="北京邮电大学主页" title="北京邮电大学主页"/></a>
                    <a href="https://bbs.byr.cn" target="_blank"><img src="../../images/linksBUPTBYR.gif" title="北邮人论坛" alt="北邮人论坛"/></a>
                    <a href="http://job.bupt.edu.cn/" target="_blank"><img src="../../images/linksBUPTjobs.jpg" alt="北京邮电大学就业信息网" title="北京邮电大学就业信息网"/></a>
                    <a href="http://lib.bupt.edu.cn" target="_blank"><img src="../../images/linksBUPTlib.png" alt="北京邮电大学图书馆" title="北京邮电大学图书馆"/></a>
                    <a href="http://grs.bupt.edu.cn/" target="_blank"><img src="../../images/linksBUPTGS.jpg" alt="北京邮电大学研究生院" title="北京邮电大学研究生院"/></a>
                </div>
    		</div>
    	</div>
</template>
<script>
export default{
    data:()=>({
        news:[],
        achievements:[]
    }),
    mounted:function(){
        this.$nextTick(function () {
            this.getNews();
            this.getAchievements();
        })
    },
    methods:{
        getNews:function(){
            this.$http.get('../statics/data/todayNews.json').then((response) => {
              this.news=response.data.news;
            })
        },
        getAchievements:function(){
            this.$http.get('../statics/data/todayAchievements.json').then((response) => {
              this.achievements=response.data.achievements;
            })
        }
    }
}
</script>
<style>
#sidebar {
	float: right;
	width: 300px;
	text-shadow: 1px 1px 0px #FFFFFF;
}

#sidebar .title {
	display: block;
	width: 240px;
	height: 59px;
	margin-bottom: 20px;
	padding: 0px 30px 0px 30px;
	background: url(../../images/sidebar-title-bg.png) no-repeat right top;
	line-height: 59px;
	text-shadow: 1px 1px 1px #161C1F;
	font-family: 'Abel', sans-serif;
	font-size: 18px;
	font-weight: 400;
	color: #FFFFFF;
}

#sidebar p {
	margin: 0px 30px;
}

#sidebar ul {
	margin: 0px;
	padding: 0px 0px 0px 0px;
	list-style: none;
}

#sidebar li {
	margin: 0px 30px 0px 30px;
	padding: 10px 0px 10px 0px;
	background: url(../../images/sidebar-separator-bg.png) repeat-x left top;
}

#sidebar li a {
	display: block;
	overflow:hidden;
	white-space:nowrap;
	text-decoration:none;
}

#sidebar .first {
	background: none;
}

#sidebar .links{
	margin: 0px 30px 0px 30px;
	padding: 10px 0px 10px 0px;
}
#sidebar .links img{
	padding: 2px 0px;
}
.more{
    display:block;
    float: right;
    text-decoration: none;
    color: #fff;
    font-size: 15px;
}
.more:hover{
    color: #476c8b;
}
</style>