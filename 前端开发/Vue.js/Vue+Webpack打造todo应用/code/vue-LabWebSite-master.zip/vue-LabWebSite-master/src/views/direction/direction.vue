<template>
<div>
    <lab-header></lab-header>
    <lab-menu></lab-menu>
    <div class="direction-wrapper">
        <div class="direction-title"><p>科研方向&nbsp;&nbsp;&gt;</p></div>
        <div class="direction-title"><h1>I'm sorry, the page is being maintained!!!</h1></div>
    </div>
</div>
</template>

<script>
import header from '../../components/header/header.vue';
import menu from '../../components/menu/menu.vue';
export default{
    components:{
        'lab-header':header,
        'lab-menu':menu
    },
    methods:{

    }
}
</script>

<style>
.direction-wrapper{
    width: 900px;
    height:572px;
    position:relative;
    margin: 20px auto;
    border: 1px solid #B2B9BD;
    background-color: #FFFFFF;
    overflow:hidden;
}
.direction-title{
    float:left;
    width:73.3%;
    padding:0;
    margin:10px;
}
.direction-title p{
    padding-left:10px;
    border-left: 10px solid #c2bbb9;
    border-bottom:2px solid #006389;
}
</style>