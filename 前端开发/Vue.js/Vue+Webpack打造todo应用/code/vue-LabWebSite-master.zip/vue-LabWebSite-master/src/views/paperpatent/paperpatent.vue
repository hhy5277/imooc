<template>
<div>
    <lab-header></lab-header>
    <lab-menu></lab-menu>
    <lab-content
        menuContent='学术论文'
        :menuMessage='years'
        :menuSelected='yearSelected'
        :dataStatus='yearDataStatus'
        :dataContent='yearDataContent'>
    </lab-content>
</div>
</template>

<script>
//components中的驼峰式命名在字符串模板<template>中自动转换成短横线分隔式命名
//这里是父组件向子组件传送数据，所以用到了props，但是对后台的数据有格式要求,解决的方法是将不相同的部分封装成不同的子组件
//比如labContent中的内容显示的部分，有的是论文形式的数据，有的是非论文形式的数据，所以可以再分出几个用于呈现不同形式的内容的子组件
//如果是插入整个标签则用slot
import header from '../../components/header/header.vue';
import menu from '../../components/menu/menu.vue';
import labContent from '../../components/common/labContent.vue';
import { mapState } from 'vuex';
export default{
    components:{
        'lab-header':header,
        'lab-menu':menu,
         labContent
    },
    computed:mapState({
        years:state=>state.years,
        yearSelected:state=>state.yearSelected,
        yearDataStatus:state=>state.yearDataStatus,
        yearDataContent:state=>state.yearDataContent,
    })
}
</script>

<style>

</style>