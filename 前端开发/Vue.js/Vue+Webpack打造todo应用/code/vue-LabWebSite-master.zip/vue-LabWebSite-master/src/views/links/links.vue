<template>
<div>
    <lab-header></lab-header>
    <lab-menu></lab-menu>
    <div class="links-wrapper">
        <div class="links-position"><p>相关链接&nbsp;&nbsp;&gt;</p></div>
        <div class="links-journal-wrapper">
            <h2>期刊链接</h2>
            <div class="links-journal">
                <div v-for="item in journal" class="links-journal-show">
                    <a :href="item.link" target="_blank">
                        <img :src="item.picUrl" :alt="item.name" :title="item.name"/>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script>
import header from '../../components/header/header.vue';
import menu from '../../components/menu/menu.vue';
export default{
    data:()=>({
        journal:[]
    }),
    components:{
        'lab-header':header,
        'lab-menu':menu
    },
    mounted: function () {
          this.$nextTick(function () {
            // Code that will run only after the
            // entire view has been rendered
            this.getLinks();
          })
    },
    methods:{
        getLinks(){
            this.$http.get('../statics/data/links.json').then((response)=>{
                this.journal=response.data.journal;
            })
        }
    }
}
</script>

<style>
.links-wrapper{
    width: 900px;
    height:572px;
    position:relative;
    margin: 20px auto;
    border: 1px solid #B2B9BD;
    background-color: #FFFFFF;
    overflow:hidden;
}
.links-position{
    float:left;
    width:100%;
    padding:0;
    margin:10px;
}
.links-position p{
    padding-left:10px;
    border-left: 10px solid #c2bbb9;
    border-bottom:2px solid #006389;
}
.links-journal-wrapper{
    float:left;
    width:100%;
    padding:0;
    margin:0;
    text-align:center;
}
.links-journal{
    position:relative;
    height:450px;
    padding:0;
    margin:10px 4px;
    text-align:center;
    overflow-y:scroll;
}
.links-journal-show{
    float:left;
    margin:20px auto;
    width:33.3%;
}
</style>