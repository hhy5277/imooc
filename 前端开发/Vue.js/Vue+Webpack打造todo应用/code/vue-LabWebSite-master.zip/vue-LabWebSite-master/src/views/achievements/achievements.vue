<template>
<div>
    <lab-header></lab-header>
    <lab-menu></lab-menu>
    <div class="achievements-wrapper">
        <span>
            I'm sorry, the page is being maintained!!!
        </span>
    </div>
</div>
</template>

<script>
import header from '../../components/header/header.vue';
import menu from '../../components/menu/menu.vue';
export default{
    components:{
        'lab-header':header,
        'lab-menu':menu
    },
    methods:{

    }
}
</script>

<style>
.achievements-wrapper{
    width: 900px;
    height:500px;
    position:relative;
    margin: 20px auto;
    border: 1px solid #B2B9BD;
    background-color: #FFFFFF;
}
.achievements-wrapper span{
    display:block;
    font-size:20px;
    font-weight:bold;
    text-align:center;
    padding:50px;
}
</style>