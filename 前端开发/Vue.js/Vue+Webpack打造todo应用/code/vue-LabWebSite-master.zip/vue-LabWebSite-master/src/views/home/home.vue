<template>
<div>
    <lab-header></lab-header>
    <lab-menu></lab-menu>
    <lab-banner></lab-banner>
    <lab-page></lab-page>
</div>
</template>

<script>
import header from '../../components/header/header.vue';
import menu from '../../components/menu/menu.vue';
import banner from '../../components/common/banner.vue';
import page from '../../components/common/page.vue';
export default{
    components:{
        'lab-header':header,
        'lab-menu':menu,
        'lab-banner':banner,
        'lab-page':page
    },
    methods:{

    }
}
</script>

<style>

</style>