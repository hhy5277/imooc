<template>
<div>
    <div id="wrapper">
        <div id="wrapper-bgbtm">
            <div id="wrapper-bgtop">
                <router-view></router-view>
            </div>
        </div>
    </div>
    <div id="footer" class="container">
    	<p>&copy; 411实验室&nbsp;&nbsp;|&nbsp;&nbsp;邮编：888888 &nbsp;&nbsp;|&nbsp;&nbsp;地址 北京海淀区西土城路10号邮电大学</p>
    </div>
</div>
</template>
<style>
@import "./style/common.css";
[v-cloak] {
  display: none;
}
</style>