基于vue的无后台服务器的实验室网页设计
====

        "vue": "^2.5.13",
        "vue-router": "^3.0.1"
        "vuex": "^3.0.1"
        "axios": "^0.18.0"


        doneload文件到本地，安装依赖运行npm run webpack即可