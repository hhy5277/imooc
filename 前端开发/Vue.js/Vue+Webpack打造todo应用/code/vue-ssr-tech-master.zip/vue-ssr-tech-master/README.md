# About
这是慕课网上[Vue+Webpack打造todo应用](https://www.imooc.com/learn/935)课程的源码

# 使用方法
```
git clone git@github.com:dddddd1/vue-ssr-tech.git
```
进入项目目录
```
cd vue-ssr-tech
```
运行
```
npm install
```
然后执行
```
npm run dev
```
开始开发项目

演示地址:http://dbdbdbdb.gitee.io/vue-ssr-tech/dist/
