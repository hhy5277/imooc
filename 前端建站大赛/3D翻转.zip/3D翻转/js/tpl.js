var tpl = "<div class=\"photo photo-center\">" +
		"<div class=\"photo-wrap\">" +
			"<div class=\"side-front side-common\">" +
				"<img src=\"{{src}}\" alt=\"{{desc}}\" width=\"130\" height=\"180\">" +
			"</div>" +
			"<div class=\"side-back side-common\">{{desc}}</div>" +
		"</div>" +
	"</div>";