<h2><strong>HTML5 TWaver 3D机房</strong></h2><p>用html5写的一个3D室内机房效果图，我转载别的。</p><p>直接可以生成跟3D max 一样的真实场景图。可随意拖动、放大、缩小！效果超棒。<br/></p><p><img src="http://img.mukewang.com/55b8619a0001bc5605000240.jpg" style=""/></p><p><img src="http://img.mukewang.com/55b8619a0001a07205000311.jpg" style=""/></p><p><img src="http://img.mukewang.com/55b8619a0001840b05000325.jpg" style=""/></p><p><br/></p>

