var express = require('express');
var router = express.Router();
var util = require('util');
var formidable = require('formidable'); 
var fs = require('fs');

var UPLOAD_FOLDER = '/upload/';

router.get('/', function(req, res, next) {
	res.render('index', {status : '请添加一个文件', errcode : 'info', code : 0, name : '未有上传文件'});
});

router.post('/', function(req, res, next) {
	var form = new formidable.IncomingForm();   		//创建上传表单
    form.encoding = 'utf-8';							//设置编辑
    form.uploadDir = 'res' + UPLOAD_FOLDER;			//设置上传目录
    form.keepExtensions = true;	 						//保留后缀
    //form.maxFieldsSize = 2 * 1024 * 1024;   			//文件大小
    
    var fileName = '';
    form.parse(req, function() {});
    
    form.on('error',function(err){
        res.end(err);
    });
    
    form.on('file', function(name, file) {
	    fileName = file.name;
	    var newPath = form.uploadDir + fileName;
	    fs.renameSync(file.path, newPath); 
	    console.log(file.path);
    });
    
    form.on('progress', function(bytesReceived, bytesExpected) {
    	return;
    });
    
    form.on('end', function() {
    	res.render('index', {status : '上传成功', errcode : 'info', code : 1, name : fileName});
    	return;
    });
});

module.exports = router;
