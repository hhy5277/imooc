var express = require('express');
var router = express.Router();
var path = require('path');
var command = require('../public/script/ffmpeg');

function validateTranslateFile(index, filename) {
	var extname = path.extname(filename);
	if(parseInt(index) === 0 || parseInt(index) === 1 || parseInt(index) === 2) {
		if('.avi' !== extname) {
			return false;
		}
	} else {
		if('.mp4' !== extname) {
			return false;
		}
	}
	return true;
}

router.get('/', function(req, res, next) {
	var index = req.query.index;
	var filename = req.query.filename;
	var flag = validateTranslateFile(index, filename);
	
	if(!flag) {
		res.send('error');
		return;
	}
	
	command(index, filename,function() {
		console.log('file has been converted succesfully');
		res.send('ok');
	});
	
});

module.exports = router;