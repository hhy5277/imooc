(function() {
	var $ = function(id) {
		return document.querySelectorAll(id);
	};

	var fileDom = $('#file')[0];
	var subDom = $('#submit')[0];
	var uploadDOM = $('#upload')[0];
	var statusDOM = $('#status')[0];
	var errcodeDOM = $('#errcode')[0];
	var startDOM = $('#start')[0];
	var codeDOM = $('#code')[0];
	var nameDOM = $('#name')[0];
	var commandDOM = $('#command')[0];
	var liList = $('#oplog ul li');

	function printStatus(msg, flag) {
		if(flag) {
			statusDOM.className = 'error';
		} else {
			statusDOM.className = 'info';
		}
		statusDOM.innerHTML = msg;
	}

	function generateCommand(index) {
		var commands = {
			"0" : "ffmpeg -threads 4 -i %input(avi)% -b 1500k -vcodec libx264 -vpre slow -vpre baseline -g 30 -s %output(mp4)%",
			"1" : "ffmpeg -threads 4 -i %input(avi)% -b 1500k -vcodec libtheora -acodec libvorbis -ab 160000 -g 30 %output(ogg)%",
			"2" : "ffmpeg -threads 4 -i %input(avi)% -b 1500k -vcodec libvpx -acodec libvorbis -ab 160000 -f webm -g 30 %output(webm)%",
			"3" : "ffmpeg -threads 4 -i %input(mp4)% -b 1500k -vcodec libtheora -acodec libvorbis -ab 160000 -g 30 %output(ogg)%",
			"4" : "ffmpeg -threads 4 -i %input(mp4)% -b 1500k -vcodec libvpx -acodec libvorbis -ab 160000 -f webm -g 30 %output(webm)%",
			"5" : "ffmpeg -threads 4 -i %input(mp4)% -r 29.97 -vcodec h264 -flags +loop -cmp +chroma -crf 24 -bt 256k -refs 1 -coder 0 -me_range 16 -subq 5 -partitions +parti4x4+parti8x8+partp8x8 -g 250 -keyint_min 25 -level 30 -qmin 10 -qmax 51 -trellis 2 -sc_threshold 40 -i_qfactor 0.71 -acodec libvo_aacenc -ab 128k -ar 48000 -ac 2 %input(mp4)%"
		};
		return commands[index];
	}

	function vlidateFile(fileList) {
		var length = fileList.length;
		
		if(length === 0 || length > 1){ 
			printStatus("只能添加一个文件", 1);
	        return false; 
	    } 
		
		var type = fileList[0].type;
		if(type !== 'video/avi' && type !== 'video/mp4') {
			printStatus("目前仅支持avi或者mp4格式转码,请选择合适文件上传", 1);
			return false;
		}
		
		return true;
	}

	var _ajax = function(obj) {
		var url = obj.url || '';
		var type = obj.type || 'get';
		var data = obj.data || {};
		if(data) {
			var params = "?";
			for(var key in data) {
				params += (key + '=' + data[key] + '&');
			}
		}
		url = url + params.slice(0, -1);
		var callback = obj.success || function(){};
		var xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function() {
			if (xhr.readyState == 4) {
				if((xhr.status >= 200) && (xhr.status < 300) || xhr.status == 304) {
					var jsonString = xhr.responseText;
					callback(jsonString);
				}
			}
		};
		xhr.open(type, url, true);
		xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest"); 
		xhr.send(null);
	};

	uploadDOM.onclick = function(event) {
		fileDom.click();
	};

	fileDom.addEventListener('change', function(event) {
		event.preventDefault();
		var fileList = event.target.files;
		if(vlidateFile(fileList)) {
			subDom.click();
		} else {
			return;
		}
	});

	//禁止浏览器默认行为
	document.addEventListener('dragleave', function(event) {
		event.preventDefault();
	});

	document.addEventListener('drop', function(event) {
		event.preventDefault();
	});

	document.addEventListener('dragenter', function(event) {
		event.preventDefault();
	});

	document.addEventListener('dragover', function(event) {
		event.preventDefault();
	});

	// 放置文件
	uploadDOM.addEventListener('drop', function(event) {
		event.preventDefault();
		var fileList = event.dataTransfer.files;
		vlidateFile(fileList);
		
		//上传 
	    var xhr = new XMLHttpRequest(); 
	    xhr.open("post", "/", true); 
	    xhr.onreadystatechange = function() {
			if (xhr.readyState == 4) {
				if((xhr.status >= 200) && (xhr.status < 300) || xhr.status == 304) {
					var jsonString = xhr.responseText;
					if(jsonString) {
						printStatus("上传成功", 0);
						codeDOM.innerHTML = 1;
						nameDOM.innerHTML = fileList[0].name;
					}
				}
			}
		};
	    xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest"); 
	     
	    var fd = new FormData(); 
	    fd.append('file', fileList[0]); 
	    xhr.send(fd); 
		
		printStatus("正在上传...", 0);
	}, false);

	uploadDOM.addEventListener('dropover', function(event) {
		event.preventDefault();
		uploadDOM.style.opacity = 0.7;
	}, false);

	var liLength = liList.length;
	var globalIndex = 0;
	for(var i = 0; i < liLength; i++) {
		var liEle = liList[i];
		(function(index) {
			liEle.addEventListener('click', function(event) {
				this.className = 'active';
				globalIndex = index;
				for(var i = 0; i < liLength; i++) {
					if(i !== index) {
						liList[i].className = '';
					}
				}
			});
		})(i);
	}

	// 上传按钮
	startDOM.addEventListener('click', function(event) {
		// code : 0 -> 未上传 	1 -> 上传成功 	2 -> 正在转换 	3 -> 转换成功  	4 -> 格式错误
		var code = codeDOM.firstChild.nodeValue;
		var fileName = nameDOM.firstChild.nodeValue;
		
		if(parseInt(code) === 0) {
			printStatus("请上传文件或文件正在上传中...", 1);
		} else if(parseInt(code) === 1) {
			// 开始转化
			commandDOM.innerHTML = generateCommand(globalIndex);
			_ajax({
				url : '/translate',
				type : 'get',
				data : {
					code : code,
					index : globalIndex,
					filename : fileName
				},
				success : function(data) {
					if(data === 'ok') {
						codeDOM.innerHTML = 3;
						printStatus("文件转化成功", 0);
						setTimeout(function() {
							codeDOM.innerHTML = 0;
							printStatus("请添加一个文件", 0);
						}, 3000);
					} else if(data === 'error') {
						codeDOM.innerHTML = 4;
						printStatus("转化文件格式错误", 1);
						setTimeout(function() {
							codeDOM.innerHTML = 1;
							printStatus("请重新选择转化类型", 0);
						}, 3000);
					}
				}
			});
			codeDOM.innerHTML = 2;
		} else if(parseInt(code) === 2) {
			printStatus("文件正在转化中...", 1);
		}
	});
})();

