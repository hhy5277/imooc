var path = require('path');
var ffmpeg = require('fluent-ffmpeg');
ffmpeg.setFfmpegPath('D:\\develop\\ffmpeg\\bin\\ffmpeg.exe');
ffmpeg.setFfprobePath('D:\\develop\\ffmpeg\\bin\\ffprobe.exe');

function generateCommand(options, filename, extname, startCallback, endCallback, errorCallback) {
	var transFilePath = path.resolve(__dirname, '../../res/upload', filename);
	var basename = path.basename(transFilePath, path.extname(transFilePath));
	var transDesFilePath = path.resolve(__dirname, '../../res/upload/trs', basename);
	
	var startCallback = startCallback ||  function(commandLine) {console.log('Spawned Ffmpeg with command: ' + commandLine);};
	var endCallback = endCallback || function() {console.log('file has been converted succesfully');};
	var errorCallback = errorCallback || function(err) {console.log('an error happened: ' + err.message);};
	
	var command = ffmpeg(transFilePath).outputOptions(options).saveToFile(transDesFilePath + extname, {end:true});
	command.on('start', startCallback).on('end', endCallback).on('error', errorCallback);
	return command;
}

function transformFFmpegCommand(index, filename, endCallback, startCallback, errorCallback) {
	var commands = {
			"0" : function() {	// avi -> mp4
				var options = ['-threads 4','-b 1500k','-vcodec libx264',
	               '-vpre slow','-vpre baseline','-g 30'];
				return generateCommand(options, filename, '.mp4', startCallback, endCallback, errorCallback);
			},
			"1" : function() {	// avi -> ogg
				var options = ['-threads 4','-b 1500k','-vcodec libtheora',
	               '-acodec libvorbis','-ab 160000','-g 30'];
				return generateCommand(options, filename, '.ogg', startCallback, endCallback, errorCallback);
			},
			"2" : function() {	// avi -> webm
				var options = ['-threads 4','-b 1500k','-vcodec libvpx',
	               '-acodec libvorbis', '-ab 160000', '-f webm', '-g 30'];
				return generateCommand(options, filename, '.ogg', startCallback, endCallback, errorCallback);
			},
			"3" : function() {	// mp4 -> ogg
				var options = ['-threads 4','-b 1500k','-vcodec libtheora',
	               '-acodec libvorbis','-ab 160000','-g 30'];
				return generateCommand(options, filename, '.ogg', startCallback, endCallback, errorCallback);
			},
			"4" : function() {	// mp4 -> webm
				var options = ['-threads 4','-b 1500k','-vcodec libvpx',
	               '-acodec libvorbis', '-ab 160000', '-f webm', '-g 30'];
				return generateCommand(options, filename, '.ogg', startCallback, endCallback, errorCallback);
			},
			"5" : function() {	// mp4 -> mp4(鏀瑰彉澶у皬)
				var options = ['-threads 4','-r 29.97','-vcodec h264','-flags +loop','-cmp +chroma', '-bt 256k', '-refs 1' , '-coder 0', '-me_range 16', 
	               '-subq 5','-partitions +parti4x4+parti8x8+partp8x8', '-g 250', '-keyint_min 25', '-level 30', '-qmin 10', '-qmax 51',
	               '-trellis 2', '-sc_threshold 40', '-i_qfactor 0.71', '-acodec libvo_aacenc', '-ab 128k', '-ar 48000', '-ac 2'];
				return generateCommand(options, filename, '.mp4', startCallback, endCallback, errorCallback);
			}
	};
	return commands[index]();
}

module.exports = transformFFmpegCommand;
