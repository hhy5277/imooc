<blockquote><p><strong>介绍</strong></p></blockquote>
<p><strong>这是我参加百度技术前端的作品全集</strong><br/></p>
<ol><li><p>团队名称：imooc-慕星人</p></li><li><p>团队介绍：来自慕课网的慕星人;</p></li><li><p>我们都是有梦想的年轻人</p></li></ol><p><br/></p>
<blockquote><p>在线演示Demo</p></blockquote><p><strong>&nbsp;
地址：</strong>&nbsp;<a href="https://imooc-muxingpeople.github.io/imooc-MuXing-people/Team-Introduce/#page1" _src="https://imooc-muxingpeople.github.io/imooc-MuXing-people/Team-Introduce/#page1">https://imooc-muxingpeople.github.io/imooc-MuXing-people/Team-Introduce/#page1</a></p><p><br/></p>
<blockquote><p>作者相关<br/></p></blockquote>
<ul><li><p>作者：阮小泽 <br>慕课网ID:太阳神_SunOracle</p></li>
<li><p>github 邮箱：ruanxiaoze@outlook.com</p></li><li><p>本作品源码：<a href="https://imooc-muxingpeople.github.io/imooc-MuXing-people/Team-Introduce/#page1" _src="https://imooc-muxingpeople.github.io/imooc-MuXing-people/Team-Introduce/#page1">https://imooc-muxingpeople.github.io/imooc-MuXing-people/Team-Introduce/#page1</a>&nbsp; &nbsp;<br/></p></li>
<li><p>该作品为本人所原创，转载请联系本人。谢谢；</p></li></ul>
<p><br/></p>