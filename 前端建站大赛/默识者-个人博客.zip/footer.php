	<!-- /*footer.php*/ -->
	<a class="to-top">Top</a>

	<footer id="footer">
		<span>			
		Copyright © 2016 H-five | Theme By <a href="<?php echo admin_url(); ?>" target="_blank">HL</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="<?php echo home_url().'/sitemap'; ?>" target="_blank">站点地图</a>
		<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1257455873'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s95.cnzz.com/z_stat.php%3Fid%3D1257455873' type='text/javascript'%3E%3C/script%3E"));</script>		
		</span>
	</footer>
</div>
  <div id="snowContainer">
    <canvas id="canvas"></canvas>    
  </div>
  <style type="text/css">
    #snowContainer{
		position: fixed;
		width: 100%;
		height: 100%;
		overflow: hidden;
		top: 0;
		left: 0;
  	}

  	#snowContainer #canvas{
  		display: block;
  	}

  </style>
	</body>
	<script type="text/javascript">
$(document).ready(function() {

	seachShow();
	//innitMuc('<?php echo get_template_directory_uri();?>');

	$('.to-top').toTop({
		//options with default values
		autohide: true,
		offset: 320,
		speed: 1000,
		position: true,
		right: 50,
		bottom: 50
	});
});

	</script>
</html>