<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>
		 <?php 
		         if (is_home()||is_search()) { bloginfo('name'); } 
		         else{wp_title(''); echo ' | '; bloginfo('name');} 
		 ?>
		</title>
		<?php if (is_home() || is_front_page())
			{
			$description = "这是一个个人博客，用于记录一些学习心得，及生活琐事。";
			$keywords = "何雷,默识者,默而识之,默@语,暗中记住的人,HL,程画,中南民族大学,HL的博客,wordpress教程,酷毙程序员";
			}
			elseif (is_category())
			{
			$description = strip_tags(trim(category_description()));
			$keywords = single_cat_title('', false);
			}
			elseif (is_tag())
			{
			$description = sprintf( __( '与标签 %s 相关联的文章列表'), single_tag_title('', false));
		    $keywords = single_tag_title('', false);
			}
			elseif (is_single())
			{
		     if ($post->post_excerpt) {$description = $post->post_excerpt;} 
			 else {$description = get_expert($post->ID,110);}
		    $keywords = "";
		    $tags = wp_get_post_tags($post->ID);
		    foreach ($tags as $tag ) {$keywords = $keywords . $tag->name . ", ";}
			}
			elseif (is_page())
			{
			$keywords = get_post_meta($post->ID, "keywords", true);
			$description = get_post_meta($post->ID, "description", true);
			}
			?>
		<meta name="keywords" content="<?php echo $keywords ?>" />
		<meta name="description" content="<?php echo $description?>" />		
		<!--[if lt IE 7]>
			<script>window.location.href='http://cdn.dmeng.net/upgrade-your-browser.html?referrer='+location.href;</script>
		<![endif]-->
		<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url');?>/style.css">
		<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url');?>/css/monokai-sublime.css">
		<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url');?>/css/font-awesome.min.css">
		<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/jquery.1.10.2.min.js"></script>
		<!--[if lt IE 9]>
			<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/html5.js"></script>
		<![endif]-->	
		<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/selectivizr-min.js"></script>
		<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/HMingQiu.js"></script>
		<?php wp_deregister_script("jquery");?>
		<?php wp_head();?>
	</head>
	<body>
		<div id="indexContainer">
			<?php
				if(has_nav_menu('primary')){
			?>
			<nav>
			<?php wp_nav_menu(
							array(
								'theme_location'=>'primary',
								'container'=>'',
								'menu_id'=>'menue-primary-items',
								'menue_class'=>'menu-items',
								'fallback_cb'=>'',
								'item_wrap'=>'<div class="wrap"><ul id="%s" class="%s">%s</ul></div>'
							)
						);
			get_search_form(true);
			?>
			</nav>
			<?php 
				}
			?>