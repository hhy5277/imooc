<?php 
    get_header();
?>
 
<div id="wrap">

<?php 
  $limit = get_option('posts_per_page'); 
  $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; 
  if (have_posts()) : 
?>

      <div class="nowPosition"><span> </span>
<?php
    the_category( ">>", "multiple" ); 
?>
     </div>
    <section id="showEssay">     
<?php   

  while (have_posts()) : the_post(); ?>
        <div class="product_list">
            <div class="product_list_content">
                <div class="essay-info">
                    <h1>
                        <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                            <?php the_title(); ?>
                            <span ><?php the_time(n月d日)?></span>
                        </a>
                    </h1>
                    <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                        <img src="<?php echo catch_first_image(get_the_id());?>" alt="" />
                    </a>

                </div>
                <div class="essay_content">
                        <p><?php echo  get_expert(get_the_id(),120);?></p>
                </div>
            </div>
            <div class="clearFix"></div>           
        </div>
    <?php $postnun++; 
    endwhile ;
    else: echo "<section id='showEssay'> <span class='noEassy'>暂无文章，敬请期待！！！</span>";;
    endif;
    ?>

        <div class="clearFix"></div>
    </section>
<div id="page"><?php par_pagenavi(); ?></div>

</div>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/responsiveslides.min.js"></script> 
  <script type="text/javascript" src="<?php bloginfo('template_url');?>/js/imagesloaded.pkgd.min.js"></script>
  <script type="text/javascript" src="<?php bloginfo('template_url');?>/js/masonry.pkgd.min.js"></script>   
<script type="text/javascript">
  $(document).ready(function(){
      showPicAnimation('#dowebok');
      
      var $container = $('#showEssay');
      $container.imagesLoaded(function() {
        $container.masonry({
          itemSelector: '.product_list',
          columnWidth: 0 //每两列之间的间隙为5像素
        });

      });
            
  });
</script>
<?php get_footer();?>