<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar 1')) : ?> 
<?php endif; ?>