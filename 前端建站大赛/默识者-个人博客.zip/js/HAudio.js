(function() {
   var ashu_upload_frame;   
   var value_id;   
   tinymce.create('tinymce.plugins.HAudio', {
      init : function(ed, url) {
         ed.addButton('HAudio', {
            title : 'HAudio',
            image : url+'/HAudio.png',
            onclick: function(event) {
               value_id = jQuery(this).attr('id');
               event.preventDefault();
               if (ashu_upload_frame) {
                  ashu_upload_frame.open();
                  return;
               }
               ashu_upload_frame = wp.media({
                  title: 'Insert image',
                  button: {
                     text: 'Insert',
                  },
                  multiple: false
               });
               ashu_upload_frame.on('select', function() {
                  attachment = ashu_upload_frame.state().get('selection').first().toJSON();
                  //jQuery('#'+value_id+'_input').val(attachment.url).trigger('change');  
                  // jQuery('input[name=' + value_id + ']').val(attachment.url).trigger('change');
                  var text = attachment.url;
    
                  if (text != null && text != ''){
                        ed.execCommand('mceInsertContent', false, '[HAudio mp3="'+text+'"][/HAudio]');
                  }
              
               });
               ashu_upload_frame.open();


            }
         });
   },
      createControl : function(n, cm) {
         return null;
      },
      getInfo : function() {
         return {
            longname : "Recent Posts",
            author : 'Specs',
            authorurl : 'http://9iphp.com',
            infourl : 'http://9iphp.com/opensystem/wordpress/1094.html',
            version : "1.0"
         };
      }
   });
   tinymce.PluginManager.add('HAudio', tinymce.plugins.HAudio);
})();