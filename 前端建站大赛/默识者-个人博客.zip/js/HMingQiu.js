
function seachShow(){
	console.log("show search");
	$("form#searchform input#s").attr("placeholder","搜索…");
	$("#searchform .screen-reader-text").on("click",function(){
		var state = $("form#searchform input#s").attr("nowState");
		if (typeof(state) === "undefined") {
			state = 0;

		}

		state = parseInt(state);
		state=(++state)%2;
		console.log(state);
		if (state == 1) {
			$("form#searchform input#s").css({
				"width": "200px",
				"padding": "7px 8px",
				"border-width": "1px"
			});
		} else {
			$("form#searchform input#s").css({
				"width": "0px",
				"padding": "7px 0px",
				"border-width": "0px"
			});
		}
		var state = $("form#searchform input#s").attr("nowState", state);

	});
}

// 主页轮播图
function showPicAnimation(dom){

	$(dom).responsiveSlides({
	auto: true,             // Boolean: Animate automatically, true or false
	speed: 500,            // Integer: Speed of the transition, in milliseconds
	timeout: 4000,          // Integer: Time between slide transitions, in milliseconds
	pager: true,           // Boolean: Show pager, true or false
	nav: false,             // Boolean: Show navigation, true or false
	random: false,          // Boolean: Randomize the order of the slides, true or false
	pause: true,           // Boolean: Pause on hover, true or false
	pauseControls: false,    // Boolean: Pause when hovering controls, true or false
	prevText: "Previous",   // String: Text for the "previous" button
	nextText: "Next",       // String: Text for the "next" button
	maxwidth: "",           // Integer: Max-width of the slideshow, in pixels
	navContainer: "",       // Selector: Where controls should be appended to, default is after the 'ul'
	manualControls: "",     // Selector: Declare custom pager navigation
	namespace: "HMingQiu",   // String: Change the default namespace used
	before: function(){},   // Function: Before callback
	after: function(){}     // Function: After callback
			});
}
// 滚动到顶部

(function( $ ){
    'use strict';
    
    $.fn.toTop = function(opt){
        
        //variables
        var elem = this;
        var win = $(window);
        var doc = $('html, body');
        
        //Extended Options
        var options = $.extend({
            autohide: true,
            offset: 420,
            speed: 500,
            position: true,
            right: 15,
            bottom: 30
        }, opt);
        
        elem.css({
            'cursor': 'pointer'
        });
        
        if(options.autohide){
            elem.css('display', 'none');
        }
        
        if(options.position){
            elem.css({
                'position': 'fixed',
                'right': options.right,
                'bottom': options.bottom,
            });
        }
        
        elem.click(function(){
            doc.animate({scrollTop: 0}, options.speed);
        });
        
        win.scroll(function(){
            var scrolling = win.scrollTop();
            
            if(options.autohide){
                if(scrolling > options.offset){
                    elem.fadeIn(options.speed);
                }
                else elem.fadeOut(options.speed);
            }
            
        });
        
    };
    
}( jQuery ));
