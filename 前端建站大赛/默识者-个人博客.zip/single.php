
<?php get_header();?>
<div id="wrapper">
    <div id="single_posts">
        <?php while(have_posts()):the_post();?>
            <div id="single_posts_content">
                <div class="single_title"><h1><?php the_title(); ?></h1><span class="single_date"><?php the_date(n月d日);?></span></div>
                <div class="single_content"><?php the_content(); ?></div>
                <div class="symbol">
转载请注明来源，<a class="eassyBlogUrl" href="<?php bloginfo('url'); ?>" target="_blank"><?php echo bloginfo('name'); ?></a>
                </div>
            </div>
        <?php endwhile; ?>
        <div id="nav_page">
            <?php
            $prev_post = get_previous_post();
            if (!empty( $prev_post )): ?>
              <a class="prev_post" title="<?php echo $prev_post->post_title; ?>" href="<?php echo get_permalink( $prev_post->ID ); ?>" rel="external nofollow" >上一篇：<?php echo $prev_post->post_title; ?></a>
            <?php endif; ?>
            <?php
            $next_post = get_next_post();
            if (!empty( $next_post )): ?>
              <a  class="next_post" title="<?php echo $next_post->post_title; ?>" href="<?php echo get_permalink( $next_post->ID ); ?>" rel="external nofollow" >下一篇：<?php echo $next_post->post_title; ?></a>
            <?php endif; ?> 
             <div class="clearFix"></div>           
        </div>
        <div id="single_comments">
            <?php comments_template(); ?>
        </div>
    </div>
    <div class="clearFix"></div>
</div>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/highlight.pack.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        hljs.initHighlightingOnLoad();
        
    });
</script>

<?php get_footer();?>
