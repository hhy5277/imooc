<?php 
    get_header();
?>
 
<div id="wrap">
    <header>
        <div id="branding">
            <h1 class="siteTitle"><a href="<?php echo home_url()?>"><?php echo get_bloginfo ( 'title' ); ?></a></h1>
            <h2><?php echo get_bloginfo ( 'description' ); ?></h2>
        </div>
    </header>
    <section id="headImg">
        <ul class="rslides" id="dowebok">
<?php
    $args = array(
        'posts_per_page' => -5,
        'post__in'  => get_option( 'sticky_posts' )
    );
    $sticky_posts = new WP_Query( $args ); 
    while ( $sticky_posts->have_posts() ) : $sticky_posts->the_post();

        echo '<li><img src="'.catch_thumbnail(get_the_id()).'" /><div class="descriptText"><article>'.
             '<h3><a href="'.get_permalink(get_the_id()).'">'.get_the_title().'</a></h3>'.
             '<p>'.get_expert(get_the_id(),110).'</p>'.
             '<div class="postBar">'.
             '<span>'.get_avatar(get_the_author_ID()).get_the_author_meta("nickname",get_the_author_ID()).'</span>'.
             '<span class="post_date"><i class="fa fa-clock-o"></i>'.hFormatDate(get_the_date()).'</span>'.
             '<span><i class="fa fa-eye"></i>'.post_views("", "",0).'</span>'.
             '</div>'.                           
             '<span class="moreButton"><a href="'.get_permalink(get_the_id()).'">阅读</a></span>'.
             '</article></div></li>';
        $imgInfo=null;

     endwhile; wp_reset_query();
?>        
        </ul>   
    </section>
    <section id="showEssay">
<?php 
  $limit = get_option('posts_per_page'); 
  $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; 
  $sticky = get_option('sticky_posts'); 
  $args = array( 
    'showposts' => $limit, 
    // //排除置顶文章，不输出置顶文章。这一句和上一句只留一句即可，根据自己需要处理 
    // 'post__not_in' => $sticky, 
    'paged' => $paged 
  ); 
  query_posts($args); 
  if (have_posts()) : 
  while (have_posts()) : the_post(); ?>
        <div class="product_list">
            <div class="product_list_content">
                <div class="essay-info">
                    <h1>
                        <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                            <?php the_title(); ?>
                            <span ><?php the_time(n月d日)?></span>
                        </a>
                    </h1>
                    <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                        <img src="<?php echo catch_first_image(get_the_id());?>" alt="" />
                    </a>

                </div>
                <div class="essay_content">
                        <p><?php echo  get_expert(get_the_id(),120);?></p>
                </div>
            </div>
            <div class="clearFix"></div>           
        </div>
    <?php $postnun++; 
    endwhile ; wp_reset_query();
    else: "<span class='noEassy'>暂无文章，敬请期待！！！</span>";;
    endif;
    ?>

        <div class="clearFix"></div>
    </section>
<div id="page"><?php par_pagenavi(); ?></div>

</div>
<script type="text/javascript" src="<?php bloginfo('template_url');?>/js/responsiveslides.min.js"></script> 
  <script type="text/javascript" src="<?php bloginfo('template_url');?>/js/imagesloaded.pkgd.min.js"></script>
  <script type="text/javascript" src="<?php bloginfo('template_url');?>/js/masonry.pkgd.min.js"></script>   
<script type="text/javascript">
  $(document).ready(function(){
      showPicAnimation('#dowebok');
      
      var $container = $('#showEssay');
      $container.imagesLoaded(function() {
        $container.masonry({
          itemSelector: '.product_list',
          columnWidth: 0 //每两列之间的间隙为5像素
        });

      });
            
  });
</script>
<?php get_footer();?>