<?php return array (
  0 => 
  array (
    'title' => '今天的北京天气真是太好了',
    'content' => '如题，这种天气就适合在教室敲代码',
    'time' => '2015/12/02 15:38:29',
  ),
  1 => 
  array (
    'title' => '今天星期三，再过两天就是周末了哒',
    'content' => '看来周末还得再多敲敲代码啊',
    'time' => '2015/12/02 15:40:06',
  ),
  2 => 
  array (
    'title' => 'Example with default values',
    'content' => 'The dual listbox is created from a select multiple by calling .bootstrapDualListbox(settings); on a selector. The selector can be any element, not just selects. When the method is called on a selector other than a select, then all select childrens',
    'time' => '2015/12/02 16:24:30',
  ),
  3 => 
  array (
    'title' => '仿站技术——获取和使用某些网站的iconfont图标字体',
    'content' => '前言：
很多前端新手在仿一些大型网站的时候经常遇到一个问题：该网站使用了图标字体——iconfont，虽然现在阿里有开源的iconfont库，但是还是没有原网站的效果（本人强迫症但非处女座）。所以此文章介绍一下如何获取和使用网站的iconfont，该技术仅供学习交流，请勿用于任何商业行为。
工具：
1.代码编辑器（本人sublime），2.浏览器（本人火狐），3.迅雷，4.使用iconfont的网站（1号店），一个空css文件。
开始：
先看看什么是iconfont，如下图中的图标：',
    'time' => '2015/12/02 16:38:02',
  ),
)?>