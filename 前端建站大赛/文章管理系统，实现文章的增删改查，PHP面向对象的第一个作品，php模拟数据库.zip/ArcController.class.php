<?php 
class ArcController{
	
// 保存数据库的属性
	private $db;
	public function __construct($data){
		$this->db=$data;
	}
	// 载入首页
	public function index(){
		$data =$this->db;
		include './tpl/index.html';
	}
//	添加功能
	public function add(){
		include './tpl/add.html';
		if(!empty($_POST)){
//			获得时间
			$_POST['time'] = date('Y/m/d H:i:s');
//			将数据放入数据库
			$this->db[]=$_POST;
//			代码合法化
			$newData = "<?php return ".var_export($this->db,true) ."?>";
			file_put_contents('./data.php', $newData);
			$str=<<<str
			<script>
				alert("发表成功");
				location.href="./index.php";
			</script>
str;
			echo $str;
		}
	}
//	删除
	public function del(){
//		获得id
		$id = $_GET['id'];
//		引入数据库
		$data = $this->db;
//		删除
		unset($data[$id]);
//		代码合法化
		$newData = "<?php return " . var_export($data,true) . "?>";
//		出入数据库
		file_put_contents('./data.php', $newData);
			$str=<<<str
			<script>
				alert("删除成功");
				location.href="./index.php";
			</script>
str;
			echo $str;
	}
//	修改
 	public function edit(){
// 		获得编辑ID
		$id = $_GET['id'];
// 		载入数据库
		$data = $this->db;
//		载入编辑页面
		include './tpl/edit.html';
		$oldData = $data[$id];
		if(!empty($_POST)){
			$_POST['time'] = $oldData['time'];
			$data[$id] = $_POST;
//			代码合法化
			$newData = "<?php return " . var_export($data,true) . "?>";
		file_put_contents('./data.php', $newData);
			$str=<<<str
			<script>
				alert("修改成功");
				location.href="./index.php";
			</script>
str;
			echo $str;
		}
		
 	}
	
//		展示页面
		public function show(){
//			引入数据库
			$data = $this->db;
//			获得ID
			$id = $_GET['id'];
//			载入展示页面
			include './tpl/show.html';
		}
	
	
	
	
	
	

}
 ?>