<p>仿京东七夕弹幕 HTML+CSS+jQuery实现弹幕技术</p><p>部分不足之处：<a href="http://www.cnblogs.com/zxyun/p/4740672.html" _src="http://www.cnblogs.com/zxyun/p/4740672.html">http://www.cnblogs.com/zxyun/p/4740672.html</a> </p><p>欢迎在这里讨论</p>

