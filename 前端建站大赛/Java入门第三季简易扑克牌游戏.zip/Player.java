
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

/**
 *玩家类，有姓名和ID属性并持有一副手牌，可根据手牌大小比较两个玩家的大小，
 */
public class Player implements Comparable<Player> {
    private int id;
    private String name;
    private HandCards handCards=new HandCards();

    
    public Player(String n,int id){
        this.name=n;
    	this.id=id;
    }
    public String getName(){
        return name;
    }
	public int getID(){
        return id;
    }

    public HandCards getHandCards() {
        return handCards;
    }
    public void getCard(Card c){
        handCards.addCard(c);
    }
    public void displayCard(){
        System.out.print(id+name);  
        for(int i=0;i<handCards.getHandCards().length;i++){
            System.out.print(handCards.getHandCards()[i]+",");
        }
        if(handCards.getCardNo()==5){
            System.out.print("牌型大小为"+handCards.getCardPatterns());
        }
        System.out.println("");
    }

    public int compareTo(Player other) {
        return other.getHandCards().compareTo(this.getHandCards());
    }
    public String toString(){
        StringBuffer s=new StringBuffer();
            s.append(id).append("号玩家-").append(name).append(":");
            for(int i=0;i<handCards.getHandCards().length;i++){
            s.append(handCards.getHandCards()[i]).append(",");
            }
            s.append("牌型大小为").append(CardPattern.getCardPattern(handCards.getCardPatterns()).toString()).append("\n\r");//根据序列号获得友好形式的牌型显示方法
        return s.toString();
    }
	/**
	*定义一个牌型枚举，并定义一个可根据序列号返回枚举数值的方法
	*/
	 enum CardPattern{
			散牌,单对,二对,三条,顺子,同花,富尔豪斯,四条,同花顺;
			static CardPattern getCardPattern(int i){
				for(CardPattern c:CardPattern.values()) {
					if(c.ordinal()==i)
					return c;
				}
				return null;
			}
		}

	public void clearHanderCards(){
		handCards.clearHanderCards();
	}
}

  

