
import java.util.*;
/**
 *
 */
public class FiveCard {
    
	 public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Player[] players=creationPlayer(sc);
		gameingStage(sc,players);
    }
	private static void gameingStage(Scanner sc,Player[] players){
		while(true){
			System.out.println("是否开始新一盘的游戏,输入over结束游戏，输入其他开始新的游戏");
			if("over".equals(sc.next()))
				return;
			System.out.println("创建新牌");
			ArrayList<Card> cardGroup=Staff.getNewCardsGroup();
			System.out.println("新牌创建成果");
			System.out.println(cardGroup);
			System.out.println("洗牌");
			cardGroup=Staff.flushCardsGroup(cardGroup);
			for(int i=0;i<5;i++){//直接发完五次牌，具体的第一张手牌隐藏之类的以后再补充吧
			System.out.println("发牌");
			Staff.pushCard(cardGroup, players);
			}
			System.out.println("最终排名");
			Staff.sortPlayers(players);
			Staff.clearHanderCards(players);
		}
	}
	private static Player[] creationPlayer(Scanner sc){
		System.out.println("创建玩家,请输入参与玩家数量");
		int playernum = scNextInt(sc);
		Player[] players=new Player[playernum];
		int idtemp=0;
		for(int i=0;i<playernum;i++){
			System.out.println("请输入第"+(i+1)+"个玩家的ID和姓名:");
			System.out.println("请输入ID");
			idtemp=scNextInt(sc);
			System.out.println("请输入姓名");
			players[i]=new Player(sc.next(),idtemp);
		}
		for(Player p:players)
			System.out.println("欢迎"+p.getID()+"号玩家:"+p.getName());
		return players;
	}
	private static int scNextInt(Scanner sc){
		String s=sc.next();
		  try {
			return Integer.parseInt(s);
		  } catch (NumberFormatException e) {
			System.out.println("未输入合法数值，默认数字为2");
		    return 2;
		  }
	}
}

  

