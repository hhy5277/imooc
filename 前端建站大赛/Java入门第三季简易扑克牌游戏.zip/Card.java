
/**
 * 扑克牌类，包含牌的名称，数字，花色以及牌面大小对比的一个方法，其中将牌的数字和花色种类定义为了一个枚举
 */
public class Card implements Comparable<Card>{
    private String name;//牌的名称
    private Colors color;//牌的花色
    private CardValues cardvalue;//牌的数字
    private int fNo;//牌的数字大小，由枚举序列号决定
    private int sNo;//牌的花色大小，由枚举序列号决定
    public Card(Colors color,CardValues cardvalue){
        this.color=color;
        this.cardvalue=cardvalue;
        this.name=color.toString()+cardvalue.toString();//复制牌的名称
        this.fNo=cardvalue.ordinal();
        this.sNo=color.ordinal();
    }
    @Override
    public String toString(){
        return name;
    }
    /**
     * 牌的大小比较方法，先比较数字大小，相同时再比较花色大小
     * @param other
     * @return 
     */
    public int compareTo(Card other){
        if(fNo>other.getfNo()){
            return 1;
        }else if(fNo<other.getfNo()){
            return -1;
        }else if(sNo>other.getsNo()){
            return 1;
        }else if(sNo<other.getsNo()){
            return -1;
        }else {
            return 0;
        }
    }
    public int getfNo() {
        return fNo;
    }

    public int getsNo() {
        return sNo;
    }
}
enum Colors{
    方块,梅花,红桃,黑桃;
}
enum CardValues{
     二,三,四,五,六,七,八,九,十,J,Q,K,A;
}

  

