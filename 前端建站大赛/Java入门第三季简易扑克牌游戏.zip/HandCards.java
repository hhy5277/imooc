
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

/**
 * 梭哈游戏的手牌类，定义了手牌上限5个，并创建了对手牌进行排序的方法、获得手牌牌型的方法、手牌与手牌比较大小的方法
 */
public class HandCards implements Comparable<HandCards>{
    private Card[] handCards=new Card[5];//创建手牌数组，上限为5张手牌
    private int cardNo=0;//初始化手牌数量为0
    private ArrayList<Card> sc=new ArrayList<Card>();//手牌排序所用集合
    private int cardPatterns;//手牌牌型，定义为int方便比较大小

    public ArrayList<Card> getSc() {
        return sc;
    }
    public int getCardNo() {
        return cardNo;
    }

    public int getCardPatterns() {
        return cardPatterns;
    }

    
    public Card[] getHandCards() {
        return handCards;
    }
    
    public void addCard(Card c){
        handCards[cardNo]=c;
        ++cardNo;
        if(cardNo==5){//手牌已满，可以进行排序了
            setSortCard();
            cardPatterns=setCardPatterns();
        }
    } 

    /**
     * 将手牌排序
     */
    private void setSortCard(){
        for(int i=0;i<handCards.length;i++){
            sc.add(handCards[i]);
        }
        Collections.sort(sc);
    }
    
    /**
     * 获得手牌牌型
     */
    public int setCardPatterns(){
        HashSet<Integer> hs= new HashSet<Integer>(); //用HashSet确定手牌数字种类数
        hs.add(sc.get(0).getfNo());
        hs.add(sc.get(1).getfNo());
        hs.add(sc.get(2).getfNo());
        hs.add(sc.get(3).getfNo());
        hs.add(sc.get(4).getfNo());
        boolean a=(sc.get(0).getfNo()==sc.get(1).getfNo());//确定相邻数字是否相等
        boolean b=(sc.get(1).getfNo()==sc.get(2).getfNo());
        boolean c=(sc.get(2).getfNo()==sc.get(3).getfNo());
        boolean d=(sc.get(3).getfNo()==sc.get(4).getfNo());
        boolean e=(sc.get(0).getsNo()==sc.get(1).getsNo()&&sc.get(0).getsNo()==sc.get(2).getsNo()&&sc.get(0).getsNo()==sc.get(3).getsNo()&&sc.get(0).getsNo()==sc.get(4).getsNo());//确定是否同花
        int f=sc.get(0).getfNo()-sc.get(4).getfNo(); //最大最小差
        int g=hs.size(); //手牌数字种类数
        if(g==2){
            if(a&&d){
                return 6;
            }else{
                return 7;
            } 
        }else if(g==3){
            if(a&&b||b&&c||c&&d){
                return 3;
            }else{
                return 2;
            }
        }else if(g==4){
            return 1;
        }else if(g==5&&f==4){
            if(e){
                return 8;
            }else{
                return 4;
            }
        }else if(e){
            return 5;
        }else {
            return 0;
        }
    }

    public int compareTo(HandCards other) {
        if(this.getCardPatterns()>other.getCardPatterns()){
            return 1;
        }else if(this.getCardPatterns()<other.getCardPatterns()){
            return -1;
        }else {
            return this.getSc().get(4).compareTo(other.getSc().get(4));
        }
    }

/**
清空手牌
*/
    public void clearHanderCards(){
		handCards=new Card[5];
		cardNo=0;
		ArrayList<Card> sc=new ArrayList<Card>();
	}
       
}


  

