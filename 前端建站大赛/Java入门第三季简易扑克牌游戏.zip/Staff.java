import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/**
 *牌的工具类，包含创建新牌，洗牌，发牌，显示玩家手牌的方法
 */
public class Staff {
    /**
     * 工具类，禁止创建对象
     */
    private Staff(){
        
    };
    
    /**
     * 创建一副新牌
     * @return 
     */
    public static ArrayList<Card> getNewCardsGroup(){
        ArrayList<Card> cards;
        cards = new ArrayList<Card>();
        for(CardValues v:CardValues.values()){
            for(Colors c:Colors.values()){
                cards.add(new Card(c,v));
            }
        }
        return cards;
    }
    
    /**
     * 洗牌
     * @param src
     * @return 
     */
    public static ArrayList<Card> flushCardsGroup(ArrayList<Card> src){
        ArrayList<Card> result=new ArrayList<Card>();
        while(src.size()>0){
            int size=src.size();
            //以size为限，生成0~size之间的随机数
            Random r=new Random();
            int index=r.nextInt(size);
            if(index<0){index=0;}
            if(index>size-1){index=size-1;}
            Card c=src.get(index);
            result.add(c);
            src.remove(index);
        }
        return result;
    }
    
    /**
     * 发牌
     * @param src
     * @param players 
     */
    public static void pushCard(ArrayList<Card> src, Player[] players){
        for(Player p:players){
            p.getCard(src.get(0));//获得顶端的牌
            src.remove(0);//每发一支牌，牌堆删掉那支
        }
    }
    
    /**
     * 显示玩家与持牌
     * @param players 
     */
     public static void displayPlayers(Player[] players){
         for(Player p:players){
            p.displayCard();
        }
     }
     public static void sortPlayers(Player[] players){
         Arrays.sort(players);
         System.out.println(Arrays.toString(players));
    	 System.out.println(players[0].getName()+"是本局冠军");
     }
	 public static void clearHanderCards(Player[] players){
		 for(Player p:players){
            p.clearHanderCards();
        }
	 }
}


  

