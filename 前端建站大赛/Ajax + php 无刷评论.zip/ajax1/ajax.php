<?php
include_once("connect.php");

$q=mysql_query("select * from comments");
while($row=mysql_fetch_array($q)){
		$comments[] = array("id"=>$row['id'],"user"=>$row['user'],"comment"=>$row['comment'],"addtime"=>$row['addtime']);
}
echo json_encode($comments);

?>