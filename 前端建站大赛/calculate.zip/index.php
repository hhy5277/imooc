<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-cn">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
	<title>计算器</title>
	<meta name="keywords" content="关键字列表" />
	<meta name="description" content="网页描述" />
	<link rel="stylesheet" type="text/css" href="" />
	<script src="js/ajax.js" type="text/javascript"></script>
	<script src="js/calculate.js" type="text/javascript"></script>
	<script src="js/keydown.js" type="text/javascript"></script>
	<style type="text/css">
	input{
		width:100%;
		height:100%;
		font-size:25px;
	}

	</style>
	<script type="text/javascript">

	//页面加载完成初始化
	window.onload=function(){
		var objInput=document.getElementsByTagName("input");
		var num=document.getElementById('num');
		var express=document.getElementById('express');
		var hidden1=document.getElementById('hidden1');
		for(var i=0;i<objInput.length;i++){
			objInput[i].onclick=function(){
				if(this.className=='num'){				
					addnum(this.value);
				}else if(this.className=='opera'){
					addexp(this.value);
				}else if(this.value=='='){
					addexp('');
					ajax();
				}
			}
		}
	}
	</script>
</head>
<body>
<h1 align="center">计算器</h1>
<form id="myForm">
<span id="hidden1" style="display:none;"></span>
<table id="cal" width="300" height="400" border="0" align="center">
  <tr>
    <td colspan="5"><input id="express" type="text" value="" readonly="readonly" /></td>
  </tr>
  <tr>
    <td colspan="5"><input id="num" type="text" value="" readonly="readonly" /></td>
  </tr>
  <tr>
    <td><input type="button" class="num" value="7" /></td>
    <td><input type="button" class="num" value="8" /></td>
    <td><input type="button" class="num" value="9" /></td>
    <td><input type="button" class="opera" value="÷" /></td>
    <td><input type="button" class="opera" value="%" /></td>
  </tr>
  <tr>
    <td><input type="button" class="num" value="4" /></td>
    <td><input type="button" class="num" value="5" /></td>
    <td><input type="button" class="num" value="6" /></td>
    <td><input type="button" class="opera" value="×" /></td>
    <td><input type="reset" value="C" /></td>
  </tr>
  <tr>
    <td><input type="button" class="num" value="1" /></td>
    <td><input type="button" class="num" value="2" /></td>
    <td><input type="button" class="num" value="3" /></td>
    <td><input type="button" class="opera" value="-" /></td>
    <td rowspan="2"><input type="button" value="=" /></td>
  </tr>
  <tr>
    <td colspan="2"><input type="button" class="num" value="0" /></td>
    <td><input type="button" class="num" value="." /></td>
    <td><input type="button" class="opera" value="+" /></td>
  </tr>
</table>
</form>
</body>
</html>
