	
	//创建ajax引擎
	function getXmlHttpObject(){
		var xmlHttpRequest;
		//不同的浏览器获取对象xmlhttprequest 对象方法不一样
		if(window.ActiveXObject){
			xmlHttpRequest=new ActiveXObject("Microsoft.XMLHTTP");
		}else{
			xmlHttpRequest=new XMLHttpRequest();
		}
		return xmlHttpRequest;
	}

	//由于js认为'+'号是连接符，会把'+'号丢失，所以用"%2B"替换
	//把'×'号用"*"替换
	//把'÷'号用"/"替换
	function vchar(str){
		str=str.replace(/\+/g,"%2B");
		str=str.replace(/×/g,"*");
		str=str.replace(/÷/g,"/");
		return str;
	}

	var myXmlHttpRequest="";

	//验证用户名是否存在
	function ajax(){
		myXmlHttpRequest=getXmlHttpObject();
		//怎么判断创建ok
		if(myXmlHttpRequest){	
			//通过myXmlHttpRequest对象发送请求到服务器的某个页面
			//第一个参数表示请求的方式, "get" / "post"
			//第二个参数指定url,对哪个页面发出ajax请求(本质仍然是http请求)
			//第三个参数表示 true表示使用异步机制,如果false表示不使用异步
			var url="validate.php?express="+vchar(document.getElementById('express').value);
			//var data="express="+vchar(document.getElementById('express').value);
			//打开请求.
			//alert(url);
			myXmlHttpRequest.open("get",url,true);
			//myXmlHttpRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			//指定回调函数.chuli是函数名
			myXmlHttpRequest.onreadystatechange=cal;
			//真的发送请求,如果是get请求则填入 null即可
			//如果是post请求，则填入实际的数据
			myXmlHttpRequest.send(null); 
		}
	}

	//回调函数
	function cal(){
		//window.alert("处理函数被调回"+myXmlHttpRequest.readyState);
		//我要取出从registerPro.php页面返回的数据
		if(myXmlHttpRequest.readyState==4){
			//取出值,根据返回信息的格式定.text
			//if(result!=''){
				//var result=myXmlHttpRequest.responseText;
				//window.alert(result);
				document.getElementById('num').value=myXmlHttpRequest.responseText;
				document.getElementById('hidden1').innerHTML=myXmlHttpRequest.responseText;
			//}
		}
	}