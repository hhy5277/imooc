	
	//缁戝畾keydown浜嬩欢
	document.onkeydown=function(evt){
		var keynum;
		var keychar;
		var numcheck;
		var arrNum=['96','97','98','99','100','101','102','103','104','105','110','190'];
		var arrNumChar=['0','1','2','3','4','5','6','7','8','9','.','.'];
		var arrOpera=['107','109','106','111'];
		var arrOperaChar=['+','-','脳','梅'];
		var objEvent=evt || event;
		keynum=objEvent.keyCode;
		keychar = String.fromCharCode(keynum);
		numcheck = /\d/;

		if(numcheck.test(keychar)){
			//alert(keychar);
			addnum(keychar);
		}

		for(var i=0;i<arrNum.length;i++){
			if(keynum==arrNum[i]){
				//alert(arrNumChar[i]);
				addnum(arrNumChar[i]);
			}
		}

		for(var i=0;i<arrOpera.length;i++){
			if(keynum==arrOpera[i]){
				//alert(arrOperaChar[i]);
				addexp(arrOperaChar[i]);
			}
		}

		if(keynum==13){
			//alert(keynum);
			addexp('');
			ajax();
		}

		if(keynum==8){
			//alert(keynum);
			back();
		}

		if(keynum==46){
			//alert(keynum);
			del();
		}
	}