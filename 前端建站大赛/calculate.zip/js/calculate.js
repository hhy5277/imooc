	
	//运算键部分的函数
	function addexp(val){
		if(num.value!=""){
			if(hidden1.innerHTML==""){
				express.value+=num.value+val;
			}else{
				express.value=num.value+val;
			}
			num.value="";
		}else if(num.value=="" && express.value!=""){
			express.value=express.value.substr(0,express.value.length-1)+val;
		}else{
			express.value=express.value;
		}
		hidden1.innerHTML="";
	}

	//数字键部分的函数
	function addnum(val){
		if(num.value.length<=10){
			if(val=='.'){
				if(num.value==''){
					num.value='0.';
				}else if(num.value.indexOf('.')!=-1){
					num.value=num.value;
				}
			}else{
				if(hidden1.innerHTML==""){
					num.value+=val;
				}else{
					express.value="";
					num.value=val;
				}
			}
		}
		hidden1.innerHTML="";
	}

	//退格键的函数
	function back(){
		if(num.value==""){
			express.value=express.value.substr(0,express.value.length-1);
		}else{
			num.value=num.value.substr(0,num.value.length-1);
		}
	}

	//清除所以内容，重新开始计算
	function del(){
		express.value="";
		num.value="";
	}