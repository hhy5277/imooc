<?php 
/**/
	header("content-type:text/html;charset=utf-8");
	//这里两句话很重要,第一讲话告诉浏览器返回的数据是xml格式
	//header("Content-Type: text/xml;charset=utf-8");
	//告诉浏览器不要缓存数据
	//header("Cache-Control: no-cache");

	$express = $_GET['express'];
	file_put_contents("result.txt",$express."\r\n",FILE_APPEND);
	//如何在调试过程中，看到接收到的数据 。
	$arrNum = preg_split("/[+|\-|*|\/|%]/",$express);
	$arrOpera = preg_split("/[\d|\.]+/",$express);
	$countNum = count($arrNum);
	$countOpera = count($arrOpera);
	for($i = 0;$i < $countOpera;$i++){
		if(!preg_match("/[+|\-|*|\/|%]/",$arrOpera[$i]) || strlen($arrOpera[$i]) != 1){
			//var_dump(preg_match("/[+|\-|*|\/|%]/",$arrOpera[$i]));
			//continue;
			unset($arrOpera[$i]);
			//echo $arrOpera[$i];
		}
	}
	$arrOpera = array_values($arrOpera);
	$result = 0;
	for($j = 0;$j < count($arrNum);$j++){
		if($j == 0){
			$result = (float)$arrNum[$j];
			
		}else{
			$result = (float)opera($result,$arrNum[$j],$arrOpera[($j - 1)]);
		}
	}
	function opera($num1,$num2,$ope){
		switch($ope){
			case '+':
				return $num1 + $num2;
				break;
			case '-':
				return $num1 - $num2;
				break;
			case '*':
				return $num1 * $num2;
				break;
			case '/':
				if($num2 == 0){
					echo '除数不能为0';
					exit;
				}else{
					return $num1 / $num2;
				}
				break;
			case '%':
				if($num2 == 0){
					echo '除数不能为0';
					exit;
				}else{
					return $num1 % $num2;
				}
				break;
		}
	}
	echo $result;
	//var_dump($arrNum);
	//var_dump($arrOpera);
	//var_dump($result);
?>