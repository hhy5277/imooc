package com.cn.service;

import com.cn.vo.User;

public interface LoginRegisterInter{
	
	public boolean loginCheck(User user);
	
	public boolean registerCheck();
}
