package com.cn.service;

import com.cn.vo.User;

public interface BankFunctionInter {
	
	public abstract boolean save(User user);
	
	public abstract boolean withDraw(User user);
}
