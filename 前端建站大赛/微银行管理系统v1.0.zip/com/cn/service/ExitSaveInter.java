package com.cn.service;

import com.cn.vo.User;

public interface ExitSaveInter {
	
	 public abstract void exitSave(User user);

}
