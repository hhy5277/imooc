package com.cn.util;
/**
 * 取出金额超出现有金额异常类
 * @author k17
 *
 */
public class WithDrawException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WithDrawException(){
		super();
	}
	
	public WithDrawException(String msg){
		super(msg);
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "取款金额太大,不能超过现有金额！！！";
	}
	
	
}
