package com.cn.util;
/**
 * 输入金额为负数自定义异常类
 * @author k17
 *
 */
public class NegativeException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NegativeException(){
		super();
	}
	
	public NegativeException(String msg){
		super(msg);
	}

	@Override
	public String toString() {
		return "输入的金额不能为负数！！！";
	}
	
}
