package com.cn.properties;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import com.cn.util.MD5Util;

/**
 * 读取系统文件和系统文件写入类
 * 
 * @author k17
 *
 */
public class UserProperties {

	/**
	 * @param args
	 */
	private Properties pro01 = null;
	private Properties pro02 = null;
	private File file01 = null;
	private File file02 = null;

	public UserProperties() {
		pro01 = new Properties();
		pro02 = new Properties();
		file01 = new File("src/user.properties");
		file02 = new File("src/money.properties");
	}

	/*
	 * 匹配系统文件中的信息是否匹配
	 */
	public boolean userMatch(String name, String password) {
		try {
			pro01.load(new FileInputStream(file01));
		} catch (FileNotFoundException e) {
			System.out.println("找不到user.properties文件！");
			try {
				if(file01.createNewFile()){
					System.out.println("系统自动创建user.properties文件成功！");
				}
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (MD5Util.MD5(password).equals(pro01.getProperty(name))) {
			return true;
		}
		return false;
	}

	/*
	 * 将新用户信息写入系统文件
	 */
	public void setUserMsg(String name, String password) {
		pro01.setProperty(name, MD5Util.MD5(password));
		try {
			pro01.store(new FileOutputStream(file01), "User Info");
			System.out.println(name + " 信息添加成功");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if(!file02.exists()){
			try {
				file02.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		try {
			pro02.load(new FileInputStream(file02));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		pro02.setProperty(name, "0.0");
		try {
			pro02.store(new FileOutputStream(file02), "Balance Info");
			System.out.println(name + " 初始化金额为0");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/*
	 * 从系统文件中获取用户余额
	 */
	public double getBalance(String name) {
		try {
			pro02.load(new FileInputStream(file02));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String balance = pro02.getProperty(name);
		if (balance != null) {
			return Double.parseDouble(balance);
		}
		return 0;
	}

	/**
	 * 从文件系统取出用户名对应的密码，判断是否为空
	 * 
	 * @param name
	 * @return
	 */
	public boolean getPassword(String name) {
		try {
			pro01.load(new FileInputStream(file01));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String password = pro01.getProperty(name);
		if (password != null) {
			return true;
		}
		return false;
	}

}
