package com.cn.properties;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import com.cn.vo.User;

public class BankProperties {
	
	private Properties pro = null;
	private File file = null;
	
	public BankProperties() {
		pro = new Properties();
		file = new File("src/money.properties");
	}
	
	/*
	 * 修改用户金额方法
	 */
	public void setMoney(User user){
		try {
			pro.load(new FileInputStream(file));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		String name = user.getName();
		double money = user.getMoney();
		pro.setProperty(name, money+"");
		try {
			pro.store(new FileOutputStream(file), "Balance Info");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
}
