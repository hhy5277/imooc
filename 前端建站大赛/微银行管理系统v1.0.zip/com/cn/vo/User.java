package com.cn.vo;

/**
 * 用户信息类
 * @author k17
 *
 */
public class User {
	
	private String name;
	private String password;
	private double money;
	
	private static User user = new User();
	
	private User(){
		
	}
	
	public static User getInstance(){
		return user;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	
	public void save(double balance){ //存钱操作
		this.money = this.money+balance;
	}
	
	public void withDraw(double balance){ //取钱操作
		this.money = this.money-balance;
	}
	
}
