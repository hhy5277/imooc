package com.cn.serviceImpl;

import java.util.Scanner;

import com.cn.properties.UserProperties;
import com.cn.service.LoginRegisterInter;
import com.cn.vo.User;
/**
 * 登陆和注册的检查类
 * @author k17
 * 
 */
public class LoginRegister implements LoginRegisterInter{

	/**
	 * @param args
	 */
	private  UserProperties userProperties = null;
	private  Scanner scan = new Scanner(System.in);
	
	public LoginRegister(){
		userProperties = new UserProperties();
		scan = new Scanner(System.in);
	}
	
	/*
	 * 登陆检查功能
	 */
	public boolean loginCheck(User user){
		System.out.println("请输入用户名：");
		String name = scan.nextLine();
		System.out.println("请输入密码：");
		String password = scan.nextLine();
		if("".equals(name)||"".equals(password)){
			System.out.println("不能输入空用户名或空密码！");
		}else if(userProperties.userMatch(name, password)){
			System.out.println(name+" 登录成功！");
			user.setName(name);
			user.setPassword(password);
			user.setMoney(userProperties.getBalance(name));
			System.out.println("1秒后进入主功能面板");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return true;
		}else {
			System.out.println("用户名或密码输入错误！");
		}
		
		return false;
	}
	
	/*
	 * 注册检查功能,并将新用户写入系统文件
	 */
	public boolean registerCheck(){
		System.out.println("请输入要注册的用户名:(不超过6个长度)");
		String name = scan.nextLine();
		System.out.println("请输入相应的密码:(不超过3个长度)");
		String password = scan.nextLine();
		if("".equals(name)||"".equals(password)){
			System.out.println("不能输入空用户名或空密码！");
		}else if(userProperties.getPassword(name)){
			System.out.println(name+" 用户名已注册请重新登录或注册！");
		}else{
			userProperties.setUserMsg(name, password);
			System.out.println(name+" 注册成功！请登录系统！");
		}
		return false;
			
	}
		
		
}
