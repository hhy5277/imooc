package com.cn.serviceImpl;

import java.util.Scanner;

import com.cn.service.BankFunctionInter;
import com.cn.util.NegativeException;
import com.cn.util.WithDrawException;
import com.cn.vo.User;
/**
 * 存取钱功能实现类
 * @author k17
 *
 */
public class BankFunction implements BankFunctionInter{
	
	private Scanner scan = null;
	
	public BankFunction(){
		scan = new Scanner(System.in);
	}
	
	/*
	 * 存钱功能,并判断存钱是否合法
	 */
	public boolean save(User user){
		System.out.println("输入要储存的金额：(只能是正数)");
		String money01 = scan.nextLine();
		double money02 = 0.0;
		try{
			 money02 = Double.parseDouble(money01);
		}catch(NumberFormatException e){
			System.out.println("警告！不能输入非数字金额！！！");
			return false;
		}
		if(money01==null||"".equals(money01)){
			System.out.println("不能输入空金额！");
		}else if(money02<0){
			try{
				throw new NegativeException("输入金额不能为负数!!！");
			}catch(NegativeException e){
				System.out.println(e.getMessage());
			}
		}else if(money02>=0){
			user.save(money02);
			return true;
		}
			
		return false;
	}
	
	/*
	 * 取款功能,并判断取款是否合法
	 */
	public boolean withDraw(User user){
		System.out.println("输入要取出的金额：(只能是整数)");
		String money01 = scan.nextLine();
		double money02 = 0.0;
		try{
			 money02 = Double.parseDouble(money01);
		}catch(NumberFormatException e){
			System.out.println("警告！不能输入非数字金额！！！");
			return false;
		}
		if(money01==null||"".equals(money01)){
			System.out.println("不能输入空金额！");
		}else if(money02<0){
			try{
				throw new NegativeException("输入金额不能为负数!!！");
			}catch(NegativeException e){
				System.out.println(e.getMessage());
			}
		}else if(money02>=0){
			if(money02>user.getMoney()){
				try{
					throw new WithDrawException("取款金额太大,不能超过现有金额！！！");
				}catch(WithDrawException e){
					System.out.println(e.getMessage());
				}
				return false;
			}
			user.withDraw(money02);
			return true;
		}
		
		return false;
	}
	
	
}
