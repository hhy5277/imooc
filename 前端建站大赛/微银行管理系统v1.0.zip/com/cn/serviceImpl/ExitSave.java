package com.cn.serviceImpl;

import com.cn.properties.BankProperties;
import com.cn.service.ExitSaveInter;
import com.cn.vo.User;
/**
 * 
 * @author k17
 *
 */
public class ExitSave implements ExitSaveInter {
	
	private BankProperties bankProperties = null;
	
	public ExitSave(){
		bankProperties = new BankProperties();
	}

	@Override
	public void exitSave(User user) {
		bankProperties.setMoney(user); //保存金额于系统文件中
		System.exit(1);
	}
	
	
}
