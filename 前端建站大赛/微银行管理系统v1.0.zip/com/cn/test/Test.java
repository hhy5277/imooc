package com.cn.test;

/**
 * �ۺϲ�����
 * @author k17
 * @version 1.0
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MainPanel.main(args);
	}

}
