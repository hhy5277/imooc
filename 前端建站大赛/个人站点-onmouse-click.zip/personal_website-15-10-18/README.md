# Personal_Website

//   2015/10/18

i use fullpage.js 

that nice !

and the file of this website   have some problem  last night.
and i fixed it just now.


//2016/3/5

it is personal website template

i am still hacking on this job 
and long time not update

I rebuild the website as a node website//time 2016/3/5


<hr>
### file path
per_page
    --view
        --index.jade //main page
    --public
        --css
            --mainstyle.css
        --js
            --hehe.js
        --img
        
    


_________________________________________________________________________________________________________________________
##### below this line will help u use the files

###

### How to use reset this website: 


#####index.html  &nbsp;&nbsp;&nbsp;&nbsp;HTML

html 
    -head
    
        -body
            -div  #dowebok  .content
                    -header .section .active
                    -section .green-section .section
                    -section .blue-section .section
                    -section .purple-section .section
                    -section .grey-section .section
                    -section .bottom .section
        
    

#####mainstyle.css  &nbsp;&nbsp;&nbsp;&nbsp;CSS



    

#####hehe.js  &nbsp;&nbsp;&nbsp;&nbsp;javasript


### install and start node








