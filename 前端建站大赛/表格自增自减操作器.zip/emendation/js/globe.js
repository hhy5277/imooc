jQuery(function($){
	/*
		a 标签 href 的事件
	*/
	jQuery(".no_a").click(function(){
		alert_demo2({
			title: "操作提示",
			text: "禁止进行该操作！",
			time: 50,
			before_open:function(){
				return false;
			}
		});	
		return false;
	});	
	//删除图集里面图片
	$(".enet360_upload_all").delegate("p","click",function(){
		if(window.confirm('你确定要删除此图片吗？')){
			var p=$(this);
			var f=p.children('img').attr('src');
			var validate={
				file:f
			};
			$.post(delFile, validate, function(data){
				if(data == '1')
				{
					p.remove();
				}
				else
				{
					alert('删除失败');
				}	
			});
		}
	});
	jQuery("#ymtiaozhuan").click(function(){
		var url=$(this).attr("val");
		var p = $("#p_page").val();
		if(p>0){
			p=p;
		}else{
			p=1;
		}
		window.location.href=url+"?"+page+"="+p;
	});
	/*
		class 为 url  点击弹出页面 attr url 
	*/
	jQuery(".buttonurl").click(function(){
		var url=jQuery(this).attr("url");
		if(url){
			window.location.href=url;
		}
	});
	jQuery(".url").click(function(){
		var url=jQuery(this).attr("url");
		if(url){
			visitList(url);
		}
	});
	jQuery(".hrefurl").click(function(){
		var url=jQuery(this).attr("url");
		if(url){
			// visitList(url);
			window.location.href=url;
		}
	});
	
	// 关闭弹出页面
	jQuery(".closehtml").click(function(){
		window.returnValue=0;
		window.close();
	});
	// 提交表单 成功以后关闭页面
	jQuery(".ajaxFromSubmit").click(function(){
		
		var form_id	=	jQuery(this).attr("form_id");
		var form_url	=	jQuery(this).attr("form_url");;
		
		// alert(form_id+'_'+form_url);
		
		$("#"+form_id).ajaxSubmit({  //
			url		:	form_url,
			type	:	"post",
			success	:	function(data){
				alert_demo2({
					title: "操作提示",
					text: data.name,
					time: 10,
					after_close:function(){
						if(data.id==1){
							window.returnValue=1;
							window.opener.location.reload(); 
							window.close();
						}
					}
				});				
			},
			dataType:	"json"
		});	
	});
	
	// 提交表单 成功以后刷新页面
	jQuery(".ajaxFromSubmitUrl").click(function(){
		var form_id	=	jQuery(this).attr("form_id");
		var form_url	=	jQuery(this).attr("form_url");;
		//alert(form_url);
		
		$("#"+form_id).ajaxSubmit({
			url		:	form_url,
			type	:	"post",
			success	:	function(data){
				alert_demo2({
					title: "操作提示",
					text: data.name,
					time: 10,
					after_close:function(){
						if(data.id==1){
							window.returnValue=1;window.location.reload(); 
						}
					}
				});
			},
			dataType:	"json"
		});	
	});
	jQuery(".ajaxFromSubmitUrllocation").click(function(){
		
		var form_id	=	jQuery(this).attr("form_id");
		var form_url	=	jQuery(this).attr("form_url");;
		//alert(form_url);
		
		$("#"+form_id).ajaxSubmit({
			url		:	form_url,
			type	:	"post",
			success	:	function(data){
				alert_demo2({
					title: "操作提示",
					text: data.name,
					time: 10,
					after_close:function(){
						if(data.id==1){
							window.location.reload(); 
						}
					}
				});
			},
			dataType:	"json"
		});	
	});
	/*
		点击执行删除事件
	*/
	jQuery(".jqdelete").click(function(){
		var url = jQuery(this).attr("url");
		
		jQuery.get(url,function(data){
			alert_demo2({
				title: "操作提示",
				text: data.name,
				time: 10,
				after_close:function(){
					window.location.reload(); 
				}
			});			
		},"json");
	});	
	var enet360_editor_all_a = [];
	jQuery(".enet360_editor_all").each(function(){
		enet360_editor_all_a[jQuery(this).attr("id")] = UE.getEditor(jQuery(this).attr("id"),{
            elementPathEnabled:false
		});
	});
	KindEditor.ready(function(K){
		/*var editor = K.create('.enet360_editor_all', {
			uploadJson : upload_json,
			fileManagerJson : file_manager_json,
			allowFileManager : true,
			filterMode : false,
			afterBlur: function(){editor.sync();}
		});*/
		var editor_upload = K.editor({
			uploadJson : upload_json,
			fileManagerJson : file_manager_json,
			allowFileManager : true,
			afterBlur: function(){editor_upload.sync();}
		});
		// 上传图片
		K('.enet360_upload_images').click(function(){
			var up_id = $(this).attr("varid");
			editor_upload.loadPlugin('image', function() {
				editor_upload.plugin.imageDialog({
					imageUrl : K('#'+up_id+'_input').val(),
					clickFn : function(url, title, width, height, border, align) {
						K('#'+up_id+'_input').val(url);
						$('#'+up_id+'_img').attr('src',url);
						editor_upload.hideDialog();
					}
				});
			});
		});

		//上传图片2
		$(document).on('click','.enet360_upload_images2',function(){
			var _self = this;
			editor_upload.loadPlugin('image', function() {
				editor_upload.plugin.imageDialog({
					imageUrl : $(_self).siblings('input:hidden').val(),
					clickFn : function(url, title, width, height, border, align) {
						$(_self).siblings('input:hidden').val(url);
						$(_self).siblings('img').attr('src',url);
						editor_upload.hideDialog();
					}
				});
			});
		});

		// 上传附件
		K('.enet360_upload_fail').click(function(){
			var up_id = $(this).attr("varid");
			editor_upload.loadPlugin('insertfile', function(){
				editor_upload.plugin.fileDialog({
					fileUrl : K('#'+up_id+'_input').val(),
					clickFn : function(url, title) {
						K('#'+up_id+'_input').val(url);
						editor_upload.hideDialog();
					}
				});
			});
		});
		
		//批量上传图片
		K('.enet360_upload_all_img').click(function(){
			var up_id = $(this).attr("varid");
			editor_upload.loadPlugin('multiimage', function() {
				editor_upload.plugin.multiImageDialog({
					clickFn : function(urlList) {
						var div = K('#'+up_id+'_div');
						K.each(urlList, function(i, data) {
							div.append('<p><img src="' + data.url + '" /><input type="hidden" name="img[]" value="' + data.url + '" /></p>');
						});
						editor_upload.hideDialog();
					}
				});
			});
		});
		
	});
});

function visitLists(url){
	var returnValue = window.showModalDialog(url, window, "dialogTop=0;dialogLeft=0;dialogWidth="+document.documentElement.clientWidth+";dialogHeight="+document.documentElement.clientHeight+";center=yes;help=no;resizable=no;status=no");
	//if(returnValue){
		window.opener.location.reload(); 
	//}
}
function visitList(url) {
	var w=document.documentElement.clientWidth-50;
	var h=document.documentElement.clientHeight-95;
    window.open(url,"","top=20,left=20,width=" + w + ",height=" + h + ",toolbar=no,menubar=no,scrollbars=yes,resizable=yes,location=no,status=no");
	//location.reload();
}
/*
function openwinx(url,name,w,h) { //refersh_window();close_window();
	if(!w) w=screen.width-4;
	if(!h) h=screen.height-95;
	url = url+'&pc_hash='+pc_hash;
    window.open(url,name,"top=100,left=400,width=" + w + ",height=" + h + ",toolbar=no,menubar=no,scrollbars=yes,resizable=yes,location=no,status=no");
}
*/