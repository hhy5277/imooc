/**
 * 表格增减插件开发
 *  @version 1.0
 *  @author zhangbo <1148427309@qq.com>
 * 一、CLASS_NAME
 * 		1) .container-am	 [整体容器]
 * 		2) .operate			 [一级内容]	
 * 		3) .container-am-two [二级容器]
 * 		4) .operate-two 	 [二级内容]
 * 二、OPERATE_NAME
 * 	二级栏位
 * 		1) .add-two	 [增加]
 * 		2) .del-two	 [减少]
 * 		3) .up-two	 [向上移动]
 * 		4) .down-two [向下移动]
 * 	一级栏位
 * 		1) .add-one [增加]
 * 		2) .del-one [减少]
 * 		3) .add-two-s [增加一个子级]
 * 		3) .del-two-s [删除所有子级]
 * 		4) .up-one	  [向上移动]
 * 		5) .down-one  [向下移动]
 **/
var emendation = function(form_name){
	this.$elem = $(form_name);
}
emendation.prototype = {
	init: function() {
		/* 二级操作事件 */
		this.$elem.on('click','.add-two','ADD',this.regulation_two);
		this.$elem.on('click','.del-two','DELETE',this.regulation_two);
		this.$elem.on('click','.up-two','UP',this.move_two);
		this.$elem.on('click','.down-two','DOWN',this.move_two);

		/* 一级操作事件 */
		this.$elem.on('click','.add-one','ADD',this.regulation_one);
		this.$elem.on('click','.del-one','DELETE',this.regulation_one);
		this.$elem.on('click','.add-two-s','INSERT',this.regulation_one);
		this.$elem.on('click','.del-two-s','DELETE-ALL',this.regulation_one);
		this.$elem.on('click','.close-under','HIDE',this.regulation_one);
		this.$elem.on('click','.up-one','UP',this.move_one);
		this.$elem.on('click','.down-one','DOWN',this.move_one);

		/* 提交事件 */
		// this.$elem.on('click',this.submit_name,this.submitting);
		return this;
	},

	//Regulation the second element
	regulation_two: function(event) {
		mode = event.data;
		var $operate_two  = $(this).parents('.operate-two');		
		var $container_am_two = $(this).parents('.container-am-two');
		var $operate = $container_am_two.siblings('.operate');
		if(mode == 'ADD') {
			$operate_two.after(document.getElementById('html_two').innerHTML);
		} else if(mode == 'DELETE') {
			var operate_all_lenght = $operate_two.siblings('.operate-two').length+1;
			if(operate_all_lenght == 1) {
				$operate.find('.add-two-s').show();
				$operate.find('.del-two-s').hide();
				$operate_two.parents('.container-am-two').hide();
			}
			$operate_two.remove();
		}
	},
	//Move the second element
	move_two: function(event) {
		mode = event.data;
		$operate_two = $(this).parents('.operate-two');
		if(mode == 'UP') {
			$operate_two_prev = $(this).parents('.operate-two').prev('.operate-two');
			if($operate_two_prev.length) {
				$operate_two_prev.insertAfter($operate_two);
			}
		} else if(mode == 'DOWN') {
			$operate_two_next = $(this).parents('.operate-two').next('.operate-two');
			if($operate_two_next.length) {
				$operate_two_next.insertBefore($operate_two);
			}
		}
	},

	//Regulation the first element
	regulation_one: function(event) {
		mode = event.data;
		var $operate = $(this).parents('.operate');
		var $container_am = $(this).parents('.container-am');
		var $container_am_two = $operate.siblings('.container-am-two');
		if(mode == 'ADD') {
			$('.del-one[visible=1]').show().removeAttr('visible');
			var init = get_init_pos($container_am.find('.close-under').attr('src'),1);
			var add_visible = $(this).siblings('.add-two-s').is(':visible');
			var del_visible = $(this).siblings('.del-two-s').is(':visible');
			var _param = [{init:init,add_visible:add_visible,del_visible:del_visible}];
			$container_am.after($('#html_one').tmpl(_param).html());
		} else if(mode == 'DELETE') {
			var operate_all_lenght = $('.container-am').length;
			if (operate_all_lenght == 2)  $container_am.siblings('.container-am').find('.del-one').hide().attr('visible','1');
			if(operate_all_lenght != 1) {
				$container_am.remove();
			}
		} else if(mode == 'INSERT') {
			$(this).hide().siblings('.del-two-s').show();
			$container_am_two.show().find('tbody').append(document.getElementById('html_two').innerHTML);
		} else if(mode == 'HIDE') {
			if($container_am_two.find('.operate-two').length) {
				var img_src = $(this).attr('src');
				var init = get_init_pos(img_src);
				var img_src = $(this).attr('src','img/'+init+'.gif');
				$container_am_two.toggle();
			}
		} else if(mode == 'DELETE-ALL') {
			if(confirm('确定要删除全部的子类吗？')) {
				$(this).siblings('.add-two-s').show().end().hide();
				$operate.find('.close-under').prop('src','img/0.gif');
				$container_am_two.hide().find('.operate-two').remove();
			}
		}
	},
	//Move the second element
	move_one: function(event) {
		mode = event.data;
		var $container_am = $(this).parents('.container-am');
		if(mode == 'UP') {
			var $container_am_prev = $(this).parents('.container-am').prev('.container-am');
			if($container_am_prev.length) {
				$container_am_prev.insertAfter($container_am);
			}
		} else if(mode == 'DOWN') {
			var $container_am_next = $(this).parents('.container-am').next('.container-am');
			if($container_am_next.length) {
				$container_am_next.insertBefore($container_am);
			}
		}
	},

	//Submitting the form for the elements
	submitting: function(e) {
		e.preventDefault();
		var container_am = '',
		ion = 0, itw = 0,//eachCount
		size = 0, _child = '', name = '', value = '', operate_two_length, operate_two_length2,container_am_two
		container_am2 = '';
		$('.container-am').find('.operate,.container-am-two').each(function(){
			itw = 0;
			if($(this).hasClass('operate')){
				ion++;
				operate_two_length = $(this).siblings('.container-am-two').find('.operate-two').length;
				container_am2 = each_ipt_str(this);

				//判断二级容器是否可见
				visible = $(this).siblings('.container-am-two').is(':visible');
				if(visible) visible = 1; else visible = 0;

				if(operate_two_length) {
					_child = ',"_child":['
				} else {
					_child = ',"_child":""},';
				}
				if(ion > 1)
					container_am += '{'+container_am2+',"visible":"'+visible+'"'+_child;
				else
					container_am += '[{'+container_am2+',"visible":"'+visible+'"'+_child;
			}
			operate_two_length2 = $(this).find('.operate-two').length;
			if($(this).hasClass('container-am-two') && operate_two_length2) {
				size = operate_two_length2;
				$(this).find('.operate-two').each(function(){
					itw++;
					// console.log(itw,size);
					container_am2 = each_ipt_str(this);
					if(itw == size)
						container_am += '{'+container_am2+'}]},';
					else
						container_am += '{'+container_am2+'},';
				});
			}
		});
		container_am = container_am.substring(0,container_am.length-1)+']';
		return container_am;
	},

	//Restore the last time save
	restore: function(jsondata) {
		$('.restore').on('click',function(){
			if(jsondata) {
				$('.container-am').remove();
				if(typeof jsondata == 'string') jsondata = JSON.parse(jsondata);
				// console.log(jsondata);
				$("#html_one_e").tmpl(jsondata,{
					restore_count: function() {
						return jsondata.length;
					}
				}).insertAfter($('.restore-container'));
			} else {
				alert('您还没有将此操作提交到数据库！');
			}
		});
		return this;
	}
};

var get_init_pos = function(img_src,opin){
	var init = img_src.substr(img_src.indexOf('.')-1,1);
	if(opin) return init;
	if(init == 0) init = 1;else init = 0;
	return init;
}
var each_ipt_str = function(_param){
	var name, value,
	container_am2 = '';
	$(_param).find('input[name]').each(function() {
		name = $(this).attr('name');
		value = $(this).val();
		container_am2 += '"'+name+'":"'+value+'",';
	});
	return container_am2.substring(0,container_am2.length-1);
}