<?php
define('APP_NAME', 'App');
//define('DEFAULT_MODULE', 'Home');
//引入核心入口文件
require 'Frame/Start.php';

  

