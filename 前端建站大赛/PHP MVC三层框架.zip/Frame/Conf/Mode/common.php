<?php
return array(
    'tags'      => array(
        'check_login'   => array(
            'admin\Behavior\CheckLogin'
        )
    )
);

  

