<?php
/**
 *          Mysqli(Frame\Driver\DB\Mysqli.class.php)
 *
 *    功　　能：MySQL数据库访问接口
 *
 *    作　　者：李伯特
 *    完成时间：2015/08/14
 *
 */
namespace Frame\Driver\DB;
use Frame\Db;

class Mysqli extends Db{
 
    public function __construct($config=''){
        if(!empty($config)){
            $this->config = $config;
            if(empty($this->config['params'])){
                $this->config['params'] = '';
            }
        }
    }
    private function connect($config='',$linkNum=0){
        if(!isset($this->linkID[$linkNum])){
            if(empty($config)) $config = $this->config;
            /**
             * 实例化：\mysqli()  全面的'\'不可去掉，不然默认是当前命名空间的类冲突
             * 此处的错误查找了半天时间才找出来，犯这样的低级错误还是基本功不扎实
             */
            @$this->linkID[$linkNum] = new \mysqli($config['hostname'],$config['username'],$config['password'],$config['database'],$config['hostport']?$config['hostport']:3306);
            if(mysqli_connect_error()) E('[数据库连接错误]'.mysqli_connect_errno().':'.mysqli_connect_error());
            // 设置数据库编码
            $this->linkID[$linkNum]->query("SET NAMES '".C('DB_CHARSET')."'");
            $this->connected = true;
        }
        return $this->linkID[$linkNum];
    }
    //以关联数组的格式从结果集中获取全部的数据
    private function getAll(){
        $result = array();
        if($this->numRows>=0){
            for($i=0;$i<$this->numRows;$i++){
                $result[$i] = $this->queryResult->fetch_assoc();
            }
            $this->queryResult->data_seek(0);
        }
        return $result;
    }
    private function error(){
        $this->error = $this->_linkID->errno.':'.$this->_linkID->error;
        if('' != $this->queryStr){
            $this->error .= "\n [SQL语句]:".$this->queryStr;
        }
        return $this->error;
    }
    protected function escapeString($str){
        if($this->_linkID){
            return $this->_linkID->real_escape_string($str);
        }else{
            return addslashes($str);
        }
    }
    /**
     * 释放当前暂存的结果集
     */
    protected function free(){
        $this->queryResult->free_result();
        $this->queryResult = null;
    }
    /**
     * 关闭当前数据库连接
     * @see \Frame\Db::close()
     */
    protected function close(){
        if($this->_linkID){
            $this->_linkID->close();
        }
        $this->_linkID = null;
    }
    //接口方法
    public function query($sql){
        $this->_linkID =$this->Connect();
        if(!$this->_linkID) return false;
        $this->queryStr = $sql;//记录当前正在执行的SQL
        //销毁当前结果集
        if($this->queryResult) $this->free();
        $this->queryResult = $this->_linkID->query($sql);
        if($this->_linkID->more_results()){
            while(($results = $this->_linkID->next_result()) != NULL){
                $results->free_result();
            }
        }
        if(false === $this->queryResult){
            E($this->error());
            return false;
        }else{
            $this->numRows = $this->queryResult->num_rows;
            $this->numCols = $this->queryResult->field_count;
            return $this->getAll();
        }
    }
    /**
     * 执行一条sql语句
     * @param  string $sql    sql语句字符串
     * @return int            返回受影响的行数
     * @see                   \Frame\Db::execute()
     */
    public function execute($sql){
        $this->_linkID = $this->Connect();
        if(!$this->_linkID) return false;
        $this->queryStr = $sql;
        if($this->queryResult) $this->free();
        $result = $this->_linkID->query($sql);
        if(false === $result){
            $this->error();
            return false;
        }else{
            $this->affectedRows = $this->_linkID->affected_rows;
            $this->lastInsertID = $this->_linkID->insert_id;//记录id，每次插入后都会更新
            return $this->affectedRows;
        }
    }
    public function insertAll($dataList,$options,$replace){
        
    }
    /**
     * 提交事务
     * @access public
     * @return boolean 提交成功返回true，失败返回false
     */
    public function commit(){
        //有事务时进行提交
        if($this->transTimes > 0){
            $result = $this->_linkID->commit();
            $this->_linkID->autocommit(true);
            $this->transTimes = 0;//提交后清空标识
            if(!$result){
                $this->error();
                return false;
            }
        }
        return true;
    }
    /**
     * 事务回滚
     * @access public
     * @return boolean
     * @see \Frame\Db::rollback()
     */
    public function rollback(){
        if($this->transTimes > 0){//有事务时进行回滚
            $result = $this->_linkID->rollback();
            $this->_linkID->autocommit(true);//开启自动提交
            $this->transTimes = 0;
            if(!result){
                $this->error();
                return false;
            }
        }
        return true;
    }
    /**
     * 启动事务
     * @access public
     * @return void
     */
    public function startTrans(){
        $this->_linkID = $this->connect();//连接数据库
        if($this->transTimes == 0){
            $this->_linkID->autocommit(false);//关闭自动提交
        }
        $this->transTimes++;
        return;
    }
    /**
     * 获取字段信息数组
     * @param unknown $tableName
     */
    public function getFields($tableName){
        $result = $this->query('SHOW COLUMNS FROM '.$this->parseKey($tableName));
        $info   = array();
        if($result){
            foreach ($result as $key => $val){
                $info[$val['Field']] = array(
                    'name'    => $val['Field'],
                    'type'    => $val['Type'],
                    'notnull' => (bool)($val['Null'] === ''),
                    'primary' => (strtolower($val['Key']) == 'pri'),
                    'autoinc' => (strtolower($val['Extra']) == 'auto_increment')
                );
            }
        }
        return $info;
    }
    protected function parseKey(&$key){
        $key = trim($key);
        if(!preg_match('/[,\'\"\*\(\)`.\s]/',$key)){
            $key = '`'.$key.'`';
        }
        return $key;
    }

}

  

