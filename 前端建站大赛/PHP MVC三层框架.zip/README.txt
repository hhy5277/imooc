<ol class=" list-paddingleft-2" style="list-style-type: decimal;"><li><h2>采用MVC分层设计原则，实现了模型控制器（Model）、视图控制器（View）、用户控制器（Controller）</h2></li><li><h2>内置模板解析引擎，可调用三方模板解析引擎（Samrty）</h2></li><li><h2>封装了数据库CURD，目前支持Mysql数据</h2></li><li><h2>自动部署</h2></li></ol>

