

  
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.http.Consts;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
/**
 * HTTP 请求类
 * @author stone
 */
@Service("httpClientService")
public class HttpClientService {
   
    private Logger logger = LoggerFactory.getLogger(getClass());
   
    private HttpClient client = HttpClientBuilder.create().build();
   
    /**
     * make a http get method to specified url
     * @param url url to access
     * @return result from {@link url}
     */
    public String get(String url) {
        try {
            HttpGet request = new HttpGet(url);
            HttpResponse response = client.execute(request);
            String result = EntityUtils.toString(response.getEntity(), Consts.UTF_8);
            logger.debug("<== {} - {} - {}", url, response.getStatusLine().getStatusCode(), result);
            return result;
        } catch (Exception e) {
            logger.error("http get error!", e);
        }
        return null;
    }

    /**
     * make a http post method to specified url
     * @param url url to access
     * @param nameValuePairs params to post
     * @return result from {@link url}
     */
    public String post(String url, NameValuePair... nameValuePairs) {
        try {
            HttpClient client = HttpClientBuilder.create().build();
            HttpPost post = new HttpPost(url);
            List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
            Collections.addAll(urlParameters, nameValuePairs);
            post.setEntity(new UrlEncodedFormEntity(urlParameters, Consts.UTF_8));
            HttpResponse response = client.execute(post);
            String result = EntityUtils.toString(response.getEntity(), Consts.UTF_8);
            logger.debug("<== {} - {} - {}", url, response.getStatusLine().getStatusCode(), result);
            return result;
        } catch (Exception e) {
            logger.error("http post error!", e);
        }
        return null;
    }
}


