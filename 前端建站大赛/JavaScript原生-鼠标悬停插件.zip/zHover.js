(function(){
	function zHover(opts){
		this.opts = opts;
		this.aChild = document.getElementById(this.opts.id).children;
		this.defaults = {
			opacity: '0.7',														// 浮层透明度
			duration: '200',													// 运动的快慢
			easing: 'ease-in',													// 运动方式（加速）
			text: [																	
					{'title': '1', 'content': '', 'href': 'javascript:;'}
					,{'title': '', 'content': '', 'href': 'javascript:;'}
					,{'title': '', 'content': '', 'href': 'javascript:;'}
					,{'title': '', 'content': '', 'href': 'javascript:;'}
					,{'title': '', 'content': '', 'href': 'javascript:;'}
					,{'title': '', 'content': '', 'href': 'javascript:;'}
					,{'title': '', 'content': '', 'href': 'javascript:;'}
					,{'title': '', 'content': '', 'href': 'javascript:;'}
				],																// 浮层文本及链接
			pattern: 'sildeTop',												// 动画风格
			fSize: '2',															// 标题字体大小
			fSize: '1'															// 描述字体大小
		};
		this.extend(this.defaults, this.opts);
		this.init();
		if(this.defaults.pattern == 'zoomIn'){
			this.zoomInInit();
		}else if(this.defaults.pattern == 'sildeTop'){
			this.sildeTopInit();
		}
	}

	var zProto = zHover.prototype;

	// 样式初始化
	zProto.init = function(){
		for(var i = 0; i < this.aChild.length; i++){
			this.aChild[i].style.display = 'block';
			this.aChild[i].style.overflow = 'hidden';
			this.aChild[i].style.position = 'relative';
			this.aChild[i].style.float = 'left';
			this.aChild[i].style.cursor = 'pointer';
		}
		this.sW = this.aChild[0].children[0].offsetWidth;
		this.sH = this.aChild[0].children[0].offsetHeight;
	};
	// 效果 zoomIn 初始化
	zProto.zoomInInit = function(){
		for(var i = 0; i < this.aChild.length; i++){
			this.aChild[i].appendChild(this.createEle1(i));
		}
		this.zoomIn();
	};
	// 效果 sildeTop 初始化
	zProto.sildeTopInit = function(){
		for(var i = 0; i < this.aChild.length; i++){
			this.aChild[i].appendChild(this.createEle(i));
		}
		this.sildeTop();
	};
	// 效果 zoomIn 事件
	zProto.sildeTop = function(){
		var _this = this;
		for(var i = 0;i< this.aChild.length; i++){
			(function(index){
				_this.aChild[i].onmouseenter = function(){
					this.oDiv = this.children[1];
					move(this.oDiv, {bottom: 0}, {duration: _this.defaults.duration, easing: _this.defaults.easing});
				}
				_this.aChild[i].onmouseleave = function(){
					this.oDiv = this.children[1];
					this.B = this.oDiv.offsetHeight;
					move(this.oDiv, {bottom: -this.B}, {duration: _this.defaults.duration, easing: _this.defaults.easing});
				}
			})(i);
		}
	};
	// 效果 sildeTop 事件
	zProto.zoomIn = function(){
		var _this = this;
		for(var i = 0;i< this.aChild.length; i++){
			(function(index){
				_this.aChild[i].onmouseenter = function(){
					this.oImg = this.children[0];
					this.W = this.oImg.offsetWidth*1.15;
					this.H = this.oImg.offsetHeight*1.15;
					this.T = -(this.W - this.oImg.offsetWidth)/2;
					this.L = -(this.H - this.oImg.offsetHeight)/2;
					this.oDiv = this.children[2];
					this.oA = this.children[1];
					var that = this;
					move(this.oImg, {width: this.W, height: this.H, top: this.T ,left: this.L}, {duration: _this.defaults.duration, easing: _this.defaults.easing, complete: function(){ that.oA.style.display = 'block'; }});
					move(this.oDiv, {opacity: 0}, {duration: _this.defaults.duration, easing: _this.defaults.easing});
				};
				_this.aChild[i].onmouseleave = function(){
					this.oImg = this.children[0];
					this.oDiv = this.children[2];
					this.oA = this.children[1];
					var that = this;
					move(this.oImg, {width: _this.sW, height: _this.sH, top: 0 ,left: 0}, {duration: _this.defaults.duration, easing: _this.defaults.easing});
					move(this.oDiv, {opacity: _this.defaults.opacity}, {duration: _this.defaults.duration, easing: _this.defaults.easing, complete: function(){ that.oA.style.display = 'none'; }});
				};
			})(i);
		}
	};

	// 效果 zoomIn 加载样式
	zProto.createEle1 = function(index){
		var _this = this;
		this.aChild = document.getElementById(this.opts.id).children;
		this.w = this.aChild[0].offsetWidth;
		this.h = this.aChild[0].offsetHeight;
		this.aChild[index].children[0].style.position = 'absolute';
		this.newEle = document.createElement('div');
		this.newEle.style.width = this.w + 'px';
		this.newEle.style.height = this.h + 'px';
		this.newEle.style.position = 'absolute';
		this.newEle.style.top = 0;
		this.newEle.style.backgroundColor = 'rgb(0,0,0)';
		this.newEle.style.opacity = this.defaults.opacity;
		this.newEle.style.filter='alpha(opacity:' + this.defaults.opacity*100+')';
		this.newDiv = document.createElement('div');
		this.newDiv.style.width = '100%';
		this.newDiv.style.height = '100%';
		this.newDiv.style.position = 'absolute';
		this.newDiv.style.zIndex = 1000;
		this.newDiv.style.display = 'none';
		this.newDiv.innerHTML = '<a href="'+ this.defaults.text[index].href +'" style="text-decoration: none; "><h1 style="color:#fff; text-align: center; margin:15%; overflow: hidden; font-size: '+ this.defaults.fSize +'em;">'+ this.defaults.text[index].title +'</h1>'
					+'<p style="color:#fff; text-align: center">'+ this.defaults.text[index].content +'</p></a>';
		this.aChild[index].appendChild(this.newDiv);
		return this.newEle;
	};
	// 效果 sildeTop 加载样式
	zProto.createEle = function(index){
		this.aChild = document.getElementById(this.opts.id).children;
		this.w = this.aChild[0].offsetWidth;
		this.h = this.aChild[0].offsetHeight;
		this.newEle = document.createElement('div');
		this.newEle.style.width = this.w + 'px';
		this.newEle.style.height = this.h + 'px';
		this.newEle.style.position = 'absolute';
		this.newEle.style.backgroundColor = 'rgba(0,0,0,'+ this.defaults.opacity +')';
		this.newEle.style.bottom = -this.h +'px';
		this.newEle.innerHTML = '<a href="'+ this.defaults.text[index].href +'" style="text-decoration: none"><h1 style="color:#fff; text-align: center; margin:15%; font-size: 2em;">'+ this.defaults.text[index].title +'</h1>'
					+'<p style="color:#fff; text-align: center">'+ this.defaults.text[index].content +'</p></a>'
		return this.newEle;
	};
	// extend 封装
	zProto.extend = function (target, source){
	    for (var p in source) {
	        if (source.hasOwnProperty(p)) {
	            target[p] = source[p];
	        }
	    }
	    return target;
	};
	/**
	 * @description 		获取非行间样式 
	 * @param  {Object} obj  		html元素
	 * @param  {[type]} name 		样式名称
	 */
	function getStyle(obj, name){
		return (obj.currentStyle || getComputedStyle(obj,false))[name];
	}
	/**
	 * description 		运动函数封装
	 * @param  {Object} obj     	html元素
	 * @param  {Object} json      	样式 {width: 600, height:300}
	 * @param  {Object} options   	运动参数 {duration：400, easing: 'ease-in', complete:function(){ ... }} 
	 *                            			duration 	每次运动需要的时间
	 *                            			easing		运动的方式  ease-in 加速   ease-out 减速    linear 匀速
	 *                            			complete    运动完成执行的函数
	 */
	function move(obj, json, options){
		//考虑默认值
		options=options || {};
		options.duration=options.duration || 700;
		options.easing=options.easing || 'ease-out';
		var count=Math.round(options.duration/30);
		var start={};
		var dis={};
		for(var name in json){
			start[name]=parseFloat(getStyle(obj,name));
			if(isNaN(start[name])){
				switch(name){
					case 'left':
						start[name]=obj.offsetLeft;
						break;
					case 'top':
						start[name]=obj.offsetTop;
						break;
					case 'width':
						start[name]=obj.offsetWidth;
						break;
					case 'height':
						start[name]=obj.offsetHeight;
						break;
					case 'marginLeft':
						start[name]=obj.offsetLeft;
						break;
					case 'opacity':
						start[name]=obj.style.opacity;
						break;
				}
			}
			dis[name]=json[name]-start[name];
		}
		var n=0;
		clearInterval(obj.timer);
		obj.timer=setInterval(function(){
			n++;
			for(var name in json){
				switch(options.easing){
					case 'linear':
						var a=n/count;
						var cur=start[name]+dis[name]*a;
						break;
					case 'ease-in':
						var a=n/count;
						var cur=start[name]+dis[name]*a*a*a;
						break;
					case 'ease-out':
						var a=1-n/count;
						var cur=start[name]+dis[name]*(1-a*a*a);
						break;
				}
				
				if(name=='opacity'){
					obj.style.opacity=cur;
					obj.style.filter='alpha(opacity:'+cur*100+')';
				}else{
					obj.style[name]=cur+'px';
				}
			}
			if(n==count){
				clearInterval(obj.timer);
				options.complete && options.complete();
			}
		},30);
	}

	window.zConfig = function(opt){
		return new zHover(opt);
	};
	
})();