<h2><strong>百度知道9周年-HTML5动画活动页</strong></h2><p>另存收藏的百度知道9周年，用Html5做的一个场景动画活动页面。没用canvas写的。全用JS写的！这类东西，改把改把就可以当简历使。好用，谁用谁知道。</p><p><img src="http://img.mukewang.com/558cb868000191b405000263.jpg" style=""/></p><p><img src="http://img.mukewang.com/558cb86c0001368d05000306.jpg" style=""/></p><p><img src="http://img.mukewang.com/558cb86d00019e4905000320.jpg" style=""/></p><p><br/></p>

