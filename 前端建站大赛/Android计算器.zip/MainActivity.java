package com.itheima.iterator;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity implements OnClickListener {
    // 初实化对象
	private Button bt_0;
	private Button bt_1;
	private Button bt_2;
	private Button bt_3;
	private Button bt_4;
	private Button bt_5;
	private Button bt_6;
	private Button bt_7;
	private Button bt_8;
	private Button bt_9;

	private Button bt_plus;
	private Button bt_divide;
	private Button bt_multiply;
	private Button bt_minus;

	private Button bt_point;
	private Button bt_clear;
	private Button bt_delete;

	private Button bt_equal;

	private EditText inputNumber;
	boolean flag;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// 通过ID获取各对象
		bt_0 = (Button) this.findViewById(R.id.bt_0);
		bt_1 = (Button) this.findViewById(R.id.bt_1);
		bt_2 = (Button) this.findViewById(R.id.bt_2);
		bt_3 = (Button) this.findViewById(R.id.bt_3);
		bt_4 = (Button) this.findViewById(R.id.bt_4);
		bt_5 = (Button) this.findViewById(R.id.bt_5);
		bt_6 = (Button) this.findViewById(R.id.bt_6);
		bt_7 = (Button) this.findViewById(R.id.bt_7);
		bt_8 = (Button) this.findViewById(R.id.bt_8);
		bt_9 = (Button) this.findViewById(R.id.bt_9);
		bt_plus = (Button) this.findViewById(R.id.bt_plus);
		bt_multiply = (Button) this.findViewById(R.id.bt_multiply);
		bt_divide = (Button) this.findViewById(R.id.bt_divide);
		bt_minus = (Button) this.findViewById(R.id.bt_minus);
		bt_point = (Button) this.findViewById(R.id.bt_point);
		bt_delete = (Button) this.findViewById(R.id.bt_delete);
		bt_clear = (Button) this.findViewById(R.id.bt_clear);
		bt_equal = (Button) this.findViewById(R.id.bt_equal);
		inputNumber = (EditText) this.findViewById(R.id.edit_number);

		bt_0.setOnClickListener(this);
		bt_1.setOnClickListener(this);
		bt_2.setOnClickListener(this);
		bt_3.setOnClickListener(this);
		bt_4.setOnClickListener(this);
		bt_5.setOnClickListener(this);
		bt_6.setOnClickListener(this);
		bt_7.setOnClickListener(this);
		bt_8.setOnClickListener(this);
		bt_9.setOnClickListener(this);
		bt_plus.setOnClickListener(this);
		bt_multiply.setOnClickListener(this);
		bt_divide.setOnClickListener(this);
		bt_minus.setOnClickListener(this);
		bt_point.setOnClickListener(this);
		bt_delete.setOnClickListener(this);
		bt_clear.setOnClickListener(this);
		bt_equal.setOnClickListener(this);

	}

	@Override
	public void onClick(View view) {
		// TODO Auto-generated method stub
		String str = inputNumber.getText().toString();
		switch (view.getId()) {
		case R.id.bt_0:
		case R.id.bt_1:
		case R.id.bt_2:
		case R.id.bt_3:
		case R.id.bt_4:
		case R.id.bt_5:
		case R.id.bt_6:
		case R.id.bt_7:
		case R.id.bt_8:
		case R.id.bt_9:
			if (flag) {
				flag = false;
				str = "";
				inputNumber.setText("");
			}
			inputNumber.setText(str + ((Button) view).getText());
			break;
		case R.id.bt_plus:
		case R.id.bt_multiply:
		case R.id.bt_minus:
		case R.id.bt_divide:
			if (flag) {
				flag = false;
				str = "";
				inputNumber.setText("");
			}
			inputNumber.setText(str + " " + ((Button) view).getText() + " ");
			break;
		case R.id.bt_clear:
			flag = false;
			str = "";
			inputNumber.setText("");
			break;
		case R.id.bt_delete:
			if (flag) {
				flag = false;
				str = "";
				inputNumber.setText("");
			} else if (str != null && !str.equals(""))
				inputNumber.setText(str.substring(0, str.length() - 1));
			break;
		case R.id.bt_equal:
			getResult();
			break;
		}
	}

	private void getResult() {
		// TODO Auto-generated method stub
		String exp = inputNumber.getText().toString();

		if (exp == null || exp.equals("")) {
			return;
		}

		if (!exp.contains(" ")) {
			return;
		}
		if (flag) {
			flag = false;
			return;
		}
		flag = true;
		String s1 = exp.substring(0, exp.indexOf(" "));
		String op = exp.substring(exp.indexOf(" ") + 1, exp.indexOf(" ") + 2);
		String s2 = exp.substring(exp.indexOf(" ") + 3);

		double result = 0;

		if (!s1.equals(" ") && !s2.equals(" ")) {
			double d1 = Double.parseDouble(s1);
			double d2 = Double.parseDouble(s2);
			if (op.equals("+")) {
				result = d1 + d2;
			} else if (op.equals("-")) {
				result = d1 - d2;
			} else if (op.equals("*")) {
				result = d1 * d2;
			} else if (op.equals("/")) {
				if (d2 == 0) {
					inputNumber.setError("除数不能为空!");
					inputNumber.setText("");
					return;
				} else {
					result = d1 / d2;
				}
			}
			if (!s1.contains(".") && !s2.contains(".")&&!op.equals("/")) {
				int r = (int) result;
				inputNumber.setText(r + "");
			} else {
				inputNumber.setText(result + "");
			}
		} else if (!s1.equals("") && s2.equals("")) {
			inputNumber.setText(exp);
		} else if (s1.equals("") && !s2.equals("")) {
			double d2 = Double.parseDouble(s2);
			if (op.equals("+")) {
				result = 0 + d2;
			} else if (op.equals("-")) {
				result = 0 - d2;
			} else if (op.equals("*")) {
				result = 0;
			} else if (op.equals("/")) {
				result = 0;
			}
			if (!s2.contains(".")) {
				int r = (int) result;
				inputNumber.setText(r + "");
			} else {
				inputNumber.setText(result + "");
			}
		} else {
			inputNumber.setText("");
		}

	}

}


  

