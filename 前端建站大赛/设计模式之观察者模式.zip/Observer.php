<?php 
/*
     设计模式之：观察者模式
     适用场景：当一个对象的改变需要给变其它对象时，而且它不知道具体有多少个对象有待改变时
                 一个抽象某型有两个方面，当其中一个方面依赖于另一个方面，这时用观察者模式可以将这两者封装在独立的对象中使它们各自独立地改变和复用
 */


//抽象主题（Subject）：它把所有观察者对象的引用保存到一个聚集里
//每个主题都可以有任何数量的观察者。抽象主题提供一个接口，可以增加和删除观察者对象。
interface Obserserable{
    function attach(Observer $Observer);
	function detach(Observer $Observer);
	function notify($someone);
}
//具体主题（ConcreteSubject）：将有关状态存入具体观察者对象；
//在具体主题内部状态改变时，给所有登记过的观察者发出通知
class boss implements Obserserable{
	private $Observers = array();
	function attach(Observer $Observer){
		$this->Observers[] = $Observer;
	}
	function detach(Observer $Observer){}
	function notify($someone=null){
		
		 foreach ($this->Observers as $obs) {
		 	  echo get_class($obs).'你'. $obs->doing.'<br/>';
		 }
		
	} 
}
//具体主题（ConcreteSubject）：将有关状态存入具体观察者对象；
//在具体主题内部状态改变时，给所有登记过的观察者发出通知
class Secretary implements Obserserable{
	private $Observers = array();

	function attach(Observer $Observer){
         $this->Observers[] = $Observer;
	}
	function detach(Observer $Observer){
		 $newObservers = array();
		 foreach($this->Observers as $ob ){
		 	  if($ob == $Observer){
		 	  	  $newObservers[] = $ob;
		 	  }
		 }
		 $this->Observers = $newObservers;
	}

	function notify($someone){
		 if($someone instanceof boss){
		 foreach ($this->Observers as $obs) {
		 	   $obs->update($this);
		 }
		}
	}

}
//抽象观察者（Observer）：为所有的具体观察者定义一个接口，在得到主题通知时更新自己
interface Observer{
	 function update(Obserserable $Obserserable);
}
abstract class employer implements Observer{
	     protected  $condition;
	 function __construct(Obserserable $Obserserable=null){
	 	  $this->condition = $Obserserable;
	 	  if($Obserserable!=null){
          $Obserserable->attach($this);
      }
	 }
	 function update(Obserserable $Obserserable){
	 	  if($Obserserable == $this->condition){
	 	  	   $this->doupdate();
	 	  }
	 }
	 abstract function doupdate();
}
// 具体观察者（ConcreteObserver）：实现抽象观察者角色所要求的更新接口，以便使本身的状态与主题状态协调。
class zhang extends employer{
	 public $doing;
	 function doupdate(){
	 	  $this->working();
	 }
	 function working(){
          $this->doing ='在赶着自己的项目，码代码中';
	 }
	 function notworking(){
          $this->doing ='！！没在工作，在谈论炒股的事情';
	 }
}
// 具体观察者（ConcreteObserver）：实现抽象观察者角色所要求的更新接口，以便使本身的状态与主题状态协调。
class wang extends employer{
	 public $doing;
	 function doupdate(){
	 	  $this->working();
	 	}
	  function working(){
          $this->doing ='在做分内的工作，码代码中';
	 }
	 function notworking(){
          $this->doing ='！！没在工作，在看NBA直播';
	 }
}

header('content-type:text/html;charset=utf8');
//创建一个前台秘书
$secretary = new Secretary();
//创建两个员工 小张和小王
//小王和前台秘书没有搞好关系 而小张经常献出自己的身体
$wang = new wang();
$zhang = new zhang($secretary);  //此时小张是具体观察者 前台秘书室具体被观察对象 一旦秘书处发生主题改变 将会通知再秘书处注册过的观察者
//两个人都在工作时间不务正业 
$wang->notworking();
$zhang->notworking();
//模拟老板回来了
$boss = new boss();
//模拟卧底秘书通知没在工作的员工 
$secretary->notify($boss);
//模拟老板视察员工状况
$boss->attach($wang);
$boss->attach($zhang);
$boss->notify();








 ?>

