/**
* 瀹氫箟妯″潡1
*/
define(function(){

	return {
		a : 4
	};
});