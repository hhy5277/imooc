/*
* 瀹氫箟main妯″潡
*/
require(['mod2'],function(m2){

	alert(m2.a * m2.b);
});