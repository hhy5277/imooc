/*
* 瀹氫箟妯″潡2
*/
define(['mod1'],function(m1){
	
	var a, b = 2, c = 3;
	a = c * m1.a;
	return {
		a : a,
		b : b
	};
});
