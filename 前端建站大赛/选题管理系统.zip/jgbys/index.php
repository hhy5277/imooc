<?php
define('APP_DEBUG',TRUE);

define('THINK_PATH','./ThinkPHP/');
define('APP_NAME','myapp');
define('APP_PATH','./myapp/');

require(THINK_PATH.'ThinkPHP.php');

App::run();
?>
