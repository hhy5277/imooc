<?php
//以下为后台模块的操作
class IndexAction extends Action{
    function _initialize(){
    	header("Content-type:text/html;charset=utf-8");
    }
    function index(){
        $url=U("login");
    	header("Location:$url");
    }
    function login(){      //登录模块
    	$this->display();
    }
    function check_logined(){    //检测是否已经登录，注意跟下面的判断是否登录成功是不同的，这个要调用在各个页面中。
    	session_start();
    	$user=M('Admin');
    	$condition['username']=$_SESSION['username'];
    	$us=$user->where($condition)->find();
        if(!$us){$url=U('login');
		$this->assign("jumpUrl",$url);
		$this->error("还未登陆");}
    }
    function admin() {     //后台管理首页
    	$this->check_logined();
    	$date=date("Y年m月d日",time());
    	$this->assign(date,$date);
    	$this->assign('username',$_SESSION['username']);
    	$this->display();

    }
    function siteinfo(){  //后台管理的首页信息
    	$this->check_logined();
    	$this->display();
    }
    function check_login(){       //判断是否登录成功
    	session_start();
    	$user=M('Admin');
    	if(!$data=$user->create()){
    		$this->error("登录失败");
    	}
    	$condition['username']=$data['username'];
    	$us=$user->where($condition)->find();
    	if(!$us){ $this->error("用户名或者密码错误！！");}
    	if($us['password']!=md5($data['password'])){$this->error("用户名或者密码错误！！");}
    	$_SESSION['username']=$data['username'];
    	$this->assign("jumpUrl",U('admin'));
    	$this->success("登录成功");
    }
    function admin_exit(){      //退出系统
    	$this->check_logined();
    	unset($_SESSION['username']);   
    	$this->assign("jumpUrl",U('login'));
    	$this->success("退出成功");
    }
    function manageStuInfo(){     //管理学生信息
    	$this->check_logined();
    	$stu=M("Student");
    	$count=$stu->count();
    	$listRows=10;
        import("ORG.Util.Page");
        $p=new Page($count,$listRows);
        $limit_options=$p->firstRow.",".$p->listRows;
    	$stu_info=$stu->order("id desc")->limit($limit_options)->findAll();
    	$page=$p->show();
    	$this->assign("page",$page);
    	$this->assign("pagestyle","green-black");
    	$this->assign("stu_info",$stu_info);
    	$this->display();
    }
    function editStuInfo(){      //编辑学生信息
            $this->check_logined();
            $stu=M("Student");
            $id=$_GET['id'];
            if(empty($id))   $this->error("参数为空");
            $stuInfo=$stu->where("id=$id")->find();
            $checked="";
            if($stuInfo[sex]=="女") $checked="checked";
            $this->assign("checked",$checked);
            $this->assign("stuInfo",$stuInfo);
            $this->display();
    }
    function updateStuInfo(){    //更新学生信息
        $this->check_logined();
        $stu=M('Student');
    	$id=$_GET['id'];
    	if(!$data=$stu->create()){
    		$this->error("修改失败");
    	}
    	if(!$stu->where("id=$id")->save($data)){
    		$this->error("修改失败");
    	}
    	$this->success("修改成功");
    }
    function deleteStuInfo(){      //删除学生信息
    	 $this->check_logined();
    	 $id=$_GET['id'];
    	 $condition['id']=$id;
    	 $stu=M('Student');
    	 if(!$stu->where($condition)->limit('1')->delete()){
    	 	$this->error("删除失败");
    	 }
    	 $selected=M("selected");
    	 if($selected_info=$selected->where("stu_id=$id")->select()){
    	 	 $selected->where("stu_id=$id")->delete();    //如果这个学生有选课信息，把该学生选课信息删除掉。
    	 	 for($i=0;$i<count($selected_info);$i++){
    	 	 	 $course_id[$i]=$selected_info[$i]['course_id'];
    	 	 }
    	 	 $course=M("Course");
    	 	 $map['id']=array("in",$course_id);
    	 	 $course->setDec("selectedMan",$map);   //并把这个学生选的课的已选人数减少一个。
    	 }
    	 $this->success("删除成功");
    }
    function importStuInfo(){    //添加学生信息，分手工添加和sql添加两种
    	$this->check_logined();
    	$this->display();
    }
    function addStuInfo(){      //手工添加学生信息
    	$this->check_logined();
    	$stu=M('Student');
    	if(!$stu->create()){
    		$this->error("添加失败");
    	}
    	if(!$stu->add()){
    		$this->error("添加失败");
    	}
    	$this->success("添加成功");
    }
    function importStuSql(){      //sql添加学生信息，这主要用于从其它数据库导出学生信息，再导入到本数据库来，注意字段跟表要构造出一致来。
    	$this->check_logined();
    	if(!empty($_FILES['sqlStuFile']['name'])) {
            // 判断文件后缀
            $pathinfo = pathinfo($_FILES['sqlStuFile']['name']);
            $ext  =   $pathinfo['extension'];
            if(!in_array($ext,array('sql','txt'))) {
                $this->error("文件格式不符合！！");
            }
            // 导入SQL文件
           $sql = file_get_contents($_FILES['sqlStuFile']['tmp_name']);
        }else{
            $this->error("请选择文件！！");
        }
           unlink($_FILES['sqlStuFile']['tmp_name']);
           if ($sql !== mb_convert_encoding(mb_convert_encoding($sql, "UTF-32", "UTF-8"), "UTF-8", "UTF-32")) {
                 $sql=iconv("gb2312","utf-8",$sql);
           }
           $check_arr=array("select","delete","drop");
           for($i=0;$i<count($check_arr);$i++){
           	    if(strchr($sql,$check_arr[$i])){$this->error("含有非法字符！！");}
           }
           $sql=str_replace("\r\n","\n",$sql);
           $sql=trim($sql);
           if((strrpos($sql,";")+1)==strlen($sql)) $sql=substr($sql,0,-1);
           $query_sql=explode(";",$sql);
           $stu=M("Student");
           foreach($query_sql as $sql){
           	     if(!$stu->execute(trim($sql))){$this->error("sql语句有误！！请仔细检查！！");}
           }
           $this->success("导入成功");
    }
    function manageTeacInfo(){     //管理教师信息
    	$this->check_logined();
    	$teac=M("Teacher");
    	$count=$teac->count();
    	$listRows=10;
        import("ORG.Util.Page");
        $p=new Page($count,$listRows);
        $limit_options=$p->firstRow.",".$p->listRows;
    	$teac_info=$teac->order("id desc")->limit($limit_options)->findAll();
    	$page=$p->show();
    	$this->assign("page",$page);
    	$this->assign("pagestyle","green-black");
    	$this->assign("teac_info",$teac_info);
    	$this->display();
    }
    function editTeacInfo(){      //编辑教师信息
            $this->check_logined();
            $teac=M("Teacher");
            $id=$_GET['id'];
            if(empty($id))   $this->error("参数为空");
            $teacInfo=$teac->where("id='$id'")->find();
            $checked="";
            $checked="checked";
            $this->assign("checked",$checked);
            $this->assign("teacInfo",$teacInfo);
            $this->display();
    }
    function updateTeacInfo(){       //更新教师信息
        $this->check_logined();
        $teac=M('Teacher');
    	$id=$_GET['id'];
    	if(!$data=$teac->create()){
    		$this->error("修改失败");
    	}
    	if(!$teac->where("id='$id'")->save($data)){
    		$this->error("修改失败");
    	}
    	$this->success("修改成功");
    }
    function deleteTeacInfo(){      //删除教师信息
    	 $this->check_logined();
    	 $id=$_GET['id'];
    	 $teac=M('Teacher');
    	 $teac_info=$teac->where("id='$id'")->find();
    	 if(!$teac->where("id='$id'")->limit('1')->delete()){
    	 	$this->error("删除失败");
    	 }
         $course=M("Course");
         if($course_info=$course->where("teacher_id=$id")->select()){
         	 $course->where("teacher_id=$id")->delete();      //如果这个老师有发布课程，把它删除掉。
         	 for($i=0;$i<count($course_info);$i++){
         	 	$course_id[$i]=$course_info[$i]['id'];
         	 }
         	 $map['course_id']=array("in",$course_id);
         	 $selected=M("selected");
         	 if($selected->where($map)->select()){
         	 	$selected->where($map)->delete();  //如果有学生选了这个老师的课，把选课信息删除掉。
         	 }
         }
    	 $this->success("删除成功");
    }
    function importTeacInfo(){    //添加教师信息，分手工添加和sql添加两种
    	$this->check_logined();
    	$this->display();
    }
    function addTeacInfo(){     //手工添加教师信息
    	$this->check_logined();
    	$teac=M('Teacher');
    	if(!$teac->create()){
    		$this->error("添加失败");
    	}
    	if(!$teac->add()){
    		$this->error("添加失败");
    	}
    	$this->success("添加成功");
    }
    function importTeacSql(){     //sql添加教师信息
    	$this->check_logined();
    	if(!empty($_FILES['sqlTeacFile']['name'])) {
            // 判断文件后缀
            $pathinfo = pathinfo($_FILES['sqlTeacFile']['name']);
            $ext  =   $pathinfo['extension'];
            if(!in_array($ext,array('sql','txt'))) {
                $this->error("文件格式不符合！！");
            }
            // 导入SQL文件
           $sql = file_get_contents($_FILES['sqlTeacFile']['tmp_name']);
        }else{
            $this->error("请选择文件！！");
        }
           unlink($_FILES['sqlTeacFile']['tmp_name']);
           if ($sql !== mb_convert_encoding(mb_convert_encoding($sql, "UTF-32", "UTF-8"), "UTF-8", "UTF-32")) {
                 $sql=iconv("gb2312","utf-8",$sql);
           }
           $check_arr=array("select","delete","drop");
           for($i=0;$i<count($check_arr);$i++){
           	    if(strchr($sql,$check_arr[$i])){$this->error("含有非法字符！！");}
           }
           $sql=str_replace("\r\n","\n",$sql);
           $sql=trim($sql);
           if((strrpos($sql,";")+1)==strlen($sql)) $sql=substr($sql,0,-1);
           $query_sql=explode(";",$sql);
           $teac=M("Teacher");
           foreach($query_sql as $sql){
           	     if(!$teac->execute(trim($sql))){$this->error("sql语句有误！！请仔细检查！！");}
           }
           $this->success("导入成功");
    }
    function editPassword(){     //修改密码
    	$this->check_logined();
    	$this->display();
    }
    function updatePassword(){   //更新密码
    	$this->check_logined();
    	$admin=M("Admin");
    	$oldpass=md5($_POST['oldpass']);
    	$condition['password']=$oldpass;
    	if(!$adminInfo=$admin->where($condition)->find()) $this->error("旧密码错误");
    	$newpass=md5($_POST['newpass']);
    	$condition['username']=$_SESSION['username'];
    	$data['password']=$newpass;
    	if(!$admin->where($condition)->save($data)) $this->error("修改失败");
    	$this->success("修改成功");

    }
	function editMessage(){     //跳到添加完成教师信息页面
    	$this->check_logined();
		$mes=M('Message');
		$message_info=$mes->findall();
		$this->assign("message_info",$message_info);
    	$this->display();
    }
	function subMessage(){     //添加完成教师信息
    	$this->check_logined();
    	$mes=M('message');
		$data['message']=$_POST['message'];
		print_r($_POST['message']);
    	if(!$mes->add($data)){
    		$this->error("添加失败");
    	}
    	$this->success("添加成功");
    }
	function export(){       //导出总表操作
    	$this->check_logined();
    	session_start();
    	header("Content-type:application/vnd-ms-excel");
    	header("Content-Disposition:attachment;filename=all.xls");
		$student=M("Student");
		$all=$student->table('info_student student, info_selected selected, info_course course')->where('student.id = selected.stu_id and course.num=selected.course_id')->select();
		$this->assign("all",$all);
        $this->display();
    }
	function exportUnSelStu(){          //导出未选课题学生
    	$this->check_logined();
		header("Content-type:application/vnd-ms-excel");
    	header("Content-Disposition:attachment;filename=allUnSelect.xls");
    	$selected=M("Selected");
		$student=M("Student");
		$selected_info=$selected->where("select_state='K'")->select();
		for($i=0;$i<count($selected_info);$i++)
		{
             $stu_id[$i]=$selected_info[$i]['stu_id'];			 
		}
		$condition['id']=array('in',$stu_id);	
		$count=count($selected_info);
		if($_POST['submit']){  
			$sel_info=M("Selected")->where("stu_id=$_POST[keyword]")->select();
			if($sel_info[0][select_state]=="K"){
				$condition['id']="$_POST[keyword]";
			}else{
				$condition['id']="0";
			}			
    	}
		
    	$student_info=$student->where($condition)->findAll();
		
    	$this->assign("all",$student_info);
    	$this->display();
    }
	//添加管理员关闭教师选课功能
    function BanStudentsElective()
	{
	    $conn=mysql_connect('localhost','jgbys','JGlwxt') or die 
	    ("连接数据库失败".mysql_error());
	    $select=mysql_select_db('jgbys',$conn);
		if($_POST[id]!=null)
        {
		    mysql_query("update jgbys.info_teacher set surplus='0' where id='".$_POST[id]."'");
            $this->success("该老师的课程报名已经终止");  
		}
	   else	   
	      $this->error("您没有输入老师的ID"); 
	}
}
?>