<?php

class IndexAction extends Action{
    function _initialize(){
    	header("Content-type:text/html;charset=utf-8");
    }
    function index(){
    	$url=U("login");
    	header("Location:$url");
    }
    function login(){    //登录模块
    	$this->display();
    }
    function check_login(){  //判断是否登录成功
    	session_start();
    	if($_POST['type']=="stu")
    	      $user=M('Student');
    	else
    	      $user=M('Teacher');

    	switch($_POST['type']){                 //根据是学生登录还是教师登录跳转到不同的页面
    		case "stu":$condition['id']=$_POST['userid'];
                        $url=U("student");
                        break;
            case "teac":$condition['id']=$_POST['userid'];
    	                 $url=U("teacher");
    	                 break;
    	}
    	$us=$user->where($condition)->find();
    	if(!$us){ $this->error("用户名或者密码错误！！");}
    	if($us['password']!=md5($_POST['password'])){$this->error("用户名或者密码错误！！");}
    	$_SESSION['userid']=$_POST['userid'];
    	$this->assign("jumpUrl",$url);
    	$this->success("登录成功");
    }
    function checkStu_logined(){       //检测学生是否已经登录
    	session_start();
    	$user=M('Student');
    	$condition['id']=$_SESSION['userid'];
    	$us=$user->where($condition)->find();
        if(!$us){$url=U('login');$this->assign("jumpUrl",$url);$this->error("还没有登录！！");}
    }
    function checkTeac_logined(){       //检测教师是否已经登录
    	session_start();
    	$user=M('Teacher');
    	$condition['id']=$_SESSION['userid'];
    	$us=$user->where($condition)->find();
        if(!$us){$url=U('login');$this->assign("jumpUrl",$url);$this->error("还没有登录！！");}
    }
    function admin_exit(){
    	unset($_SESSION['userid']);
        $url=U("login");
    	$this->assign("jumpUrl",$url);
    	$this->success("退出成功");
    }
    function teacher(){               //教师管理模块
        $this->checkTeac_logined();
        session_start();
    	$user=M('Teacher');
    	$us=$user->where("id=$_SESSION[userid]")->find();
        $username=$us['name'];
    	$date=date("Y年m月d日",time());
    	$this->assign('date',$date);
    	$this->assign('username',$username);
    	$this->display();
    }
	
    function teacher_page(){          //教师管理首页信息
    	$this->checkTeac_logined();
		
    	$this->display();
    }

    function publishCourse(){      //发布课程模块
    	$this->checkTeac_logined();
    	$this->display();
    }
    function addCourse(){     //添加课程
    	$this->checkTeac_logined();
    	session_start();
        $course=M("Course");
        if(!$data=$course->create()) $this->error("发布失败");
        $user=M('Teacher');
    	$us=$user->where("id=$_SESSION[userid]")->find();
        $data['teacher_name']=$us['name'];
        $data['teacher_id']=$_SESSION['userid'];
        if(!$course->add($data)) $this->error("发布失败,可能课题编号已经存在");
        $url=U("publishCourse");
        $this->assign("jumpUrl",$url);
        $this->success("发布成功");
    }
    function manageCourse(){        //管理课程
    	$this->checkTeac_logined();
    	session_start();
    	$course=M("Course");
        $teac=M("Teacher");
        $teac_info=$teac->where("id=$_SESSION[userid]")->find();
        $count=$course->where(array("teacher_name"=>$teac_info['name']))->count();
    	$listRows=10;
        import("ORG.Util.Page");
        $p=new Page($count,$listRows);
        $limit_options=$p->firstRow.",".$p->listRows;
    	$course_info=$course->where(array("teacher_name"=>$teac_info['name']))->limit($limit_options)->findAll();
    	$displaypage=1;
    	$page=$p->show();
    	$this->assign("displaypage",$displaypage);
    	$this->assign("page",$page);
    	$this->assign("pagestyle","green-black");
    	$this->assign("course_info",$course_info);
		$this->assign("t_info",$teac_info);
    	$this->display();
    }
    function deleteCourse(){         //删除课程信息
    	$this->checkTeac_logined();
    	$id=$_GET['id'];
    	$course=M("Course");
    	if(!$course->delete($id)) $this->error("删除失败");
        $selected=M("selected");
        if($selected->where("course_id=$id")->find()){     //如果有学生选了这门课，那么选课信息中也要删除掉选了这门课的学生。
        	if(!$selected->query("update info_selected set course_id=null , select_state='K' where course_id=$id")) $this->error("删除失败");
        }
        $url=U("manageCourse");
        $this->assign("jumpUrl",$url);
        $this->success("删除成功");

    }
	function findStuById(){// 根据学号寻找学生
		$this->checkStu_logined();
    	$student=M("Student");
    	$student_info=$Student->where("id=$_POST[id]")->select();
        
        $export=0;
        if(count($student_info)>0) $export=1;
        $this->assign("export",$export);
        $this->assign("student_info",$student_info);
        $this->display();
	}
	function tSelCouForStuPre(){//教师给学生选课
		$this->checkTeac_logined();
    	session_start();
    	$course=M("Course");
        $teac=M("Teacher");
        $teac_info=$teac->where("id=$_SESSION[userid]")->find();
        $count=$course->where(array("teacher_name"=>$teac_info['name']))->count();
    	$listRows=10;
        import("ORG.Util.Page");
        $p=new Page($count,$listRows);
        $limit_options=$p->firstRow.",".$p->listRows;
    	$course_info=$course->where(array("teacher_name"=>$teac_info['name']))->limit($limit_options)->findAll();
    	$displaypage=1;
    	$page=$p->show();
    	$this->assign("displaypage",$displaypage);
    	$this->assign("page",$page);
    	$this->assign("pagestyle","green-black");
    	$this->assign("course_info",$course_info);
		$this->assign("stu_id",$_GET['stu_id']);
    	$this->display();
	}
	function tSelCouForStu(){     //教师的选课操作
    	$this->checkTeac_logined();
    	$id=$_GET['id'];
    	$data['stu_id']=$_GET['stu_id'];
    	$data['course_id']=$id;
		$data['select_state']='T';
		$counst['stu_id']=$_GET['stu_id'];
		$course=M("Course");
    	$course_info=$course->find($id);
    	if($course_info['selectedMan']>=$course_info['capacity']) $this->error("名额已满");
		
		
		$course=M("Course");
		$con['num']=$id;
		$c_info=$course->where($con)->select();
		$t_name="'".$c_info[0]['teacher_name']."'";
		$teacher=M("Teacher");
		if(!$teacher->setDec('surplus',"name=$t_name")) $this->error("选课失败2");
		
		$selected=M("Selected");
		$is=$selected->where($counst)->save($data);
    	if(!$is) $this->error("选课失败");
		if(!$course->setInc('selectedMan',"num=$id")) $this->error("选课失败3");
    	$this->success("选课成功");
    }
	function unSelStu(){          //显示未选课题学生
    	$this->checkTeac_logined();
    	$selected=M("Selected");
		$student=M("Student");
		$selected_info=$selected->where("select_state='K'")->select();
		for($i=0;$i<count($selected_info);$i++)
		{
             $stu_id[$i]=$selected_info[$i]['stu_id'];			 
		}
		$condition['id']=array('in',$stu_id);	
		$count=count($selected_info);
		if($_POST['submit']){  
			$sel_info=M("Selected")->where("stu_id=$_POST[keyword]")->select();
			if($sel_info[0][select_state]=="K"){
				$condition['id']="$_POST[keyword]";
			}else{
				$condition['id']="0";
			}			
    	}
		$count=$student->where($condition)->count();
		$listRows=10;
        import("ORG.Util.Page");
        $p=new Page($count,$listRows);
        $limit_options=$p->firstRow.",".$p->listRows;
    	$student_info=$student->where($condition)->limit($limit_options)->findAll();
		if(COUNT($student_info)==0){$count=0;}
		$displaypage=1;
		if($count==0)$displaypage=0;
    	$page=$p->show();
    	$this->assign("displaypage",$displaypage);
    	$this->assign("page",$page);
    	$this->assign("pagestyle","green-black");
    	$this->assign("student_info",$student_info);
    	$this->display();
    }
	function exportUnSelStu(){          //导出未选课题学生
    	$this->checkTeac_logined();
		header("Content-type:application/vnd-ms-excel");
    	header("Content-Disposition:attachment;filename=allUnSelect.xls");
    	$selected=M("Selected");
		$student=M("Student");
		$selected_info=$selected->where("select_state='K'")->select();
		for($i=0;$i<count($selected_info);$i++)
		{
             $stu_id[$i]=$selected_info[$i]['stu_id'];			 
		}
		$condition['id']=array('in',$stu_id);	
		$count=count($selected_info);
		if($_POST['submit']){  
			$sel_info=M("Selected")->where("stu_id=$_POST[keyword]")->select();
			if($sel_info[0][select_state]=="K"){
				$condition['id']="$_POST[keyword]";
			}else{
				$condition['id']="0";
			}			
    	}
		
    	$student_info=$student->where($condition)->findAll();
		
    	$this->assign("all",$student_info);
    	$this->display();
    }
    function editTeacPassword(){      //修改教师密码
    	$this->checkTeac_logined();
    	$this->display();
    }
    function updateTeacPassword(){     //更新教师密码
    	$this->checkTeac_logined();
    	session_start();
    	$teac=M("Teacher");
    	$oldpass=md5($_POST['oldpass']);
    	$condition['password']=$oldpass;
    	if(!$teacInfo=$teac->where($condition)->findAll()) $this->error("旧密码错误");
    	$newpass=md5($_POST['newpass']);
    	$condition['id']=$_SESSION['userid'];
    	$data['password']=$newpass;
    	if(!$teac->where($condition)->save($data)) $this->error("修改失败");
    	$this->success("修改成功");
    }
	
	
    function sc(){    //选课详情
	$this->checkTeac_logined();
    session_start();
	$id=$_GET['id'];
    $selected=M("Selected");
	$student=M("Student");
    $teacher=M("Teacher");
	$t_info=$teacher->where("id=$_SESSION[userid]")->select();
	$t_name=$t_info[0]['name'];
	$student=M("Student");
	$count=$student->table('info_student student, info_selected selected, info_course course')->where("course.teacher_name='".$t_name."' and selected.course_id=$id and student.id = selected.stu_id and course.num=selected.course_id ")->count();
	$listRows=10;
    import("ORG.Util.Page");
    $p=new Page($count,$listRows);
	$limit_options=$p->firstRow.",".$p->listRows;
	$s_info=$student->table('info_student student, info_selected selected, info_course course')->where("course.teacher_name='".$t_name."' and selected.course_id=$id and student.id = selected.stu_id and course.num=selected.course_id ")->limit($limit_options)->findAll();
	$page=$p->show();
	$displaypage=0;
    if(count($course_info)>0) $displaypage=1;
	$this->assign("page",$page);
    $this->assign("student",$s_info);
	$this->assign("displaypage",displaypage);
	$this->assign("selected",$id);
    $this->display();
	}
	
	function delStu(){     //删除已选择该课题的学生
		$this->checkTeac_logined();
		$id=$_GET['id'];
    	$selected=M("Selected");
    	$course=M("Course");
		$num=$_GET['num'];
		$data[stu_id]=$id;
		$data[course_id]=null;
		$data[select_state]=K;
		
		if(!$selected->where("stu_id=$id AND course_id=$num")->save($data)) $this->error("删除失败1");
		
		$course=M("Course");
		$con[num]=$_GET['num'];
		$c_info=$course->where($con)->select();
		$t_name="'".$c_info[0]['teacher_name']."'";
		$teacher=M("Teacher");
		if(!$teacher->setInc('surplus',"name=$t_name")) $this->error("删除失败");
		
		$course=M("Course");
    	if(!$course->setDec('selectedMan',"num=$num")) $this->error("删除失败2");
        $this->success("删除成功");
	}
	function lockStu(){  // 锁定学生
		$this->checkTeac_logined();
		$id=$_GET['id'];
    	$selected=M("Selected");
    	$course=M("Course");
		$num=$_GET['num'];
		$data[stu_id]=$id;
		$data[course_id]=$_GET['num'];
		$data[select_state]=T;
		if(!$selected->where("stu_id=$id AND course_id=$num")->save($data)) $this->error("锁定失败1");
        $this->success("锁定成功");
	
	}
	function export(){       //导出教师选课题操作
    	$this->checkTeac_logined();
    	session_start();
    	header("Content-type:application/vnd-ms-excel");
    	header("Content-Disposition:attachment;filename=all.xls");
		$teacher=M("Teacher");
		$t_info=$teacher->where("id=$_SESSION[userid]")->select();
		$t_name=$t_info[0]['name'];
		$student=M("Student");
		$all=$student->table('info_student student, info_selected selected, info_course course')->where("course.teacher_name='".$t_name."' and student.id = selected.stu_id and course.num=selected.course_id ")->select();
		$this->assign("all",$all);
        $this->display();
    }
    function student(){        //学生管理首页
    	$this->checkStu_logined();
    	session_start();
    	$user=M('Student');
    	$us=$user->where("id=$_SESSION[userid]")->find();
    	$username=$us['name'];
    	$date=date("Y年m月d日",time());
    	$this->assign(date,$date);
    	$this->assign('username',$username);
    	$this->display();
    }
    function student_page(){    //学生管理首页信息
    	$this->checkStu_logined();
		$mes=M('Message');
		$message_info=$mes->findall();
		$this->assign("message_info",$message_info);
    	$this->display();
    }
	
    function listCourse(){    //课程列表   
    	$this->checkStu_logined();
		$condition="";
    	if($_POST['submit']){
			$condition=" and course.teacher_name like '%".$_POST[keyword]."%'";
		}
    	$course=M("Course");
    	$count=$course->table("info_course course, info_teacher teacher")->where("course.teacher_name = teacher.name".$condition)->count();
    	$listRows=10;
		if($_POST['submit']){
			$listRows=20;
		}
        import("ORG.Util.Page");
        $p=new Page($count,$listRows);
        $limit_options=$p->firstRow.",".$p->listRows;
    	$course_info=$course->table("info_course course, info_teacher teacher")->where("course.teacher_name = teacher.name".$condition)->limit($limit_options)->findAll();
    	$displaypage=0;
    	if(count($course_info)>0) $displaypage=1;
    	$page=$p->show();
    	$this->assign("displaypage",$displaypage);
    	$this->assign("page",$page);
    	$this->assign("pagestyle","green-black");
    	$this->assign("course_info",$course_info);
    	$this->display();
    }
    function selectCourse(){     //选课操作
    	$this->checkStu_logined();
    	session_start();
    	$id=$_GET['id'];
    	$data['stu_id']=$_SESSION['userid'];
    	$sel=M("Selected");
    	$selected_info=$sel->where("stu_id=$_SESSION[userid]")->select();	
        $select_state[0]=$selected_info[0]['select_state'];
		if($select_state[0]==T) $this->error("选课题已被教师指定,如需更换请先联系课题教师");
    	if($select_state[0]!=K) $this->error("已经选过课题,如需更换请先退选");		
    	$course=M("Course");
		$selected=M("Selected");
    	$course_info=$course->find($id);
        $selected_info=$selected->where("stu_id=$_SESSION[userid]")->select();
        for($i=0;$i<count($selected_info);$i++){
        	$course_id[$i]=$selected_info[$i]['course_id'];
        }
    	if($course_info['selectedMan']>=$course_info['capacity']) $this->error("名额已满");
    	$data['course_id']=$id;
		$data['select_state']=S;
		
		$course=M("Course");
		$con[num]=$id;
		$c_info=$course->where($con)->select();
		$t_name="'".$c_info[0]['teacher_name']."'";
		$teacher=M("Teacher");
		$t_info=$teacher->where("name=$t_name")->select();
		$surplus=$t_info[0][surplus];
		if($surplus<=0) $this->error("该教师选课学生已满，请选择其他课题");
		if(!$teacher->setDec('surplus',"name=$t_name")) $this->error("选课失败2");
		if(!$course->setInc('selectedMan',"num=$id")) $this->error("选课失败3");
    	if(!$selected->where("stu_id=$_SESSION[userid]")->save($data)) $this->error("选课失败1");
    	
    	$this->success("选课成功");
    }
    function selectedCourse(){     //已选课程信息
        $this->checkStu_logined();
        session_start();
    	$selected=M("Selected");
    	$selected_info=$selected->where("stu_id=$_SESSION[userid]")->select();
        for($i=0;$i<count($selected_info);$i++)
             $course_id[$i]=$selected_info[$i]['course_id'];
        $course=M("Course");
        $condition['num']=array('in',$course_id);
        $course_info=$course->table("info_course course, info_teacher teacher")->where("teacher.name=course.teacher_name and course.num=$course_id[0]")->select();
        $export=0;
        if(count($course_info)==1) $export=1;
        $this->assign("export",$export);
		$this->assign("selected_info",$selected_info);
        $this->assign("course_info",$course_info);
        $this->display();
    }
    function quitCourse(){         //退课操作
    	$this->checkStu_logined();
    	$id=$_GET['id'];
		$sid=$_SESSION[userid];
    	$selected=M("Selected");
		$selected_info=$selected->where("stu_id=$sid")->select();
		$state=$selected_info[0]['select_state'];
		if($state=='T') $this->error("该课题为教师指定课题，如需退选请先联系课题教师");
		$data['stu_id']=$sid;
		$data['course_id']=null;
		$data['select_state']='K';
		
		$course=M("Course");
		$con['num']=$id;
		$c_info=$course->where($con)->select();
		$t_name="'".$c_info[0]['teacher_name']."'";
		
    	if(!$selected->where("stu_id=$sid")->save($data)) $this->error("退课失败");
    	$course=M("Course");
		
    	if(!$course->setDec('selectedMan',"num=$id")) $this->error("退课失败");
		$teacher=M("Teacher");
		if(!$teacher->setInc('surplus',"name=$t_name")) $this->error("退课失败");
		
        $this->success("退课成功");
    }
     function editStuData(){                          //添加手机和电子邮件，完善信息
		$this->checkStu_logined();
	   session_start();
	   $stu=M("student");
	   $condition['id']=$_SESSION['userid'];
	   $stuinfo=$stu->where($condition)->select();
	   $this->assign("phone",$stuinfo[0]['phone']);
       $this->assign("email", $stuinfo[0]['email']);
		$this->display();
		}
	function  StuData(){
	   $this->checkStu_logined();
	   session_start();
	   $stu=M("student");
	   $condition['id']=$_SESSION['userid'];
	   $phone=$_POST['phone'];
	   $email=$_POST['email'];
	   $data['phone']=$phone;
	   $data['email']=$email;
	   if(!$stu->where($condition)->save($data)) $this->error("添加失败");
	   $this->success("添加成功");
	   }
    function editStuPassword(){      //修改学生密码
    	$this->checkStu_logined();
    	$this->display();
    }
    function updateStuPassword(){      //更新学生密码操作
    	$this->checkStu_logined();
    	session_start();
    	$stu=M("Student");
		$id=$_GET['id'];
    	$data['stu_id']=$_SESSION['userid'];
    	$oldpass=md5($_POST['oldpass']);
    	$condition['password']=$oldpass;
    	if(!$stuInfo=$stu->where($condition)->findAll()) $this->error("旧密码错误");
    	$newpass=md5($_POST['newpass']);
    	$condition['id']=$_SESSION['userid'];
    	$data['password']=$newpass;
    	if(!$stu->where($condition)->save($data)) $this->error("修改失败");
    	$this->success("修改成功");
    }
}
?>