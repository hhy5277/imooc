<?php
return array(
'DB_HOST'=>'localhost',
'DB_USER'=>'jgbys',
'DB_PWD'=>'JGlwxt',
'DB_NAME'=>'jgbys',
);
?>
