<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>论文选题系统</title>
<style type="text/css">
body {
	height:100%;
	margin:0;
	padding:0;
	font-size:10pt;
	background:#CFF;
	color:#333;
	overflow:auto;
	overflow-x:hidden;
}
</style>
</head>
<body>
<p>
<center>
<h1>山东农业大学毕业论文课题管理系统
</h1>
<br />
经管学院2016届毕业生毕业论文选题于2015年11月10日（周二）12:00开始，于11月13日（周五）上午12:00结束。可以先看一下<a href="http://http://114.215.105.222/jgbys/Public/ktlb.xls">课题列表</a>。
</center>
</p>
</body>
</html>
