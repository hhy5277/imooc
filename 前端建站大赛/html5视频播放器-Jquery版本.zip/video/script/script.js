/**
 * script.js
 * @author ryn
 * @version 1.0.0
 * @time 2015-10-13
 */

jQuery(document).ready(function($) {
	var player = $("#player")[0];				// 视频区域
	var $play = $("#play");						// 播放按钮
	var $pause = $("#pause");					// 暂停按钮
	var $stop = $("#stop");						// 停止按钮
	var $currentTime = $("#current-time");		// 当前时间显示
	var $totalTime = $("#total-time");			// 总时间显示
	var $volumeMax = $("#volume-max");			// 音量最大
	var $volumeMute = $("#volume-mute");		// 音量最小
	var $blockQuote = $("#boq");				// 播放滑块
	var $screenMax = $('#screen-max');			// 全屏
	var $screenMin = $('#screen-min');			// 取消全屏
	var $fileList = $(".file-list ul");		// 文件列表
	var $bar = $("#bar");						// 播放条
	var $overlay = $(".video-overlay");			// 视频遮罩层
	var $video = $(".video")[0];				
	var $wrapper = $(".video-wrapper");
	var $centerPlay = $("#center-play");
	
	var loadStatus = false;			// 视频加载状态
	var currentTime = undefined;	// 当前时间
	var totalTime = undefined;		// 总共时间
	var drag = false;				// 是否可以拖拽
	var dragLeft = undefined;		// left
	var barWidth = $(".progress").width();
	
	// 加载文件列表
	$.ajax({
		type : "get",
		url : "./res/data/data.json",
		dataType : "json",
		success: function(json) {
			var list = json.data.list;
			$.each(list, function(index, value) {
				$(".file-list ul").append($("<li><a href='javascript:void(0);'>"+value.name+"</a></li>"));
			});
		}
	});
	
	// 视频加载完成显示总时间
	player.onloadedmetadata = function () { 
		totalTime = player.duration; 
		var newTime = new Date(totalTime * 1000);
		$totalTime.text(toUTCTime(newTime));
		
		loadStatus = true;
		$overlay.hide();
	}
	
	// 时间更新控制滑块位置
	player.ontimeupdate = function () { 
		currentTime = player.currentTime; 
		var percent = currentTime / totalTime;
		var left = (barWidth * percent) + 'px';
		$("#bar-inner").css('width', left);
		$blockQuote.css('left', left);
		updateTime();
	};
	
	// 视频播放完成时
	player.onended = function() {
		playerReset();
	};
	
	$(".video-body").on('click', function() {
		if(player.paused) {
			playerPlay();
		} else {
			playerPause();
		}
	});
	
	// 点击播放按钮
	$play.on('click', function(event) {
		event.preventDefault();
		playerPlay();
	});

	// 点击暂停按钮
	$pause.on('click', function(event) {
		event.preventDefault();
		playerPause();
	});

	// 点击停止按钮
	$stop.on('click', function(event) {
		event.preventDefault();
		playerReset();
	});

	// 点击静音按钮
	$volumeMax.on('click', function(event) {
		event.preventDefault();
		player.muted = true;
		$volumeMute.show();
		$volumeMax.hide();
	});

	// 点击取消静音按钮
	$volumeMute.on('click', function(event) {
		event.preventDefault();
		player.muted = false;
		$volumeMax.show();
		$volumeMute.hide();
	});
	
	// 点击全屏按钮
	$screenMax.on('click', function(event) {
		event.preventDefault();
		fullScreen();
		$screenMax.hide();
		$screenMin.show();
		return false;
	});
	
	// 点击退出全屏按钮
	$screenMin.on('click', function(event) {
		event.preventDefault();
		exitFullScreen();
		$screenMax.show();
		$screenMin.hide();
		return false;
	})
	
	// 点击播放条
	$bar.on('click', function(event) {
		event.preventDefault();
		var length = event.pageX - $bar.offset().left;
		$blockQuote.removeClass('trans').css('left', length);
		skipPlay(length);
	});
	
	$blockQuote.on('mousedown', function(event) {
		player.pause();
		drag = true;
	});
	
	$blockQuote.on('mouseup', function(event) {
		drag = false;
		skipPlay(dragLeft);
	});
	
	document.onmousemove = function(event) {
		if(drag) {
			var barLeft = $bar.offset().left;
			var barTop = $blockQuote.offset().top;
			var pageX = event.pageX;
			var pageY = event.pageY;
			
			if(pageX - barLeft < 0) {
				dragLeft = 0;
			} else if(pageX - barLeft > barWidth) {
				dragLeft = barWidth;
			} else {
				dragLeft = pageX - barLeft;
			}
			
			if(pageY - barTop < 7 || pageY - barTop > 21) {
				drag = false;
			}
			
			$blockQuote.removeClass('trans').css('left', dragLeft);
		}
	};
	
	// 点击文件列表的链接时
	$fileList.on('click', 'li', function(e) {
		playerReset();
		$(this).addClass('active').siblings('li').removeClass('active');
		var name = $(this).children('a').text();
		var newHref = "./res/" + name;
		$("#header").text($(this).children('a').text());
		player.src = newHref;
		player.poster = "./images/" + name.replace(name.substr(-4, 4), "") + ".png";
		
		loadStatus = false;
		$overlay.show();
	});

	function fullScreen() {
//		var controlLeftWidth = $(".control-left").outerWidth();
//		var timeWidth = $(".play-time").outerWidth();
//		var controlRightWidth = $(".control-right").outerWidth();
		$("#fs")[0].href = "./style/fullscreen.css";
		var progressWidth = $(window).outerWidth() - 296;
		barWidth = progressWidth;
	    $(".video-body").css("height", $(window).height() - 120);
	    $(".progress").css("width", progressWidth);
	}
	
	// 窗口重置时
	$(window).on('resize', function() {
		fullScreen();
		$screenMax.hide();
		$screenMin.show();
	});
	
	// 退出全屏
	function exitFullScreen() {
		$("#fs")[0].href = "./style/normal.css";
		barWidth = 400;
	    $(".video-body").css("height", "320px");
	    $(".progress").css("width", 400);
	}
	
	// 点击播放
	function skipPlay(length) {
		var percent = length / barWidth;
		currentTime = totalTime * percent;
		playerPlay();
		player.currentTime = parseInt(currentTime);
	}

	// 时间更新
	function updateTime() {
		var newTime = new Date(player.currentTime * 1000);
		$currentTime.text(toUTCTime(newTime));
	}
	
	// 视频播放按钮状态
	function playerPlay() {
		$play.hide();
		$pause.show();
		$centerPlay.hide();
		player.play();
	}
	
	// 视频停止按钮状态
	function playerPause() {
		$play.show();
		$pause.hide();
		$centerPlay.show();
		player.pause();
	}
	
	// 视频重置按钮状态
	function playerReset() {
		$blockQuote.removeClass('trans').css('left', 0);
		$currentTime.text("00:00:00");
		$("#bar-inner").css('width', 0);
		$play.show();
		$pause.hide();
		$centerPlay.show();
		player.load();
	}

	// 时间转化
	function toUTCTime(time) {
		var pattern = /(\d{2}:\d{2}:\d{2})\s*GMT\+\d(\d)\d{2}/;
		var result = time.toString().match(pattern);
		if(result != null) {
			var fullTime = result[1];	// 08:00:00
			var timezone = result[2];	// 8
			var hour = time.getHours();
			return fullTime.substring(0,1) + (hour - timezone) + fullTime.substring(2);
		}
	}
});

