package util;

public enum ErrorMessage{
	用户名不存在,
	用户名或密码不正确,
	请不要重复提交,
	邮箱地址不存在,
	验证码输入错误
}
