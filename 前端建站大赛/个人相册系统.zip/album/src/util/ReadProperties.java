package util;


import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.junit.Test;
/**
 * 按行读取properties文件，每行安Map格式返回
 * @author liuxiaojun
 *
 */
public class ReadProperties {
 @SuppressWarnings("rawtypes")
public static  Map<String,String> getProperties(String fileName){
	  Map<String,String> map = new HashMap<String,String>();
	  Properties props = new Properties();
	  InputStream in = null;
	   
	  try {
		in = Object.class.getResourceAsStream(fileName); 
		if(in!=null){
			props.load(in);
			Enumeration en = props.propertyNames();
			while(en.hasMoreElements()){
				String key = (String) en.nextElement();
				String value = props.getProperty(key);
				map.put(key, value);
			}
		}
		
	} catch (IOException e) {
		System.out.println("读取文件错误");
	}finally{
		try {
			in.close();
		} catch (IOException e) {
			System.out.println("关闭输入流错误");		
		}
	}
	  return map;
  }
  @Test
  public void test(){
	 Map map =  getProperties("/bean.properties");
	 System.out.println(map);
  }
}
