package util;

import java.util.Map;

import org.junit.Test;


public class BeanFactory {
  @SuppressWarnings({ "rawtypes", "unchecked" })
public static   <T> T getBean(String key){
	  T entity = null;
	  try {
		Map map = ReadProperties.getProperties("/bean.properties");
		String name = (String) map.get(key);
		Class c = Class.forName(name);
		entity =(T) c.newInstance();
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	} catch (InstantiationException e) {
		e.printStackTrace();
	} catch (IllegalAccessException e) {
		e.printStackTrace();
	}
	  System.out.println(entity);
	  return entity;
  }
  

  @Test
 public void test(){
	 getBean("albumDao");
 }
}
