package serviceImpl;

import java.util.List;

import dao.AlbumDao;
import dao.PhotoDao;
import entity.Photo;
import service.PhotoService;
import util.BeanFactory;

public class PhotoServiceImpl implements PhotoService{
	private PhotoDao dao = BeanFactory.getBean("photoDao");
	@Override
	public void addPhoto(Photo photo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updatePhoto(Photo quePhoto, Photo conPhoto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePhoto(Photo photo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Photo queryOnePhoto(Photo quePhoto, Photo conPhoto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Photo> queryPhotoList(Photo quePhoto, Photo conPhoto) {
		// TODO Auto-generated method stub
		return null;
	}

}
