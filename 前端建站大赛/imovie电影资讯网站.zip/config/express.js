var express = require('express');
var bodyParser = require('body-parser');

module.exports = function() {
	console.log('express配置中...');
	var app = express();
	app.use(bodyParser.json());

	app.use(express.static('./public'));
	require('../app/routes/server.routes')(app);

	//处理所有未知的请求
	app.use(function(req, res, next) {
		res.status(404);
		try {
			return res.json('资源不存在');
		} catch (e) {
			console.error('404重复返回');
		}
	});

	

	//统一处理出错的情况
	app.use(function(err, req, res, next) {
		if (!err) {
			return next()
		}
		res.status(500);
		try {
			return res.json(err.message || '服务器错误');
		} catch (e) {
			console.error('500重复返回');
		}
	});

	return app;
};