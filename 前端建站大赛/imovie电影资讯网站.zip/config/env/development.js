module.exports = {
	port: 8050,
	mongodb: 'mongodb://120.26.73.33:27017/api'
}

