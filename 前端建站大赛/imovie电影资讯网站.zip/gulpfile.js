var gulp = require('gulp'),
	less = require('gulp-less'),
    notify = require('gulp-notify'),
    cssmin = require('gulp-minify-css'),
    plumber = require('gulp-plumber'),
    livereload = require('gulp-livereload');

gulp.task('Less', function() {
	gulp.src('public/less/*.less')
		.pipe(plumber({
			errorHandler: notify.onError('Error: <%= error.message %>')
		}))
		.pipe(less())
		.pipe(cssmin())
		.pipe(gulp.dest('public/css'))
		.pipe(livereload());
});

gulp.task('watch', function() {
	livereload.listen();
    gulp.watch('public/**/*.*', ['Less']);
});