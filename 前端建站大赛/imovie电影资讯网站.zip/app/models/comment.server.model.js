var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var ObjectId = Schema.Types.ObjectId;

var CommentSchema = new Schema({

	content: String,

	//电影ID
	movie: {
		type: String,
		ref: 'Movie'
	},
	//发送人ID
	from: {
		type: ObjectId,
		ref: 'User'
	},

	reply:[{
		from: {
			type: ObjectId,
			ref: 'User'
		},
		to: {
			type: ObjectId,
			ref: 'User'
		},
		content: String,
	}],
	
	meta: {
		//创建时间
		createTime: {
			type: Date,
			default: Date.now
		},
		//更新时间
		updateTime: {
			type: Date,
			default: Date.now
		}
	}
});

CommentSchema.pre('save', function(next) {
	if (this.isNew) {
		this.meta.createTime = this.meta.updateTime = Date.now();
	} else {
		this.meta.updateTime = Date.now();
	}
	next()
})

var Comment = mongoose.model('Comment', CommentSchema);