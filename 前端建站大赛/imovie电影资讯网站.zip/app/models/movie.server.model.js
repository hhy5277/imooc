var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var ObjectId = Schema.Types.ObjectId;

var MovieSchema = new mongoose.Schema({
	//豆瓣ID
	DId: String,
	//片名
	title: String,
	//导演
	director: String,
	//主演
	actor: String,
	//上映时间
	showTime: String,
	//类型
	catetory: String,
	//评分
	average: String,
	//海报地址
	poster: String,
	//简介
	summary: String,
	//地区
	country: String,
	//标题
	style: String,
	//访问量
	SCount: {
		type: Number,
		default: 0
	},
	//收藏量
	LCount: {
		type: Number,
		default: 0
	},
	//评论量
	CCount: {
		type: Number,
		default: 0
	},
	//记录
	meta: {
		//创建时间
		createTime: {
			type: Date,
			default: Date.now
		},
		//更新时间
		updateTime: {
			type: Date,
			default: Date.now
		}
	}
});

MovieSchema.pre('save', function(next) {
	if (this.isNew) {
		this.meta.createTime = this.meta.updateTime = Date.now();
	} else {
		this.meta.updateTime = Date.now();
	}
	next()
})

var Movie = mongoose.model('Movie', MovieSchema);