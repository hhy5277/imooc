var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');
var Schema = mongoose.Schema;
var ObjectId = Schema.Types.ObjectId;

var UserSchema = new mongoose.Schema({
	username: {
		unique: true,
		type: String
	},
	//鐢靛奖ID
	movie: {
		type: ObjectId,
		ref: 'Movie'
	},
	password: String,
	email: String,
	phone: String,
	//瑙掕壊
	//0:user
	//1:admin
	role: {
		type: Number,
		default: 0
	},
	//璁板綍
	meta: {
		//鍒涘缓鏃堕棿
		createTime: {
			type: Date,
			default: Date.now()
		},
		//鏇存柊鏃堕棿
		updateTime: {
			type: Date,
			default: Date.now()
		}
	}
});

UserSchema.pre('save', function(next) {
	var user = this;
	if (this.isNew) {
		this.meta.createTime = this.meta.updateTime = Date.now();
	} else {
		this.meta.updateTime = Date.now();
	}
	next();
})

var User = mongoose.model('User', UserSchema);