var mongoose = require('mongoose');
var _ = require('underscore');
var Movie = mongoose.model('Movie');
var superagent = require('superagent');
var cheerio = require('cheerio');

module.exports = {
  
	//电影的创建
	create: function(req, res, next) {
		var _movie;
		var movieObj = req.body;
		if (req.body.DId !== undefined) {
			Movie.findOne({
				DId: req.body.DId
			}, function(err, movie) {
				if (err) {
					return next(err);
				}
				if (movie == '' || movie == null) {
					_movie = new Movie(req.body);
					_movie.save(function(err) {
						if (err) return next(err);
						return res.send("update success");
					});
				} else {
					_movie = _.extend(movie, movieObj);
					_movie.save(function(err) {
						if (err) return next(err);
						return res.send("update success");
					})
				}
			});
		} else {
			_movie = new Movie(req.body);
			_movie.save(function(err) {
				if (err) return next(err);
				return res.send("create success");
			});
		}
	},

	getRecentM: function(req, res, next) {
		return res.json(req.movie);
	},

	getByStyle: function(req, res, next, style) {
		if (!style) return next(new Error('user not Found'));
		Movie
			.find({
				style: style
			})
			.exec(function(err, doc) {
				if (err) return next(err);
				if (!doc) return res.send(false);
				req.movie = doc;
				return next();
			});
	},

	//获取电影列表
	list: function(req, res, next) {
		Movie
			.find()
			.sort({
				'meta.updateTime': -1
			})
			.exec(function(err, docs) {
				if (err) return next(err);
				return res.json(docs);
			});
	},

	//通过ID获取电影信息
	getById: function(req, res, next, id) {
		if (!id) return next(new Error('查找失败'));
		Movie
			.findOne({
				_id: id
			})
			.exec(function(err, doc) {
				if (err) return next(err);
				if (!doc) return next(new Error('该电影不存在'));
				req.movie = doc;
				return next();
			});
	},

	//获取电影详情
	get: function(req, res, next) {
		return res.json(req.movie);
	},

	//删除电影
	deletemovie: function(req, res, next) {
		Movie.remove({
			_id: req.movie._id
		}, function(err) {
			if (err) return next(err);
			return res.send("success");
		});
	},
};