var mongoose = require('mongoose');
var _ = require('underscore');
var User = mongoose.model('User');
var bcrypt = require('bcrypt-nodejs');

module.exports = {

	save: function(req, res, next) {
		var _user = req.body;
		var temp = {
			err: '',
			result: true,
		};
		User.findOne({
			username: _user.username
		}, function(err, user) {
			if (err) return next(err);
			if (user) {
				temp.err="此用户名已被使用"
				return res.json(temp);
			} else {
				User.findOne({
						phone: _user.phone
					},
					function(err, user) {
						if (err) return next(err);
						if (user) {
							temp.err="此手机号已被使用"
							return res.json(temp);
						} else {
							User.findOne({
									email: _user.email
								},
								function(err, user) {
									if (err) return next(err);
									if (user) {
										temp.err="此邮箱已被使用"
										return res.json(temp);
									} else {
										bcrypt.hash(_user.password, null, null, function(err, hash) {
											if (err) return next(err);
											_user.password = hash;
											var user = new User(_user);
											user.save(function(err) {
												if (err) return next(err);
												User.findOne({
													username: _user.username
												}, function(err, user) {
													if (err) return next(err);
													if (user) {
														var data = {
															userId: user._id,
															result: false,
														};
														return res.json(data);
													}
												});
											});
										});
									};
								});
						};
					});
			};
		});
	},

	userlist: function(req, res, next) {
		User
			.find()
			.sort('meta.updateTime')
			.exec(function(err, docs) {
				if (err) return next(err);
				return res.json(docs);
			});
	},

	getById: function(req, res, next, id) {
		if (!id) return next(new Error('user not Found'));
		User
			.findOne({
				_id: id
			})
			.exec(function(err, doc) {
				if (err) return next(err);
				if (!doc) return res.send(false);
				var msg = {
					username: doc.username,
					role: doc.role,
				}
				req.msg = msg
				return next();
			});
	},

	getByName: function(req, res, next, name) {
		if (!name) return next(new Error('user not Found'));
		User
			.findOne({
				username: name
			})
			.exec(function(err, doc) {
				if (err) return next(err);
				if (!doc) return res.send(false);
				return res.send(true);
			});
	},

	getByPhone: function(req, res, next, phone) {
		if (!phone) return next(new Error('user not Found'));
		User
			.findOne({
				phone: phone
			})
			.exec(function(err, doc) {
				if (err) return next(err);
				if (!doc) return res.send(false);
				return res.send(true);
			});
	},

	getByEmail: function(req, res, next, email) {
		if (!email) return next(new Error('user not Found'));
		User
			.findOne({
				email: email
			})
			.exec(function(err, doc) {
				if (err) return next(err);
				if (!doc) return res.send(false);
				return res.send(true);
			});
	},

	checklogin: function(req, res, next) {
		return res.json(req.msg);
	},

	deleteuser: function(req, res, next) {
		User.remove({
			username: req.msg.username
		}, function(err) {
			if (err) return next(err);
			return res.send(true);
		});
	},

	login: function(req, res, next) {
		var _user = req.body;
		var email = _user.email;
		var password = _user.password;
		User
			.findOne({
				email: email
			}, function(err, user) {
				if (err) return next(err);
				if (!user) return res.send(false);
				bcrypt.compare(password, user.password, function(err, isMatch) {
					if (err) return next(err);
					if (isMatch) {
						user.save(function(err) {
							if (err) return next(err);
							return;
						});
						var data = {
							userId: user._id,
							result: true,
						}
						return res.json(data);
					} else {
						return res.send(false);
					}
				})
			})
	},

};