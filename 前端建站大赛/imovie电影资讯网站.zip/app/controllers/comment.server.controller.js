var mongoose = require('mongoose');
var _ = require('underscore');
var Comment = mongoose.model('Comment');

module.exports = {

	save: function(req, res, next) {
		var _comment = req.body;
		var comment = new Comment(_comment);
		comment.save(function(err) {
			if (err) return next(err);
			return res.send("create success");
		});
	},

	getByMovie: function(req, res, next, id) {
		if (!id) return next(new Error('鏌ユ壘澶辫触'));
		Comment
			.find({
				movie: id
			})
			.populate('from','username')
			.exec(function(err, comment) {
				if (err) return next(err);
				if (!comment) return next(new Error('璇ョ數褰变笉瀛樺湪'));
				return res.json(comment);
			});
	},

	deleteComment: function(req, res, next) {
		Comment.remove({
			_id: req.id
		}, function(err) {
			if (err) return next(err);
			return res.send(true);
		});
	},

	list: function(req, res, next) {
		Comment
			.find()
			.populate('from','username')
			.sort({
				'meta.createTime': -1
			})
			.exec(function(err, comment) {
				if (err) return next(err);
				return res.json(comment);
			});
	},

	getById: function(req, res, next, id) {
		if (!id) return next(new Error('user not Found'));
		Comment
			.findOne({
				_id: id
			})
			.exec(function(err, doc) {
				if (err) return next(err);
				if (!doc) return res.send(false);
				req.id = id;
				return next();
			});
	},

}