var MovieController = require('../controllers/movie.server.controller');
var UserController = require('../controllers/user.server.controller');
var CommentController = require('../controllers/comment.server.controller');

module.exports = function(app) {

	//user
	app.route('/user/register')
		.get(UserController.userlist)
		.post(UserController.save);
	app.route('/user/login')
		.post(UserController.login);
	app.route('/user/deleteuser/:userid')
		.get(UserController.deleteuser);
	app.route('/user/checklogin/:userid')
		.get(UserController.checklogin);
	app.param('userid', UserController.getById);

	//movie
	app.route('/admin/movie')
		.get(MovieController.list)
		.post(MovieController.create);
	app.route('/admin/movie/detail/:nid')
		.get(MovieController.get);
	app.route('/movie/recentM/:style')
		.get(MovieController.getRecentM);
	app.route('/admin/movie/delete/:nid')
		.get(MovieController.deletemovie);
	app.param('nid', MovieController.getById);
	app.param('style', MovieController.getByStyle);

	//comment
	app.route('/admin/comment')
		.get(CommentController.list)
	app.route('/comment/save')
		.post(CommentController.save);
	app.route('/comment/deleteComment/:CommentId')
		.get(CommentController.deleteComment);
	app.route('/comment/get/:id')
		.get(CommentController.getByMovie);
	app.param('id', CommentController.getByMovie);
	app.param('CommentId', CommentController.getById);

}