angular.module('webapp')
	.service("MovieService", ["$http", "$q", MovieService]);

function MovieService($http, $q) {

	//处理服务器请求
	function handleRequest(method, url, data) {
		var defered = $q.defer();
		var config = {
			method: method,
			url: url
		};

		if ("POST" === method) {
			config.data = data
		} else if ("GET" === method) {
			config.params = data;
		}

		$http(config).success(function(data) {
			defered.resolve(data);
		}).error(function(err) {
			defered.reject(err);
		});

		return defered.promise;
	}

	return {
		list: function(params) {
			return handleRequest('GET', "/admin/movie", params);
		},
		save: function(data) {
			return handleRequest('POST', "/admin/movie", data);
		},
		detail: function(id) {
			return handleRequest('GET', "/admin/movie/detail/" + id);
		},
		delete: function(id) {
			return handleRequest('GET', "/admin/movie/delete/" + id);
		},
		update: function(id) {
			return handleRequest('GET', "/admin/movie/update/" + id);
		},
		recentM: function(style) {
			return handleRequest('GET', "/movie/recentM/" + style);
		},
		commentSave: function(data) {
			return handleRequest('POST', "/comment/save", data);
		},
		getComment: function(id) {
			return handleRequest('GET', "/comment/get/" + id);
		},
		commentlist: function(params) {
			return handleRequest('GET', "/admin/comment", params);
		},
		deleteComment: function(id) {
			return handleRequest('GET', "/comment/deleteComment/" + id);
		},
	}
}