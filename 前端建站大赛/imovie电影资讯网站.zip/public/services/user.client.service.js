angular.module('webapp')
	.service("UserService", ["$http", "$q", UserService]);

function UserService($http, $q) {
	//处理服务器请求
	function handleRequest(method, url, data) {
		var defered = $q.defer();
		var config = {
			method: method,
			url: url
		};

		if ("POST" === method) {
			config.data = data
		} else if ("GET" === method) {
			config.params = data;
		}

		$http(config).success(function(data) {
			defered.resolve(data);
		}).error(function(err) {
			defered.reject(err);
		});

		return defered.promise;
	}

	return {
		register: function(data) {
			return handleRequest('POST', "/user/register", data);
		},
		userlist: function(params) {
			return handleRequest('GET', "/user/register", params);
		},
		deleteuser: function(id) {
			return handleRequest('GET', "/user/deleteuser/" + id);
		},
		login: function(data) {
			return handleRequest('POST', "/user/login", data);
		},
		checklogin: function(data) {
			return handleRequest('GET', "/user/checklogin/" + data);
		},
	}
}