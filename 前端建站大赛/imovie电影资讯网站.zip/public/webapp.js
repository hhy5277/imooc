"use strict"

var webapp = angular.module("webapp", ['ui.router', 'ngCookies', 'ngAnimate']);