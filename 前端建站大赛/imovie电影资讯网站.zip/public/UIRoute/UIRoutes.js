var webapp = angular.module('webapp');

webapp.config(function($stateProvider, $urlRouterProvider) {
	$urlRouterProvider.otherwise("/index");
	$stateProvider
		.state('index', {
			url: "/index",
			views: {
				'': {
					templateUrl: "/frame/index.html",
				},
				'navbar@index': {
					templateUrl: "/index/public/navbar.html",
					controller: function($scope, factory, $rootScope) {
						$rootScope.searchHide = true;
						factory.checkLogin();
						$rootScope.nav = '1';
						$rootScope.movies = undefined;
					}
				},
				'banner@index': {
					templateUrl: "/index/public/banner.html",
					controller: function() {
						$('.carousel').carousel();
					}
				},
				'main@index': {
					templateUrl: "/index/MovieList.html",
					controller: function($scope, factory, $rootScope, $cookieStore, MovieService, $state) {
						var string = 'recent';
						MovieService.recentM(string).then(
							function(data) {
								$scope.movieRecnts = data;
							},
							function(err) {}
						);
						$scope.detailM = function(id) {
							$cookieStore.put('Did', id);
							$state.go('index.detail');
						}
						$(function() {
							var elmArr = [],
								$win = $(window);
							$(".visible").each(function(i, elm) {
								$(elm).data("ot", $(elm).offset().top);
								elmArr.push(elm);
							});

							dealClass(1);
							$win.on("scroll", dealClass);

							function dealClass(isRemove) {
								var top = $win.height() + $win.scrollTop();
								if (isRemove != 1) { //滚动页面时的判断，并添加class="visible"
									for (var i = 0, $elem; i < elmArr.length; i++) {
										$elem = $(elmArr[i]);
										if ($elem.data("ot") <= top) {
											$elem.addClass("visible");
											elmArr.splice(i, 1);
											--i;
										}
									}
								} else { //初始化页面时的判断，并删除class="visible"
									for (var i = 0, $elem; i < elmArr.length; i++) {
										$elem = $(elmArr[i]);
										if ($elem.data("ot") >= top) {
											$elem.removeClass("visible");
										}
									}
								}
							}
						})
					}
				},
				'footer@index': {
					templateUrl: "/index/public/footer.html",
				}
			}
		})
		.state('index.register', {
			url: "/register",
			views: {
				'navbar@index': {},
				'banner@index': {},
				'main@index': {
					templateUrl: "/register.html",
					controller: function($scope, $state, $rootScope, factory, $cookieStore, UserService) {
						$scope.ustate = 1;

						factory.animationBG();

						$scope.register = function() {
							if ($scope.valida()) {
								var user = {
									username: $scope.username,
									email: $scope.email.toLowerCase(),
									phone: $scope.phone,
									password: $scope.password,
								};
								UserService.register(user).then(
									function(data) {
										if (!data.result) {
											$scope.hide = {
												opacity: 0
											};
											$scope.logomove = {
												top: '150px'
											}
											$cookieStore.put('userId', data.userId);
											$rootScope.loginState = true;
											factory.checkLogin();
											setTimeout(function() {
												$state.go("index");
											}, 1000);
										} else {
											factory.tipshow(data.err);
										}
									},
									function(err) {}
								);
							};
						};

						$scope.valida = function() {
							if ($scope.username == '' || $scope.username == null) {
								factory.tipshow("请填写用户名");
								return false
							}
							if ($scope.phone == '' || $scope.phone == null) {
								factory.tipshow("请填写手机号");
								return false
							}
							if (factory.isPhoneNo($scope.phone)) {
								factory.tipshow("请填写正确的手机号");
								return false
							}
							if ($scope.email == '' || $scope.email == null) {
								factory.tipshow("请填写邮箱");
								return false
							}
							if (factory.isEmailNo($scope.email)) {
								factory.tipshow("请填写正确的邮箱");
								return false
							}
							if ($scope.password == '' || $scope.password == null) {
								factory.tipshow("请填写密码");
								return false
							}
							if ($scope.passwords == '' || $scope.passwords == null) {
								factory.tipshow("请重复填写一次密码");
								return false
							}
							if ($scope.password != $scope.passwords) {
								factory.tipshow("两次密码不一致");
								return false
							}
							return true;
						};
					}
				},
				'footer@index': {
					templateUrl: "/index/public/footer.html",
					controller: function($scope) {
						$scope.fix = {
							position: 'fixed',
							bottom: '0',
						}
					}
				}
			}
		})
		.state('index.login', {
			url: "/login",
			views: {
				'navbar@index': {},
				'banner@index': {},
				'main@index': {
					templateUrl: "/login.html",
					controller: function($scope, $state, $rootScope, factory, $cookieStore, UserService) {
						$scope.ustate = 2;
						factory.animationBG();
						$scope.login = function() {
							if ($scope.valida()) {
								var user = {
									email: $scope.email.toLowerCase(),
									password: $scope.password
								};
								UserService.login(user).then(
									function(data) {
										if (data.result) {
											$scope.hide = {
												opacity: 0,
											};
											$scope.logomove = {
												top: '100px',
											}
											$cookieStore.put('userId', data.userId);
											$rootScope.loginState = true;
											factory.checkLogin();
											setTimeout(function() {
												$state.go("index");
											}, 1000);
										} else {
											factory.tipshow("邮箱或密码有误，请重新填写");
										}
									},
									function(err) {}
								);
							};
						};

						$scope.valida = function() {
							if ($scope.email == '' || $scope.email == null) {
								factory.tipshow("请填写邮箱");
								return false
							}
							if (factory.isEmailNo($scope.email)) {
								factory.tipshow("请填写正确的邮箱");
								return false
							}
							if ($scope.password == '' || $scope.password == null) {
								factory.tipshow("请填写密码");
								return false
							}
							return true;
						};
					}
				},
				'footer@index': {
					templateUrl: "/index/public/footer.html",
					controller: function($scope) {
						$scope.fix = {
							position: 'fixed',
							bottom: '0',
						}
					}
				}
			}
		})
		.state('index.coming', {
			url: "/coming",
			views: {
				'navbar@index': {
					templateUrl: "/index/public/navbar.html",
					controller: function($scope, factory, $rootScope, $cookieStore) {
						$rootScope.searchHide = true;
						factory.checkLogin();
					}
				},
				'banner@index': {},
				'main@index': {
					templateUrl: "/coming.html",
					controller: function($scope, $cookieStore, $state, $rootScope, factory, MovieService) {
						$rootScope.nav = '3';
						$scope.textList = '即将上映';
						MovieService.recentM("coming").then(
							function(data) {
								$scope.movieComings = data;
							},
							function(err) {}
						);
						$scope.detailM = function(id) {
							$cookieStore.put('Did', id);
							$state.go('index.detail');
						}
					}
				},
			}
		})
		.state('index.recent', {
			url: "/recent",
			views: {
				'navbar@index': {
					templateUrl: "/index/public/navbar.html",
					controller: function($scope, factory, $rootScope, $cookieStore) {
						$rootScope.searchHide = true;
						factory.checkLogin();
					}
				},
				'banner@index': {},
				'main@index': {
					templateUrl: "/recent.html",
					controller: function($scope, $state, $cookieStore, $rootScope, factory, MovieService) {
						$rootScope.nav = '2';
						$scope.textList = '最新上映';
						var string = 'recent';
						MovieService.recentM(string).then(
							function(data) {
								$scope.movieRecents = data;
							},
							function(err) {}
						);
						$scope.detailM = function(id) {
							$cookieStore.put('Did', id);
							$state.go('index.detail');
						}
					}
				},
			}
		})
		.state('index.detail', {
			url: "/detail",
			views: {
				'navbar@index': {
					templateUrl: "/index/public/navbar.html",
					controller: function($scope, factory, $rootScope, $cookieStore) {
						$rootScope.nav = '0';
						$rootScope.searchHide = true;
						factory.checkLogin();
					}
				},
				'banner@index': {},
				'main@index': {
					templateUrl: "/detail.html",
					controller: function($scope, $rootScope, factory, $cookieStore, MovieService) {
						$rootScope.movies=undefined;
						factory.getMovieDB($cookieStore.get('Did'));
						$scope.commentSave = function() {
							if($scope.content.length>25){
								if ($cookieStore.get('userId')) {
									var comment = {
										movie:$rootScope.movies.id,
										content:$scope.content,
										from:$cookieStore.get('userId'),
									}
									MovieService.commentSave(comment).then(
										function(data) {
											$scope.content='';
											factory.getComment($rootScope.movies.id);
										},
										function(err) {}
									);
								}else{
									factory.tipshow("请先登录");
								}
							}else{
								factory.tipshow("请输入至少25字的评论");
							}
							
							
						}
					}
				},
			}
		})
		.state('index.search', {
			url: "/search",
			views: {
				'navbar@index': {
					templateUrl: "/index/public/navbar.html",
					controller: function($scope, factory, $rootScope, $cookieStore) {
						$scope.searchHide = false;
						factory.checkLogin();
					}
				},
				'banner@index': {},
				'main@index': {
					templateUrl: "/search.html",
					controller: function($scope, $rootScope, $state, $http, $cookieStore, factory, MovieService) {
						if ($cookieStore.get('search')) {
							var str = $cookieStore.get('search');
							$scope.string = str;
							$http({
								method: "JSONP",
								params: {
									input: "GM",
									callback: "jsonpM"
								},
								url: "https://api.douban.com/v2/movie/search?q=" + str,
								isArray: true
							}).success(function(data, status) {}).error(function(data, status) {
								$scope.SearchM = jsonM;
							});
						};

						$scope.search = function(str) {
							if (str) {
								$cookieStore.put('search', $scope.string);
								$http({
									method: "JSONP",
									params: {
										input: "GM",
										callback: "jsonpM"
									},
									url: "https://api.douban.com/v2/movie/search?q=" + str,
									isArray: true
								}).success(function(data, status) {}).error(function(data, status) {
									$scope.SearchM = jsonM;
								});
							}
						};

						$scope.detailM = function(id) {
							$cookieStore.put('Did', id);
							$state.go('index.detail');
						};

					}
				},
			}
		})
		.state('manage', {
			url: "/manage",
			views: {
				'': {
					templateUrl: "/frame/manage.html",
				},
				'slide@manage': {
					templateUrl: "/manage/slide.html",
					controller: function($scope, $state, factory, UserService, $rootScope, $cookieStore) {
						if ($cookieStore.get('userId') != '' && $cookieStore.get('userId') != null) {
							var userId = $cookieStore.get('userId');
							$rootScope.loginState = true;
							UserService.checklogin(userId).then(
								function(data) {
									if (data.role == 1) {
										$rootScope.loginName = data.username;
										factory.loadMovie(1);
									} else {
										$state.go("index");
									}
								},
								function(err) {}
							);
						} else {
							$state.go("index.login");
						};

						$scope.loadMovies = function() {
							factory.loadMovie(1);
						};
					}
				},
				'main@manage': {
					templateUrl: "/manage/movieM.html",
					controller: 'movieManager'
				},
			}
		})
		.state('manage.user', {
			url: "/user",
			views: {
				'main@manage': {
					templateUrl: "/manage/userM.html",
					controller: 'userMananger'
				},
			}
		})
		.state('manage.comment', {
			url: "/comment",
			views: {
				'main@manage': {
					templateUrl: "/manage/commentM.html",
					controller: 'commentMananger'
				},
			}
		})
});



//公共方法存放
function factory($rootScope, $state, UserService, MovieService, $http, $cookieStore) {
	var factory = {};
	var num = 0;
	var nums = 0;

	//豆瓣获取电影数据
	factory.updateMovie = function(url, string, temp) {
		$.ajax({
			type: "GET",
			dataType: "jsonp",
			jsonp: "callback",
			url: url,
			success: function(data) {
				data.subjects.forEach(function(movie) {
					var casts = [];
					var genres = [];
					var _movie = {};
					_movie.DId = movie.id;
					_movie.title = movie.title;
					if (movie.directors != '') {
						_movie.director = movie.directors[0].name;
					} else {
						_movie.director = '未知';
					};
					movie.casts.forEach(function(cast) {
						casts.push(cast.name);
					});
					_movie.actor = casts.join('、');
					movie.genres.forEach(function(genre) {
						genres.push(genre);
					});
					_movie.catetory = genres.join('、');
					_movie.poster = movie.images.large;
					_movie.showTime = movie.year;
					_movie.average = movie.rating.average;
					_movie.style = string;
					MovieService.save(_movie).then(
						function(datas) {	
							nums += 1;
							if (nums == data.total) {
								factory.tipshow("更新" + nums + "条电影数据");
								factory.loadMovie();
							};
						},
						function(err) {}
					);

				})
			},
		})
	};

	//通过豆瓣ID获取豆瓣电影数据
	factory.getMovieDB = function(id) {
		var casts = '';
		var genres = '';
		$http({
			method: "JSONP",
			params: {
				input: "GM",
				callback: "jsonpM"
			},
			url: "https://api.douban.com/v2/movie/subject/" + id,
			isArray: true
		}).success(function(data, status) {}).error(function(data, status) {
			if (jsonM) {
				factory.getComment(jsonM.id);
				$rootScope.movies = jsonM;
			}

		});

	}

	factory.getComment = function(id) {
		MovieService.getComment(id).then(
			function(data) {
				$rootScope.comments = data;
			},
			function(err) {}
		);
	};

	//通过豆瓣ID获取豆瓣电影数据
	factory.getMovieInfo = function(id, string) {
		var casts = [];
		var genres = [];
		var _movie = {};
		$http({
			method: "JSONP",
			params: {
				input: "GM",
				callback: "jsonpM"
			},
			url: "https://api.douban.com/v2/movie/subject/" + id,
			isArray: true
		}).success(function(data, status) {}).error(function(data, status) {
			var movie = jsonM;
			_movie.DId = movie.id;
			_movie.title = movie.title;
			if (movie.directors != '') {
				_movie.director = movie.directors[0].name;
			} else {
				_movie.director = '未知';
			};
			movie.casts.forEach(function(cast) {
				casts.push(cast.name);
			});
			_movie.actor = casts.join('、');
			movie.genres.forEach(function(genre) {
				genres.push(genre);
			});
			_movie.catetory = genres.join('、');
			_movie.poster = movie.images.large;
			_movie.showTime = movie.year;
			_movie.average = movie.rating.average;
			$rootScope.movies = _movie;
		});
	}

	//获取数据库电影详情
	factory.detailM = function(id) {
		MovieService.detail(id).then(
			function(data) {
				$rootScope.movies = data;
			},
			function(err) {}
		);
	}


	//加载数据库电影列表
	factory.loadMovie = function(num) {
		// $scope.pics = [];
		// $scope.pages = [];
		// $scope.pagecss = num;
		// var pages = 0;
		// var page = parseInt(num);
		MovieService.list().then(
			function(data) {
				// pages = Math.ceil(data.length / $scope.pagesize);
				// if ($scope.pages == "") {
				// 	for (var i = 1; i <= parseInt(pages); i++) {
				// 		$scope.pages.push(i.toString());
				// 	}
				// }
				// var pagestart = (page - 1) * $scope.pagesize;
				// var pageend = pagestart + $scope.pagesize;
				// $scope.list = data.slice(pagestart, pageend);
				$rootScope.list = data;
				$rootScope.Mlist = true;
			},
			function(err) {}
		);
	};

	//更新最新上映电影数据
	factory.saveMovie = function(data, string) {
		data.style = string;
		MovieService.save(data).then(
			function(data) {
				nums += 1;
				if (nums == num) {
					factory.tipshow("更新" + num + "条电影数据");
					factory.loadMovie();
				};
			},
			function(err) {}
		);

	};

	//搜索
	$rootScope.searchs = function(temp) {
		if (typeof(temp) == "undefined" || temp == '') {
			factory.tipshow('请输入关键字搜索');
		} else {
			$cookieStore.put('search', temp);
			$state.go('index.search');
		}
	}

	//信息提示栏
	factory.tipshow = function(temp) {
		$rootScope.tip = temp;
		$('.tips').css({
			top: '0'
		});
		setTimeout(function() {
			$('.tips').css({
				top: '-60px'
			});
		}, 3000);
	};

	//验证邮箱格式
	factory.isEmailNo = function(data) {
		var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
		if (reg.test(data) === false) {
			return true;
		}
	};

	//验证手机号格式
	factory.isPhoneNo = function(data) {
		var reg = /^0?1[3|4|5|8][0-9]\d{8}$/;
		if (reg.test(data) === false) {
			return true;
		}
	};

	//检验登陆
	factory.checkLogin = function() {
		if ($cookieStore.get('userId') != '' && $cookieStore.get('userId') != null) {
			var userId = $cookieStore.get('userId');
			$rootScope.loginState = true;
			UserService.checklogin(userId).then(
				function(data) {
					$rootScope.loginName = data.username;
				},
				function(err) {}
			);
		}
	};

	//
	$rootScope.formatTime = function(time) {
		return moment(time).format('YYYY年MM月DD日 HH:mm');
	};

	//退出
	$rootScope.quit = function() {
		$rootScope.loginState = false;
		$cookieStore.remove('userId');
	};

	//动态背景
	factory.animationBG = function() {
		try {
			if (/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)) {

			} else {
				$(function() {
					var canvas = document.querySelector('canvas'),
						ctx = canvas.getContext('2d')
					canvas.width = window.innerWidth;
					canvas.height = window.innerHeight;
					ctx.lineWidth = .3;
					ctx.strokeStyle = (new Color(150)).style;

					var mousePosition = {
						x: Math.random() * canvas.width,
						y: Math.random() * canvas.height
					};

					var dots = {
						nb: 120,
						distance: 100,
						d_radius: 50,
						array: []
					};

					function createColorStyle(r, g, b) {
						op = Math.random() * 1;
						return 'rgba(' + r + ',' + g + ',' + b + ', ' + op + ')';
					}

					function mixComponents(comp1, weight1, comp2, weight2) {
						return (comp1 * weight1 + comp2 * weight2) / (weight1 + weight2);
					}

					function averageColorStyles(dot1, dot2) {
						return createColorStyle(102, 102, 102);
					}

					function Color(min) {
						this.style = createColorStyle(102, 102, 102);
					}

					function Dot() {
						this.x = Math.random() * canvas.width;
						this.y = Math.random() * canvas.height;

						this.vx = -.5 + Math.random();
						this.vy = -.5 + Math.random();

						this.radius = Math.random() * 2;

						this.color = new Color();
					}

					Dot.prototype = {
						draw: function() {
							ctx.beginPath();
							ctx.fillStyle = this.color.style;
							ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
							ctx.fill();
						}
					};

					function createDots() {
						for (i = 0; i < dots.nb; i++) {
							dots.array.push(new Dot());
						}
					}

					function moveDots() {
						for (i = 0; i < dots.nb; i++) {

							var dot = dots.array[i];

							if (dot.y < 0 || dot.y > canvas.height) {
								dot.vx = dot.vx;
								dot.vy = -dot.vy;
							} else if (dot.x < 0 || dot.x > canvas.width) {
								dot.vx = -dot.vx;
								dot.vy = dot.vy;
							}
							dot.x += dot.vx;
							dot.y += dot.vy;
						}
					}

					function connectDots() {
						for (i = 0; i < dots.nb; i++) {
							for (j = 0; j < dots.nb; j++) {
								i_dot = dots.array[i];
								j_dot = dots.array[j];

								if ((i_dot.x - j_dot.x) < dots.distance && (i_dot.y - j_dot.y) < dots.distance && (i_dot.x - j_dot.x) > -dots.distance && (i_dot.y - j_dot.y) > -dots.distance) {
									if ((i_dot.x - mousePosition.x) < dots.d_radius && (i_dot.y - mousePosition.y) < dots.d_radius && (i_dot.x - mousePosition.x) > -dots.d_radius && (i_dot.y - mousePosition.y) > -dots.d_radius) {
										ctx.beginPath();
										ctx.strokeStyle = averageColorStyles(i_dot, j_dot);
										ctx.moveTo(i_dot.x, i_dot.y);
										ctx.lineTo(j_dot.x, j_dot.y);
										ctx.stroke();
										ctx.closePath();
									}
								}
							}
						}
					}

					function drawDots() {
						for (i = 0; i < dots.nb; i++) {
							var dot = dots.array[i];
							dot.draw();
						}
					}

					function animateDots() {
						ctx.clearRect(0, 0, canvas.width, canvas.height);
						moveDots();
						connectDots();
						drawDots();

						requestAnimationFrame(animateDots);
					}

					$('canvas').on('mousemove', function(e) {
						mousePosition.x = e.pageX;
						mousePosition.y = e.pageY;
					});

					$('canvas').on('mouseleave', function(e) {
						mousePosition.x = e.pageX;
						mousePosition.y = e.pageY;
					});

					createDots();
					requestAnimationFrame(animateDots);
				});
			}
		} catch (e) {};
	}

	return factory;
};

function movieManager($scope, $rootScope, $cookieStore, MovieService, factory) {
	$scope.movie = {};
	$scope.HotShows = [];
	$scope.pagesize = 10;
	$scope.pagecss = '';
	$rootScope.menu = 'm';
	$rootScope.Mlist = false;
	$scope.timeHide = false;
	$scope.getMovieInfo = function() {
		factory.getMovieInfo($rootScope.movies.DId, false)
	}
	$scope.clearM = function() {
		$scope.Htitle = '录入电影';
		$scope.timeHide = false;
		$rootScope.movies = {};
		$('#myModal').modal('show');
	};
	$scope.updateRMovie = function() {
		$rootScope.Mlist = false;
		factory.updateMovie('https://api.douban.com/v2/movie/in_theaters?count=40', 'recent', true);
	};
	$scope.updateCMovie = function() {
		$rootScope.Mlist = false;
		factory.updateMovie('https://api.douban.com/v2/movie/coming_soon?count=100', 'coming', true);
	};
	// $scope.updateTMovie = function() {
	// 	$rootScope.Mlist = false;
	// 	factory.updateMovie('https://api.douban.com/v2/movie/top250?start=0&count=75', 'top250', false);
	// 	factory.updateMovie('https://api.douban.com/v2/movie/top250?count=75&start=76', 'top250', false);
	// 	factory.updateMovie('https://api.douban.com/v2/movie/top250?count=100&start=151', 'top250', true);
	// };
	$scope.detailM = function(id) {
		$scope.Htitle = '电影详情';
		$scope.timeHide = true;
		factory.detailM(id);
	}
	$scope.delete = function(id) {
		MovieService.delete(id).then(
			function(data) {
				$rootScope.list.forEach(function(v, i, _) {
			      if (v._id == id) {
			        _.splice(i, 1);
			      }
			    });
				factory.tipshow("成功删除");
			},
			function(err) {}
		);
	};
	$scope.save = function(data) {
		MovieService.save(data).then(
			function(datas) {
				$('#myModal').modal('hide')
				factory.loadMovie();
				factory.tipshow("成功更新《" + data.title + "》资料");
			},
			function(err) {
				$scope.editorMessage = err;
			}
		);
	}
};

function userMananger($scope, $rootScope, $cookieStore, UserService, factory) {
	$rootScope.menu = 'u';
	$scope.loadUser = function() {
		UserService.userlist().then(
			function(data) {
				$scope.userlist = data;
			},
			function(err) {}
		);
	};
	$scope.loadUser();
	$scope.deleteuser = function(id) {
		UserService.deleteuser(id).then(
			function(data) {
				if(data){
					$scope.userlist.forEach(function(v, i, _) {
				      if (v._id == id) {
				        _.splice(i, 1);
				      }
				    });
					factory.tipshow("成功删除");
				}
			},
			function(err) {}
		);
	}
};

function commentMananger($scope, $rootScope, $cookieStore, MovieService, factory) {
	$rootScope.menu = 'c';
	$scope.loadComment = function() {
		MovieService.commentlist().then(
			function(data) {
				$scope.commentlist = data;
			},
			function(err) {}
		);
	};
	$scope.loadComment();
	$scope.deleteComment = function(id) {
		MovieService.deleteComment(id).then(
			function(data) {
				if(data){
					$scope.commentlist.forEach(function(v, i, _) {
				      if (v._id == id) {
				        _.splice(i, 1);
				      }
				    });
					factory.tipshow("成功删除");
				}
			},
			function(err) {}
		);
	}
};

webapp.factory('factory', ['$rootScope', '$state', 'UserService', 'MovieService', '$http', '$cookieStore', factory])
webapp.controller('movieManager', ['$scope', '$rootScope', '$cookieStore', 'MovieService', 'factory', movieManager]);
webapp.controller('userMananger', ['$scope', '$rootScope', '$cookieStore', 'UserService', 'factory', userMananger]);
webapp.controller('commentMananger', ['$scope', '$rootScope', '$cookieStore', 'MovieService', 'factory', commentMananger]);