/**
 * Created by Administrator on 2015/9/6.
 */
window.onload=function(){
    var more_product=document.getElementById("more_product");
    var right_bar=document.getElementById("right_bar");
    more_product.onmouseover=function(){
        right_bar.style.display="block";
    }
    right_bar.onmouseout=function(){
        this.style.display="none";
    }
    right_bar.onmouseover=function(){
        this.style.display="block";
    }
}