#!/usr/bin/env python
# -*- coding:utf-8 -*-

# 对城市的数据统计
from Lagou import db
import re


class AnalyseMachine():
    def __init__(self):
        print("数据分析机启动中...")
        self.lagou_db = db.LGDB()
        self.maxSize = self.lagou_db.db.jobs.find().count()


    def __getJobsCollection(self):
        "取得数据集合"
        return self.lagou_db.db.jobs.find()


    def __dataFormatPercent(self, diction):
        "将数据转化成百分比"
        result = []

        for name, count in diction:
            percent = float(count) / float(self.maxSize) * 100
            result.append((name, count, str(round(percent, 2)) + "%"))

        return result

    def getNormalDataPercent(self, key, pattern=None):
        "获取普通的数据集，并进行排序"
        print("正在获取%s的数据" % key)
        diction = {}

        # 编辑职业取属性
        for job in self.__getJobsCollection():
            # 如果使用了正则表达式，则通过匹配相应字符
            if pattern:
                matchArr = re.findall(pattern, job[key])
                if len(matchArr):
                    attr = matchArr[0]
                else:
                    attr = job[key]
            else:
                attr = job[key]

            if attr in diction:
                diction[attr] += 1
            else:
                diction[attr] = 1

        diction = sorted(diction.items(), key=lambda item: item[1], reverse=True)
        return self.__dataFormatPercent(diction)

if __name__ == '__main__':
    analyse = AnalyseMachine()
    print("样本总数：", analyse.maxSize)

    def getEduData():
        pattern = re.compile("(初中|高中|大学|中专|大专|本科|研究生|硕士|博士|不限)")
        print(analyse.getNormalDataPercent("education", pattern))

    def getCityData():
        print(analyse.getNormalDataPercent("city"))

    stage = "|".join(("未融资", "上市公司", "A轮", "B轮", "C轮", "D轮", "天使轮", "不需要融资"))
    pattern = "(%s)" % stage
    print(analyse.getNormalDataPercent("financeStage", pattern))

    getCityData()
    getEduData()

  

