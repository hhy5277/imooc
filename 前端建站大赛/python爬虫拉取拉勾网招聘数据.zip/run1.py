#!/usr/bin/env python
# -*- coding:utf-8 -*-
from LG import LG2
if __name__ == '__main__':
    print("使用第二种方式爬取数据...")
    #1112126
    lg = LG2(10, startId=1142248)
    lg.run()
    print("所有数据已存储...")


  

