/**
 * 第二副场景页面
 *
 */
function pageA(element,callback) {
    //圣诞男孩
    var $boy = element.find(".christmas-boy");
    //窗户
    var $window = element.find(".window");
    var $leftWin  = $window.find(".window-left");
    var $rightWin = $window.find(".window-right");
    var animationEnd = "animationend webkitAnimationEnd";
    /**
     * 小男孩动作
     * @return {[type]} [description]
     */
    var boyAction = {
        //走路
        walk: function() {
            var dfd = $.Deferred();
            $boy.transition({
                "left": "4.5rem"
            }, 4000, "linear", function() {
                dfd.resolve()
            });
            return dfd;
        },
        //停止走路
        stopWalk: function() {
            $boy.removeClass("boy-walk");
            $boy.addClass("boy-stand");
        },
        //继续走路
        runWalk: function() {
            $boy.transition({
                "left": "16rem"
            }, 5000, "linear");
            //$boy.removeClass("boy-stand");
            $boy.addClass("boy-walk");

        }
    };
    //开始走路
    boyAction.walk()
        .then(function() {
            //停止走路
            boyAction.stopWalk();
        }).then(function(){
            //运行动画
            windowAction.openWindow();
        }).then(function(){
            shot.switch_lens();
        }).then(function(){
            setTimeout(function(){
                callback();
            },6000)

        })
    /**
     * 开窗 封装开窗类
     * @return {[type]} [description]
     */
    var windowAction={
        openWindow : function(callback) {
            var count = 1;
            var complete = function() {
                ++count
                if (count === 2) {
                    callback && callback();
                }
                }
            var bind = function(data) {
                data.one("transitionend webkitTransitionEnd", function(event) {
                    data.removeClass("window-transition");
                    complete();
                })
            }
            bind($leftWin.addClass("window-transition").addClass("hover"));
            bind($rightWin.addClass("window-transition").addClass("hover"));
        },
        /**
         * 运行下一个动画
         * @return {Function} [description]
         */
        next : function(options) {
            var dfd = $.Deferred();
            $boy.transition(options.style, options.time, "linear", function() {
                dfd.resolve();
            });
            return dfd;
        }
    }
    /*
     镜头拉放效果封装类
     * */
    var shot={
      switch_lens:function(){
          $(".page-a").addClass("effect-out");
      },
        switch_lens1:function(){
            $(".page-b").addClass("effect-in");
        }
    }
}
