/**
 * 慕课网特制
 * 圣诞主题效果
 * @type {Object}
 */
/**
 * 背景音乐
 * @param {[type]} url  [description]
 * @param {[type]} loop [description]
 */
function HTML5Audio(url, loop) {
    var audio = new Audio(url);
    audio.autoplay = true;
    audio.loop = loop || false; //是否循环
    audio.play();
    return {
        end: function(callback) {
            audio.addEventListener('ended', function() {
                callback();
            }, false);
        }
    }
}
/**
 * 中间调用
 */
var Christmas = function() {
    var audio1 = HTML5Audio('music/1.mp3',true);
    //页面容器元素
    var $pageA = $(".page-a");
    var $pageB = $(".page-b");
    var $pageC = $(".page-c");
    //观察者
    var observer = new Observer();
    //A场景页面
    setTimeout(function(){
    new pageA($pageA,function() {
        observer.publish("completeA");
    })
    },3000)
    //进入C场景
    observer.subscribe("pageC", function() {
        setTimeout(function(){
new pageC($pageC);
        },12000)
    })
    observer.subscribe("completeB", function() {
        setTimeout(function(){
            $pageB.addClass("effect-out-out");
            $pageC.addClass("effect-in");
        },6500)
            observer.publish("pageC");
    })
    //进入B场景
    observer.subscribe("pageB", function() {
        new pageB($pageB,function() {
            observer.publish("completeB");
        })
    })
    observer.subscribe("completeA", function() {
            observer.publish("pageB");
    })
};
$(function() {

        //圣诞主题效果，开始
        Christmas();

})