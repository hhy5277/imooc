<?php
//header('content-type:text/html;charset=utf-8');

class MsSql{
	  private $Host;    //连接数据库服务器
      private $Database;//连接数据库主机名
      private $UID;     //连接数据库用户名
      private $PWD;     //连接数据库密码
      
      /**
       * @author XL
       *析构函数，完成数据成员的初始化
       */
      
      function __construct($Host='',$Database='',$UID='',$PWD=''){
      	$this->Host=$Host;
      	$this->Database=$Database;
      	$this->UID=$UID;
      	$this->PWD=$PWD;
      }
      
      public function conn(){
      	$Host=$this->Host;
      	$db_info=array("Database"=>$this->Database,"UID"=>$this->UID,"PWD"=>$this->PWD);
         if ($link=sqlsrv_connect($Host,$db_info))
         {
         	return $link;
         }else {
      	//print_r($Host);
        //print_r($db_info);exit;
      	   $this->err('数据库连接错误');
         }
      }
      
	/**
	 * @author XL
	 *执行select查询
	 *@param unknown $tables
	 *@param string $fields
	 *@param string $where
	 *@param string $group
	 *@param string $having
	 *@param string $order
	 *@return Ambigous <unknown, unknown, multitype:>
	 *
	 */
 	public function fun_select($tables,$fields='*',$where=NULL,$group=NULL,$having=NULL,$order=NULL){
	    $sql='SELECT '.$fields.' FROM '.$tables
		.$this->parseWhere($where)
		.$this->parseGroup($group)
		.$this->parseHaving($having)
		.$this->parseOrder($order);
		$query=sqlsrv_querey($sql);
		$dataAll=sqlsrv_fetch_array($query);
		//echo $dataAll[1];
		return $dataAll;
 	}
 	
 	/**
 	 * @author XL
 	 *添加记录的操作*
 	 *@param string $table
 	 *@param array $dataArray
 	 *@return Ambigous <boolean, unknown, number>
 	 */
 	public function fun_add($tables,$dataArray){
 		if (is_array($dataArray)&&!empty($tables)){
              $keys=array_keys($dataArray);//将$dataArray[]的索引取出组成一个数组
              $keys=join(',', $keys);
              $values=array_values($dataArray);//将$dataArray[]的数值取出组成一个数组
              $values=join('\',\'', $values);
              $values="'".$values."'";
              $sql="INSERT {$tables}({$keys}) VALUES({$values})";
              var_dump($sql);exit;
              return $this->execute($sql);
 		}else {
 			$this->err('没有要插入的数据');
 			return false;
 		}	
 	}
 	/**
 	 * @author XL
 	 *更新记录的操作
 	 *@param string $table
 	 *@param array $data
 	 *@param string $where
 	 *@param string $order
 	 *@return Ambigous <boolean, unknown, number>
 	 */
 	public function fun_update($tables,$data,$where,$order=null){
 		if (is_array($data)&&!empty($where)){
 			foreach ($data as $key=>$val){
 				$sets.=$key."='".$val."',";
 				
 			}
 			$sets=rtrim($sets,',');
			    $sql="UPDATE {$tables} SET {$sets} ".$this->parseWhere($where).$this->parseOrder($order);
 			return $this->execute($sql);
 		}else {
 			return false;
 		}
 	}
 	/**
 	 * @author XL
 	 *删除记录的操作
 	 *@param string $table
 	 *@param string $where
 	 *@param string $order
 	 *@return Ambigous <boolean, unknown, number>
 	 */
 	public function fun_delete($tables,$where,$order=NULL){
 		if (is_string($where)&&!empty($where)){
 			$sql="DELETE FROM {$tables}".$this->parseWhere($where).$this->parseOrder($order);
 			return $this->execute($sql);
 		}
 		return false;
 	}
	/**
	 * @author XL
	 * 解析Where条件 
	 * @param string $where
	 * @return string
	 */
   	public function parseWhere($where){
		$whereStr='';
		if (is_string($where)&&!empty($where)){
			$whereStr=$where;
		}
		return empty($whereStr)?'':' WHERE '.$whereStr;
	}
	/**
	 * @author XL
	 * 解析group by条件
	 * @param unknown $group
	 * @return string
	 */
	public function parseGroup($group) {
		$groupStr = '';
		if (is_array ( $group )) { //判断$group是否为数组，并进行解析
			$groupStr .= ' GROUP BY ' . implode ( ',', $group );
		} 
		elseif (is_string ( $group ) && ! empty ( $group )) { //判断$group是否为字符串，并进行解析
			$groupStr .= ' GROUP BY ' . $group;
		}
		return empty( $groupStr ) ? '' : $groupStr;
	}
	/**
	 * @author XL
	 * 解析Having by子句,对分组结果进行二次筛选
	 * @param string $having
	 * @return string
	 */
	public function parseHaving($having){
		$havingStr='';
		if (is_string($having)&&!empty($having)){
			$havingStr.=' HAVING '.$having;
		}
		return $havingStr;
	}
	/**
	 * @author XL
	 * 解析Order by子句
	 * @param unknown $order
	 * @return string
	 */
	public function parseOrder($order){
		$orderStr='';
		if (is_array($order)){
			$orderStr.=' ORDER BY '.join(',', $order).'';
		}elseif (is_string($order)&&!empty($order)){
			$orderStr.=' ORDER BY '.$order.'';
		}
		return $orderStr;
	}
	/**
     * @author XL
     *将sql语句进行预处理
     */
	public function execute($sql = NULL) {
		$link=$this->conn();
		if (!$link) {
			return false;
		}
		if (!empty ($sql)){
		    $queryStr =sqlsrv_prepare($link,$sql);
		    $res =sqlsrv_execute ( $queryStr );
		    return $res;
		}
	}
	/**
     * @author XL
     *错误提示信息
     */
	public function err($msg) {
		if (!empty($msg)){
			echo "<script>alert('".$msg."')</script>";
		    die (); 
		}
	}
}

$Host=".";
$Database="DB";
$UID="sa";
$PWD="123";
$ms=new MsSql($Host,$Database,$UID,$PWD);   
$ms->conn();                   //连接SQL server
//$ms->err('出现错误');
//echo $ms->err(12);
//$where="id=2";
//echo $ms->parseWhere($where);  //对where字段解析
//echo "<hr/>";
//$Group="id";
//echo $ms->parseGroup($Group);  //对Group字段解析
//echo "<hr/>";
//$having="id,name";
//echo $ms->parseHaving($having);//对having字段解析
//echo "<hr/>";
//$order="id DESC";
//echo $ms->parseOrder($order);  //对order字段解析
//echo "<hr/>";
//echo $ms->fun_select('[user]','*');
//echo "<hr/>";
//$add=array('id'=>'1','name'=>'张三','age'=>'12','sex'=>'男');
//$ms->fun_add(user, $add);
// echo "<hr/>";
//echo $ms->fun_delete('user', 'id=33','name DESC');
// $update=array('password'=>'14','name'=>'李四以123');
// echo  $ms->fun_update('[user]', $update, 'id=14');
 // $sql="SELECT * FROM [DB].[dbo].[user]";
 // $rest= sqlsrv_querey($sql);
// sqlsrv_fetch_array($rest);
//$a= $ms->execute($sql);        //执行预处理语句
//echo $rest[];

