<pre class="brush:php;toolbar:false">&lt;?php
//header(&#39;content-type:text/html;charset=utf-8&#39;);

class&nbsp;MsSql{
	&nbsp;&nbsp;private&nbsp;$Host;&nbsp;&nbsp;&nbsp;&nbsp;//连接数据库服务器
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;$Database;//连接数据库主机名
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;$UID;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//连接数据库用户名
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;$PWD;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//连接数据库密码
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/**
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;@author&nbsp;XL
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*析构函数，完成数据成员的初始化
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;__construct($Host=&#39;&#39;,$Database=&#39;&#39;,$UID=&#39;&#39;,$PWD=&#39;&#39;){
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	$this-&gt;Host=$Host;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	$this-&gt;Database=$Database;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	$this-&gt;UID=$UID;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	$this-&gt;PWD=$PWD;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;conn(){
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	$Host=$this-&gt;Host;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	$db_info=array(&quot;Database&quot;=&gt;$this-&gt;Database,&quot;UID&quot;=&gt;$this-&gt;UID,&quot;PWD&quot;=&gt;$this-&gt;PWD);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;($link=sqlsrv_connect($Host,$db_info))
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	return&nbsp;$link;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}else&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	//print_r($Host);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//print_r($db_info);exit;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	&nbsp;&nbsp;&nbsp;$this-&gt;err(&#39;数据库连接错误&#39;);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	/**
	&nbsp;*&nbsp;@author&nbsp;XL
	&nbsp;*执行select查询
	&nbsp;*@param&nbsp;unknown&nbsp;$tables
	&nbsp;*@param&nbsp;string&nbsp;$fields
	&nbsp;*@param&nbsp;string&nbsp;$where
	&nbsp;*@param&nbsp;string&nbsp;$group
	&nbsp;*@param&nbsp;string&nbsp;$having
	&nbsp;*@param&nbsp;string&nbsp;$order
	&nbsp;*@return&nbsp;Ambigous&nbsp;&lt;unknown,&nbsp;unknown,&nbsp;multitype:&gt;
	&nbsp;*
	&nbsp;*/
&nbsp;	public&nbsp;function&nbsp;fun_select($tables,$fields=&#39;*&#39;,$where=NULL,$group=NULL,$having=NULL,$order=NULL){
	&nbsp;&nbsp;&nbsp;&nbsp;$sql=&#39;SELECT&nbsp;&#39;.$fields.&#39;&nbsp;FROM&nbsp;&#39;.$tables
		.$this-&gt;parseWhere($where)
		.$this-&gt;parseGroup($group)
		.$this-&gt;parseHaving($having)
		.$this-&gt;parseOrder($order);
		$query=sqlsrv_querey($sql);
		$dataAll=sqlsrv_fetch_array($query);
		//echo&nbsp;$dataAll[1];
		return&nbsp;$dataAll;
&nbsp;	}
&nbsp;	
&nbsp;	/**
&nbsp;	&nbsp;*&nbsp;@author&nbsp;XL
&nbsp;	&nbsp;*添加记录的操作*
&nbsp;	&nbsp;*@param&nbsp;string&nbsp;$table
&nbsp;	&nbsp;*@param&nbsp;array&nbsp;$dataArray
&nbsp;	&nbsp;*@return&nbsp;Ambigous&nbsp;&lt;boolean,&nbsp;unknown,&nbsp;number&gt;
&nbsp;	&nbsp;*/
&nbsp;	public&nbsp;function&nbsp;fun_add($tables,$dataArray){
&nbsp;		if&nbsp;(is_array($dataArray)&amp;&amp;!empty($tables)){
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$keys=array_keys($dataArray);//将$dataArray[]的索引取出组成一个数组
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$keys=join(&#39;,&#39;,&nbsp;$keys);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$values=array_values($dataArray);//将$dataArray[]的数值取出组成一个数组
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$values=join(&#39;\&#39;,\&#39;&#39;,&nbsp;$values);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$values=&quot;&#39;&quot;.$values.&quot;&#39;&quot;;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$sql=&quot;INSERT&nbsp;{$tables}({$keys})&nbsp;VALUES({$values})&quot;;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;var_dump($sql);exit;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;$this-&gt;execute($sql);
&nbsp;		}else&nbsp;{
&nbsp;			$this-&gt;err(&#39;没有要插入的数据&#39;);
&nbsp;			return&nbsp;false;
&nbsp;		}	
&nbsp;	}
&nbsp;	/**
&nbsp;	&nbsp;*&nbsp;@author&nbsp;XL
&nbsp;	&nbsp;*更新记录的操作
&nbsp;	&nbsp;*@param&nbsp;string&nbsp;$table
&nbsp;	&nbsp;*@param&nbsp;array&nbsp;$data
&nbsp;	&nbsp;*@param&nbsp;string&nbsp;$where
&nbsp;	&nbsp;*@param&nbsp;string&nbsp;$order
&nbsp;	&nbsp;*@return&nbsp;Ambigous&nbsp;&lt;boolean,&nbsp;unknown,&nbsp;number&gt;
&nbsp;	&nbsp;*/
&nbsp;	public&nbsp;function&nbsp;fun_update($tables,$data,$where,$order=null){
&nbsp;		if&nbsp;(is_array($data)&amp;&amp;!empty($where)){
&nbsp;			foreach&nbsp;($data&nbsp;as&nbsp;$key=&gt;$val){
&nbsp;				$sets.=$key.&quot;=&#39;&quot;.$val.&quot;&#39;,&quot;;
&nbsp;				
&nbsp;			}
&nbsp;			$sets=rtrim($sets,&#39;,&#39;);
			&nbsp;&nbsp;&nbsp;&nbsp;$sql=&quot;UPDATE&nbsp;{$tables}&nbsp;SET&nbsp;{$sets}&nbsp;&quot;.$this-&gt;parseWhere($where).$this-&gt;parseOrder($order);
&nbsp;			return&nbsp;$this-&gt;execute($sql);
&nbsp;		}else&nbsp;{
&nbsp;			return&nbsp;false;
&nbsp;		}
&nbsp;	}
&nbsp;	/**
&nbsp;	&nbsp;*&nbsp;@author&nbsp;XL
&nbsp;	&nbsp;*删除记录的操作
&nbsp;	&nbsp;*@param&nbsp;string&nbsp;$table
&nbsp;	&nbsp;*@param&nbsp;string&nbsp;$where
&nbsp;	&nbsp;*@param&nbsp;string&nbsp;$order
&nbsp;	&nbsp;*@return&nbsp;Ambigous&nbsp;&lt;boolean,&nbsp;unknown,&nbsp;number&gt;
&nbsp;	&nbsp;*/
&nbsp;	public&nbsp;function&nbsp;fun_delete($tables,$where,$order=NULL){
&nbsp;		if&nbsp;(is_string($where)&amp;&amp;!empty($where)){
&nbsp;			$sql=&quot;DELETE&nbsp;FROM&nbsp;{$tables}&quot;.$this-&gt;parseWhere($where).$this-&gt;parseOrder($order);
&nbsp;			return&nbsp;$this-&gt;execute($sql);
&nbsp;		}
&nbsp;		return&nbsp;false;
&nbsp;	}
	/**
	&nbsp;*&nbsp;@author&nbsp;XL
	&nbsp;*&nbsp;解析Where条件&nbsp;
	&nbsp;*&nbsp;@param&nbsp;string&nbsp;$where
	&nbsp;*&nbsp;@return&nbsp;string
	&nbsp;*/
&nbsp;&nbsp;&nbsp;	public&nbsp;function&nbsp;parseWhere($where){
		$whereStr=&#39;&#39;;
		if&nbsp;(is_string($where)&amp;&amp;!empty($where)){
			$whereStr=$where;
		}
		return&nbsp;empty($whereStr)?&#39;&#39;:&#39;&nbsp;WHERE&nbsp;&#39;.$whereStr;
	}
	/**
	&nbsp;*&nbsp;@author&nbsp;XL
	&nbsp;*&nbsp;解析group&nbsp;by条件
	&nbsp;*&nbsp;@param&nbsp;unknown&nbsp;$group
	&nbsp;*&nbsp;@return&nbsp;string
	&nbsp;*/
	public&nbsp;function&nbsp;parseGroup($group)&nbsp;{
		$groupStr&nbsp;=&nbsp;&#39;&#39;;
		if&nbsp;(is_array&nbsp;(&nbsp;$group&nbsp;))&nbsp;{&nbsp;//判断$group是否为数组，并进行解析
			$groupStr&nbsp;.=&nbsp;&#39;&nbsp;GROUP&nbsp;BY&nbsp;&#39;&nbsp;.&nbsp;implode&nbsp;(&nbsp;&#39;,&#39;,&nbsp;$group&nbsp;);
		}&nbsp;
		elseif&nbsp;(is_string&nbsp;(&nbsp;$group&nbsp;)&nbsp;&amp;&amp;&nbsp;!&nbsp;empty&nbsp;(&nbsp;$group&nbsp;))&nbsp;{&nbsp;//判断$group是否为字符串，并进行解析
			$groupStr&nbsp;.=&nbsp;&#39;&nbsp;GROUP&nbsp;BY&nbsp;&#39;&nbsp;.&nbsp;$group;
		}
		return&nbsp;empty(&nbsp;$groupStr&nbsp;)&nbsp;?&nbsp;&#39;&#39;&nbsp;:&nbsp;$groupStr;
	}
	/**
	&nbsp;*&nbsp;@author&nbsp;XL
	&nbsp;*&nbsp;解析Having&nbsp;by子句,对分组结果进行二次筛选
	&nbsp;*&nbsp;@param&nbsp;string&nbsp;$having
	&nbsp;*&nbsp;@return&nbsp;string
	&nbsp;*/
	public&nbsp;function&nbsp;parseHaving($having){
		$havingStr=&#39;&#39;;
		if&nbsp;(is_string($having)&amp;&amp;!empty($having)){
			$havingStr.=&#39;&nbsp;HAVING&nbsp;&#39;.$having;
		}
		return&nbsp;$havingStr;
	}
	/**
	&nbsp;*&nbsp;@author&nbsp;XL
	&nbsp;*&nbsp;解析Order&nbsp;by子句
	&nbsp;*&nbsp;@param&nbsp;unknown&nbsp;$order
	&nbsp;*&nbsp;@return&nbsp;string
	&nbsp;*/
	public&nbsp;function&nbsp;parseOrder($order){
		$orderStr=&#39;&#39;;
		if&nbsp;(is_array($order)){
			$orderStr.=&#39;&nbsp;ORDER&nbsp;BY&nbsp;&#39;.join(&#39;,&#39;,&nbsp;$order).&#39;&#39;;
		}elseif&nbsp;(is_string($order)&amp;&amp;!empty($order)){
			$orderStr.=&#39;&nbsp;ORDER&nbsp;BY&nbsp;&#39;.$order.&#39;&#39;;
		}
		return&nbsp;$orderStr;
	}
	/**
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;@author&nbsp;XL
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*将sql语句进行预处理
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/
	public&nbsp;function&nbsp;execute($sql&nbsp;=&nbsp;NULL)&nbsp;{
		$link=$this-&gt;conn();
		if&nbsp;(!$link)&nbsp;{
			return&nbsp;false;
		}
		if&nbsp;(!empty&nbsp;($sql)){
		&nbsp;&nbsp;&nbsp;&nbsp;$queryStr&nbsp;=sqlsrv_prepare($link,$sql);
		&nbsp;&nbsp;&nbsp;&nbsp;$res&nbsp;=sqlsrv_execute&nbsp;(&nbsp;$queryStr&nbsp;);
		&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;$res;
		}
	}
	/**
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;@author&nbsp;XL
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*错误提示信息
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/
	public&nbsp;function&nbsp;err($msg)&nbsp;{
		if&nbsp;(!empty($msg)){
			echo&nbsp;&quot;&lt;script&gt;alert(&#39;&quot;.$msg.&quot;&#39;)&lt;/script&gt;&quot;;
		&nbsp;&nbsp;&nbsp;&nbsp;die&nbsp;();&nbsp;
		}
	}
}

$Host=&quot;.&quot;;
$Database=&quot;DB&quot;;
$UID=&quot;sa&quot;;
$PWD=&quot;123&quot;;
$ms=new&nbsp;MsSql($Host,$Database,$UID,$PWD);&nbsp;&nbsp;&nbsp;
$ms-&gt;conn();&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//连接SQL&nbsp;server</pre><p><br/></p>

