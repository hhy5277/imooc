package simple.hardware;

import java.util.Map;

public class HardWareVoForShow {
	private String name ;
	private String xh;
	private double price;
	@SuppressWarnings("unused")
	private String priceStr;
	private int qtt;
	@SuppressWarnings("unused")
	private String qttStr;
	private double heji;
	@SuppressWarnings("unused")
	private String hejiStr;
	private Map<String ,Double> hm;
	public HardWareVoForShow() {
		super();
		this.qtt = 0;
		this.qttStr = String.valueOf(qtt);
	}
	public HardWareVoForShow(String name,Map<String ,Double> hm
			) {
		this();
		this.name = name;
		this.hm =hm;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getXh() {
		return xh;
	}
	public String getPriceStr() {
		return priceStr =  String.valueOf(price);
	}
	
	public String getQttStr() {
		return qttStr = String.valueOf(qtt);
	}
	
	public String getHejiStr() {
		return hejiStr = String.valueOf(heji);
	}
	
	public void setPrice(double price) {
		this.priceStr = String.valueOf(price);
		this.price = price;
	}
	public void setHeji(double heji) {
		this.hejiStr = String.valueOf(heji);
		this.heji = heji;
	}
	public void setHm(Map<String, Double> hm) {
		this.hm = hm;
	}
	public void setXh(String xh) {
		this.price = hm.get(xh);
		this.priceStr = String.valueOf(price);
		this.xh = xh;
	}
	public void setPriceStr(String priceStr) {
		this.price  = Double.parseDouble(priceStr);
		this.priceStr = priceStr;
	}
	public void setQttStr(String qttStr) {
		this.qtt = Integer.parseInt(qttStr);
		this.heji = qtt*price;
		this.qttStr = qttStr;
	}
	public double getPrice() {
		return price;
	}
	
	public int getQtt() {
		return qtt;
	}
	public void setQtt(int qtt) {
		this.qttStr = String.valueOf(qtt);
		this.heji = qtt*price;
		this.qtt = qtt;
	}
	public double getHeji() {
		this.heji =(double)Math.round(qtt*price*100)/100;
		return heji;
	}
	
	public Map<String, Double> getHm() {
		return hm;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(heji);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((hm == null) ? 0 : hm.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + qtt;
		result = prime * result + ((xh == null) ? 0 : xh.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HardWareVoForShow other = (HardWareVoForShow) obj;
		if (Double.doubleToLongBits(heji) != Double
				.doubleToLongBits(other.heji))
			return false;
		if (hm == null) {
			if (other.hm != null)
				return false;
		} else if (!hm.equals(other.hm))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Double.doubleToLongBits(price) != Double
				.doubleToLongBits(other.price))
			return false;
		if (qtt != other.qtt)
			return false;
		if (xh == null) {
			if (other.xh != null)
				return false;
		} else if (!xh.equals(other.xh))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "HardWareVoForShow [name=" + name + ", xh=" + xh + ", price="
				+ price + ", qtt=" + qtt + ", heji=" + heji + "]";
	}
	
	
}
