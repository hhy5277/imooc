package simple.hardware;

import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.SystemColor;
import javax.swing.UIManager;
import javax.swing.SwingConstants;

public class HardWareDialog extends JDialog implements ActionListener ,ItemListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Container mp = getContentPane();
	 List<HardWareXh> hwxl;
	 DefaultListModel<String> model;
	 HardWareIO hio = new HardWareIO();
	 String mcn = new String();
	 JTextField name,xh,price;
	 JLabel mc,xhl,pril;
	 JButton jia,jian,bc,qx;
	 JPanel p1,p2,p3,p4;
	 JList<String> hc;
	   HardWareDialog() {
	   	getContentPane().setBackground(SystemColor.inactiveCaption);
		setTitle("硬件管理");
		getContentPane().setLayout(null);
		hwxl = new ArrayList<>();
		
		p1 = new JPanel();
		p1.setBackground(SystemColor.inactiveCaption);
		p1.setBounds(51, 13, 355, 50);
		mp.add(p1);
		p1.setLayout(null);
		
		mc = new JLabel("名称：");
		mc.setBounds(14, 0, 90, 47);
		mc.setFont(new Font("微软雅黑", Font.BOLD, 30));
		p1.add(mc);
		
		name = new JTextField();
		name.setHorizontalAlignment(SwingConstants.CENTER);
		name.setBackground(SystemColor.controlHighlight);
		name.setFont(new Font("微软雅黑", Font.PLAIN, 25));
		name.setBounds(118, 2, 156, 47);
		p1.add(name);
		name.setColumns(10);
		
		 p2 = new JPanel();
		 p2.setBackground(SystemColor.inactiveCaption);
		 p2.setBounds(51, 370, 355, 49);
		mp.add(p2);
		p2.setLayout(null);
		
		bc= new JButton("保存");
		bc.setBackground(UIManager.getColor("Tree.selectionBackground"));
		bc.setFont(new Font("楷体", Font.BOLD, 30));
		bc.setBounds(37, 0, 113, 49);
		bc.addActionListener(this);
		p2.add(bc);
		
		qx = new JButton("取消");
		qx.setBackground(UIManager.getColor("Tree.selectionBackground"));
		qx.setFont(new Font("楷体", Font.BOLD, 30));
		qx.setBounds(183, 0, 113, 49);
		qx.addActionListener(this);
		p2.add(qx);
		
		p3 = new JPanel();
		p3.setBackground(SystemColor.inactiveCaption);
		p3.setBounds(51, 76, 355, 281);
		mp.add(p3);
		p3.setLayout(null);
		
		xhl= new JLabel("型号");
		xhl.setBounds(41, 13, 72, 34);
		xhl.setFont(new Font("微软雅黑", Font.BOLD, 25));
		p3.add(xhl);
		
		pril = new JLabel("价格");
		pril.setBounds(157, 13, 72, 34);
		pril.setFont(new Font("微软雅黑", Font.BOLD, 25));
		p3.add(pril);
		
		xh = new JTextField();
		xh.setHorizontalAlignment(SwingConstants.CENTER);
		xh.setBackground(SystemColor.controlHighlight);
		xh.setBounds(24, 234, 119, 34);
		xh.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		p3.add(xh);
		xh.setColumns(10);
		
		price = new JTextField();
		price.setHorizontalAlignment(SwingConstants.CENTER);
		price.setBackground(SystemColor.controlHighlight);
		price.setBounds(171, 234, 112, 34);
		price.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		price.setColumns(10);
		p3.add(price);
		
		jian = new JButton("-");
		jian.setFont(new Font("宋体", Font.BOLD, 15));
		jian.setBounds(300, 60, 41, 27);
		p3.add(jian);
		jian.addActionListener(this);
		
		jia = new JButton("+");
		jia.setFont(new Font("宋体", Font.BOLD, 15));
		jia.setBounds(300, 241, 41, 27);
		p3.add(jia);
		jia.addActionListener(this);
		
		p4 = new JPanel();
		p4.setBackground(SystemColor.inactiveCaption);
		p4.setBounds(14, 48, 283, 186);
		p3.add(p4);
		
		
		
		model = new DefaultListModel<>();
		p4.setLayout(null);
		hc = new JList<>(model);
		hc.setBackground(UIManager.getColor("ScrollPane.background"));
		hc.setVisibleRowCount(10);
		hc.setFont(new Font("楷体", Font.PLAIN, 25));
	/*	Set<Entry<String, Double>> hs =  hwfs.get(0).getHm().entrySet();
		for (Entry<String, Double> entry : hs) {
			model.addElement(String.format("%-15s"+entry.getValue(),entry.getKey()));
		}*/
	
		JScrollPane listPane = new JScrollPane(hc);
		listPane.setBounds(12, 5, 258, 162);
		p4.add(listPane);
		
		setSize(460, 480);
		setResizable(false);
		setVisible(false);
		setLocation(500, 300);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	public JDialog change(HardWare hw){
		mcn = hw.getName();
		name.setText(mcn);
		for (HardWareXh hxh : hw.getHwx()) {
			model.addElement(String.format("%-8s"+" "+hxh.getPrice(),hxh.getXh()));
			hwxl.add(new HardWareXh(hxh.getXh(),hxh.getPrice()));
		}
		bc.setText("修改");
		return  this;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
			if (e.getSource() == jia ){
				try {
				if(Double.parseDouble(price.getText()) >0 && !xh.getText().isEmpty()){
				model.addElement(String.format("%-8s"+" "+price.getText(),xh.getText()));
				hwxl.add(new HardWareXh(xh.getText(),Double.parseDouble(price.getText())));
				xh.setText(null);
				price.setText(null);
				}
				else{JOptionPane.showMessageDialog(this, "输入错误！"); }
				} catch (NumberFormatException ne) {
					ne.printStackTrace();
					JOptionPane.showMessageDialog(this, "请输入合理的价格！！！");
				}
			}
			if(e.getSource() == jian && hc.getSelectedValue() != null){
				String[] s= hc.getSelectedValue().toString().split(" ");
				if(hc.getSelectedValue() != null){
					model.removeElement(hc.getSelectedValue());
					for (HardWareXh hh : hwxl) {
						if(hh.getXh().equals(s[0])){
							hwxl.remove(hh);
							break;
						}
					}
				}
			}
			if(e.getSource() == bc){
				if(bc.getText().equals("保存")){
				if(!name.getText().isEmpty() && !hwxl.isEmpty()){
					HardWare hw = new HardWare(name.getText(),hwxl);
					try {
						hio.writeOne(hw);
						name.setText(null);
						model.removeAllElements();
						xh.setText(null);
						price.setText(null);
						hwxl.clear();
						JOptionPane.showMessageDialog(this, "已成功保存");
						this.dispose();
					} catch (Exception e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(this, "添加失败");
						this.dispose();
					}
				}
			
				}else if(bc.getText().equals("修改")){
					if(!name.getText().isEmpty() && !hwxl.isEmpty()){
						HardWare hw = new HardWare(name.getText(),hwxl);
						try {
							hio.delete(mcn);
							hio.writeOne(hw);
							JOptionPane.showMessageDialog(this, "已成功修改");
							this.dispose();
						} catch (Exception e1) {
							e1.printStackTrace();
							JOptionPane.showMessageDialog(this, "修改失败");
							this.dispose();
						}
					}
				}
				
			}
			if(e.getSource() == qx){
				
				this.dispose();
			}
	}
	@Override
	public void itemStateChanged(ItemEvent e) {
			
	}
}
