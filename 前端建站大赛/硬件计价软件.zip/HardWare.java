package simple.hardware;

import java.io.Serializable;
import java.util.List;

public class HardWare implements Serializable {
	private static final long serialVersionUID = 1L;
	private String name ;
	private List<HardWareXh> hwx;
	public HardWare() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HardWare(String name, List<HardWareXh> hwx) {
		super();
		this.name = name;
		this.hwx = hwx;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hwx == null) ? 0 : hwx.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HardWare other = (HardWare) obj;
		if (hwx == null) {
			if (other.hwx != null)
				return false;
		} else if (!hwx.equals(other.hwx))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<HardWareXh> getHwx() {
		return hwx;
	}
	public void setHwx(List<HardWareXh> hwx) {
		this.hwx = hwx;
	}
	@Override
	public String toString() {
		return "HardWare [name=" + name + ", hwx=" + hwx + "]";
	}
	
}
