package simple.hardware;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.Color;


import java.awt.SystemColor;

import javax.swing.JToggleButton;

import java.awt.Cursor;
import java.awt.FlowLayout;

public class HardWareApp extends JFrame implements ItemListener,ActionListener,ListSelectionListener,WindowListener,MouseListener{
	private static final long serialVersionUID = 1L;
	Container myPane = getContentPane();
	JDialog jd ,jd2;
	 HardWareIO hio = new HardWareIO();
	  List<HardWareVoForShow> hwfs; 
	  HardWare hwer;
	 String [] s = {"����","�ͺ�","����","����","�ϼ�"};
	 String [] qtt = {"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
	 double sum;
	 JToggleButton append;
	 JLabel mc,xh,sl,dj,hj,hjj,names;
	 JPanel p1,p2,p3;
	 HardWareApp() throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
    	super("Ӳ���Ƽ�ϵͳ");
    	setBackground(Color.WHITE);
    	getContentPane().setBackground(Color.WHITE);
    	 UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
    	 Font font = new Font("΢���ź�", Font.PLAIN, 30);
     	UIManager.put("Label.font", font);
     	UIManager.put("Panel.font", font);
     	UIManager.put("List.font", font);
    	myLayout();
    	setDefaultCloseOperation(EXIT_ON_CLOSE);
    	setLocation(400, 400);
    	setResizable(false);
		setVisible(true);
		pack();
	}
	 public void init(){
		 
	 }
	 public void myLayout(){
		 hwfs =hio.queryAll();
		
		 mc = new JLabel("���� ");
		 mc.setFont(new Font("�����п�", Font.BOLD, 50));
		 xh = new JLabel("�ͺ� ");
		 xh.setFont(new Font("�����п�", Font.BOLD, 50));
		 sl = new JLabel("���� ");
		 sl.setFont(new Font("�����п�", Font.BOLD, 50));
		 dj = new JLabel("���� ");
		 dj.setFont(new Font("�����п�", Font.BOLD, 50));
		 hj = new JLabel("�ϼ� ");
		 hj.setFont(new Font("�����п�", Font.BOLD, 50));
		 append = new JToggleButton("����");
		 append.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		 append.setFont(new Font("����", Font.PLAIN, 25));
		 append.addActionListener(this);
		
		
			p1 = new JPanel();
			p3 = new JPanel();
			p3.setBackground(new Color(153, 204, 204));
			FlowLayout flowLayout = (FlowLayout) p3.getLayout();
			flowLayout.setHgap(100);
			flowLayout.setAlignment(FlowLayout.LEFT);
			p1.setBackground(SystemColor.textHighlight);
	    	myPane.setLayout(new BorderLayout());
	    	p1.setLayout(new GridLayout(1,5));
	    	p1.add(mc);
	    	p1.add(xh);
	    	p1.add(sl);
	    	p1.add(dj);
	    	p1.add(hj);
	    	p3.add(append);
	    	p2 =load();
	    	myPane.add(p1,BorderLayout.NORTH);
	    	myPane.add(p2,BorderLayout.CENTER);
	    	myPane.add(p3,BorderLayout.SOUTH);
	 }
    public JPanel load(){
    	
    	sum =0.00;
    	p2 = new JPanel();
    	p2.setBackground(SystemColor.activeCaption);
    	p2.setLayout(new GridLayout(hwfs.size(),5));
    	for (HardWareVoForShow hs : hwfs) {
    		String name = hs.getName();
    		names = new JLabel(name);
			names.setName(name);
			names.addMouseListener(this);
    		p2.add(names);
			if(hs.getXh()==null){
			hs.setXh(hio.queryXhName(name).get(0));}
			Choice c= new Choice();
			c.setBackground(SystemColor.menu);
			c.add(hs.getXh());
			for (String  s : hio.queryXhName(name)) {
				if(!hs.getXh().equals(s)){
				c.add(s);}
			}
			p2.add(c);
			c.addItemListener(this);
			JList<Object> q = new JList<Object>(qtt);
			q.setName(name);
			q.setVisibleRowCount(1);
			q.setBackground(SystemColor.menu);
			q.addListSelectionListener(this);
			JScrollPane listPane = new JScrollPane(q);
		    JScrollBar scrollBar = listPane.getVerticalScrollBar();    //�õ���ֱ����Ĺ�����
		    int x = 0;
		    if (hs.getQtt()>0&&hs.getQtt()<=31){
		    	x = 10+hs.getQtt()*42;}
		    scrollBar.setMaximum(x);
		    scrollBar.setValue(scrollBar.getMaximum());   
			p2.add(listPane);
			p2.add(new JLabel(hs.getPriceStr()));
			p2.add(new JLabel(hs.getHejiStr()));
			sum = sum+hs.getHeji();
		}
    	sum = (double)Math.round(sum*100)/100;
    	hjj = new JLabel("�ܼۣ�"+sum+" RMB");
    	p3.add(hjj);
    	return p2;
    }
    public void flush(){
    	myPane.remove(p2);
    	myPane.remove(p3);
    	p3.remove(hjj);
    	load();
    	myPane.repaint();
    	myPane.add(p2,BorderLayout.CENTER);
    	myPane.add(p3,BorderLayout.SOUTH);
    	myPane.setVisible(false);
    	myPane.setVisible(true);
    }
    @Override
    public void itemStateChanged(ItemEvent e) {
    	//system.out.println(e.getItem());
    	int i =0;
    	for (HardWareVoForShow hs : hwfs) {
    		if(hio.queryXhName(hs.getName()).contains(e.getItem())){
    			hs.setXh((String) e.getItem());
    			hs.setQtt(0);
    			//System.out.println(hs.getPrice());
    		}
    		hwfs.set(i, hs);
    		i++;
    	}
    	flush();
    	}
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		new HardWareApp();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == append){
			 jd = new HardWareDialog();
			 jd.addWindowListener(this);
			jd.setAlwaysOnTop(true);
				jd.setVisible(true);
		}		
	}
	@Override
	public void valueChanged(ListSelectionEvent e) {
		if (!e.getValueIsAdjusting()) {
			
	    	int i =0;
	    	for (HardWareVoForShow hs : hwfs) {
	    		if(e.toString().contains(hs.getName())){
	    			hs.setQtt(e.getLastIndex());
	    		hwfs.set(i, hs);
	    		i++;
	    	}else{
	    		i++;}
		}
	    	flush();
	}
	
	}
	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowClosed(WindowEvent e) {
		hwfs =hio.queryAll();
		flush();
		pack();
		if(jd != null){
		jd.removeAll();
		}
		if(jd2 != null){
		jd2.setName("x");
		}
	}
	@Override
	public void windowClosing(WindowEvent e) {
		
	}
	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		hwer = new HardWare();
		for (HardWareVoForShow hw : hwfs) {
			if(e.toString().contains(hw.getName()) && e.getModifiersEx() == 0){
				hwer = hio.queryOne(hw.getName());
				if(jd2 == null || jd2.getName() == "x"){
				jd2 = new HardWareDialog().change(hwer);
				 jd2.addWindowListener(this);
				}
				jd2.setVisible(true);
				jd2.setAlwaysOnTop(true);
				
				break;
			}else if(e.toString().contains(hw.getName()) && e.getModifiersEx() == 256){
				int i = JOptionPane.showConfirmDialog(this, "ȷ��Ҫɾ��"+hw.getName()+"��", "���棡����",JOptionPane.YES_NO_OPTION);
				if(i == JOptionPane.YES_OPTION ){
				try {
					hio.delete(hw.getName());
					hwfs =hio.queryAll();
					flush();
					pack();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
				}
			}
		}
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
