package simple.hardware;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HardWareIO {
	
	
	//读取全部；
	@SuppressWarnings("unchecked")
	public  Map<String, HardWare> read() {
		Map<String, HardWare> hw = new HashMap<>();
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(
					new FileInputStream("hardware.dat"));
		} catch (FileNotFoundException e) {
			
			try {
				writeAll(hw);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println("创建了新文件");
			return hw;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			hw = (Map<String, HardWare>) ois.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ois.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hw;
	}
	//写入更新全部；
	public  void writeAll(Map<String, HardWare> hws) throws Exception{
		
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("hardware.dat"));
		oos.writeObject(hws);
		oos.close();
	}
	//写入单个对象；
	public  void writeOne(HardWare hwo) throws Exception{
		Map<String, HardWare> hw = read();
		
		hw.put(hwo.getName(), hwo);
		writeAll(hw);
	}
	//根据硬件名找到该条；
	public HardWare queryOne(String s){
		Map<String, HardWare> hw = read();
		HardWare h = hw.get(s);
		return h;
	}
	//根据多个硬件名找到多个对象数组
	public List<HardWare> querySome(String...strings){
		List<HardWare> hw =new ArrayList<HardWare>();
		for (String s : strings) {
			hw.add(queryOne(s));
		}
		return hw;
	}
	//根据硬件名删除；
	public void delete(String s) throws Exception{
		Map<String, HardWare> hw = read();
		hw.remove(s);
		writeAll(hw);
	}
	//显示全部硬件名；
	public Set<String> queryName(){
		Map<String, HardWare> hw = read();
		Set<String> ls=  hw.keySet();
		return ls;
	}
	//通过硬件名得到型号数组；
	public Map<String,Double> queryXh(String s){
		Map<String,Double> hwm = new HashMap<>();
		HardWare h = queryOne(s);
		List<HardWareXh> ls = h.getHwx();
		for (HardWareXh hx : ls) {
			hwm.put(hx.getXh(), hx.getPrice());
		}
		return hwm;
	}
	public List<HardWareVoForShow> queryAll(){
		Map<String, HardWare> hw = read();
		List<HardWareVoForShow> hl = new ArrayList<>();
		HardWare h = new HardWare();
		Set<Entry<String, HardWare>> hs =  hw.entrySet();
		for (Entry<String, HardWare> entry : hs) {
			h = entry.getValue();
			HardWareVoForShow hwss = new HardWareVoForShow(h.getName(),queryXh(h.getName()));
			hl.add(hwss);
		}
		return hl;
	}
	public HardWareVoForShow queryForShow(String s){
		HardWare hw = queryOne(s);
		HardWareVoForShow hws = new HardWareVoForShow(hw.getName(),queryXh(hw.getName()));
		return hws;
	}
	public List<String> queryXhName(String s){
		HardWare hw = queryOne(s);
		List<String> ls = new ArrayList<>();
		for (HardWareXh hx : hw.getHwx()) {
			ls.add(hx.getXh());
		}
		return ls;
	}
}