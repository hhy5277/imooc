document.getElementById("show").src="../../IMG/photo-01/20150121.jpg";

function changeImg0(e)
    {
    document.getElementById("show").src="../../IMG/photo-01/20150121.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}

function changeImg7(e)
    {
    document.getElementById("show").src="../../IMG/photo-01/IMG_1192.jpg";
	document.getElementById("show").style.width = 50 + "%";
	document.getElementById("show").style.margin = 0 + " " + 25 + "%";
}