document.getElementById("show").src="../../IMG/photo-02/new-year.jpg";

function changeImg0(e)
    {
    document.getElementById("show").src=src="../../IMG/photo-02/new-year.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}

function changeImg1(e)
    {
    document.getElementById("show").src="../../IMG/photo-02/IMG_1250.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}

function changeImg2(e)
    {
    document.getElementById("show").src="../../IMG/photo-02/IMG_1239.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}