document.getElementById("show").src="../../IMG/photo-04/IMG_1642.jpg";

function changeImg0(e)
    {
    document.getElementById("show").src="../../IMG/photo-04/IMG_1642.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}

function changeImg1(e)
    {
    document.getElementById("show").src="../../IMG/photo-04/IMG_1641.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}

function changeImg2(e)
    {
    document.getElementById("show").src="../../IMG/photo-04/IMG_1639.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}

function changeImg3(e)
    {
    document.getElementById("show").src="../../IMG/photo-04/IMG_1638.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}

function changeImg4(e)
    {
    document.getElementById("show").src="../../IMG/photo-04/IMG_1626.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}

function changeImg5(e)
    {
    document.getElementById("show").src="../../IMG/photo-04/IMG_1622.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}

function changeImg6(e)
    {
    document.getElementById("show").src="../../IMG/photo-04/IMG_1621.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}

function changeImg7(e)
    {
    document.getElementById("show").src="../../IMG/photo-04/IMG_1618.jpg";
	document.getElementById("show").style.width = 50 + "%";
	document.getElementById("show").style.margin = 0 + " " + 25 + "%";
}

function changeImg8(e)
    {
    document.getElementById("show").src="../../IMG/photo-04/IMG_1614.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}