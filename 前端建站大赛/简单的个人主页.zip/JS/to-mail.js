function showDiv0(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 0+"px";
	o.style.width = 62+"px";
}

function showDiv1(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 62+"px";
	o.style.width = 62+"px";
}

function showDiv2(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 124+"px";
	o.style.width = 62+"px";
}

function showDiv3(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 186+"px";
	o.style.width = 62+"px";
}-

function showDiv4(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 248+"px";
	o.style.width = 78+"px";
}

function showDivReturn(e)
    {
    var a = document.getElementById("hidDiv");
    a.style.left = 248+"px";
	a.style.width = 78+"px";
}

function sendEmail() {
                var url = 'mailto:'+'yangjm2015@126.com'+'?subject=' +encodeURIComponent('给Stubborn的留言')+ '&body= ' + encodeURIComponent(document.getElementById('cont1').innerHTML) + ':'+ encodeURIComponent(document.getElementById('content1').value) ;
                window.open(url);
            };

            function checkstring(msg,lenth,elementId) {
                 document.getElementById(msg).innerHTML ='';
                   var string = document.getElementById(elementId).value.trim();
                   var reg=new RegExp('^.{1,'+lenth+'}$');
                   if (string == ''||!reg.test(string.value)) {
                          document.getElementById(msg).innerHTML = '<b>请输入1到'+lenth+'个字符！</b>';
                          return false;
                   }else if(string.indexOf(">")>-1||string.indexOf("<")>-1) {
                          document.getElementById(msg).innerHTML = '<b>字符中包含<>，请重新输入！</b>';
                          return false;
                   }
                return true;    
            };
			
document.getElementById("middle").style.height=document.getElementById("middle").scrollWidth/2.15+"px";

document.getElementById("content1").style.height=document.getElementById("middle").scrollHeight+"px";