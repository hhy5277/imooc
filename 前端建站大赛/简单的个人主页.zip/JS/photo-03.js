document.getElementById("show3").src="../../IMG/photo-03/IMG_3622.jpg";

function changeImg30(e)
    {
    document.getElementById("show").src="../../IMG/photo-03/IMG_3622.jpg";
	document.getElementById("show").style.width = 100 + "%";
	document.getElementById("show").style.margin = 0;
}