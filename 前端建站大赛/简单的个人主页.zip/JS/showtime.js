function showDiv0(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 0+"px";
	o.style.width = 62+"px";
}

function showDiv1(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 62+"px";
	o.style.width = 62+"px";
}

function showDiv2(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 124+"px";
	o.style.width = 62+"px";
}

function showDiv3(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 186+"px";
	o.style.width = 62+"px";
}

function showDiv4(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 248+"px";
	o.style.width = 78+"px";
}

function showDivReturn(e)
    {
    var a = document.getElementById("hidDiv");
    a.style.left = 186+"px";
	a.style.width = 62+"px";
}