function showDiv0(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 0+"px";
	o.style.width = 62+"px";
}

function showDiv1(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 62+"px";
	o.style.width = 62+"px";
}

function showDiv2(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 124+"px";
	o.style.width = 62+"px";
}

function showDiv3(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 186+"px";
	o.style.width = 62+"px";
}

function showDiv4(e)
    {
    var o = document.getElementById("hidDiv");
    o.style.left = 248+"px";
	o.style.width = 78+"px";
}

function showDivReturn(e)
    {
    var a = document.getElementById("hidDiv");
    a.style.left = 62+"px";
	a.style.width = 62+"px";
}

function showImg00(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-04/IMG_1642.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg01(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-04/IMG_1641.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg10(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-04/IMG_1639.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg11(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-04/IMG_1638.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg12(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-04/IMG_1626.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg20(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-04/IMG_1622.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg21(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-04/IMG_1621.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg30(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-04/IMG_1618.jpg";
	document.getElementById("fullshow").style.width = 50 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg31(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-04/IMG_1614.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg32(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-03/IMG_3622.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg40(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-02/new-year.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg41(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-02/IMG_1250.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg50(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-02/IMG_1239.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg51(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-01/IMG_1192.jpg";
	document.getElementById("fullshow").style.width = 50 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function showImg52(e)
    {
    document.getElementById("fullshow").src="../../IMG/photo-01/20150121.jpg";
	document.getElementById("fullshow").style.width = 100 + "%";
	document.getElementById("putout").style.display = "block";
	document.getElementById("outinside").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
	document.getElementById("outshut").style.marginTop=(document.getElementById("putout").offsetHeight-document.getElementById("outinside").offsetHeight)/2+"px";
}

function disshowImg(e)
    {
	document.getElementById("putout").style.display = "none";
}

window.onload = function(){
	document.getElementById("right").style.height=document.getElementById("left").offsetHeight+"px";
};