var text=document.getElementById("text1");
var counter=0;                      //判断是否为第一次运算。
var result=0;                       //累加器
var container=0;                    //接收数据。
var fuhao=0;                        //判断运算符
function zero(){
	var text=document.getElementById("text1");
	if(container>=1||container<=-1){
	text.value+="0";
	container+="0";
	}
	document.getElementById("+").disabled=false;
	document.getElementById("-").disabled=false;
	document.getElementById("/").disabled=false;
	document.getElementById("*").disabled=false;
	document.getElementById("mod").disabled=false;
	document.getElementById("^").disabled=false;
}
function un(){
	var text=document.getElementById("text1");
	text.value+="1";
	container+="1";
	document.getElementById("+").disabled=false;
	document.getElementById("-").disabled=false;
	document.getElementById("/").disabled=false;
	document.getElementById("*").disabled=false;
	document.getElementById("mod").disabled=false;
	document.getElementById("^").disabled=false;
}
function deux(){
	var text=document.getElementById("text1");
	text.value+="2";
	container+="2";
	document.getElementById("+").disabled=false;
	document.getElementById("-").disabled=false;
	document.getElementById("/").disabled=false;
	document.getElementById("*").disabled=false;
	document.getElementById("mod").disabled=false;
	document.getElementById("^").disabled=false;
}
function trois(){	
var text=document.getElementById("text1");
	text.value+="3";
	container+="3";
	document.getElementById("+").disabled=false;
	document.getElementById("-").disabled=false;
	document.getElementById("/").disabled=false;
	document.getElementById("*").disabled=false;
	document.getElementById("mod").disabled=false;
	document.getElementById("^").disabled=false;
}
function quatre(){	
var text=document.getElementById("text1");
	text.value+="4";
	container+="4";
	document.getElementById("+").disabled=false;
	document.getElementById("-").disabled=false;
	document.getElementById("/").disabled=false;
	document.getElementById("*").disabled=false;
	document.getElementById("mod").disabled=false;
	document.getElementById("^").disabled=false;
	}
function cinq(){	
var text=document.getElementById("text1");
	text.value+="5";
	container+="5";
	document.getElementById("+").disabled=false;
	document.getElementById("-").disabled=false;
	document.getElementById("/").disabled=false;
	document.getElementById("*").disabled=false;
	document.getElementById("mod").disabled=false;
	document.getElementById("^").disabled=false;
	}
function six(){	
var text=document.getElementById("text1");
	text.value+="6";
	container+="6";
	document.getElementById("+").disabled=false;
	document.getElementById("-").disabled=false;
	document.getElementById("/").disabled=false;
	document.getElementById("*").disabled=false;
	document.getElementById("mod").disabled=false;
	document.getElementById("^").disabled=false;
	}
function sept(){	
var text=document.getElementById("text1");
	text.value+="7";
	container+="7";
	document.getElementById("+").disabled=false;
	document.getElementById("-").disabled=false;
	document.getElementById("/").disabled=false;
	document.getElementById("*").disabled=false;
	document.getElementById("mod").disabled=false;
	document.getElementById("^").disabled=false;
	}
function huit(){	
var text=document.getElementById("text1");
	text.value+="8";
	container+="8";
	document.getElementById("+").disabled=false;
	document.getElementById("-").disabled=false;
	document.getElementById("/").disabled=false;
	document.getElementById("*").disabled=false;
	document.getElementById("mod").disabled=false;
	document.getElementById("^").disabled=false;
	}
function neuf(){	
var text=document.getElementById("text1");
	text.value+="9";
	container+="9";
	document.getElementById("+").disabled=false;
	document.getElementById("-").disabled=false;
	document.getElementById("/").disabled=false;
	document.getElementById("*").disabled=false;
	document.getElementById("mod").disabled=false;
	document.getElementById("^").disabled=false;
	}
function point(){
	var counter;
	var text=document.getElementById("text1");
	if((text.value<1&&text.value>=0)||(text.value>-1&&text.value<0)){
	text.value+="0.";
    }
	else{
	text.value+=".";
	}
	if(container<-1||container>1){
	container+=".";
	}
	else{
	container+="0.";
	}
	counter=1;
	if(counter!=0)
	document.getElementById(".").disabled="disabled";
}
function CE(){
document.getElementById("text1").value="";
document.getElementById(".").disabled=false;
document.getElementById("minus2").disabled=false;
document.getElementById("0").disabled=false;
document.getElementById("1").disabled=false;
document.getElementById("2").disabled=false;
document.getElementById("3").disabled=false;
document.getElementById("4").disabled=false;
document.getElementById("5").disabled=false;
document.getElementById("6").disabled=false;
document.getElementById("7").disabled=false;
document.getElementById("8").disabled=false;
document.getElementById("9").disabled=false;
document.getElementById("-").disabled=false;
document.getElementById("+").disabled=false;
document.getElementById("=").disabled=false;
document.getElementById(".").disabled=false;
document.getElementById("*").disabled=false;
document.getElementById("/").disabled=false;
document.getElementById("^").disabled=false;
document.getElementById("mod").disabled=false;
counter=0;
result=0;
container=0;
fuhao=0;
}
function plus(){
	if(counter==0){
	result+=parseFloat(container);
	counter=1;
	}
	else if(counter==1){
	switch(fuhao){                                     //判断前一个运算符
	    case 1:result+=parseFloat(container);break;
		case 2:result-=parseFloat(container);break;
		case 3:result/=parseFloat(container);break;
		case 4:result*=parseFloat(container);break;
		case 5:result%=parseFloat(container);break;
		case 6:result=Math.pow(result,container);break;
		case 7:result=Math.round(result);break;
	}
	
	}
	fuhao=1;
	container=0;
	if(document.getElementById("text1").value!="")
	document.getElementById("text1").value+='+';
	document.getElementById("+").disabled=true;
	document.getElementById(".").disabled=false;
}
function minus(){
	if(counter==0){
	result+=parseFloat(container);
	counter=1;
	}
	else if(counter==1){
	switch(fuhao){
	    case 1:result+=parseFloat(container);break;
		case 2:result-=parseFloat(container);break;
		case 3:result/=parseFloat(container);break;
		case 4:result*=parseFloat(container);break; 
		case 5:result%=parseFloat(container);break;
		case 6:result=Math.pow(result,container);break;
		case 7:result=Math.round(result);break;
	}
	
	}
	fuhao=2;
	container=0;
	if(document.getElementById("text1").value!="")
	document.getElementById("text1").value+='-';
	document.getElementById("-").disabled=true;
	document.getElementById(".").disabled=false;
}
function minus2(){
	var text=document.getElementById("text1");
	text.value*=-1;
	container*=-1;
	result*=-1;     //question1 
}
function divide(){
	if(counter==0){
	result+=parseFloat(container);
	counter=1;
	}
	else if(counter==1){
	switch(fuhao){
	    case 1:result+=parseFloat(container);break;
		case 2:result-=parseFloat(container);break;
		case 3:result/=parseFloat(container);break;
		case 4:result*=parseFloat(container);break;
		case 5:result%=parseFloat(container);break;
		case 6:result=Math.pow(result,container);break;
		case 7:result=Math.round(result);break;
	}
	
	}
	fuhao=3;
	container=0;
	if(document.getElementById("text1").value!="")
	document.getElementById("text1").value+='/';
	document.getElementById("/").disabled=true;
	document.getElementById(".").disabled=false;
}
function multiply(){
	if(counter==0){
	result+=parseFloat(container);
	counter=1;
	}
	else if(counter==1){
	switch(fuhao){
	    case 1:result+=parseFloat(container);break;
		case 2:result-=parseFloat(container);break;
		case 3:result/=parseFloat(container);break;
		case 4:result*=parseFloat(container);break;
		case 5:result%=parseFloat(container);break;
		case 6:result=Math.pow(result,container);break;
		case 7:result=Math.round(result);break;
	}
	}
	fuhao=4;
	container=0;
	if(document.getElementById("text1").value!="")
	document.getElementById("text1").value+='*';
	document.getElementById("*").disabled=true;
	document.getElementById(".").disabled=false;
}
function mod(){
	if(counter==0){
	result+=parseFloat(container);
	counter=1;
	}
	else if(counter==1){
	switch(fuhao){
	    case 1:result+=parseFloat(container);break;
		case 2:result-=parseFloat(container);break;
		case 3:result/=parseFloat(container);break;
		case 4:result*=parseFloat(container);break;
		case 5:result%=parseFloat(container);break;
		case 6:result=Math.pow(result,container);break;
		case 7:result=Math.round(result);break;
	}
	}
	fuhao=5;
	container=0;
    if(document.getElementById("text1").value!="")
	document.getElementById("text1").value+="mod";
	document.getElementById("mod").disabled=true;
	document.getElementById(".").disabled=false;
}
function chengfang(){
	if(counter==0){
	result+=parseFloat(container);
	counter=1;
	}
	else if(counter==1){	
	switch(fuhao){
	    case 1:result+=parseFloat(container);break;
		case 2:result-=parseFloat(container);break;
		case 3:result/=parseFloat(container);break;
		case 4:result*=parseFloat(container);break;
		case 5:result%=parseFloat(container);break;
		case 6:result=Math.pow(result,container);break;
		case 7:result=Math.round(result);break;
	}
	counter=1;
	}
	fuhao=6;	
	container=0;
	if(document.getElementById("text1").value!="")
	document.getElementById("text1").value+="^";
	document.getElementById("^").disabled=true;
	document.getElementById(".").disabled=false;
}
function around(){
	var text=document.getElementById("text1");
	switch(fuhao){
	    case 1:result+=parseFloat(container);break;
		case 2:result-=parseFloat(container);break;
		case 3:result/=parseFloat(container);break;
		case 4:result*=parseFloat(container);break;
		case 5:result%=parseFloat(container);break;
		case 6:result=Math.pow(result,container);break;
		case 7:result=Math.round(result);break;
	}
	fuhao=7;	
	container=0;
	text.value=Math.round(result);
	result=Math.round(result);
}
function equal(){
	var text=document.getElementById("text1");
	switch(fuhao){                       
	    case 1:result+=parseFloat(container);text.value=parseFloat(result);container=0;counter=0;break;
		case 2:result-=parseFloat(container);text.value=parseFloat(result);container=0;counter=0;break;
		case 3:result/=parseFloat(container);text.value=parseFloat(result);container=0;counter=0;break;
		case 4:result*=parseFloat(container);text.value=parseFloat(result);container=0;counter=0;break;
		case 5:result%=parseFloat(container);text.value=parseFloat(result);container=0;counter=0;break;
		case 6:result=Math.pow(result,container);text.value=parseFloat(result);container=0;counter=0;break;
	}
	fuhao=0;
	document.getElementById("+").disabled=false;
}
function  input(){
	document.getElementById("text1").value=prompt("您想说些啥?(Qu'est-ce que vous venez dire?/What are you willing to say?)");
}
function tips(){
	document.getElementById("tips").style.visibility="visible";
}
function shutdown(){
	document.getElementById("tips").style.visibility="hidden";
}