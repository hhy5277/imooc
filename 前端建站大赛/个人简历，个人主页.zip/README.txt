<p>这是一个完整的个人简历，还有一些细节需要优化。</p><ol class=" list-paddingleft-2" style="list-style-type: decimal;"><li><p>html&nbsp;&nbsp; , 1.css&nbsp;&nbsp; , 1.js&nbsp;&nbsp; ,1.png&nbsp; 这四个文件必须放到一个文件夹才能正常运行；</p></li></ol><p>这是基于CSS3 响应式纵向滚屏翻页的改良，欢迎一起学习交流。<br/></p>

