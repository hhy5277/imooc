<?php
	require_once('connect.php');
	$key=trim($_GET['key']);
	$sql="select * from article where title like '%$key%' order by dateline desc";
	$query=mysql_query($sql);
	if($query&&mysql_num_rows($query))
	{
		while($row=mysql_fetch_assoc($query))
		{	
			$data[]=$row;
		}
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="default.css" rel="stylesheet" type="text/css" />
</head>

<body>
	<div class="head">
		<h1>耽美文</h1>
		<a href="contact.php" class="lead">联系我们</a>
        <a href="about.php" class="lead">关于我们</a>
		<a href="article.list.php" class="lead">文章</a>
	</div>
    <div class="mainbody">
		<?php
			if(empty($data))
			{
				echo "当前没有文章，请管理员在后台添加";
			}
			else
			{
				foreach($data as $value)
				{
		?>
    	<span style="color:#30F;font-size:30px"><?php echo $value['title']?></span>
        <span style="color:#999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;作者：<?php echo $value['author']?></span>
        <div class="line1"></div>
        <p><?php echo $value['description']?></p><br />
        <a href="article.show.php?id=<?php echo $value['id']?>">查看详细&nbsp;&gt;&gt;</a>
        <div class="line2"></div>
		<?php
				}
			}
		?>
    </div>
	<div class="searchbar">
		<span style="font-size:25px;color:#30F;">search</span>
        <div class="line1"></div>
        <form method="get" action="article.search.php">
        <input type="text" name="key" id="id" value="" style="width:200px;height:20px;"/>
        <input type="submit" name="submit" id="submit" value="提交" style="width:50px;height:30px;"/>
        </form>
    </div>
</body>
</html>
