<?php
	//把传递过来的信息入库,入库之前信息校验
	require_once('../connect.php');
	if(!(isset($_POST['title'])&&(!empty($_POST['title']))))
	{
		echo "<script>alert('标题不能为空');window.location.href='article.add.php'</script>";
		return;
	}
	$title=$_POST['title'];
	$author=$_POST['author'];
	$description=$_POST['description'];
	$content=$_POST['cont'];
	$dateline=time();
	$insertsql="insert into article(title,author,description,content,dateline)values('$title','$author','$description','$content',$dateline)";
	if(mysql_query($insertsql))
	{
		echo "<script>alert('发布文章成功');window.location.href='article.add.php'</script>";
	}
	else
	{
		echo "<script>alert('发布文章失败');window.location.href='article.add.php'</script>";
	}
	
?>