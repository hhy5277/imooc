<?php
	require_once('../connect.php');
	$sql="select * from article order by dateline desc";
	$query=mysql_query($sql);
	if($query&&mysql_num_rows($query))
	{
		while($row=mysql_fetch_assoc($query))
		{
			$data[]=$row;
		}
	}
	else
	{
		$data=array();
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="../default.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="top">
	<div style="width:300px;margin:0 auto;"><h1>后台管理系统</h1></div>
</div>
<div class="mainBody">
	<div class="manageBar">
    	<a href="article.add.php">发布文章</a><br /><br />
    	<a href="article.manage.php">管理文章</a>
    </div>
    <div class="addArticle">
    	<form id="form1" method="post" action="article.modify.handle.php">
			<table class="content" border="1px solid blue" style="width:1000px;">
				<tr>
					<td colspan="3" align="center"><h2>文章管理列表</h2></td>
				</tr>
				<tr>
					<td><h3>编号</h3></td>
					<td><h3>标题</h3></td>
					<td><h3>操作</h3></td>
				</tr>
				<?php
					if(!empty($data))
					{
						foreach($data as $value)
						{
				?>
				<tr>
					<td><?php echo $value['id']?></td>
					<td><?php echo $value['title']?></td>
					<td>
						<a href="article.del.handle.php?id=<?php echo $value['id']?>">删除</a>
						<a href="article.modify.php?id=<?php echo $value['id']?>">修改</a>
					</td>
				</tr>
				<?php
						}
					}
				?>
				
			</table
        </form>
    </div>
</div>
</body>
</html>