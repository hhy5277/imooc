<?php
	require_once('../connect.php');
	//读取旧信息
	$id=$_GET['id'];
	$query=mysql_query("SELECT * FROM article WHERE id=$id ");
	$data=mysql_fetch_assoc($query);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="../default.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="top">
	<div style="width:300px;margin:0 auto;"><h1>后台管理系统</h1></div>
</div>
<div class="mainBody">
	<div class="manageBar">
    	<a href="article.add.php">发布文章</a><br /><br />
    	<a href="article.manage.php">管理文章</a>
    </div>
    <div class="addArticle">
    	<form id="form1" method="post" action="article.modify.handle.php">
        <div class="content">
        	<h2>修改文章</h2><br /><br />
			<input type="hidden" name="id" value="<?php echo $data['id']?>">
            <strong>标题：</strong><input type="text" value="<?php echo $data['title']?>" name="title" id="title" /><br /><br />
            <strong>作者：</strong><input type="text" value="<?php echo $data['author']?>" name="author" id="author" /><br /><br />
            <strong>简介：</strong><textarea cols="100" rows="5" name="description" id="decription"><?php echo $data['description']?></textarea><br /><br />
			<strong>内容：</strong><textarea cols="100" rows="20" name="cont" id="cont"><?php echo $data['content']?></textarea><br /><br />
            <input id="submit" type="submit" value="保存" style="width:50px;height:25px" />
        </div>
        </form>
    </div>
</div>
</body>
</html>
