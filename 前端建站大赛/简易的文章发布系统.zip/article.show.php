<?php
	require_once('connect.php');
	$id=intval($_GET['id']);
	$sql="select * from article where id=$id";
	$query=mysql_query($sql);
	if($query&&mysql_num_rows($query))
	{
		$row=mysql_fetch_assoc($query);
	}
	else
	{
		echo "这篇文章不存在";
		exit;
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="default.css" rel="stylesheet" type="text/css" />
</head>

<body>
	<div class="head">
		<h1>耽美文</h1>
		<a href="contact.php" class="lead">联系我们</a>
        <a href="about.php" class="lead">关于我们</a>
		<a href="article.list.php" class="lead">文章</a>
	</div>
    <div class="mainbody" style="width:100%;">
    	<span style="color:#30F;font-size:30px"><?php echo $row['title']?></span>
        <span style="color:#999;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;作者：<?php echo $row['author']?></span>
        <div class="line1"></div>
        <div><?php echo nl2br(nl2br($row['content']))?></div>
    </div>
</body>
</html>