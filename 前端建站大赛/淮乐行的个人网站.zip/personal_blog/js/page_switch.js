(function($){
	$.fn.page_switch = function(){

	}
	$.fn.page_switch.defult = {
		selectors :{
			sections : ".sections",
			section : ".section",
			page : ".pages",
			active : ".active"
		},
		index : 0,
		easing : "ease",
		duration : 500,
        loop : flase,
        
	}
})(jQuery);