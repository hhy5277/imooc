<<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
       <?php
            echo '<a href="index.html">首页</a> -
                  <a href="test2.html">test2</a> -
                  <a href="test3.php">test3</a> -
                  <a href="safetest.html">safetest</a> ';
       ?>
</body>
</html>>
