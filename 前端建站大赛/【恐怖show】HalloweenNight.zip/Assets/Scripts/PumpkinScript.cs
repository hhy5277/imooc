锘縰sing UnityEngine;
using System.Collections;

public class PumpkinScript : MonoBehaviour
{

    public float moveRate = 0.1f;
    public float maxMove = 3f;

    public float duration = 2f;

    private float elapse;
    private float moveDis;
    private bool playSound;

    private Vector3 position;
    private SpriteRenderer sr;
    private AudioSource audioSource;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        audioSource = GetComponent<AudioSource>();
        position = transform.position;
        
        moveDis = 0;
        elapse = 0;
        playSound = false;

        SetAlpha(0);
    }

    void Update()
    {

        //Set Alpha and Play sound
        if (elapse < duration)
        {
            elapse += Time.deltaTime;
            SetAlpha(elapse / duration);
        }
        else
        {
            if (!playSound)
            {
                audioSource.Play();
                playSound = true;
            }

            //Shake
            moveDis += moveRate;
            if (moveDis > maxMove || moveDis < -maxMove)
            {
                moveRate = -moveRate;
            }
            transform.position = position + new Vector3(0, moveDis, 0);
        }
    }

    public void SetAlpha(float a)
    {
        Color c = sr.color;
        c.a = a;
        sr.color = c;
    }

}
