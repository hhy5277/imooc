锘縰sing UnityEngine;
using System.Collections;

public class CastleScript : MonoBehaviour
{
    public float rate = 64;

    private float colorChange;

    private SpriteRenderer sr;
    public GameObject batParticle;

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        colorChange = 0;
        batParticle.SetActive(false);
    }

    void Update()
    {
        colorChange += (rate * Time.deltaTime);
        if (colorChange < 256)
        {
            SetColor(colorChange / 255);
        }
        else
        {
            batParticle.SetActive(true);
        }
    }

    public void SetColor(float rgb)
    {
        Color color = sr.color;
        color.r = rgb;
        color.g = rgb;
        color.b = rgb;
        color.a = rgb;
        sr.color = color;
    }

}
