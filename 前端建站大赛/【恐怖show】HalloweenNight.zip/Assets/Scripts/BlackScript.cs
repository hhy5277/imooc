锘縰sing UnityEngine;
using System.Collections;

public class BlackScript : MonoBehaviour
{

    public float duration = 2f;

    private float elapse;
    private SpriteRenderer sr;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        elapse = 0;
        SetAlpha(0);
    }

    void Update()
    {
        if (elapse < duration)
        {
            elapse += Time.deltaTime;
            SetAlpha(elapse / duration);
        }
        else
        {
            Application.Quit();
        }
    }

    public void SetAlpha(float a)
    {
        Color c = sr.color;
        c.a = a;
        sr.color = c;
    }
}
