锘縰sing UnityEngine;
using System.Collections;

public class CandySpawnScript : MonoBehaviour
{
    public float leftLimit = -8f;
    public float rightLimit = 8f;
    public float rate = 0.5f;

    public GameObject[] candy = new GameObject[3];

    private float createRate = 0;

    void Update()
    {
        createRate += Time.deltaTime;
        if(createRate>rate)
        {
            Vector3 pos = this.transform.position;
            pos.x += Random.Range(leftLimit, rightLimit);
            Instantiate(candy[Random.Range(0, candy.Length)], pos, transform.rotation);
            createRate = 0;
        }
    }
}