锘縰sing UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour
{

    public GameObject mudi;
    public GameObject witch;
    public GameObject castle;
    public GameObject pumpkin;
    public GameObject candySpawn;
    public GameObject word;

    public GameObject black;

    public float[] timeArray = new float[] { 2, 4, 8, 12, 16, 20 };
    private int index;

    private bool canEsc;

    void Awake()
    {
        index = 0;
        canEsc = true;
        //mudi.SetActive(false);
        //witch.SetActive(false);
        castle.SetActive(false);
        pumpkin.SetActive(false);
        candySpawn.SetActive(false);
        word.SetActive(false);
    }

    void Update()
    {
        if(index<timeArray.Length&&Time.realtimeSinceStartup>=timeArray[index])
        {
            SetEvent(index);
            index++;
        }

        if(canEsc&&Input.GetKeyDown(KeyCode.Escape))
        {
            canEsc = false;
            GameOver();
        }
    }

    private void SetEvent(int index)
    {
        switch(index)
        {
            case 0:
                //mudi.SetActive(true);
                Instantiate(mudi, new Vector3(0, 0, -1), transform.rotation);
                break;
            case 1:
                //witch.SetActive(true);
                Instantiate(witch, transform.position, transform.rotation);
                break;
            case 2:
                castle.SetActive(true);
                break;
            case 3:
                pumpkin.SetActive(true);
                break;
            case 4:
                candySpawn.SetActive(true);
                break;
            case 5:
                word.SetActive(true);
                break;
            default:
                break;
        }
        return;
    }

    private void GameOver()
    {
        Instantiate(black, new Vector3(0, 0, -5), transform.rotation);
    }
 
}
