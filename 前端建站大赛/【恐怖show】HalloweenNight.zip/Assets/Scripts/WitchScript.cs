锘縰sing UnityEngine;
using System.Collections;

public class WitchScript : MonoBehaviour
{

    public float deleteTime = 6.0f;

    private float delete;

    void Start()
    {
        delete = 0;
    }

    void Update()
    {
        delete += Time.deltaTime;
        if(delete>deleteTime)
        {
            Destroy(this.gameObject);
        }
    }
}
