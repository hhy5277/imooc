锘縰sing UnityEngine;
using System.Collections;

public class CandyRotateScript : MonoBehaviour
{
    public float maxRoteRate = 60;
    public float minRoteRate = 30;

    private float rotateRate;

    void Start()
    {
        rotateRate = Random.Range(minRoteRate, maxRoteRate);
        rotateRate *= (Random.Range(0, 1f) >= 0.5 ? 1 : -1);
    }

    void Update()
    {
        transform.Rotate(new Vector3(0, 0, rotateRate*Time.deltaTime));
    }
}
