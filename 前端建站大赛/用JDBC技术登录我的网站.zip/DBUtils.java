package com.sxt.JDBC;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class DBUtils {
    static Properties pro= new Properties();
	static String driver;
	static String url;
	static String user;
	static String password;
	static {
//		String file=inputFileName("请输入数据库配置文件名称(如：dbconfig.properties)>>>>>>");
		InputStream is=ClassLoader.getSystemResourceAsStream("dbconfig.properties");
		try {
			pro.load(is);
			driver=pro.getProperty("driver");
			url=pro.getProperty("url");
			user=pro.getProperty("user");
			password=pro.getProperty("password");
			//加载驱动
			Class.forName(driver);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("加载驱动失败！");
		}
	}
	//获得连接方法
	public static Connection getConnectionOfDB(){
		Connection con=null;
		try {
			con=DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			System.out.println("获得连接失败！");
		}
		return con;
	}
	//创建静态会话方法
	public static Statement getStatementOfDB(Connection con){
		Statement stmt=null;
		try {
			stmt=con.createStatement();
		} catch (SQLException e) {
			System.out.println("创建会话失败！");
		}
		return stmt;
	}
	//创建动态会话方法
	public static PreparedStatement getPreparedStatement(String sql,Connection con){
		PreparedStatement pstmt=null;
		try {
			pstmt=con.prepareStatement(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pstmt;
	}
	// 发送SQL语句，获得结果集
	public static ResultSet getResultSetOfDB(String sql,Statement stmt){
		ResultSet rs=null;
		try {
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			System.out.println("获得结果集失败！");
		}
		return rs;
	}
	// 创建获得动态SQL结果集方法
	public static ResultSet getResultSetOfDB(PreparedStatement pstmt){
		ResultSet rs=null;
		try {
			rs=pstmt.executeQuery();
		} catch (SQLException e) {
			System.out.println("获得结果集失败！");
		}
		return rs;
		
	}
	//关闭资源
	public static void closeAll(ResultSet rs,Statement stmt,Connection con){
		if(rs!=null){
			try {
				rs.close();
			} catch (SQLException e) {
				System.out.println("关闭结果集失败！");
			}
		}
		if(stmt!=null){
			try {
				stmt.close();
			} catch (SQLException e) {
				System.out.println("关闭会话失败！");
			}
		}
		if(con!=null){
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("关闭连接失败！");
			}
		}
	}
	//提示用户输入信息方法
	public static String inputFileName(String info){
		System.out.print(info);
		Scanner sc=new Scanner(System.in);
		return sc.nextLine();
	}
	
}


  

