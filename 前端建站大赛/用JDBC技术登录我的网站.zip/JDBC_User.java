package com.sxt.JDBC.test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.sxt.JDBC.DBUtils;

public class JDBC_User {
	// 获得连接
	static Connection con = DBUtils.getConnectionOfDB();

	public static void main(String[] args) {
		System.out.println("***************************");
		System.out.println("欢迎登陆www.doubledumbao.xyz");
		System.out.println("***************************" + "\n" + "\n");
		while (true) {
			System.out.println("********************************");
			String choice = DBUtils
					.inputFileName("请选择您需要的操作(【0-3】)：" + "\n0.退出" + "\n1.注册" + "\n2.登陆" + "\n3.找回密码" + "\n您的选择是：");
			System.out.println("********************************");
			int ch = Integer.parseInt(choice);
			if (ch == 0) {
				exitSys();
			} else if (ch == 1) {
				regest();
			} else if (ch == 2) {
				login();
			} else if (ch == 3) {
				String password = getPassword();
				if (password != null) {
					System.out.println("您的密码是：" + password);
				}
			} else {
				System.out.println("您的输入有误，请重新输入！");
			}
		}
	}

	// 退出方法
	public static void exitSys() {
		System.out.println("欢迎再次光临本网站！再见！");
		System.exit(0);
	}

	// 登陆方法
	public static void login() {
		String sql = "select id from tb_users where name=? and password=?";
		PreparedStatement pstmt = DBUtils.getPreparedStatement(sql, con);
		System.out.println("您现在使用的是本网站登陆功能！");
		String name = DBUtils.inputFileName("请输入用户名：");
		String password = DBUtils.inputFileName("请输入密码：");
		try {
			pstmt.setString(1, name);
			pstmt.setString(2, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ResultSet rs = DBUtils.getResultSetOfDB(pstmt);
		try {
			if (rs.next()) {
				int id = rs.getInt(1);
				System.out.println("\n" + "***************************************************");
				System.out.println("欢迎登陆我的网站,祝您玩得愉快！您的ID是：" + id);
				while (true) {
					System.out.println("**************************************************");
					String choice = DBUtils.inputFileName("请选择您需要的服务：" + "\n0.退出系统" + "\n1.修改用户信息" + "\n2.浏览网页资源"
							+ "\n3.上传文件" + "\n4.查询我上传的文件" + "\n5.删除我的文件" + "\n您的选择是：");
					System.out.println("**************************************************");
					int ch = Integer.parseInt(choice);
					if (ch == 0) {
						exitSys();
					} else if (ch == 1) {
						System.out.println("您当前所在位置为修改用户信息服务中");
						updateUser(id);
					} else if (ch == 2) {
						showPages();
					} else if (ch == 3) {
						uploadFile(id);
					} else if (ch == 4) {
						printFile(id);
					} else if (ch == 5) {
						int counter = printFile(id);
						if (counter > 0) {
							deleteFile(id);
						} else {
							System.out.println("因您没有上传过文件，故不需要删除！");
						}

					} else {
						System.out.println("请选择正确的服务代码：");
					}
				}
			} else {
				System.out.println("您输入的用户名或密码错误！");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtils.closeAll(rs, pstmt, null);
	}

	// 注册方法
	public static void regest() {
		String sql = "insert into tb_users values(?,?,?)";
		int id = (int) (10000 * Math.random());
		while (getId(id)) {
			id = (int) (10000 * Math.random());
		}
		//int id = getCounter() + 1;此方法，生成ID后，不可删除用户，若删除用户，后续插入用户会有错误。故将生成id方法改为随机生成。
		System.out.println("您现在使用的是本网站注册功能！");
		while (true) {
			String name = DBUtils.inputFileName("请输入用户名：");
			if (getName(name) == true) {
				System.out.println("该用户名已经注册，请重新输入用户名：");
			} else {
				String password = DBUtils.inputFileName("请输入密码：");
				PreparedStatement pstmt = DBUtils.getPreparedStatement(sql, con);
				try {
					pstmt.setInt(1, id);
					pstmt.setString(2, name);
					pstmt.setString(3, password);
					int num = pstmt.executeUpdate();
					if (num > 0) {
						System.out.println("恭喜您注册成功！您的ID是：" + id);
						break;
					} else {
						System.out.println("oh,no.竟然注册失败了，要不再试试吧！");
						regest();
					}

				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					DBUtils.closeAll(null, pstmt, null);
				}
			}
		}
	}

	// 获取注册用户数量方法
	public static int getCounter() {
		int counter = 0;
		String sql = "select count(*) from tb_users";
		Statement stmt = DBUtils.getStatementOfDB(con);
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				counter = rs.getInt(1);
			}
			DBUtils.closeAll(rs, stmt, null);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return counter;
	}

	// 查看该用户名是否已经被注册方法
	public static boolean getName(String name) {
		boolean flag = false;
		String sql = "select name from tb_users where name=?";
		PreparedStatement pstmt = DBUtils.getPreparedStatement(sql, con);
		ResultSet rs = null;
		try {
			pstmt.setString(1, name);
			rs = DBUtils.getResultSetOfDB(pstmt);
			if (rs.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(rs, pstmt, null);
		}
		return flag;
	}

	// 修改用户信息方法
	public static void updateUser(int id) {
		String choice = DBUtils.inputFileName("请选择您要修改的选项：" + "\n1.用户名" + "\n2.密码" + "\n您的选择是：");
		int ch = Integer.parseInt(choice);
		PreparedStatement pstmt = null;
		if (ch == 1) {
			String sql = " update tb_users set name=? where id=?";
			String name = DBUtils.inputFileName("请输入新的用户名：");
			pstmt = DBUtils.getPreparedStatement(sql, con);
			try {
				pstmt.setString(1, name);
				pstmt.setInt(2, id);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else if (ch == 2) {
			String sql = " update tb_users set password=? where id=?";
			String password = DBUtils.inputFileName("请输入新的密码：");
			pstmt = DBUtils.getPreparedStatement(sql, con);
			try {
				pstmt.setString(1, password);
				pstmt.setInt(2, id);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("您的输入有误，请重新选择");
		}
		try {
			int result = pstmt.executeUpdate();
			if (result > 0) {
				System.out.println("修改成功！");
			} else {
				System.out.println("修改失败");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(null, pstmt, null);
		}
	}

	// 找回密码方法
	public static String getPassword() {
		String sql = "select password from tb_users where name=? and id=?";
		String name = DBUtils.inputFileName("请输入您的用户名：");
		String password = null;
		if (getName(name) == false) {
			System.out.println("您尚未注册喔！");
		} else {
			String idNum = DBUtils.inputFileName("请输入您的系统分配ID：");
			int id = Integer.parseInt(idNum);
			PreparedStatement pstmt = DBUtils.getPreparedStatement(sql, con);
			ResultSet rs = null;
			try {
				pstmt.setString(1, name);
				pstmt.setInt(2, id);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					password = rs.getString(1);
				} else {
					System.out.println("您输入的ID错误，请重新选择：");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DBUtils.closeAll(rs, pstmt, null);
			}
		}
		return password;
	}

	// 获得数据库中文件数量
	public static boolean getFidOfFile(int fid) {
		boolean flag = false;
		String sql = "select fid from tb_file where fid=?";
		PreparedStatement pstmt = DBUtils.getPreparedStatement(sql, con);
		ResultSet rs = null;
		try {
			pstmt.setInt(1, fid);
			rs = DBUtils.getResultSetOfDB(pstmt);
			if (rs.next()) {
				int result = rs.getInt(1);
				if (result > 0) {
					flag = true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(rs, pstmt, null);
		}
		return flag;
	}

	// 上传文件，将路径插入数据库中
	public static void uploadFile(int id) {
		int result = 0;
		int fid = 2015000 + (int) (1000 * Math.random());
		while (getFidOfFile(fid) == true) {
			fid = 2015000 + 1000 * (int) Math.random();
		}
		String fileName = DBUtils.inputFileName("请输入上传文件名(如：a.txt)：");
		String title = fileName.substring(0, fileName.lastIndexOf("."));
		StringBuilder buf = new StringBuilder();
		buf.append("e:/jdbctest:/");
		buf.append(fileName);
		String path = buf.toString();
		FilesOfUser file = new FilesOfUser(fid, title, path, id);
		String sql = "insert into tb_file values(?,?,?,?)";
		PreparedStatement pstmt = DBUtils.getPreparedStatement(sql, con);
		try {
			pstmt.setInt(1, file.getFid());
			pstmt.setString(2, file.getTitle());
			pstmt.setString(3, file.getPath());
			pstmt.setInt(4, file.getId());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			result = pstmt.executeUpdate();
			if (result > 0) {
				System.out.println("已经将您的文件上传到服务器！");
			} else {
				System.out.println("文件上传失败！");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(null, pstmt, null);
		}
	}

	public static int printFile(int id) {
		int counter = 0;
		String sql = "select * from tb_file where id=?";
		PreparedStatement pstmt = DBUtils.getPreparedStatement(sql, con);
		ResultSet rs = null;
		try {
			pstmt.setInt(1, id);
			rs = DBUtils.getResultSetOfDB(pstmt);
			while (rs.next()) {
				counter++;
				int fid = rs.getInt(1);
				String title = rs.getString(2);
				String path = rs.getString(3);
				System.out.println("文件标号：" + fid + ",文件标题：" + title + "，服务器保存路径" + path);
				System.out.println("---------------------------------------------------");
			}
			if (counter == 0) {
				System.out.println("您之前未上传过文件！");
			} else {
				System.out.println("您上传的" + counter + "个文件展示如上。");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(rs, pstmt, null);
		}
		return counter;
	}

	public static void deleteFile(int id) {
		String sql = "delete  from tb_file where fid=? and id=?";
		String f = DBUtils.inputFileName("请输入您要删除的文件的编码：");
		int fid = Integer.parseInt(f);
		PreparedStatement pstmt = null;
		pstmt = DBUtils.getPreparedStatement(sql, con);
		int result = -1;
		try {
			pstmt.setInt(1, fid);
			pstmt.setInt(2, id);
			result = pstmt.executeUpdate();
			if (result > 0) {
				System.out.println("删除文件成功！");
			} else {
				System.out.println("删除文件失败！");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(null, pstmt, null);
		}
	}

	public static void showPages() {
		String path = "f:\\疯子和他的哲学家朋友.txt";
		// 1 声明
		FileReader fr = null;
		try {
			// 2创建
			fr = new FileReader(path);
			// 3读取
			int x = fr.read(); // 读取一个字符，反馈该字符的编码值(int值)
			// 4判断
			while (x != -1) {
				// 5 显示
				System.out.print((char) x);
				// 6继续读取
				x = fr.read();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	//查看数据库中是否有此ID方法
	public static boolean getId(int id) {
		boolean flag = false;
		String sql = "select * from tb_users where id=?";
		PreparedStatement pstmt = DBUtils.getPreparedStatement(sql, con);
		ResultSet rs = null;
		try {
			pstmt.setInt(1, id);
			rs = DBUtils.getResultSetOfDB(pstmt);
			if (rs.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(rs, pstmt, null);
		}
		return flag;
	}
}


