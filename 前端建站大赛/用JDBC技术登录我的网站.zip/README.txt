<p>本程序采用了Java中的JDBC&nbsp;技术；</p><p>步骤：</p><p>1.在oracle中创建一张表tb_users;</p><p>2.在Java项目下的src文件夹中编写数据库参数配置文件DBConfig.properties;</p><p>3.将oracle驱动包复制到项目下，并buildpath;</p><p>4.编写一个JDBC方法类，方便我们调用；</p><p>5.编写我们的登录网页的类，以方法的形式将各功能模块化；</p><p>6.编写main方法，进行测试。<br/></p>

