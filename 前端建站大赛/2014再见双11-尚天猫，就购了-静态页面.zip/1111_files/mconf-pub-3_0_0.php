window.__mallbarGetConf && __mallbarGetConf({
"notWideTab":0,//2.3.5 关闭宽版工具栏
    "showCartGuide": 0, // 2.0.0
    "showVerCat": 0,
    "showLoginBubble": 0,
    "showZeroCoupon": 0,
    "zeroCouponUrl": "",
    "zeroCouponTxt": "",
    "liveBubMax": 10,
    "liveBubDur": 12, // 1.2.3
    "isLiveD11": 0,
    "brandBubUrl": "",

    "tripLogoNoAnim": 0,
    "navTxt": "", // 1.2.3
"navTabLogo":"",//2.3.5
    "navUrl": "//www.tmall.com/go/rgn/promotion-act/2014d11-leftnav-qk.php", // 1.2.3
"tripLogo": "",
    "navActList": [], // 1.2.3
    "bonusBindedTxt": "",
    "showBonusSplit": 1,
    "tabsBg": "", // 1.2.5, 1.2.6 支持颜色
    "miniBg": "", // 1.2.5
"closeDefaultVipBubble":1,//关闭特权默认 2.4.2
    navNarrow: "//img.alicdn.com/tps/i2/TB16LphHXXXXXaSXVXXwAlVGpXX-35-71.png",//35x20
    navWideLittle: "//img.alicdn.com/tps/i1/TB1Qzb4FpXXXXaebVXXVf83JpXX-85-68.png",//85x30
    navWideBig: "//img.alicdn.com/tps/i2/TB1Cb7QGXXXXXcNaXXX.NWa_XXX-85-200.png",//85x80
    "navHeight":{"n":70,"wl":68,"wb":200},
    "navBgColor": "",
    navTopColor:'#e3003b',

"primeStartTime": 1420905600000,//3.0.1 prime开始时间-1.11 0:00
    "primeEndTime": 1451577600000,//3.0.1 prime结束时间 -3.11 23:59
"mobilecrossVersion": "3.0.0",
    "notCartDefaultBubble":0,
    "notFavorDefaultBubble":0,
"notCartBubbleNum":0,
"firstBubbleWaitTime":1,
"topAddHeight":0,//2.3.0 设置tab的布局

"notDanmuMsg":1,
    "needCrossBubble":0,//多倍积分气泡

    "bubbleShowGo11":{s:'1414771200000',e:'1415721600000'},
    "bubbleShowCharge":{s:'1414771200000',e:'1415624399999'},
     "tmallbaobannerTime":{s:'1414771200000'},
    "tmallBaoDaily":'1415624399999',
    "tmallBaoDailyBanner":'//img.alicdn.com/tps/i1/TB1va.XGXXXXXbxaXXXwX8kHXXX-200-70.png',
 "tmallBaoLink":'//fun.alipay.com/tmb/tmb.htm?scm=1048.1.3.29',//2.3.0 
"tmallBaoBubble":{s:'1414771200000',e:'1415624399999'},
    "bubbleBlacklist":['107922698','109681130'],//shopId 用于控制关闭气泡功能

    "marketMods": [

    ],
    "l": [
    {
    "on": 1,
    "i1": "",
    "id": "prof",
    "n": "我的特权",
    "u": "//vip.tmall.com?scm=1048.1.2.1",
    "arr": "//gm.mmstat.com/tmallbrand.99.19",
    "nick": "",
    "p": "mui/mallbar/plugin-prof",
    "ie6Tab": "//g.alicdn.com/tm/img/1.0.6/my_ie6.png",
    "noLogin": 0,
    "noHover": 0,
    "noExpand": 0,
    "margin": 8
    },
        {
            "on": 1,
            "i1": "",
            "id": "promotion",
            "n": "打开有惊喜",
            "u": "javascript:;",
            "arr": "//gm.mmstat.com/tmallbrand.99.83",
            "nick": "特权",
            "p": "mui/mallbar/plugin-promotion",
            "noLogin": 0,
            "margin": 0,
            "noHover": 0,
            'defaultHide': 1,
            "margin": 8
        },
        {
            "on": 0,
            "i1": "",
            "id": "live",
            "n": "直播厅",
            "u": "javascript:;",
            "arr": "//gm.mmstat.com/tmallbrand.99.6",
            "nick": "直播厅",
            "p": "mui/mallbar/plugin-live",
            "noLogin": 0,
            "margin": 0,
            "custom": 1,
            "specail":1
        },
        {
            "on": 1,
            "i1": "",
            "id": "worth",
            "n": "天猫年中大促",
            "u": "javascript:;",
            "arr": "//gm.mmstat.com/tmallbrand.99.120",
            "nick": "值得买",
            "p": "mui/mallbar/plugin-worth",
            "noLogin": 0,
            "margin": 0,
            "custom": 1,
            "noHover": 0,
            "specail":1
        },


        {
            "on": 0,
            "i1": "",
            "id": "trip",
            "n": "双11攻略",
            "u": "javascript:;",
            "arr": "//gm.mmstat.com/tmallbrand.99.45",
            "nick": "导航",
            "p": "mui/mallbar/plugin-trip",
            "noLogin": 1,
            "custom": 1,
            // "margin": 0,
            "tms": 1,
            "noHover": 0
        },

        {
            "on": 1,
            "i1": "",
            "id": "nav",
            "n": "会场导航",
            "u": "javascript:;",
            "arr": "//gm.mmstat.com/tmallbrand.99.46",
            "nick": "会场导航",
            "p": "mui/mallbar/plugin-nav",
            "noLogin": 1,
            "custom": 1,   //置于上面
            "margin": 0,
            "tms": 1,
            "noHover": 0,
            "specail":1
        },

{
    "on": 1,
    "id": "cart",
    "n": "购物车",
    "u": "javascript:;",
    "arr": "//gm.mmstat.com/tmallbrand.99.137",
    "nick": "购物车",
    "p": "mui/mallbar/plugin-cart",
    "ie6Tab": "//g.alicdn.com/tm/img/1.0.6/cart_ie6.png",
    "noLogin": 0,
    "noHover": 1,
    "margin": 8
    },
{
    "on": 1,
    "i1": "",
    "id": "asset",
    "n": "我的资产",
    "u": "//mybrand.tmall.com/myCoupon.htm?scm=1048.1.3.1",
    "arr": "//gm.mmstat.com/tmallbrand.99.4",
    "nick": "",
    "p": "mui/mallbar/plugin-asset",
    "ie6Tab": "//g.alicdn.com/tm/img/1.0.6/money_ie6.png",
    "noLogin": 0,
    "margin": 8,
    "noHover": 0
    },
{
    "on": 1,
    "i1": "//mybrand.tmall.com/ajax/mybrands/getMallBarMyBrands.htm?type=2",
    "id": "brand",
    "n": "我关注的品牌",
    "u": "//mybrand.tmall.com?scm=1048.1.4.1",
    "arr": "//gm.mmstat.com/tmallbrand.99.5",
    "nick": "",
    "p": "mui/mallbar/plugin-brand",
    "ie6Tab": "//g.alicdn.com/tm/img/1.0.6/brand_ie6.png",
    "noLogin": 0,
    "margin": 8,
    "noHover": 0
    },
{
    "on": 1,
    "i1": "",
    "id": "favor",
    "n": "我的收藏",
    "u": "javascript:;",
    "arr": "//gm.mmstat.com/tmallbrand.99.76",
    "nick": "",
    "p": "mui/mallbar/plugin-favor",
    "noLogin": 0,
    "margin": 8,
    "noHover": 0
    },
{
    "on": 1,
    "i1": "",
    "id": "foot",
    "n": "我看过的",
    "u": "javascript:;",
    "arr": "//gm.mmstat.com/tmallbrand.99.12",
    "nick": "",
    "p": "mui/mallbar/plugin-foot",
    "ie6Tab": "//g.alicdn.com/tm/img/1.0.6/time_ie6.png",
    "scroll": 1,
    "noLogin": 0,
    "margin": 8,
    "noHover": 0
    },
{
    "on": 1,
    "i1": "",
    "id": "charge",
    "n": "我要充值",
    "u": "javascript:;",
    "arr": "//gm.mmstat.com/tmallbrand.99.72",
    "nick": "",
    "p": "mui/mallbar/plugin-charge",
    "scroll": 1,
    "noLogin": 1,
    "margin": 8,
    "noHover": 0
    },


{
    "on": 1,
    "id": "top",
    "n": "返回顶部",
    "u": "",
    "arr": "",
    "nick": "",
    "p": "mui/mallbar/plugin-top",
    "bottom": 1,
    "noExpand": 1,
    "noLogin": 1
    },
{
    "on": 1,
    "id": "qrcode",
    "n": "二维码",
    "u": "javascript:;",
    "arr": "//gm.mmstat.com/tmallbrand.99.66",
    "nick": "",
    "p": "mui/mallbar/plugin-qrcode",
    "bottom": 1,
    "noHover": 1,
    "noExpand": 1,
    "noLogin": 1
    },
{
    "on": 1,
    "id": "ue",
    "n": "用户反馈",
    "u": "",
    "arr": "",
    "nick": "",
    "p": "mui/mallbar/plugin-ue",
    "bottom": 1,
    "noExpand": 1,
    "noLogin": 1
    }
]
})