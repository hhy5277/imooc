(function($){

	var LightBox = function(){
		console.log("Class Name:LightBox | Version:1.0 | Write By:Fengzi_tan");		
		var self = this;
		this.structureDoc = null;
		this.popupMask = null;
		this.popupWin = null;
		this.popupWinStr = null;
		this.bodyNode = $(document.body);
		this.groupNode = null;
		this.groupId = 0;
		this.showId = 0;
		this.listData = [];
		this.bodyNode.delegate(".imglist li","click",function(e){
			e.stopPropagation();
			if($(this).parent().attr('data-group')==null){
				$(this).parent().attr('data-group',self.groupId++);
			}			
			if(self.groupNode==null||self.groupNode.attr('data-group')!=$(this).parent().attr('data-group')){
				self.groupNode = $(this).parent();
				self.listData.length = 0;
				self.getlistdata();
			}
			self.getindex($(this).addClass('show'));
			self.render();
		});
		//窗口尺寸变化自适应
		var timer = null;
		$(window).resize(function(){
			if(self.popupWin==null){
				return false;
			}
			window.clearTimeout(timer);
			timer = window.setTimeout(function(){
				self.popupWin.remove();
				self.renderpopupwin();
			},500);
		});
	};

	LightBox.prototype = {
		loadimg : function(callback){
			
			var img = new Image();
			img.src = this.listData[this.showId].src;
			if(!!window.ActiveXObjiect){
				img.onreadystatechange = function(){
					if(this.readyState == 'complete'){
						callback();
					}
				}
			}
			else{
				img.onload = function(){
					callback();
				}
			}
		},
		render : function(){
			var self = this;
			this.structureDoc = $('<div id="light-box">');
			this.popupMask = $('<div class="light-box-cover">').on("click",function(){
				self.destroy();
			});
			this.structureDoc.append(this.popupMask);
			this.renderpopupwin();
			this.bodyNode.append(this.structureDoc);
		},
		destroy : function(){
			this.structureDoc.remove();
		},
		getlistdata : function(){
			var self = this;
			this.groupNode.find('li').each(function(e){	
				self.listData.push(eval("("+$(this).attr('data')+")"));				
			});
		},
		getindex : function(){
			var self = this;
			this.groupNode.find('li').each(function(e){
				if($(this).hasClass('show')){
					self.showId = e;
					$(this).removeClass('show');
				}
			});
		},
		renderpopupwin : function(){
			var self = this;
			this.popupWin = $('<div class="light-box-popup">');
			var show_id = this.showId;
			var show_data = this.listData[show_id];
			var info_msg = 'The Index: '+(show_id+1)+'/'+this.listData.length;
			this.popupWinStr = '<div class="light-box-button light-box-button-left"></div>'
				+'<div class="light-box-img"><img src="" /><div>'
				+'<div class="light-box-button light-box-button-right"></div>'
				+'<div class="light-box-info">'
				+	'<p>Picture Name: '+show_data.name+'</p>'
				+	'<span>'+info_msg+'</span>'
				+'</div>';
			this.popupWin.html(this.popupWinStr);
			this.popupWin.find('.light-box-button-left').each(function(){
				if(self.showId==0){
					return false;
				}
				$(this).on('mouseover',function(){
					$(this).addClass('light-box-button-left-show');
				});
				$(this).on('mouseout',function(){
					$(this).removeClass('light-box-button-left-show');
				});
				$(this).on('click',function(){			
					self.popupWin.remove();
					self.showId--;
					self.renderpopupwin();
				});
			});
			this.popupWin.find('.light-box-button-right').each(function(){
				if(self.showId==self.listData.length-1){
					return false;
				}
				$(this).on('mouseover',function(){
					$(this).addClass('light-box-button-right-show');
				});
				$(this).on('mouseout',function(){
					$(this).removeClass('light-box-button-right-show');
				});
				$(this).on('click',function(){			
					self.popupWin.remove();
					self.showId++;
					self.renderpopupwin();
				});
			});
			this.structureDoc.append(this.popupWin);
			var window_width = $(window).width(),
				window_height = $(window).height();
			this.popupWin.css({
				'width' : window_width/2,
				'height' : window_height/2,
				'margin-left' : -window_width/4,
				'top' : -window_height/2
			}).animate({
				'top' : window_height/4,
			},function(){
				self.loadimg(function(){
					self.popupWin.find('.light-box-img img').each(function(){
						$(this).hide();
						$(this).attr('src',self.listData[self.showId].src);
						var picture_width = $(this).width();
						var picture_height = $(this).height();
						console.log(picture_width+' '+picture_height)
						var scale = Math.min($(window).width()/picture_width,$(window).height()/picture_height,1);
						if(scale<1){
							picture_width = picture_width*scale-10;
							picture_height = picture_height*scale-10;
						}
						else{
							picture_width = picture_width*scale;
							picture_height = picture_height*scale;
						}
						self.popupWin.animate({
							'width' : picture_width+'px',
							'height' : picture_height+'px',
							'margin-left' : -(picture_width/2+5)+'px',
							'top' : (($(window).height()-picture_height)/2-5)+'px'
						},function(){
							self.popupWin.find('img').css({
								'width' : '100%'
							}).fadeIn();
						});
					});
				});
			});
		}
	};	
	window["LightBox"] = LightBox;
})(jQuery);


