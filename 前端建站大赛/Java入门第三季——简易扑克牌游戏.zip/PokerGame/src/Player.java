import java.util.ArrayList;
import java.util.Collections;


public class Player {
	private String Name;
	private int ID;
	private ArrayList<Card> cardList;
	
	public Player(int id,String name)
	{
		this.Name=name;
		this.ID=id;		
		cardList=new ArrayList<Card>();
	}
	
	public void getCard(Card c)
	{
		cardList.add(c);
	}
	
	public Card getMaxCard()
	{
		return Collections.max(cardList);
	}
	
	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public void showCards() {
		// TODO Auto-generated method stub
		for(Card c:cardList)
		{
			System.out.print(c.toString()+" ");
		}
	}
}
