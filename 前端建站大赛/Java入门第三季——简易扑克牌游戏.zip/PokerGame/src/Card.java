
public class Card implements Comparable<Card>  {

	private int Number;
	private int Symbol;
	
	public Card(int symbol,int num)
	{
		this.Number=num;
		this.Symbol=symbol;
	}
	
	@Override
	public int compareTo(Card o) {
		if (this.Number > o.Number) {
			return 1;
		}
		if (this.Number == o.Number) {
			if (this.Symbol > o.Symbol)
				return 1;
			else
				return -1;
		}
		return -1;
	}

	@Override
	public String toString() {
		StringBuilder str=new StringBuilder();
		str.append(NumToCardSym());
		str.append(NumToCardNum());
		return str.toString();
	}
	
	private String NumToCardNum() {
		switch (Number) {
		case 11:
			return "J";
		case 12:
			return "Q";
		case 13:
			return "K";
		case 14:
			return "A";
		default:
			return Number + "";
		}
	}
	
	private String NumToCardSym() {
		switch (Symbol) {
		case 0:
			return "方片";
		case 1:
			return "梅花";
		case 2:
			return "红桃";
		default:
			return "黑桃";
		}
	}



	
}
