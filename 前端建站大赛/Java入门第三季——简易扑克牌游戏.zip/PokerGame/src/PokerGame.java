import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class PokerGame {
	private static Scanner in = new Scanner(System.in);
	
	private Player[] players;
	
	private ArrayList<Card> cards;
	
	public PokerGame()
	{
		initalCards();
		ShuffleCards();
	}

	public void GetCards()
	{
		System.out.println("������ÿ����������");
		int count=in.nextInt();
		for(int i=0;i<2*count;i=i+2)
		{
			players[0].getCard(cards.get(i));
			players[1].getCard(cards.get(i+1));
		}
	}
	
	public void PK()
	{
		Card c0= players[0].getMaxCard();
		Card c1=players[1].getMaxCard();
		if(c0.compareTo(c1)>0)
		{
			System.out.println(c0.toString()+">"+c1.toString());
			System.out.println(players[0].getName()+"��ʤ");
		}
		else
		{
			System.out.println(c1.toString()+">"+c0.toString());
			System.out.println(players[1].getName()+"��ʤ");
		}

		
		System.out.println(players[0].getName()+"����");
		players[0].showCards();
		System.out.println("\n"+players[1].getName()+"����");
		players[1].showCards();
		
	}
	
	private void initalCards()
	{
		System.out.println("------�����˿���------ ");
		cards=new ArrayList<Card>();
		for(int i=0;i<4;i++)
		{
			for(int j=0;j<13;j++)
			{
				Card c=new Card(i,j+2);
				cards.add(c);
			}
		}
		
		for(Card c:cards)
		{
			System.out.print(c.toString()+" ");
		}
		System.out.println("\n------�����ɹ�------ ");
	}
	
	private void ShuffleCards()
	{
		System.out.println("------��ʼϴ��------ ");
		Collections.shuffle(cards);
		System.out.println("------ϴ�ƽ���------ ");
	}

	public void CreatePlayer()
	{
		players=new Player[2];
		int i=0;
		while(i<2)
		{
			System.out.println("�������"+i+"λ�û�ID");
			try{
				int id=in.nextInt();
				System.out.println("�������"+i+"λ�û�����");
				String name=in.next();
				players[i]=new Player(id, name);
				i++;
			}
			catch(Exception e){
				System.out.println("������������");
				in = new Scanner(System.in);
				continue;
			}

		}
	}


	public static void main(String[] args) {
		PokerGame game=new PokerGame();
		game.CreatePlayer();
		game.GetCards();
		game.PK();
		
		in.close();

	}
}
