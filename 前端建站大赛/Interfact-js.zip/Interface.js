//JS接口抽象
    //构造函数
    var Interface = function (name, methods, propertys) {
        if (arguments.length < 2) {
            throw new Error(["Interface构造函数需要至少2个参数，实际只传递了", arguments.length, "个"].join(''));
        }
        if (!Array.isArray(methods)) {
            throw new Error(["methods参数需要传递数组，而非", typeof methods].join(""));
        }

        if (propertys && !Array.isArray(propertys)) {
            throw new Error(["propertys参数需要传递数组，而非", typeof propertys].join(""));
        }

        this.name = name;
        this.methods = [];
        this.propertys = [];
        for (var i = 0; i < methods.length; i++) {
            var method = methods[i];
            if (typeof method != "string")
                throw new Error(["方法名称只能是string类型，而非", typeof method].join(""));
            this.methods.push(method);
        }
        if (propertys) {
            for (var i = 0; i < propertys.length; i++) {
                var property = propertys[i];
                if (typeof property != "string")
                    throw new Error(["属性名称只能是string类型，而非", typeof method].join(""));
                this.propertys.push(property);
            }
        }
    };

    //静态方法：检测是否实现了接口
    Interface.ensureImplements = function (obj) {
        if (arguments.length < 2) {
            throw new Error(["函数需要至少2个参数，实际只传递了", arguments.length, "个"].join(''));
        }
        for (var i = 1, len = arguments.length; i < len; i++) {
            var curInterface = arguments[i];
            if (curInterface.constructor != Interface) {
                throw new Error("接口构造函数不正确");
            }

            for (var j = 0; j < curInterface.methods.length; j++) {
                var method = curInterface.methods[j];
                if (!obj[method] || typeof obj[method] !== "function") {
                    throw new Error("没有实现接口方法：" + method);
                }
            }

            if (curInterface.propertys && Array.isArray(curInterface.propertys)) {
                for (var i = 0; i < curInterface.propertys.length; i++) {
                    var property = curInterface.propertys[i];
                    if (!obj[property]) {
                        throw new Error(["没有实现接口属性：", property].join(''));
                    }
                }
            }
        }
    };

