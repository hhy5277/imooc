<?php 
//引入函数
include './functions.php';
// 1.引入数据库
$data = include './data.php';

//判断用户是否提交，提交了则将数据加入数据库数组
if (!empty($_POST)) {
	// 获得时间
	// 设置时区
	$_POST['time'] = date('Y/m/d H:i:s');
	if(empty($_POST['message'])||empty($_POST['name'])){
		echo "<script>alert('请将内容填写完整');location.href='./index.php';</script>";
		return;
	}
	// 将用户数据追加到数据库
	$data[] = $_POST;
	// 将数据php合法化
	$phpCode = "<?php return " . var_export($data,true) . "?>";
	// 将数据覆盖原来的数据库
	file_put_contents('./data.php',$phpCode);
	// 防刷新机制
	$liuyan = <<<str
	<script>
	location.href = './index.php'
	</script>
str;
	echo $liuyan;
}

//载入页面
include './html/demo.html'

 ?>