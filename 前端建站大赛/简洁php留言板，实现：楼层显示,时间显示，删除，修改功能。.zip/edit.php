<?php 
// 1.载入数据库
$data = include './data.php';
// 2.获得编辑id
$id = $_GET['id'];
// echo $id;
//找到旧数据
$oldData=$data[$id];
if (!empty($_POST)) {
    if (!empty($_POST)) {
		if(empty($_POST['message'])||empty($_POST['name'])){
			echo "<script>alert('请将内容填写完整');location.href='./edit.php?id={$id}';</script>";
			return;
	}
	// 保留首次发表的时间
	$_POST['time'] = $oldData['time'];
	// 将该数据重新赋值
	$data[$id] = $_POST;
	// 将data合法化
	$phpCode = "<?php return ".var_export($data,true)." ?>";
	//覆盖数据库
	file_put_contents('./data.php',$phpCode);

	//修改成功，跳转页面
	$edit = <<<str
	<script>
	alert('修改成功！');
	location.href='./index.php';
	</script>
str;
	echo $edit;
}

//载入页面
include './html/edit.html';
 ?>

