<?php 
// 载入函数
include './functions.php';
// 1.载入数据库
$data = include './data.php';
// 2.获得删除项的ID
$id = $_GET['id'];
// echo $id;
// 3.删除对应项
unset($data[$id]);
// 4.在将数据合法化
$phpCode = "<?php return ".var_export($data,true)."?>";
// 5.将数据写入
file_put_contents('./data.php',$phpCode);
// 6.弹出删除成功，并转到首页
$del = <<<str
	<script>
	alert("删除成功");
	location.href = './index.php';
	</script>
str;
echo $del;
 ?>