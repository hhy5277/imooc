<p>简洁php留言板，实现：楼层显示，删除，修改功能。用php模拟数据库完成！学习php第一个小项目，求围观求喷！</p><p>需将文件放入wamp中打开。<br/></p><p>预览图如下：</p><p><img src="http://img.mukewang.com/565690c600010e0505000386.jpg" alt="http://img.mukewang.com/565690c600010e0511300872.jpg"/></p>

