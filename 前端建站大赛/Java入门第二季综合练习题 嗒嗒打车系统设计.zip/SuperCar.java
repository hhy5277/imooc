package rend;

public class SuperCar extends Car {
	private int loadPerson;
	private int loadThing;
	
	
	public SuperCar(String name, double price, int loadPerson, int loadThing,String carType) {
		super(name, price,carType);
		this.loadPerson = loadPerson;
		this.loadThing = loadThing;
	}
	
	public void method(){
		System.out.println("该类车具有载人和载物的功能！");
	}
	
	public int getLoad2(){
		return loadThing;
	}
	
	public int getLoad(){
		return loadPerson;
	}
	
	public String toString(){
		String s =this.name+"\t"+this.price+"元/天\t"+"载人:"+this.getLoad()+"人\t"+"载货："+this.getLoad2()+"吨";
		return s;
	}
	
	
}
