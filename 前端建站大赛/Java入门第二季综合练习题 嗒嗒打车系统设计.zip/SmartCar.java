package rend;

public class SmartCar extends Car {

	private int load;

	public SmartCar(String name, double price, int load,String carType) {
		super(name, price,carType);
		this.load = load;
	}
	
	public int getLoad(){
		return load;
	}

	public String toString(){
		String s =this.name+"\t"+this.price+"元/天\t"+"载人:"+this.getLoad()+"人";
		return s;
	}
	
}
