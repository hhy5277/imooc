package rend;

public class Truck extends Car {
 
	private int load;

	public Truck(String name, double price, int load,String carType) {
		super(name, price,carType);
		this.load = load;
	}
	
	public void method(){
		System.out.println("该类车具有载货的功能");
	}
	
	

	public int getLoad(){
		return load;
	}
	
	
	public String toString(){
		String s =this.name+"\t"+this.price+"元/天\t"+"载货:"+this.getLoad()+"吨";
		return s;
	}
	
	
}
