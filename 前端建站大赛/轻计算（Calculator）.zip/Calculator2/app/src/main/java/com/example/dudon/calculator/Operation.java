package com.example.dudon.calculator;

        import android.app.AlertDialog;
        import android.os.Environment;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.TextView;

        import java.io.File;
        import java.io.FileReader;
        import java.io.FileWriter;
        import java.text.DecimalFormat;


/**
 * Created by dudon on 2015/11/24.
 */
public class Operation extends AppCompatActivity {
    TextView main;
    TextView deputy;

    Button button_cle;
    Button button_del;
    Button button_div;
    Button button_mul;
    Button button_sub;
    Button button_add;
    Button button_equ;
    Button button_dot;

    Button button_0;
    Button button_1;
    Button button_2;
    Button button_3;
    Button button_4;
    Button button_5;
    Button button_6;
    Button button_7;
    Button button_8;
    Button button_9;

    String units = new String();
    String record = new String();
    StringBuffer result = new StringBuffer();
    StringBuffer expression = new StringBuffer();

    String record_copy=new String();
    String result_copy = new String();
    String expression_copy = new String();

    //连续运算
    boolean additive = true;
    //建立算式
    boolean setnew = true;
    //显示记录
    boolean showdp = true;
    //连续运算中
    boolean adding = false;
    //初始化
    boolean loading = false;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_calculate);

        {//初始化各按钮
            main = (TextView) findViewById(R.id.show);
            deputy = (TextView) findViewById(R.id.records);
            //功能型按钮
            button_cle = (Button) findViewById(R.id.cle);
            button_del = (Button) findViewById(R.id.del);
            button_div = (Button) findViewById(R.id.div);
            button_mul = (Button) findViewById(R.id.mul);
            button_sub = (Button) findViewById(R.id.sub);
            button_add = (Button) findViewById(R.id.add);
            button_equ = (Button) findViewById(R.id.equ);
            button_dot = (Button) findViewById(R.id.dot);
            //数值型按钮
            button_0 = (Button) findViewById(R.id.num_0);
            button_1 = (Button) findViewById(R.id.num_1);
            button_2 = (Button) findViewById(R.id.num_2);
            button_3 = (Button) findViewById(R.id.num_3);
            button_4 = (Button) findViewById(R.id.num_4);
            button_5 = (Button) findViewById(R.id.num_5);
            button_6 = (Button) findViewById(R.id.num_6);
            button_7 = (Button) findViewById(R.id.num_7);
            button_8 = (Button) findViewById(R.id.num_8);
            button_9 = (Button) findViewById(R.id.num_9);
        }
        //载入数据

        {
            readData();
            deputy.setText(record_copy);
            if(!(result_copy.length()==0||expression_copy.length()==0||record_copy.length()==0)){
                main.setText(result_copy);
                loading = true;
            }
        }

        //按钮响应
        buttonAction();
        //操作捕捉
        buttonFunction();

    }

    void buttonAction() {
        button_div.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "÷";
                refresh();
            }
        });
        button_mul.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "×";
                refresh();
            }
        });
        button_sub.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "-";
                refresh();
            }
        });
        button_add.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "+";
                refresh();
            }
        });
        button_dot.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "dot";
                refresh();
            }
        });

        button_0.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "0";
                refresh();
            }
        });
        button_1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "1";
                refresh();
            }
        });
        button_2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "2";
                refresh();
            }
        });
        button_3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "3";
                refresh();
            }
        });
        button_4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "4";
                refresh();
            }
        });
        button_5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "5";
                refresh();
            }
        });
        button_6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "6";
                refresh();
            }
        });
        button_7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "7";
                refresh();
            }
        });
        button_8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "8";
                refresh();
            }
        });
        button_9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "9";
                refresh();

            }
        });
    }

    void buttonFunction() {
        button_del.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "delete";
                if (expression.length() != 0) {
                    if (expression.length() > 0) {
                        //删除末位字符
                        expression.deleteCharAt(expression.length() - 1);
                        refresh();
                    }
                } else {
                    expression = new StringBuffer();
                    refresh();
                }
            }
        });
        button_cle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                units = "clear";
                record = new String();
                expression = new StringBuffer();
                result = new StringBuffer();
                writeData();
                deputy.setText(record);
                showdp = false;
                refresh();
            }
        });
        button_equ.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int split = -1;
                int[] at = new int[4];
                at[0] = expression.lastIndexOf("+");
                at[1] = expression.lastIndexOf("-");
                at[2] = expression.lastIndexOf("×");
                at[3] = expression.lastIndexOf("÷");
                for (int i = 0; i < 4; i++) {
                    if (split < at[i]) {
                        split = at[i];
                    }
                }
                if (split > 0) {
                    record = new String(expression + "=");
                    //deputy.setText(expression + "=");
                    deputy.setText(record);
                    units = "equal";
                    result = process(expression);
                    main.setText(result);
                    //写入 记录 表达式 结果
                    writeData();
                    expression = new StringBuffer();
                    if (result.indexOf("错误") != -1) {
                        result = new StringBuffer();
                    }
                    additive = true;
                    setnew = true;
                    showdp = true;
                    adding = false;
                }

            }
        });
    }

    //表达式格式化并输出
    void refresh() {

        //判断是否为追加状态
        if (result.length() < expression.length()) {
            String example = new String(expression);
            example = example.substring(0, result.length());
            if (new String(result).equals(example)) {
                adding = true;
            } else {
                adding = false;
            }
        }

        //表达式追加元素
        if (expression.length() < 20) {

            char c = units.charAt(0);
            if (!(c == '+' || c == '-' || c == '×' || c == '÷')) {
                //删除处理
                if (units.equals("delete")) {
                    units = "";
                    //record = new String(result);
                }
                //清除处理
                if (units.equals("clear")) {
                    units = "";
                }
                //添加小数点
                if (units.equals("dot")) {
                    if (expression.equals("0")) {
                        units = "0.";
                    } else {
                        units = ".";
                    }
                }
                if (units.equals("equal")) {
                    //record= new String();
                    units = "";
                }
                //setnew = true;
                expression.append(units);
            } else {
                if (expression.length() == 0) {
                    if(loading){
                        if (additive) {
                            //存储数据加入运算
                            if (result_copy.indexOf("错误") == -1) {
                                expression = new StringBuffer(result_copy);
                            } else {
                                expression = new StringBuffer("0");
                            }
                            expression.append(units);
                            additive = false;
                            setnew = false;
                        }
                        loading = false;
                    }else {
                        if (additive) {
                            //连续运算
                            if (result.length() == 0) {
                                //new AlertDialog.Builder(this).setMessage("结果为空");
                                result = new StringBuffer("0");
                            }
                            expression = new StringBuffer(result);
                            expression.append(units);
                            additive = false;
                            setnew = false;
                        }
                    }
                } else {
                    //不允许连续符号
                    char operator = expression.charAt(expression.length() - 1);
                    if (operator != '+' && operator != '-' && operator != '×' && operator != '÷') {
                        if (expression.length() > 0) {
                            expression.append(units);
                        }
                    }
                    //expression.append(units);
                }
            }
        }
        if (units.equals("+") || units.equals("-") || units.equals("×") || units.equals("÷")) {

        }
        //清除不符合标准的小数点
        //if(expression.charAt(expression.length()-1)=='.')
        if (units.equals(".")) {
            expression.deleteCharAt(expression.length() - 1);
            StringBuffer temp = new StringBuffer(expression);
            if (expression.lastIndexOf(".") == -1) {
                expression.append(units);
            } else {
                int split = -1;
                int[] at = new int[4];
                at[0] = expression.lastIndexOf("+");
                at[1] = expression.lastIndexOf("-");
                at[2] = expression.lastIndexOf("×");
                at[3] = expression.lastIndexOf("÷");
                for (int i = 0; i < 4; i++) {
                    if (split < at[i]) {
                        split = at[i];
                    }
                }
                if (split > 0) {
                    temp.replace(0, split, "");
                }
                if (temp.lastIndexOf(".") == -1) {
                    expression.append(units);
                }
            }
        }


        //默认初始化为零
        if (expression.length() == 0 && units.length() != 1) {
            expression.append("0");
        }

        //首位不能为小数点
        if (expression.length() == 1) {
            if (expression.indexOf(".") == 0) {
                expression = new StringBuffer("0.");
            }
        }


        //首位不能为零
        if (expression.length() > 1 && expression.charAt(0) == '0' && expression.indexOf(".", 0) != 1) {
            int split = 1000;
            int[] at = new int[4];
            at[0] = expression.indexOf("+");
            at[1] = expression.indexOf("-");
            at[2] = expression.indexOf("×");
            at[3] = expression.indexOf("÷");
            for (int i = 0; i < 4; i++) {
                if (split > at[i] && at[i] != -1) {
                    split = at[i];
                }
            }
            if (split != 1) {
                expression.deleteCharAt(0);
            }
        }

        //副标题显示情况
        if (showdp && setnew) {
            if (!adding) {
                //record = new String(result);
                deputy.setText(result);
                showdp = false;
            }
            if(loading){
                deputy.setText(result_copy);
                loading=false;
            }
        }
        //显示表达式
        main.setText(expression);
        //重置units
        units = new String();
    }

    //计算结果并格式化
    StringBuffer process(StringBuffer expression) {
        double temp;
        String standard;
        String test;
        //清除表达式中空格
        //清除负号
        if (expression.charAt(0) == '-' || expression.charAt(0) == '+') {
            //test = new String(expression);
            //expression = new StringBuffer("0");
            //expression.append(test);
            expression.insert(0, "0");
        }
        //清除末位符号
        char c = expression.charAt(expression.length() - 1);
        if (c == '+' || c == '-' || c == '×' || c == '÷') {
            expression.deleteCharAt(expression.length() - 1);
        }

        standard = new String(expression);
        //清除表达式空格
        standard = standard.replaceAll(" ", "");
        //替换字符格式
        standard = standard.replace('×', '*');
        standard = standard.replace('÷', '/');
        temp = Calculator.conversion(standard);
        test = new String().valueOf(temp);

        //结果为整数
        if (temp % 1 == 0) {
            test = new String().valueOf((long) temp);
            //极大整数处理
            if (test.length() > 10) {
                test = new String().valueOf(temp);
                //科学记数长度处理
                while (test.length() > 12) {
                    int at = test.indexOf("E");
                    StringBuffer sb = new StringBuffer(test);
                    sb.replace(at - 1, at, "");
                    test = new String(sb);
                }

            } else {
                //短整数处理
                //尾数零位清除
            }
        } else {
            //小数部分处理
            if (test.length() > 12) {
                //极大小数处理
                if (test.indexOf("E") == -1) {
                    //保留10位小数
                    temp = Math.round(temp * 1000000000);
                    temp = temp / 1000000000;
                    test = new String().valueOf(temp);
                }
                if (test.indexOf("E") != -1) {
                    //科学计数小数位
                    while (test.length() > 12) {
                        int at = test.indexOf("E");
                        StringBuffer sb = new StringBuffer(test);
                        sb.replace(at - 2, at - 1, "");
                        test = new String(sb);
                    }
                }

            } else {
                //短小数处理
                if (test.indexOf("E") != -1) {
                    if (temp > 0.000000001) {
                        DecimalFormat df = new DecimalFormat("#.0000000000");
                        if (temp > 0) {
                            test = "0" + df.format(temp);
                        } else {
                            test = "-0" + df.format(temp);
                        }
                        //去除末位零
                        while (test.charAt(test.length() - 1) == '0') {
                            StringBuffer dislodge = new StringBuffer(test);
                            dislodge.deleteCharAt(dislodge.length() - 1);
                            test = new String(dislodge);
                        }
                    }
                }
            }
        }
        //非数
        if (test.equals("NaN")) {
            test = "错误";
        }
        //限制长度12位
        StringBuffer outer = new StringBuffer(test);
        while (outer.length() > 12) {
            //删除末位字符
            outer.deleteCharAt(outer.length() - 1);
        }
        return outer;
    }

    //读取数据
    void readData() {

        File file = null;
        try {
            file = createFile(file);

            FileReader fr = new FileReader(file);

            if((int)file.length()>0){
                char[] copy = new char[(int) file.length()];
                fr.read(copy);
                String change = new String(copy);


                int begin = change.indexOf("#");
                int end = change.lastIndexOf("#");
                if (begin != -1 && end != -1) {
                    //真实顺序为 记录 结果 表达式
                    record_copy = new String(change.substring(0, begin));
                    result_copy = new String(change.substring(begin + 1, end));
                    expression_copy = new String(change.substring(end + 1, change.length()));
                }
            }


            fr.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    //写入数据
    void writeData() {

        File file = null;
        try {
            file = createFile(file);
            FileWriter fw = new FileWriter(file);

            //读入文件
            String change = record + "#" + result + "#" + expression;
            //消除所有空格
            change = change.replaceAll(" ", "");
            //System.out.println(change);
            fw.write(change);

            fw.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    File createFile(File file) {
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
            // 创建一个文件夹对象，赋值为外部存储器的目录
            File sdcardDir = Environment.getExternalStorageDirectory();
            //得到一个路径，内容是sdcard的文件夹路径和名字
            String path = sdcardDir.getPath() + "/data.txt";
            file = new File(path);
            if (!file.exists()) {
                //若不存在，创建目录，可以在应用启动的时候创建
                //file.mkdirs();
                try {
                    file.createNewFile();
                } catch (Exception e) {
                    System.out.print(e.getMessage());
                }
                //setTitle("paht ok,path:"+path);
            }
        }
        return file;
    }
}
