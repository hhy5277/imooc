<p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 18px; font-weight: normal; font-family: &#39;Microsoft YaHei&#39;; float: left; line-height: 40px; text-align: right; white-space: normal; background-color: rgb(255, 255, 255);"><br/></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 18px; font-weight: normal; font-family: &#39;Microsoft YaHei&#39;; float: left; line-height: 40px; text-align: right; white-space: normal; background-color: rgb(255, 255, 255);"><br/></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 18px; font-weight: normal; font-family: &#39;Microsoft YaHei&#39;; float: left; line-height: 40px; text-align: right; white-space: normal; background-color: rgb(255, 255, 255);"><br/></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; font-size: 18px; font-weight: normal; font-family: &#39;Microsoft YaHei&#39;; float: left; line-height: 40px; text-align: right; white-space: normal; background-color: rgb(255, 255, 255);"><br/></p><h1>JSCharts-Free_demo</h1><p><br/></p><h2>一、JScharts介绍</h2><p>JScharts是一个用于在浏览器直接绘制图表的JavaScript工具包。JScharts支持柱状图、圆饼图以及线性图，可以直接将这个图插入网页，JScharts图的数据可以来源于XML文件、JSON文件或JavaScript数组变量。JScharts兼容所有主流的浏览器，且使用时无需任何服务器端的插件或模块，是纯JavaScript组件，免费(含水印)。</p><p><img src="http://img.mukewang.com/554c8cc700011a8202070127.jpg" style=""/>&nbsp;<img src="http://img.mukewang.com/554c8cc70001a38b02070127.jpg" style="line-height: 1.76em;"/>&nbsp;<img src="http://img.mukewang.com/554c8cc80001379402070127.jpg" style="line-height: 1.76em;"/></p><p>JScharts是收费工具，非商业使用收费39美元/1 domain；商业使用收费79美元/1 domain。可免费使用，免费版含水印。要删除水印，需要一个域密钥。</p><h2>二、JScharts新特性</h2><p>1. 支持3D饼状图或3D柱状图</p><p>2. 多系列柱状图</p><p>3. 水平柱状图</p><p>4. 线性图支持动画显示</p><p>5. 新的自定义方法</p><p>当前JScharts最新版本是3.06版。</p><p>支持的浏览器版本为：Chrome 10以上，Chrome 1.5以上，IE 8以上，Safari 3.1以上，Opera 9以上等。</p><h2>三、JScharts使用指南</h2><p><strong>1.下载JScharts库</strong></p><p>从官网下载JScharts库，我们使用的是压缩包里面的jscharts.js文件。它大约150KB。</p><p><strong>2. 使用JScharts库</strong></p><p>在网页文件（如.html或.jsp）包含JScharts库。</p><p>&lt;scripttype=&quot;text/javascript&quot; src=&quot;js/jscharts.js&quot;&gt;&lt;/script&gt;</p><p><strong>3. 定义容器</strong></p><p>要在网页文件上显示JScharts生成的图像，需要把此图像放入网页容器。此网页容器我们通常用&lt;div&gt;标签来定义，而且必须强制性地为此DIV元素指定唯一的ID值。比如：</p><p><strong>&lt;divid=&quot;chartcontainer&quot;&gt;This is just a replacement in case Javascriptis not available or used for SEO purposes&lt;/div&gt;</strong></p><p>注意：此DIV容器内的内容都会被JScharts图像所替代。</p><p><strong>4. 显示JScharts图像</strong></p><p>下面，我们需要写少量代码来显示一个线性图。首先要准备好图像所需的数据，我们可以用JavaScript数组来提供数据，数组中的每个元素都是由2个元素所组成。</p><p>代码如下：</p><pre class="brush:html;toolbar:false">&lt;scripttype=&quot;text/javascript&quot;&gt;
varmyData&nbsp;=&nbsp;new&nbsp;Array([10,20],&nbsp;[15,10],&nbsp;[20,30],&nbsp;[25,10],&nbsp;[30,5]);
varmyChart&nbsp;=&nbsp;new&nbsp;JSChart(&#39;chart_container&#39;,&nbsp;&#39;line&#39;);
myChart.setDataArray(myData);
myChart.draw();
&lt;/script&gt;</pre><p><strong>完整的代码如下：</strong></p><pre class="brush:html;toolbar:false">&lt;!DOCTYPE&nbsp;HTML&nbsp;PUBLIC&nbsp;&quot;-//W3C//DTD&nbsp;HTML&nbsp;4.01&nbsp;Transitional//EN&quot;&nbsp;&quot;http://www.w3.org/TR/html4/loose.dtd&quot;&gt;&nbsp;&nbsp;&nbsp;
&lt;html&gt;&nbsp;&nbsp;&nbsp;
&lt;head&gt;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&lt;title&gt;JScharts&nbsp;Test&lt;/title&gt;&nbsp;&nbsp;&nbsp;
&lt;/head&gt;&nbsp;&nbsp;&nbsp;
&lt;body&gt;&nbsp;&nbsp;&nbsp;
&lt;script&nbsp;type=&quot;text/javascript&quot;&nbsp;src=&quot;sources/jscharts.js&quot;&gt;&lt;/script&gt;&nbsp;&nbsp;&nbsp;
&lt;div&nbsp;&nbsp;id=&quot;chartcontainer&quot;&gt;This&nbsp;is&nbsp;just&nbsp;a&nbsp;replacement&nbsp;in&nbsp;case&nbsp;Javascript&nbsp;is&nbsp;not&nbsp;available&nbsp;or&nbsp;used&nbsp;for&nbsp;SEO&nbsp;purposes&lt;/div&gt;&nbsp;&nbsp;&nbsp;
&lt;script&nbsp;type=&quot;text/javascript&quot;&gt;&nbsp;&nbsp;&nbsp;
var&nbsp;myData&nbsp;=&nbsp;new&nbsp;Array([10,20],&nbsp;[15,10],&nbsp;[20,30],&nbsp;[25,10],&nbsp;[30,5]);&nbsp;&nbsp;&nbsp;
var&nbsp;myChart&nbsp;=&nbsp;new&nbsp;JSChart(&#39;chartcontainer&#39;,&nbsp;&#39;line&#39;);&nbsp;&nbsp;&nbsp;
myChart.setDataArray(myData);&nbsp;&nbsp;&nbsp;
myChart.draw();&nbsp;&nbsp;&nbsp;
&lt;/script&gt;&nbsp;&nbsp;&nbsp;
&lt;/body&gt;&nbsp;&nbsp;&nbsp;
&lt;/html&gt;&nbsp;&nbsp;&nbsp;&nbsp;


&lt;!DOCTYPE&nbsp;HTML&nbsp;PUBLIC&nbsp;&quot;-//W3C//DTD&nbsp;HTML&nbsp;4.01&nbsp;Transitional//EN&quot;&nbsp;&quot;http://www.w3.org/TR/html4/loose.dtd&quot;&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;html&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&lt;head&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&lt;title&gt;JScharts&nbsp;Test&lt;/title&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&lt;/head&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&lt;body&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;script&nbsp;type=&quot;text/javascript&quot;&nbsp;src=&quot;sources/jscharts.js&quot;&gt;&lt;/script&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;div&nbsp;id=&quot;chartcontainer&quot;&gt;This&nbsp;is&nbsp;just&nbsp;a&nbsp;replacement&nbsp;in&nbsp;case&nbsp;Javascript&nbsp;is&nbsp;not&nbsp;available&nbsp;or&nbsp;used&nbsp;for&nbsp;SEO&nbsp;purposes&lt;/div&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;script&nbsp;type=&quot;text/javascript&quot;&gt;&nbsp;&nbsp;&nbsp;&nbsp;
var&nbsp;myData&nbsp;=&nbsp;new&nbsp;Array([10,20],&nbsp;[15,10],&nbsp;[20,30],&nbsp;[25,10],&nbsp;[30,5]);&nbsp;&nbsp;&nbsp;&nbsp;
var&nbsp;myChart&nbsp;=&nbsp;new&nbsp;JSChart(&#39;chartcontainer&#39;,&nbsp;&#39;line&#39;);&nbsp;&nbsp;&nbsp;&nbsp;
myChart.setDataArray(myData);&nbsp;&nbsp;&nbsp;&nbsp;
myChart.draw();&nbsp;&nbsp;&nbsp;&nbsp;
&lt;/script&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&lt;/body&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;/html&gt;</pre><p><br/></p>

