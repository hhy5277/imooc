<p>暂无源码下载！<a href="http://wshome.sinaapp.com/h5-web/game/word-differ/game.html" target="_blank">游戏演示地址</a></p><p>另H5游戏—<a href="http://www.imooc.com/opus/resource?opus_id=884" target="_blank">疯狂的字母项目地址</a></p>

