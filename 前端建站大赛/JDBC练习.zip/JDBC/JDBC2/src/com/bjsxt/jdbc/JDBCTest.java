package com.bjsxt.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class JDBCTest {
	public static void main(String[] args){
		Connection conn=null;
		String url="jdbc:oracle:thin:@localhost:1521:orcl";
		String user="SCOTT";
		String password="tiger";
		Statement sttm=null;
		ResultSet rs=null;
		String sql="select * from dept";
		List<Object> list = null;
		try {
			//加载驱动
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//建立连接
			conn=DriverManager.getConnection(url, user, password);
			//创建会话
			sttm=conn.createStatement();
			//发送SQL语句，获得ResultSet;
			rs=sttm.executeQuery(sql);
			//处理ResultSet;
			list = new ArrayList<Object>();
			while(rs.next()){
				int deptno=rs.getInt(1);
				String dname=rs.getString(2);
				String loc=rs.getString(3);
				Dept d=new Dept(deptno,dname,loc);
//				System.out.println(deptno + "   " + dname + "   " + loc);
//				list.add(new Dept(deptno,dname,loc));
				list.add(d);
			}
			System.out.println("从数据库读取数据结束！");
			Iterator<Object> it=list.iterator();
			while(it.hasNext()){
				Object obj=it.next();
				System.out.println(obj);
			}
		} catch (ClassNotFoundException e) {
			System.out.println("驱动加载失败！");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(sttm!=null){
				try {
					sttm.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}

