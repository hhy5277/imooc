function changeColor1()
{
	document.getElementById("box1").style.backgroundColor = "lightgreen";
}
function changeColor2()
{
	document.getElementById("box2").style.backgroundColor = "lightgreen";
}
function changeColor3()
{
	document.getElementById("box3").style.backgroundColor = "lightgreen";
}
function reColor1()
{
	document.getElementById("box1").style.backgroundColor = "#FCAB7E";
}
function reColor2()
{
	document.getElementById("box2").style.backgroundColor = "#7D71E3";
}
function reColor3()
{
	document.getElementById("box3").style.backgroundColor = "#71D7E3";
}
function ordinary()
{
	document.getElementById("h3").innerHTML = "普通型计算器";
	document.getElementById("c11").style.display = "none";
	document.getElementById("c21").style.display = "none";
	document.getElementById("c31").style.display = "none";
	document.getElementById("c41").style.display = "none";
	document.getElementById("c51").style.display = "none";
	document.getElementById("c12").style.display = "none";
	document.getElementById("c22").style.display = "none";
	document.getElementById("c32").style.display = "none";
	document.getElementById("c42").style.display = "none";
	document.getElementById("c52").style.display = "none";
	document.getElementById("c13").style.display = "none";
	document.getElementById("c23").style.display = "none";
	document.getElementById("c33").style.display = "none";
	document.getElementById("c43").style.display = "none";
	document.getElementById("c53").style.display = "none";
}
function science()
{
	document.getElementById("h3").innerHTML = "科学型计算器";
	document.getElementById("c11").style.display = "block";
	document.getElementById("c21").style.display = "block";
	document.getElementById("c31").style.display = "block";
	document.getElementById("c41").style.display = "block";
	document.getElementById("c51").style.display = "block";
	document.getElementById("c12").style.display = "block";
	document.getElementById("c22").style.display = "block";
	document.getElementById("c32").style.display = "block";
	document.getElementById("c42").style.display = "block";
	document.getElementById("c52").style.display = "block";
	document.getElementById("c13").style.display = "none";
	document.getElementById("c23").style.display = "none";
	document.getElementById("c33").style.display = "none";
	document.getElementById("c43").style.display = "none";
	document.getElementById("c53").style.display = "none";
}
function program()
{
	document.getElementById("h3").innerHTML = "程序型计算器";
	document.getElementById("c11").style.display = "block";
	document.getElementById("c21").style.display = "block";
	document.getElementById("c31").style.display = "block";
	document.getElementById("c41").style.display = "block";
	document.getElementById("c51").style.display = "block";
	document.getElementById("c12").style.display = "block";
	document.getElementById("c22").style.display = "block";
	document.getElementById("c32").style.display = "block";
	document.getElementById("c42").style.display = "block";
	document.getElementById("c52").style.display = "block";
	document.getElementById("c13").style.display = "block";
	document.getElementById("c23").style.display = "block";
	document.getElementById("c33").style.display = "block";
	document.getElementById("c43").style.display = "block";
	document.getElementById("c53").style.display = "block";
}