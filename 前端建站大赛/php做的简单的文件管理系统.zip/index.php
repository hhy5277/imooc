<table width="100%" border="1" cellpadding="5" cellspacing="0" bgcolor="#ABCEDF">
<tr>
<td>���</td><td>�ļ���</td><td>����</td><td>�ļ���С</td><td>����ʱ��</td><td>�޸�ʱ��</td><td>����</td>
</tr>
<?php 
global $PH;
$PH='./';
if(!empty($_REQUEST['act'])&&$_REQUEST['act']=='indir'){
	$path = $_REQUEST['inin'];
	$path = dirname($_SERVER['PHP_SELF']).$path;
	$path = '.'.$path;
	$PH = $path;
	$dataz = cycledir($path);
}else{
 $dataz = cycledir();
 }
/*
 *�Ѷ�λ����ϲ���һλ����
 * */
$data1=!empty($dataz['file'])?$dataz['file']:'';
$data2=!empty($dataz['dir'])?$dataz['dir']:'';
if(empty($dataz['file'])){
$data = array_values($data2);	
}
elseif (empty($dataz['dir'])) {
$data = array_values($data1);
}else{
$data = array_merge_recursive($data1,$data2);
$data = array_values($data);
}
if(!empty($_REQUEST['act'])&&$_REQUEST['act']=='look'){
	$id = $_REQUEST['id'];
	$path = $data[$id];
	$text =	viewtext($path);
	$text2 = <<<EOF
<textarea disabled="disabled" cols="100" rows="7" style="background:pink">{$text}</textarea>
EOF;
	echo $text2;
}elseif(!empty($_REQUEST['act'])&&$_REQUEST['act']=='modify'){
	$id = $_REQUEST['id'];
	$path = $data[$id];
	$text =	viewtext($path);
	$text2 = <<<EOF
	<form action="index.php" method="post">
	<input type="hidden" name="id" value="{$id}">
<textarea cols="100" rows="7" style="background:pink" name="modify">{$text}</textarea><br />

<input type="submit" value="�޸�" style="width:200px;height:40px;line-height:40px;font-size:27px;">
</form>
EOF;
echo $text2;
	}elseif(!empty($_REQUEST['act'])&&$_REQUEST['act']=='rename'){
		$id = $_REQUEST['id'];
		 $text = $data[$id];
		var_dump($data);
		$text2 = <<<EOF
<form action="index.php" method="post">
<input type="text" value="{$text}" name="newname"/></br>
<input type="hidden" name="id" value="{$id}" />
<input type="submit" value="�޸�"/>|<input type="reset"/>
</form>
EOF;
echo $text2;
}elseif(!empty($_REQUEST['act'])&&$_REQUEST['act']=='unlink'){
	$id = $_REQUEST['id'];
	$path =	$data[$id];
	if(unlink($path)){
		promp("ɾ���ɹ�",'index.php');
	}else{
		promp("ɾ��ʧ��",'index.php');
	}
}
	if(!empty($_REQUEST['modify'])){
		$id = $_REQUEST['id'];
	if(file_put_contents($data[$id],$_REQUEST['modify'])){
	promp('�޸ĳɹ�','index.php');
	}else{
		promp('�޸�ʧ��','index.php');
	}
	}
	if(!empty($_REQUEST['newname'])){
	$id = $_REQUEST['id'];
		echo $oldname =	$data[$id];
		echo $nowname = $_REQUEST['newname'];
		renme($oldname,$nowname);
}
		
$i=1;
foreach( $data as $values ){
?>
<tr>
		<td><?php echo $i ?></td>
		<td><?php echo $values ?></td>
		<td><?php if(in_array($values,$dataz['file'])){
			echo '�ļ�';
		}else{
			echo '�ļ���';
		} ?></td>
		<td><?php 
		if(in_array($values,$dataz['file'])){
			$path = $PH.'/'.$values;
			echo changesize(filesize($path));
		}else{
			echo '�ļ���û��С';
		} ?></td>
		<td><?php echo date("Y-m-d H:i:s",filectime($path)) ?></td>
		<td><?php echo date("Y-m-d H:i:s",filemtime($path)) ?></td>
		<td><?php 
		if(in_array($values,$dataz['file'])){
			?>
			<a href="index.php?act=look&id=<?php echo $i-1 ?>" >�鿴</a>
			<a href="index.php?act=modify&id=<?php echo $i-1 ?>" >�޸�</a>
			<a href="index.php?act=rename&id=<?php echo $i-1 ?>">������</a>
			<a href="index.php?act=unlink&id=<?php echo $i-1 ?>">ɾ��</a>
			���� ����
			<?php
		}else{?>
         <a href="index.php?act=indir&inin=<?php $id=$i-1; echo $data[$id] ?>">�����ļ���</a> 
		<a href="index.php?act=rename&id=<?php echo $i-1 ?>">������</a> 
		<a href="index.php?act=unlink&id=<?php echo $i-1 ?>">ɾ��</a>
		 ����
		<?php } ?>
		</td>
</tr>
<?php 
	$i++;
}  ?>
</table>
<?php
/*
 *����·��
  ��������ļ���Ŀ¼
 * */
function cycledir($path='./'){
$dir = opendir($path);
while(($rdir=readdir($dir))!==false){
	if(is_file($path.'/'.$rdir)){
		$dataz['file'][]=$rdir;}
	if(is_dir($path.'/'.$rdir)&&$rdir!='.'&&$rdir!='..'){
		$dataz['dir'][]=$rdir;}
}
return $dataz;
}
/*
�����ʵ��ĵ�λ
*/
function changesize($size){
 $unit = array('B','KB','MB','GB','TB','PB','EB');
 $i=0;
 while($size>1024){
	 $size/=1024;
	 $i++;
 }
 if($i==0){
	 $ssize = $size.$unit[$i]; 
 }else{
 $size = numtwo($size);
 $ssize = $size.$unit[$i];
 }
echo $ssize;
}
/*
ȡС�������λ
*/
function numtwo($num){
	$afnum = strstr($num,'.');
	$afnum = substr($afnum,1,2);
	$bfnum = strstr($num,'.',true);
	$bnum = $bfnum.'.'.$afnum;
	return $bnum;
}
/*
����·�����鿴�ļ�����
*/
function viewtext($path){
	$data = file_get_contents($path);
	return $data;
}
/*
��ʾ�����ĳɹ�����ʧ��
*/
function promp($txt,$path){
echo <<<EOF
<script type="text/javascript">
alert('{$txt}');location.href="{$path}";
</script>
EOF;
}
/*
������
*/
function renme($oldname,$newname){
	if(rename($oldname,$newname)){
	promp("�������ɹ�",'index.php');
	}else{
		promp("������ʧ��",'index.php');
	}
	
}