<p>我的作品
 &nbsp; &nbsp;创建作品
 &nbsp; &nbsp;


 &nbsp; &nbsp;仿一号店首页，HTML+CSS+iconfont+JS+jQuery实现动态效果，基本布局3天，js效果两天，解决原网站缩小排版会乱的bug</p>

