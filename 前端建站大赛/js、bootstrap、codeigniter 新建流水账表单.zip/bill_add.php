    
      
      <div class="row">
        <div class="col-md-12">
          <h1 style="text-align:center;">
            <?php 
            if ($bill) echo '修改';
            else echo '增加';
            ?>账单
          </h1>
        </div>
      </div>
      
      <div class="row" ><!--style="padding:10px 180px;" -->
        <div class="col-md-12">
          <div style="color:red">
          <?php echo validation_errors(); ?>
          </div>
          
          <?php echo form_open('bill/modify/'.$id); ?>
            <div class="form-group">
              <label>时间：</label>
              <label for="time0">当前时间</label>
              <input type="radio" id="time0" name="time" value="0" <?php if (!$bill):?>checked="checked"<?php endif;?> onchange="time_input();"/>
              &nbsp;
              <label for="time1">自定义</label>
              <input type="radio" id="time1" name="time" value="1" <?php if ($bill):?>checked="checked"<?php endif;?> onchange="time_input();"/>
              <input type="text" id="timepicker1" name="timepicker1" <?php if (!$bill):?>style="display:none;"<?php else:?> value="<?=$bill->time;?>" <?php endif;?>/>
            </div>
            <div class="form-group">
              <label>进货/出货：</label>
              <label for="io0">进货</label>
              <input type="radio" id="io0" name="io" value="0" 
                <?php if ($bill && ($bill->io == 0)):?>checked="checked"<?php endif;?>
                onchange="radio_onchange();"/>
              &nbsp;
              <label for="io1">出货</label>
              <input type="radio" id="io1" name="io" value="1"
                <?php if ($bill && ($bill->io == 1)):?>checked="checked"<?php endif;?>
                onchange="radio_onchange();"/>
            </div>
            
            <div class="form-group" id="div_client">
              <label for="client">客户：</label>
              <select class="form-control" id="client" name='client'>
                <option value="0">缺省</option>
                <?php if (isset($client) && $client):?>
                <?php foreach($client->result() as $row):?>
                <option value="<?=$row->id;?>" 
                  <?php if($bill && ($bill->cid == $row->id)):?>selected <?php endif;?>
                  ><?=$row->name;?></option>
                <?php endforeach;?>
                <?php endif;?>
              </select>
              <a href="<?=site_url('client/modify');?>" class="btn btn-sm btn-primary" style="margin:10px;">或者，先去新建一条客户信息？</a>
            </div>
            
            <div class="form-group">
              <label>商品详情：</label>
              <div class="table-responsive">
                <table class="table table-striped table-hover" id="commodity">
                  <tr>
                    <td>编号</td>
                    <td>商品名称</td>
                    <td>单位</td>
                    <td>备注</td>
                    <td>库存</td>
                    <td>单价</td>
                    <td>购买数量</td>
                    <td>金额</td>
                  </tr>
                  
                  <?php if (isset($commodity) && $commodity):?>
                  <?php if (isset($bill) && $bill && $bill->goods_info)
                    $goods_info = unserialize($bill->goods_info);
                  ?>
                  <?php foreach($commodity->result() as $row):?>
                  <tr>
                    <td><?= $row->id;?></td>
                    <td><?= $row->name;?></td>
                    <td><?= $row->unit;?></td>
                    <td><?= $row->remark;?></td>
                    <td><?= $row->stock;?></td>
                    <td><?= $row->price;?></td>
                    <td>
                      <input type="number" name="num_<?= $row->bname;?>" 
                        class="form-control" price="<?= $row->price;?>"
                        bname="<?= $row->bname;?>" onkeyup="check(this);"
                        <?php
                          $value = '';
                          if($bill && $bill->goods_info){
                            if(is_array($goods_info)){
                              foreach($goods_info as $v){
                                if ($v['bname'] == $row->bname){
                                  $value = $v['num'];
                                }
                              }
                            }
                          }
                          if ($value) echo 'value="'.$value.'"';
                          else echo 'value="0"';
                        ?>
                        />
                    </td>
                    <td id="money_<?= $row->bname;?>">
                      0
                    </td>
                    <script>
                      $(function(){
                        $("#money_<?=$row->bname;?>").html( $("input[name=num_<?=$row->bname;?>]").val() * $("input[name=num_<?=$row->bname;?>]").attr("price") );
                      });
                    </script>
                  </tr>
                  <?php endforeach;?>
                  <?php endif;?>
                </table>
              </div>
            </div>
            
            <div class="form-group">
              <label for="total_money">总计：</label>
              <span id="total_money"><?php if($bill) echo $bill->money; else echo '0';?></span>&nbsp;元
              <input type="hidden" name="total_money" value="<?php if($bill) echo $bill->money; else echo '0';?>"/>
            </div>
            
            <div class="form-group">
              <label for="remark">备注：</label>
              <textarea class="form-control" id="remark" name='remark'>
                <?php if($bill && $bill->remark) echo $bill->remark;?>
              </textarea>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block" >保存</button>
          </form>
        </div>
      </div>
    
      <!-- 时间选择控件 -->
      <link rel="stylesheet" type="text/css" href="<?=base_url('tools/timepicker/css/jquery-ui.css');?>" />
      
      <script src="<?=base_url('tools/timepicker/js/jquery-1.7.2.min.js');?>"></script>
      <script src="<?=base_url('tools/timepicker/js/jquery-ui.js');?>"></script>
      <script src="<?=base_url('tools/timepicker/js/jquery-ui-slide.min.js');?>"></script>
      <script src="<?=base_url('tools/timepicker/js/jquery-ui-timepicker-addon.js');?>"></script>
      <script>
        $(function(){
          $('#timepicker1').datetimepicker();
          //<!-- end 时间选择控件 -->
          calculate_total_money();
          
        });
        
        function time_input(){
          if ( $("input[name=time]:checked").val() == 1)
            $("#timepicker1").show();
          else
            $("#timepicker1").hide();
        }
        
        function calculate_total_money(){
          var total_money = 0;
          var str = '';
          $("input[bname]").each(function(){
            money = $(this).val() * $(this).attr("price");
            total_money = money + total_money;
            if (money > 0)
              //str += money + ' + ';
              str += $(this).val() + 'x' + $(this).attr("price") + ' + ';
          });
          str = str.substring(0,str.length-3);
          str += ' = ' + total_money;
          //$("#total_money").html(total_money);
          if (total_money == 0)
            str = '0';
          $("#total_money").html(str);
          $("input[name=total_money]").val(total_money);
        }
        function check(o){
          $(o).val($(o).val().replace(/\D+/g,'') );
          $("#money_"+$(o).attr("bname")).html( $(o).val() * $(o).attr("price") );
          calculate_total_money();
        }
        function radio_onchange(o){
          var val = $("input[name=io]:checked").val();
          if (val == 0)
            $("#div_client").hide();
          else if(val == 1)
            $("#div_client").show();
        }
      </script>

