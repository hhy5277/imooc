<!doctype html>
<html>
  <head>
    <meta charset="utf-8"/>
    <title><?=$title?></title>
    <meta name="description" content="<?=$description?>"/>
    <meta name="keyword" content="<?=$keyword?>"/>
    <meta name="author" content="<?=$author?>"/>
    
    <!-- 新 Bootstrap 核心 CSS 文件 -->
    <link rel="stylesheet" href="http://cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap.min.css">

    <!-- 可选的Bootstrap主题文件（一般不用引入） -->
    <link rel="stylesheet" href="http://cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
    
    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="http://cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
  </head>
  
  <body>
    <div class="container" style="padding:30px 120px;">

