package com.bjsxt.number;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.bjsxt.util.DBUtil;

public class MyNumberDao extends NumberDaoAbstract{

	@Override
	/**
	 * 将 2 -- 10000之内的所有的偶数 存入数据库 type=os
	 * 将 2 -- 10000之内的所有的奇数 存入数据库 type=js
	 */
	public void doNumberInsert() {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		connection=DBUtil.getConnection();
		String sql="INSERT INTO T_NUMBER (ID,NUM,TYPE) VALUES(?,?,?)";
		try {
			preparedStatement=DBUtil.getPstmt(connection, sql);
			for(int i=2;i<=10000;i++){
				preparedStatement.setString(1, UUID.randomUUID().toString().replace("-",""));
				preparedStatement.setInt(2, i);
				if(i%2==0){
					preparedStatement.setString(3, "os");
				}else{
					preparedStatement.setString(3, "js");
				}
				preparedStatement.addBatch();
				preparedStatement.executeBatch();
			}	
		} catch (SQLException e) {
				e.printStackTrace();
		} finally{
			DBUtil.closeAll(connection, preparedStatement, null);
		}
	}
//	public boolean isPrime(int num) {
//		boolean flag=false;
//		Connection connection=null;
//		PreparedStatement preparedStatement=null;
//		ResultSet  resultSet=null;
//		String sql="SELECT TYPE FROM T_NUMBER WHERE NUM=?";
//		String type=null;
//		try {
//			//建立连接
//			connection=DBUtil.getConnection();
//			//创建会话
//			preparedStatement=DBUtil.getPstmt(connection, sql);
//			//为？赋值
//			preparedStatement.setInt(1, num);
//			resultSet=preparedStatement.executeQuery();
//			while(resultSet.next()){
//				type=resultSet.getString(1);
//				if(type.equalsIgnoreCase("OS")){
//					flag=true;
//				}
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		
//		return flag;
//	}

	@Override
	public String doNumberQuery(int num) {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet  resultSet=null;
		String sql="SELECT TYPE FROM T_NUMBER WHERE NUM=?";
		String type=null;
		String info=null;
		try {
			//建立连接
			connection=DBUtil.getConnection();
			//创建会话
			preparedStatement=DBUtil.getPstmt(connection, sql);
			//为？赋值
			preparedStatement.setInt(1, num);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				type=resultSet.getString(1);
				if(type.equalsIgnoreCase("OS")){
					info=num+" 是偶数！";
				}else{
					info=num+" 是奇数";
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return info;
	}

	@Override
	public Map<String, Integer> doNumberGroup() {
		// TODO Auto-generated method stub
		Map<String, Integer> map=new HashMap<String, Integer>();
		Connection connection=null;
		PreparedStatement preparedStatement=null; 
		ResultSet resultSet=null;
		connection=DBUtil.getConnection();
		int counterOS=0;
		int counterJS=0;
		try {
			String sql01="SELECT COUNT(NUM) FROM T_NUMBER WHERE TYPE='os'";
			preparedStatement=DBUtil.getPstmt(connection, sql01);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				counterOS=resultSet.getInt(1);
			}
			map.put("OS", counterOS);
			String sql02="SELECT COUNT(NUM) FROM T_NUMBER WHERE TYPE='js'";
			preparedStatement=DBUtil.getPstmt(connection, sql02);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				counterJS=resultSet.getInt(1);
			}
			map.put("JS", counterJS);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			DBUtil.closeAll(connection, preparedStatement, resultSet);
		}
		return map;
	}
	
}

