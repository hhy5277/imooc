package com.bjsxt.number;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;

public class TestNumber {
	public static void main(String[] args) {
		MyNumberDao mnd = new MyNumberDao();
		while (true) {
			System.out.println("*******************************");
			String choise = inputMessage("本程序提供以下功能：" + "\n1.向数据库中插入2-20000之间的数据" + "\n2.向数据库查询输入的数字是奇数还是偶数" + "\n3.分别统计出当前数据库中奇数和偶数分别有多少个" + "\n您的选择是【1-3】,任意字符退出：");
			if (Pattern.matches("\\d+", choise)) {
				int ch = Integer.parseInt(choise);
				switch (ch) {
				case 1:
					System.out.println("开始向数据库中插入2-10000之间的数字！");
					long time1 = System.currentTimeMillis();
					mnd.doNumberInsert();
					long time2 = System.currentTimeMillis();
					System.out.println("已向数据库中插入2-10000之间的数字,共花费" + (time2 - time1) + "毫秒");
					break;
				case 2:
					String inputNum = inputMessage("亲，你告诉我一个数，我就告诉你它是奇数还是偶数:");
					if (Pattern.matches("\\d+", inputNum)) {
						int num = Integer.parseInt(inputNum);
						String result = mnd.doNumberQuery(num);
						System.out.println(result);
					}
					break;
				case 3:
					Map<String, Integer> map = new HashMap<String, Integer>();
					map = mnd.doNumberGroup();
					int counterOS = map.get("OS");
					int counterJS = map.get("JS");
					System.out.println("数据库中偶数有" + counterOS + "个！" + "\n数据库中奇数有" + counterJS + "个！");
					break;
				default:
					System.out.println("请输入各功能所对应的正确数字！");
					break;
				}

			} else {
				System.out.println("感谢使用本软件，再见！");
				System.exit(0);
			}
		}
	}

	public static String inputMessage(String message) {
		System.out.print(message);
		Scanner sc = new Scanner(System.in);
		return sc.nextLine();
	}
}
