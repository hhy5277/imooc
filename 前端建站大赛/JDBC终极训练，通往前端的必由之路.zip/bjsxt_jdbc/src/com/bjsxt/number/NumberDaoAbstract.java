package com.bjsxt.number;

import java.util.Map;

public abstract class NumberDaoAbstract {
	/**
	 * 向数据库中插入数据
	 */
	public abstract void doNumberInsert();

	/**
	 * 向数据库查询输入的数字是奇数还是偶数
	 * @param num
	 * @return
	 */
	public abstract String doNumberQuery(int num);

	/**
	 * 分别统计出当前数据库中奇数和偶数分别有多少个
	 * @return
	 */
	public abstract Map<String, Integer> doNumberGroup();

	/**
	 * 测试目标数字是奇数还是偶数
	 * @param num
	 * @return 奇数true 偶数false
	 */
	public boolean isPrime(int num) {
		if (num <= 3) {
			return num > 1;
		} else if (num % 2 == 0 || num % 3 == 0) {
			return false;
		} else {
			for (int i = 5; i * i <= num; i += 6) {
				if (num % i == 0 || num % (i + 2) == 0) {
					return false;
				}
			}
			return true;
		}
	}
}
