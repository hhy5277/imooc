package com.bjsxt.user;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

public class User implements Serializable {
	private String id;
	private String uname;
	private String pwd;
	private String realname;
	private String gender;
	private String email;
	private Integer age;
	private Date createTime;
	private Date updateTime;

	/**
	 * 构造器
	 */
	public User() {
		this.id = UUID.randomUUID().toString().replace("-", "");
		this.createTime = new Date();
		this.updateTime = new Date();
	}

	public User(String uname, String pwd, String realname, String gender, String email, Integer age) {
		this();
		this.uname = uname;
		this.pwd = pwd;
		this.realname = realname;
		this.gender = gender;
		this.email = email;
		this.age = age;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	
	public String getRealname() {
		return realname;
	}

	public void setRealname(String realname) {
		this.realname = realname;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", uname=" + uname + ", pwd=" + pwd + ", realname=" + realname + ", gender=" + gender + ", email=" + email + ", age=" + age + ", createTime=" + createTime + ", updateTime=" + updateTime + "]";
	}

}
