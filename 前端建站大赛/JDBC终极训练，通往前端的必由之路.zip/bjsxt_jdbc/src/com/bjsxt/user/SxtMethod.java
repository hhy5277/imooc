package com.bjsxt.user;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SxtMethod {
	public static final String DATE_FORMAT="yyyy-MM-dd hh:mm:ss";
	public static String date2string(Date date) {
		if(date==null){
			date=new Date();
		}
		SimpleDateFormat sdf=new SimpleDateFormat(DATE_FORMAT);
		String str=sdf.format(date);
		return str;
	}
	public static Date string2date(String str){
		Date date=new Date();
		if(str!=null){
			SimpleDateFormat sdf=new SimpleDateFormat(DATE_FORMAT);
			try {
				date=sdf.parse(str);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return date;
	}
	

}
