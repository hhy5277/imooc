package com.bjsxt.user;

import java.util.List;

public interface UserDaoInterface {

	/**
	 * 将自己的个人信息插入至数据库
	 */
	public void doUserInsertSelf(User user);

	/**
	 * 向表中插入1000条记录
	 */
	public void doUserInsertList(List<User> userList);

	/**
	 * 查询出所有的用户信息
	 * @return
	 */
	public List<User> doUserQueryAll();

	/**
	 * 验证输入的用户名和密码是否匹配
	 * @param uname
	 * @param pwd
	 * @return
	 */
	public boolean doUserLogin(String uname, String pwd);

	/**
	 * 通过ID删除指定的用户信息
	 * @param id
	 * @return
	 */
	public boolean doUserDeleteById(String id);

	/**
	 * 通过I查询指定的用户信息
	 * @param id
	 * @return
	 */
	public User doUserQueryById(String id);

	/**
	 * 修改指定的用户信息
	 * @param user
	 */
	public void doUserUpdate(User user);

	/**
	 * 查询当前数据库中总共有多少条记录
	 */
	public void doUserRowCount();

	/**
	 * 根据页码数和每页显示的数量 查询出相应的用户信息
	 * @param pageNum 当前页码数
	 * @param pageSize 每页显示的数量
	 * @return 
	 */
	public List<User> doUserPaging(int pageNum, int pageSize);

	/**
	 * 根据查询出的用户信息生成一个XML文件
	 * @param list
	 * @param filePath
	 */
	public void createXml(List<User> list, String filePath);

	/**
	 * 删除所有的用户信息
	 */
	public void doUserDeleteAll();

	/**
	 * 根据指定路径的xml文件，获取里面所有的用户信息
	 * @param filePath
	 * @return
	 */
	public List<User> getUserFromXml(String filePath);

	/**
	 * 查看当前数据库共有多少条记录
	 * @return
	 */
	public int getRowCount();

}
