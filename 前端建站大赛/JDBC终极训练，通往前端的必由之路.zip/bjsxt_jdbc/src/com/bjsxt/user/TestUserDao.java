package com.bjsxt.user;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.UUID;
import java.util.regex.Pattern;


public class TestUserDao {
	public static void main(String[] args) {
		UserDao userDao=new UserDao();
		while(true){
			System.out.println("-------------------------------------------------------");
			System.out.println();
			String choise = inputMessage("本程序提供以下功能：" + "\n1.将自己的个人信息插入至数据库" + 
					"\n2.向表中插入1000条数据" + "\n3.将表中所有的数据查询出来" +
					"\n4.输入任意的ID删除数据库中指定ID对应的记录" + "\n5.输入任意的ID查询数据库中指定ID对应的记录" +
					"\n6.根据输入的用户名和密码验证是否匹配"+"\n7.将User对应数据库的数据进行修改"+
					"\n8.分页查询数据 LIMIT 起始位置,查询的记录数" + "\n9.将3返回的所有记录转存至XML文件,并将xml文件存放在src的根目录" +
					"\n10.删除数据库中所有的记录" + "\n11.将9生成的xml文件数据在转存至数据库,使用方法2" +
					"\n您的选择是【1-11】,其他任意字符退出：");
			if (Pattern.matches("\\d+", choise)) {
				int ch = Integer.parseInt(choise);
				switch (ch) {
				case 1:
					User user =new User("耶律阿古宝", "123456", "赵冉", "1", "ranarang8775@163.com", 18);
					System.out.println("正在插入数据");
					userDao.doUserInsertSelf(user);
					System.out.println("插入数据结束");
					break;
				case 2:
					List<User> userList=randomUserList(1000);
					userDao.doUserInsertList(userList);
					break;
				case 3:
					List<User> listUsers=userDao.doUserQueryAll();
					System.out.println("共有"+listUsers.size()+"条数据，遍历如下：");
					for (User user2 : listUsers) {
						System.out.println(user2.toString());
					}
					System.out.println("共有"+listUsers.size()+"条数据");
					break;
				case 4:
					String id=inputMessage("请输入您想要删除的数据的ID：");
					System.out.println(userDao.doUserDeleteById(id)?"删除成功！":"删除失败！");
					break;
				case 5:
					id=inputMessage("请输入您想要查询的数据的ID：");
					System.out.println(userDao.doUserQueryById(id));
					break;
				case 6:
					String uname=inputMessage("请输入您要查询的用户名：");
					String pwd=inputMessage("请输入对应的密码：");
					System.out.println(userDao.doUserLogin(uname, pwd)?"登陆成功!":"登录失败！");
					break;
				case 7:
					id=inputMessage("请输入您想要修改的数据的ID：");
					String realname =inputMessage("您要将用户真实姓名修改为：");
					user=userDao.doUserQueryById(id);
					user.setRealname(realname);
					userDao.doUserUpdate(user);
					break;
				case 8:
					String pageNumsString=inputMessage("请输入您要查询的页码数：");
					String pageSizeString=inputMessage("请输入每一页显示的数据条数：");
					int pageNum=0;
					int pageSize=0;
					if(pageNumsString.matches("\\d+")){
						pageNum=Integer.parseInt(pageNumsString);
					}
					if(pageSizeString.matches(pageSizeString)){
						pageSize=Integer.parseInt(pageSizeString);
					}
					List<User> list=userDao.doUserPaging(pageNum, pageSize);
					for (User user2 : list) {
						System.out.println(user2);
					}
					break;
				case 9:
					String filePath=System.getProperty("user.dir")+File.separator+"src"+File.separator+"users.xml";
					listUsers=userDao.doUserQueryAll();
					userDao.createXml(listUsers, filePath);
					break;
				case 10:
					userDao.doUserDeleteAll();
					break;
				case 11:
					filePath=System.getProperty("user.dir")+File.separator+"src"+File.separator+"users.xml";
					userList = userDao.getUserFromXml(filePath);
					userDao.doUserInsertList(userList);
					break;
				default:
					System.out.println("请输入各功能所对应的正确数字！");
					break;
				}
				
			} else {
				System.out.println("感谢使用本软件，再见！");
				System.exit(0);
			}
		}
	}
	
	
	private static List<User> randomUserList(int count) {
		List<User> userList=new ArrayList<User>();
		for(int i=0;i<count;i++){
			User user=new User();
			user.setUname(UUID.randomUUID().toString().replace("-", "").substring(0, 15));
			user.setPwd((int)(90000*Math.random()+10000)+"");
			user.setRealname(getRandomChar()+getRandomChar());
			user.setGender(Math.random()>0.5?"1":"2");
			user.setEmail(user.getUname()+"@bjsxt.com");
			user.setAge((int)(43*Math.random()+18));
			userList.add(user);
		}
		return userList;
	}

	public static String inputMessage(String message) {
		System.out.print(message);
		Scanner sc = new Scanner(System.in);
		return sc.nextLine();
	}
	public static String getRandomChar() {
		String str = "";
		int hightPos; 
		int lowPos;

		Random random = new Random();

		hightPos = (176 + Math.abs(random.nextInt(39)));
		lowPos = (161 + Math.abs(random.nextInt(93)));

		byte[] b = new byte[2];
		b[0] = (Integer.valueOf(hightPos)).byteValue();
		b[1] = (Integer.valueOf(lowPos)).byteValue();

		try {
			str = new String(b, "GBK");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			System.out.println("错误");
		}
		return str;
	}


}
