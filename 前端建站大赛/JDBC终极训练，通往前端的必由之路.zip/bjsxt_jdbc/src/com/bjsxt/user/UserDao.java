package com.bjsxt.user;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.stream.XMLOutputFactory;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import com.bjsxt.util.DBUtil;

public class UserDao implements UserDaoInterface {

	@Override
	public void doUserInsertSelf(User user) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String sql = "INSERT INTO USER VALUES(?,?,?,?,?,?,?,?,?)";
		try {
			connection = DBUtil.getConnection();
			preparedStatement = DBUtil.getPstmt(connection, sql);
			preparedStatement.setString(1, user.getId());
			preparedStatement.setString(2, user.getUname());
			preparedStatement.setString(3, user.getPwd());
			preparedStatement.setString(4, user.getRealname());
			preparedStatement.setString(5, user.getGender());
			preparedStatement.setString(6, user.getEmail());
			preparedStatement.setInt(7, user.getAge());
			preparedStatement.setTimestamp(8, new Timestamp(new Date().getTime()));
			preparedStatement.setTimestamp(9, new Timestamp(new Date().getTime()));
			int x = preparedStatement.executeUpdate();
			if (x > 0) {
				System.out.println("添加个人信息成功！");
			} else {
				System.out.println("添加个人信息失败！");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(connection, preparedStatement, null);
		}
	}

	@Override
	public void doUserInsertList(List<User> userList) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String sql = "INSERT INTO USER VALUES(?,?,?,?,?,?,?,?,?)";
		try {
			connection = DBUtil.getConnection();
			preparedStatement = DBUtil.getPstmt(connection, sql);
			System.out.println("正在向数据库中添加数据，请耐心等待！");
			for (User user : userList) {
				preparedStatement.setString(1, user.getId());
				preparedStatement.setString(2, user.getUname());
				preparedStatement.setString(3, user.getPwd());
				preparedStatement.setString(4, user.getRealname());
				preparedStatement.setString(5, user.getGender());
				preparedStatement.setString(6, user.getEmail());
				preparedStatement.setInt(7, user.getAge());
				preparedStatement.setTimestamp(8, new Timestamp(new Date().getTime()));
				preparedStatement.setTimestamp(9, new Timestamp(new Date().getTime()));
				preparedStatement.addBatch();
			}
			preparedStatement.executeBatch();
			System.out.println("数据添加完毕！");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(connection, preparedStatement, null);
		}
	}

	@Override
	public List<User> doUserQueryAll() {
		List<User> listUsers = new ArrayList<User>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String sql = "SELECT * FROM USER";
		try {
			connection = DBUtil.getConnection();
			preparedStatement = DBUtil.getPstmt(connection, sql);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				listUsers.add(DBUtil.result2bean(resultSet, User.class));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(connection, preparedStatement, resultSet);
		}

		return listUsers;
	}

	@Override
	public boolean doUserLogin(String uname, String pwd) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String sql = "SELECT * FROM USER WHERE UNAME=? AND PWD=?";
		try {
			connection = DBUtil.getConnection();
			preparedStatement = DBUtil.getPstmt(connection, sql);
			preparedStatement.setString(1, uname);
			preparedStatement.setString(2, pwd);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(connection, preparedStatement, resultSet);
		}
		return false;
	}

	@Override
	public boolean doUserDeleteById(String id) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String sql = "DELETE FROM USER WHERE ID=?";
		try {
			connection = DBUtil.getConnection();
			preparedStatement = DBUtil.getPstmt(connection, sql);
			preparedStatement.setString(1, id);
			int x = preparedStatement.executeUpdate();
			if (x == 1) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(connection, preparedStatement, null);
		}
		return false;
	}

	@Override
	public User doUserQueryById(String id) {
		User user = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String sql = "SELECT * FROM USER WHERE ID=?";
		try {
			connection = DBUtil.getConnection();
			preparedStatement = DBUtil.getPstmt(connection, sql);
			preparedStatement.setString(1, id);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				user = DBUtil.result2bean(resultSet, User.class);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(connection, preparedStatement, resultSet);
		}
		return user;
	}

	@Override
	public void doUserUpdate(User user) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String sql = "UPDATE USER SET UPDATETIME = NOW() , REALNAME = ? WHERE ID = ?";
		try {
			connection = DBUtil.getConnection();
			preparedStatement = DBUtil.getPstmt(connection, sql);
			preparedStatement.setString(1, user.getRealname());
			preparedStatement.setString(2, user.getId());
			int x = preparedStatement.executeUpdate();
			if (x == 1) {
				System.out.println("修改用户信息成功");
			} else {
				System.out.println("修改用户信息失败！");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(connection, preparedStatement, null);
		}
	}

	@Override
	public void doUserRowCount() {
		// TODO Auto-generated method stub

	}

	@Override
	public List<User> doUserPaging(int pageNum, int pageSize) {
		// TODO Auto-generated method stub
		List<User> listUsers = new ArrayList<User>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String sql = "SELECT * FROM USER LIMIT ?,?";
		try {
			connection = DBUtil.getConnection();
			preparedStatement = DBUtil.getPstmt(connection, sql);
			preparedStatement.setInt(1, (pageNum - 1) * pageSize);
			preparedStatement.setInt(2, pageSize);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				listUsers.add(DBUtil.result2bean(resultSet, User.class));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(connection, preparedStatement, resultSet);
		}
		return listUsers;
	}

	@Override
	public void createXml(List<User> list, String filePath) {
		Element rootElement = new Element("users");
		for (User user : list) {
			Element userElement = new Element("user").setAttribute("id", user.getId());
			userElement.addContent(new Element("uname").setText(user.getUname()));
			userElement.addContent(new Element("pwd").setText(user.getPwd()));
			userElement.addContent(new Element("realname").setText(user.getRealname()));
			userElement.addContent(new Element("email").setText(user.getEmail()));
			userElement.addContent(new Element("gender").setText("1".equals(user.getGender()) ? "男" : "女"));
			userElement.addContent(new Element("age").setText(user.getAge() + ""));
			userElement.addContent(new Element("createtime").setText(SxtMethod.date2string(user.getCreateTime())));
			userElement.addContent(new Element("updatetime").setText(SxtMethod.date2string(user.getUpdateTime())));
			rootElement.addContent(userElement);
		}
		try {
			Document document = new Document(rootElement);
			Format format = Format.getPrettyFormat();
			format.setEncoding("utf-8");
			XMLOutputter xop = new XMLOutputter(format);
			xop.output(document, new FileOutputStream(filePath));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void doUserDeleteAll() {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String sql = "DELETE FROM  USER";
		try {
			connection = DBUtil.getConnection();
			preparedStatement = DBUtil.getPstmt(connection, sql);
			int x = preparedStatement.executeUpdate();
			if (x > 0) {
				System.out.println("删除用户信息成功");
			} else {
				System.out.println("删除用户信息失败！");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(connection, preparedStatement, null);
		}
	}

	@Override
	public List<User> getUserFromXml(String filePath) {
		//声明集合
				List<User> userList = new ArrayList<User>();
				try {
					//开始解析XML文档
					Document document = new SAXBuilder().build(new FileInputStream(filePath));
					//获取根节点
					Element rootElement = document.getRootElement();
					//获取所有的子节点
					List<Element> elements = rootElement.getChildren();
					//遍历
					for (Element element : elements) {
						User user = new User();
						user.setId(element.getAttributeValue("id"));
						user.setUname(element.getChildText("uname"));
						user.setPwd(element.getChildText("pwd"));
						user.setRealname(element.getChildText("realname"));
						user.setGender("男".equals(element.getChildText("gender")) ? "1" : "2");
						user.setEmail(element.getChildText("email"));
						user.setAge(Integer.parseInt(element.getChildText("age")));
						user.setCreateTime(SxtMethod.string2date(element.getChildText("createtime")));
						user.setUpdateTime(SxtMethod.string2date(element.getChildText("updatetime")));
						//将对象存放至集合
						userList.add(user);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return userList;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 0;
	}

}
