第一题(使用oracle数据库完成)
	1.新建一张表 (使用sql developer建立就可以) 
		表名 
			t_number
		列
			id varchar2(40) pk  uuid.replace("-","")
			num number(5) 
			type varchar2(5)
	2.写一个方法
		将 2 -- 10000之内的所有的偶数 存入数据库 type=os
		将 2 -- 10000之内的所有的奇数 存入数据库 type=js
	3.写一个方法查询输入的数字是偶数还是奇数  public boolean query(int num);
		例如 查询 667 是奇数还是偶数
	4.写一个方法 分别统计出奇数和偶数分别有多少个
第二题mysql
	有一个User的Javabean
	private Integer id;
	private String uname;
	private String pwd;
	private String nickname;
	private String email;
	private Date createtime;
	private Date updatetime;	

	1.新建一张表
		表名 
			user
		列
			id int 10 自动增长 pk
			用户名 uname varchar 20
			密码 pwd varchar 20
			昵称 nickname 12
			性别 gender char(1)(男=1 女=2 )
			邮箱 email varchar 80 
			年龄 age int 3
			创建时间 createTime datetime
			修改时间 updateTime datetime
			
	21将自己的个人信息插入至数据库(自己的真实信息)		
			private Integer id;
			private String uname;
			private String pwd;
			private String nickname;
			private String email;
			private Date createtime;
			private Date updatetime;
	22.向表中插入数据，参数为List<User> 
		写一个方法 向表中插入1000条数据
			private Integer id; mysql自动增长
			private String uname;uuid前15位
			private String pwd;自动生成6位数字
			private String nickname;自动生成2-3个汉字(自己百度)
			private String email;生成的uname+"@bjsxt.com"
			private Date createtime;当前系统时间
			private Date updatetime;当前系统时间
	3.查询数据
		写一个方法将表中所有的数据查询出来,并返回
	31登录验证
		写一个方法 根据输入的用户名和密码验证是否匹配
	4.删除数据
		写一个方法 ，参数为ID  输入任意的ID删除数据库中指定ID对应的记录
	41查询数据
		写一个方法 ，参数为ID  输入任意的ID查询数据库中指定ID对应的记录
	5.修改数据
		写一个方法 ，参数为User 将User对应数据库的数据进行修改
	6.分页查询数据 LIMIT 起始位置,查询的记录数
		提供页码和每页显示的数量  
		例如 
			参数为1,10 说明取出数据库中第1-10条数据
			参数为2,10说明取出数据库中第11-20条数据
			参数为3,10说明取出数据库中第21-30条数据
			这是一个等差数列，找到规律，写出正确的sql查询语句
	7.操作记录
		将2返回的所有记录转存至XML文件,并将xml文件存放在src的根目录
		<?xml version='1.0' encoding="utf-8" ?>
		<users>
			<user id="1">
				<uname>zhangsan</uname>
				<pwd>123</pwd>
				<realname>....
				<gender>男/女
			</user>
			<user id="2">
				<uname>
				<pwd>
				<realname>....
			</user>
			...
			<user id="1000">
				<uname>
				<pwd>
				<realname>....
			</user>
		</users>
	8.删除数据库中所有的记录
	9.将7生成的xml文件数据在转存至数据库,使用方法2
	10. 简单思考下 面向接口编程的好处
			
			
			
			
			
			
			
			
			
			
			
			
			
			