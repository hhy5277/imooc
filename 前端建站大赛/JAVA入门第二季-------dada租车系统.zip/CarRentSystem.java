package dada;

import java.util.Scanner;

public class CarRentSystem {

    public static void main(String[] args) {
		Carbage a = new Carbage();
		a.printCars();
		User u1=new User("xiaoming","1234567890","1431314313");
		System.out.println("请输入你要租多少辆车");
		Scanner input=new Scanner(System.in);
		int carNum=input.nextInt();		//租车数量
		int totalMoney=0;				//总租金
		int totalLoad=0;				//总载重辆
		int totalPerson=0;				//总载客量
		for(int i=0;i<carNum;i++){
			System.out.print("请输入你要租的车号:");
			String num=input.next();
			System.out.print("该车租用时间:");
			int useTime=input.nextInt();
			
			/*
			 * if(a.checkCar(num))
			 * 查询是否存在某辆车
			 * 若存在,查询是否在车库中
			 */
			if(a.checkCar(num)){
				a.lend(num);
				u1.rentCar(num);
				/*
				 * 统计总金额
				 * 总载客量
				 * 以及总载货量
				 */
				totalMoney+=a.lendTo(num).getRentPerDay()*useTime;
				if(a.lendTo(num) instanceof Truck)
					totalLoad+=((Truck)a.lendTo(num)).getLoad();
				else if(a.lendTo(num) instanceof Bus)
					totalPerson+=((Bus)a.lendTo(num)).getPerson();
				else{
					totalPerson+=((PickupTruck)a.lendTo(num)).getPerson();
					totalLoad+=((PickupTruck)a.lendTo(num)).getLoad();
				}
			}
			else
				i--;
		}
		u1.printUserCar();
		System.out.println("总载客数"+totalPerson+"人;总载货量"+totalLoad+"吨;应付总金额:"+totalMoney);
		
		input.close();
	}
}

  

