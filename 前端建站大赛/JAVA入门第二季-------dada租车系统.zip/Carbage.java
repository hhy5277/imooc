package dada;

import java.util.*;

public class Carbage {
    public List<Car> cars;
	
	/*
	 * 建立车的List
	 */
	public Carbage(){
		this.cars=new ArrayList<Car>();
		addCars();
	}
	/*
	 * 向队列中添加车辆
	 */
	public void addCars(){
		Car[] temp={new Bus("1001","奥迪",2000,4),
				new Bus("1002","宝马",3000,4),
				new Bus("1003","奇瑞",2000,4),
				new Bus("1004","幻影",3000,4),
				new Truck("2001","重卡",5000,10),
				new Truck("2002","重卡",5000,10),
				new PickupTruck("3001","皮卡",1000,4,1),
				new PickupTruck("3002","皮卡",1000,4,1),
				new PickupTruck("3003","皮卡",1000,4,1)
				};
		cars.addAll(Arrays.asList(temp));
	}
	/*
	 * 打印输出车辆信息
	 */
	public void printCars(){
		System.out.println("本租车厂现有车辆信息，如下：");
		System.out.println("车辆编号\t"+"车辆名称\t"+"每日租金\t"+"载人\t\t"+"载货");
		System.out.println("*************************************************");
		for(Car x : cars){
			if(!x.getHave())
				continue;
			System.out.print(x.getCarId()+"\t\t"+x.getName()+"\t\t"+x.getRentPerDay()+"\t\t");
			if(x instanceof Bus){
				Bus y=(Bus)x;
				System.out.println(y.getPerson()+"人\t\t0");
			}
			else if(x instanceof Truck){
				Truck y=(Truck)x;
				System.out.println("0\t\t"+y.getLoad()+"吨");
			}
			else{
				PickupTruck y=(PickupTruck)x;
				System.out.println(y.getPerson()+"人\t\t"+y.getLoad()+"吨");
			}
		}
	}
	/*
	 * 检查是否存在查询的车,检查车是否在库中
	 */
	public Boolean checkCar(String carId){
		for(Car c:cars){
			if(c.getCarId().equals(carId)){
				if(!c.getHave())
					System.out.println("此车已被出租,请重新选择");
				return c.getHave();
			}
		}
		System.out.println("车库中没有这辆车");
		return false;
	}
	/*
	 * 成功租出一辆车
	 */
	public void lend(String carId){
		for(Car c:cars){
			if(c.getCarId().equals(carId)){
				c.setHave(false);
				break;
			}
		}
	}
	/*
	 * 把某辆车借给某个客户
	 */
	public Car lendTo(String carId){
		Car a = null;
		for(Car c:cars){
			if(c.getCarId().equals(carId)){
				a=c;
				break;
			}
		}
		return a;
	}
	/*
	 * 收回一辆车
	 */
	public void back(String carId){
		for(Car c:cars){
			if(c.getCarId().equals(carId)){
				c.setHave(true);
				break;
			}
		}
	}
}

  

