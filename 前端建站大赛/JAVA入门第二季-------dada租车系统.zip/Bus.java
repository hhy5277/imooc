package dada;

public class Bus extends Car {
    private int person;		//车辆载人数
	
	public Bus(){
		
	}
	
	public Bus(String carId,String name,int rentPerDay,int person){
		super.setCarId(carId);
		super.setName(name);
		super.setRentPerDay(rentPerDay);
		this.person=person;
	}
	
	public void setPerson(int person) {
		this.person = person;
	}
	public int getPerson(){
		return person;
	}
}


  

