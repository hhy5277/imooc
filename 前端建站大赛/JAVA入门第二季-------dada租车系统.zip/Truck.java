package dada;

public class Truck extends Car {
    private int load;			//可载货重量
	
	public Truck(){
		
	}
	public Truck(String carId,String name,int rentPerDay,int load){
		super.setCarId(carId);
		super.setName(name);
		super.setRentPerDay(rentPerDay);
		this.load=load;
	}
	public int getLoad(){
		return load;
	}
	public void setLoad(int load) {
		this.load = load;
	}
}

  

