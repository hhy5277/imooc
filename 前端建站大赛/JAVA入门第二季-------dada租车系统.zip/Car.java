package dada;

public class Car {
    private String name;		//车辆名字
	private int rentPerDay;	//每日租金
	private String carId;	//车编号
	private Boolean have=true;	//标签,true表示在库内,false表示被租出
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setRentPerDay(int rent) {
		this.rentPerDay=rent;
	}
	public int getRentPerDay() {
		return rentPerDay;
	}
	public String getCarId() {
		return carId;
	}
	public void setCarId(String carId) {
		this.carId = carId;
	}
	public Boolean getHave() {
		return have;
	}
	public void setHave(Boolean have) {
		this.have = have;
	}
	
}

  

