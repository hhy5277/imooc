package dada;

public class PickupTruck extends Car {
    private int person;			//可载人数
	private int load;				//可载货重量
	
	public PickupTruck(String carId,String name,int rentPerDay,int person,int load){
		super.setCarId(carId);
		super.setName(name);
		super.setRentPerDay(rentPerDay);
		this.person=person;
		this.load=load;
	}
	public void setPerson(int person) {
		this.person = person;
	}
	public void setLoad(int load) {
		this.load = load;
	}
	public int getPerson(){
		return person;
	}
	public int getLoad(){
		return load;
	}
}

  

