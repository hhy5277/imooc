package dada;

import java.util.*;

public class User {
    private String name;
	private String identifiedCardNum;
	private String tel;
	private List<Car> carOfUser;
	
	public User(String name,String identifiedCardNum,String tel){
		this.name=name;
		this.identifiedCardNum=identifiedCardNum;
		this.tel=tel;
		carOfUser=new ArrayList<Car>();
	}
	public String getName() {
		return name;
	}
	public String getIdentifiedCardNum() {
		return identifiedCardNum;
	}
	public String getTel() {
		return tel;
	}
	/*
	 * 显示用户租车信息
	 */
	public void printUserCar(){
		System.out.println("你拥有如下车辆：");
		System.out.println("车辆编号\t"+"车辆名称\t"+"每日租金\t"+"载人\t\t"+"载货");
		System.out.println("*************************************************");
		for(Car x : carOfUser){
			System.out.print(x.getCarId()+"\t\t"+x.getName()+"\t\t"+x.getRentPerDay()+"\t\t");
			if(x instanceof Bus){
				Bus y=(Bus)x;
				System.out.println(y.getPerson()+"人\t\t0");
			}
			else if(x instanceof Truck){
				Truck y=(Truck)x;
				System.out.println("0\t\t"+y.getLoad()+"吨");
			}
			else{
				PickupTruck y=(PickupTruck)x;
				System.out.println(y.getPerson()+"人\t\t"+y.getLoad()+"吨");
			}
		}
	}
	/*
	 * 租车
	 */
	public void rentCar(String carId){
		Car a=new Carbage().lendTo(carId);
		carOfUser.add(a);
	}
	/*
	 * 还车
	 */
	public void returnCar(String carId){
		for(Car c:carOfUser){
			if(c.getName().equals(carId))
				carOfUser.remove(c);
		}
	}
}

  

