/*日历控件*/
function GetDateStr(day, month) {
  var dd = new Date();
  dd.setDate(dd.getDate() + day);
  dd.setMonth(dd.getMonth() + month);
  var y = dd.getFullYear();
  var m = dd.getMonth() + 1;
  if (m < 10) {
    m = "0" + m;
  };
  var d = dd.getDate();
  if (d < 10) {
    d = "0" + d;
  }
  return y + "-" + m + "-" + d;
};

/**
	Create get date for each month to first day is what week;
	Aguments[0] is year;
	Aguments[1] is month;
**/
function getWeekFn(y, m) { //获取每月第一天是星期几
  var date = new Date(y, m - 1, 1);
  var w = date.getDay();
  return w;
}


function monthDay(y, m) { /*获取上月开始到结束时间的数值*/
  var date = new Date(y, m, 0)
  a = date.getDate();
  return a;
};
function chooseYear(){
  var yyr = GetDateStr(0,0);
  var arr = yyr.split("-");
  var y = parseInt(arr[0]);
  return y;
};
function chooseMonth(){
  var yyr = GetDateStr(0,0);
  var arr = yyr.split("-");
  var y = parseInt(arr[1]);
  return y;
};
var chooseDate = function(options) {
  this.id = options.id;
  this.year = chooseYear();
  this.month = chooseMonth();
  this.callback = options.callback;
  this.slogan = options.slogan;
}

chooseDate.prototype.createLayout = function() {
  var _this = this;
  $("#" + _this.id).on('click', function(event) {
    event.preventDefault();
    event.stopPropagation();
    _this.showDom();
  });
  return _this;
};

chooseDate.prototype.showDom = function() {
  var _this = this;
  var $ele = $("#" + _this.id);
  var datePosL = $ele.offset().left;
  var datePosT = $ele.offset().top + $ele.outerHeight() + 4;
  $("#wddateLayout").remove();
  var dtd = $.Deferred();
  var createDate = function(dtd) {
    $("body").append('<div id="wddateLayout"></div>');
    $("#wddateLayout").html(
      '<div id="wddatecontrols"></div><div id="wddatehowDay"><table><tr></tr></table></div><div id="wddatedateShow"><table></table></div><div id="slogo">'+_this.slogan+'</div>'
    ).css({
      'left': datePosL,
      'top': datePosT
    });
    var nowMonth = _this.month;
    if (nowMonth < 10) nowMonth = "0" + nowMonth;
    var controls =
      '<div id="wddate-year"><a class="last"><i class="glyphicon glyphicon-triangle-left"></i></a><input value="' +
      _this.year +
      '年" type="button"><a class="next"><i class="glyphicon glyphicon-triangle-right"></i></a></div>' +
      '<div id="wddate-month"><a class="last"><i class="glyphicon glyphicon-triangle-left"></i></a><input value="' +
      nowMonth +
      '月" type="button"><a class="next"><i class="glyphicon glyphicon-triangle-right"></i></a></div>';
    $("#wddatecontrols").html(controls);
    var strWeek = "";
    var weekName = ["日", "一", "二", "三", "四", "五", "六"];
    for (var i = 0; i < 7; i++) {
      strWeek += "<td data-day='" + i + "'>" + weekName[i] + "</td>";
    };
    $("#wddatehowDay").find('tr').html(strWeek);
    var strDay = "";
    var strDay2 = "";
    for (var i = 0; i < 7; i++) {
      strDay2 += "<td></td>";
    };
    for (var i = 0; i < 6; i++) {
      strDay += "<tr>" + strDay2 + "</tr>";
    };
    $("#wddatedateShow").find("table").html(strDay);
    var y = _this.year;
    var m = _this.month;
    var d = getWeekFn(y, m);
    var day = parseInt(monthDay(y, m));
    var lastDay = parseInt(monthDay(y, m - 1));
    var $week = $("#wddatehowDay").find('td');
    var $day = $("#wddatedateShow").find('td');
    $week.each(function(index, el) {
      var newD = parseInt($(this).attr("data-day"));
      if (d == newD) {
        var now = $(this).index();
        for (var i = 0; i < day; i++) {
          var now2 = i + 1;
          $day.eq(i + now).html("<span class='num'>" + now2 +
            "</span>").attr("data-index", now2).addClass(
            'thisMonthDay');
        };
      };

      for (var i = day; i < $day.length; i++) {
        var now3 = i - day + 1;
        $day.eq(i + now).html("<span class='num'>" + now3).css(
          'color',
          '#aaa');
      };
      for (var i = now; i > 0; i--) {
        var now4 = lastDay - now + i;
        $day.eq(i - 1).html("<span class='num'>" + now4).css('color',
          '#aaa');
      };
    });
    dtd.resolve();
  }
  $.when(createDate(dtd))
    .done(function() {
      $("#wddate-year").find(".last").on('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        _this.year--;
        _this.showDom();
      });
      $("#wddate-year").find(".next").on('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        _this.year++;
        _this.showDom();
      });
      $("#wddate-month").find(".last").on('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        _this.month--;
        if (_this.month == 0) {
          _this.year--;
          _this.month = 12;
        }
        _this.showDom();
      });
      $("#wddate-month").find(".next").on('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        _this.month++
          if (_this.month > 12) {
            _this.year++;
            _this.month = 1;
          }
        _this.showDom();
      });
      $("#wddateLayout").on('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
      });
    })
    .done(function() {
      $("#wddatedateShow").find(".thisMonthDay").on('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        var year = parseInt($("#wddate-year").find("input").val()),
          month = parseInt($("#wddate-month").find("input").val()),
          day = parseInt($(this).attr("data-index"));
        var thisDate = function() {
          if (month < 10) month = "0" + month;
          if (day < 10) day = "0" + day;
          return year.toString() + "-" + month.toString() + "-" + day
            .toString()
        }
        $("#" + _this.id).val(thisDate);
        $("#wddateLayout").remove();
        if (_this.callback) {
          _this.callback();
        }
      });
    })
    .done(function() {
      $(document).on('click', function(event) {
        event.preventDefault();
        $("#wddateLayout").remove();
      });
    });
}


