<pre class="brush:html;toolbar:false;">&lt;input&nbsp;type=&quot;text&quot;&nbsp;id=&quot;date&quot;&nbsp;/&gt;
&lt;script&nbsp;type=&quot;text/javascript&quot;&gt;
&nbsp;&nbsp;&nbsp;&nbsp;//不需要回调
&nbsp;&nbsp;&nbsp;&nbsp;var&nbsp;options&nbsp;=&nbsp;{&quot;id&quot;:&quot;date&quot;,&quot;slogan&quot;:&quot;我的日历&quot;}
&nbsp;&nbsp;&nbsp;&nbsp;var&nbsp;date&nbsp;=&nbsp;new&nbsp;chooseDate(options).createLayout();
&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;//带回掉函数
&nbsp;&nbsp;&nbsp;&nbsp;var&nbsp;options&nbsp;=&nbsp;{&quot;id&quot;:&quot;date&quot;,&quot;slogan&quot;:&quot;我的日历&quot;,&quot;callback&quot;:showValue}
&nbsp;&nbsp;&nbsp;&nbsp;var&nbsp;date&nbsp;=&nbsp;new&nbsp;chooseDate(options).createLayout();
&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;showValue(){
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;var&nbsp;_value&nbsp;=&nbsp;$(&quot;#date&quot;).val();
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;console.log(_value);
&nbsp;&nbsp;&nbsp;&nbsp;}
&lt;/script&gt;</pre><p><br/></p>

