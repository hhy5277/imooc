<pre class="brush:java;toolbar:false">import&nbsp;java.util.ArrayList;
import&nbsp;java.util.Collections;
import&nbsp;java.util.List;
import&nbsp;java.util.Random;

public&nbsp;class&nbsp;CollectionSort&nbsp;{

&nbsp;public&nbsp;static&nbsp;void&nbsp;main(String[]&nbsp;args)&nbsp;{
&nbsp;&nbsp;String&nbsp;str&nbsp;=&nbsp;&quot;0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ&quot;;
&nbsp;&nbsp;stringSort(str);
&nbsp;}

&nbsp;//随机字符串排序
&nbsp;public&nbsp;static&nbsp;void&nbsp;stringSort(String&nbsp;str)&nbsp;{
&nbsp;&nbsp;List&lt;String&gt;&nbsp;list&nbsp;=&nbsp;new&nbsp;ArrayList&lt;String&gt;();
&nbsp;&nbsp;Random&nbsp;rm&nbsp;=&nbsp;new&nbsp;Random();
&nbsp;&nbsp;Integer&nbsp;n;
&nbsp;&nbsp;for&nbsp;(int&nbsp;i&nbsp;=&nbsp;0;&nbsp;i&nbsp;&lt;&nbsp;10;&nbsp;i++)&nbsp;{
&nbsp;&nbsp;&nbsp;StringBuilder&nbsp;sb&nbsp;=&nbsp;new&nbsp;StringBuilder();
&nbsp;&nbsp;&nbsp;n&nbsp;=&nbsp;rm.nextInt(9)&nbsp;+&nbsp;1;&nbsp;&nbsp;//1~10之间的随机整数
&nbsp;&nbsp;&nbsp;for&nbsp;(int&nbsp;j&nbsp;=&nbsp;0;&nbsp;j&nbsp;&lt;&nbsp;n;&nbsp;j++)&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;index&nbsp;=&nbsp;rm.nextInt(str.length());
&nbsp;&nbsp;&nbsp;&nbsp;char&nbsp;c&nbsp;=&nbsp;str.charAt(index);&nbsp;&nbsp;//获取index位置所在的字符
&nbsp;&nbsp;&nbsp;&nbsp;sb.append(c).toString();&nbsp;&nbsp;//字符转换为字符串
&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;System.out.println(&quot;成功添加字符串：&quot;&nbsp;+&nbsp;sb);
&nbsp;&nbsp;&nbsp;list.add(sb.toString());
&nbsp;&nbsp;}
&nbsp;&nbsp;System.out.println(&quot;-----排序前-----&quot;);
&nbsp;&nbsp;for&nbsp;(String&nbsp;string1&nbsp;:&nbsp;list)&nbsp;{
&nbsp;&nbsp;&nbsp;System.out.println(&quot;元素&quot;&nbsp;+&nbsp;string1);
&nbsp;&nbsp;}
&nbsp;&nbsp;Collections.sort(list);
&nbsp;&nbsp;System.out.println(&quot;-----排序后-----&quot;);
&nbsp;&nbsp;for&nbsp;(String&nbsp;string2&nbsp;:&nbsp;list)&nbsp;{
&nbsp;&nbsp;&nbsp;System.out.println(&quot;元素&quot;&nbsp;+&nbsp;string2);
&nbsp;&nbsp;}
&nbsp;}
}</pre>

