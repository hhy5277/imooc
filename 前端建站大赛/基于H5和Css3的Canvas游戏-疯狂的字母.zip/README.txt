<p>暂不开放源码下载。<a href="http://wshome.sinaapp.com/h5-web/game/drop-words/index.html" target="_blank">游戏演示地址</a></p><p>另CSS3游戏-<a href="http://www.imooc.com/opus/resource?opus_id=937" target="_blank">火眼金睛项目地址</a></p>

