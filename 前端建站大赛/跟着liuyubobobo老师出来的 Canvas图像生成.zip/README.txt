<p>学习老师提到的图像学编程挑战。目前只是照搬。</p><p>效果网址：</p><p><a href="http://apptingno.sinaapp.com/demo/canvas/img3.html" target="_blank">演示效果</a><br/></p>

