function windowToCanvas(x,y){
    
    var bbox = canvas.getBoundingClientRect();
    return {x: x-bbox.left, y:y-bbox.top};    
}





function drawImageByScale(scale){
	
    var ImageWidth = 1152 * scale;
    var ImageHeight = 600 * scale;

    var dx = canvas.width/2 - ImageWidth / 2 ;
    var dy = canvas.height/2 - ImageHeight / 2;
    
    context.clearRect(0,0,canvas.width,canvas.height);
    context.drawImage(image, dx, dy, ImageWidth, ImageHeight);
    context.drawImage(watermarkCanvas , canvas.width - watermarkCanvas.width, canvas.height - watermarkCanvas.height);
}




//花绿地


function drawLand(cxt,x,y,width,height){

	cxt.save();
    
    
    cxt.beginPath();
    cxt.moveTo(x,y);
 	cxt.bezierCurveTo(200,200,400,400,800,300);
    cxt.lineTo(width,height);
    cxt.lineTo(0,height);
    cxt.closePath();
    
    var landStyle = cxt.createLinearGradient(0, height,0,height/2);
    landStyle.addColorStop(0.0,'#030');
    landStyle.addColorStop(1.0,'#580');
    cxt.fillStyle = landStyle;
    cxt.fill();
    
    cxt.restore();

}


//画月亮
    
    function fillMoon(cxt,d,x,y,R,rot,/*optional*/ fillColor){
    	
        cxt.save();
        cxt.translate(x,y);
        cxt.rotate(rot * Math.PI/180);
        cxt.scale(R,R);
        
        pathMoon2(cxt,d);
        
        cxt.fillStyle = fillColor || '#fb5';
        cxt.fill();
        cxt.restore();
    }
    
    function pathMoon(cxt,d){  //arcTo方式画曲线
        
    	cxt.beginPath();
        cxt.arc(0,0,1,0.5*Math.PI,1.5*Math.PI,true);
        cxt.moveTo(0,-1);
        cxt.arcTo(d,0,0,1,dis(0,-1,d,0)/d);
        cxt.closePath();
        
    }

    function dis(x1,y1,x2,y2){
    	return Math.sqrt( (x1-x2)*(x1-x2)+ (y1-y2)*(y1-y2) );
    }



	function pathMoon2(cxt,d){ //贝塞尔二次方式画曲线
		
        cxt.beginPath();
        cxt.arc(0,0,1,0.5*Math.PI,1.5*Math.PI,true);
        cxt.moveTo(0,-1);
        cxt.quadraticCurveTo(1,0,0,1);
        cxt.closePath();
        
	}	

	
    

    
    
    //arcTo 画图
    
    function arcToTest(cxt,x0,y0,x1,y1,x2,y2,R,f,s){
    	
        subline = s || 'false';
        
        cxt.beginPath();
        cxt.moveTo(x0,y0);
    	cxt.arcTo(x1,y1,x2,y2,R);
    	
        cxt.lineWidth = 2;
        cxt.strokeStyle = 'red';
        cxt.stroke();

		cxt.beginPath();
        cxt.moveTo(x0,y0);
        cxt.lineTo(x1,y1);
        cxt.lineTo(x2,y2);
            
        cxt.lineWidth = 2;
        cxt.strokeStyle = 'gray';
        cxt.stroke();
           
    }
    
    
    //绘制圆角矩形
    
    function fillRoundRect( cxt, x, y, width, height, r, fillColor){
    
        if( 2*r > width || 2*r>height)
            return;
        
        cxt.save();
        cxt.translate(x,y);
    	pathRoundRect (cxt, width, height, r);
    	cxt.fillStyle = fillColor || 'black';
        cxt.fill();
        cxt.restore();    
    }
    
    
    function strokeRoundRect( cxt , x, y, width, height, r, /*option*/ lineWidth, strokeColor){        
        
        if( 2*r > width || 2*r>height)
            return;
        
        cxt.save();
        cxt.translate(x,y);
    	pathRoundRect (cxt, width, height, r);
        cxt.lineWidth = lineWidth || 1;
    	cxt.strokeStyle = strokeColor || 'black';
        cxt.stroke();
        cxt.restore();
    }
    
    function pathRoundRect(cxt, width, height, r){
    	cxt.beginPath();
        cxt.arc( width-r,height-r, r, 0, Math.PI/2);
    	cxt.lineTo(r,height);
        cxt.arc(r,height-r,r, Math.PI/2, Math.PI);
        cxt.lineTo(0,r);
        cxt.arc(r,r,r,Math.PI,Math.PI*1.5);
        cxt.lineTo(width-r,0);
        cxt.arc(width-r,r,r, Math.PI*1.5, Math.PI*2);
        cxt.closePath();
    }
    
    
    
    //绘制圆形
    
    function drawCirel(cxt,x,y,r) {
    	cxt.beginPath();
        cxt.arc(x, y, r, 0, 2* Math.PI );    
        cxt.stroke();
    }
    
    
    /*
    函数名称：drawRect
    函数作用：绘制矩形
    参数： 对象cxt,起始坐标x，起始坐标y， 宽width，高height，边框宽度borderWidth,边框颜色borderColor,填充颜色fillColor
    
    */
    function drawRect(cxt,x,y,width,height,borderWidth,borderColor,fillColor){
    	cxt.beginPath();
        cxt.moveTo(x,y);
        cxt.lineTo(x+width,y);
        cxt.lineTo(x+width,y+height);
        cxt.lineTo(x,y+height);
        cxt.closePath();
        
        cxt.lineWidth = borderWidth;
        cxt.fillStyle = fillColor;
        cxt.strokStyle = borderColor;
        
        cxt.fill();
        cxt.stroke();
    }
    
    function drawRect2(cxt,x,y,width,height,borderWidth,borderColor,fillColor){

        cxt.lineWidth = borderWidth;
        cxt.fillStyle = fillColor;
        cxt.strokStyle = borderColor;
        
        cxt.fillRect(x,y,width,height);
        cxt.strokeRect(x,y,width,height);
        
    }
    
    // 绘制五角星
    
    function drawStar(cxt,x,y,R,r,borderWidth,borderColor,fillColor,rot,borderJoin){
        
    	cxt.beginPath();
        for(var i=0; i<5; i++){
            cxt.lineTo(Math.cos( ( 18 + i * 72 -rot) / 180 * Math.PI ) * R + x ,-Math.sin( ( 18 + i * 72 -rot)/ 180 * Math.PI ) * R + y );
            cxt.lineTo(Math.cos( ( 54 + i * 72 -rot) / 180 * Math.PI ) * r + x ,-Math.sin( ( 54 + i * 72 -rot)/ 180 * Math.PI ) * r + y );
        }
        cxt.lineWidth = borderWidth;
        cxt.strokeStyle = borderColor;
        cxt.fillStyle = fillColor;
        cxt.lineJoin = borderJoin;
        cxt.closePath();

        cxt.fill();
        cxt.stroke();
    };
    

	// 通用函数
	function g(selector){
        var method = selector.substr(0,1) == '.' ? 'getElementsByClassName' : 'getElementById';
        return document[method](selector.substr(1));
    }

  

