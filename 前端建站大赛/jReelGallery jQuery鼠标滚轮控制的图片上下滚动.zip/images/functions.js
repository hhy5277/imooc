/*!
 * Interactive images gallery
 * http://www.marcelljusztin.com/
 *
 * Copyright 2010, Marcell Jusztin
 * Dual licensed under the MIT or GPL Version 2 licenses.
 *
 * Includes jQuery library
 * http://jquery.com/
 * Copyright 2010, John Resig
 * Dual licensed under the MIT or GPL Version 2 licenses.
 *
 * Date: 
 */


$(document).ready(function() {

	$('#rightside').css('height',$(window).height());
	$('#images').css('height',$(window).height());
	
});

/*function gallery() {
	fullHeight = 0;
	lastHeight = 0;
		
	function setHeight() {
		var oLi = document.getElementById('images');
		if(oLi.firstChild) { // check for children
			var oChild = oLi.firstChild;
			while(oChild) { // run over them
				if(oChild.nodeType==1) { // element
					var h = $(oChild).children().children().height();
					fullHeight += h;
					lastHeight = h;
					$(oChild).height(h);
				}
				oChild = oChild.nextSibling;
			}
		}
	}
	setHeight();
		
		
	dy = -100;
	s = 0.2;
	delta = 0;
	f = 20
	//items = countChildElements("images","li");
	
	window["timer" + 123] = window.setInterval(update,33);	
	
	
	
	$(document).mousewheel(
		function(event, delta){
			if((dy < (-1 * ((fullHeight + 150) - $('#images').height() + $('#images li').height())) && delta < 0) || ( dy > -200 && delta > 0 )) {
				f = f / 1.5;
			} else {
				f = 20;
			}
			dy += delta * f;
		}
	);
	
	$(document).keydown(
		function(event){
			if((dy < (-1 * ((fullHeight + 150) - $('#images').height() + $('#images li').height())) && event.keyCode == 40) || ( dy > -200 && event.keyCode == 38 )) {
				f = f / 1.5;
			} else {
				f = 20;
			}
			if(event.keyCode == 40) dy += -1.6 * f;
			if(event.keyCode == 38) dy += 1.6 * f;
			if(event.keyCode == 36) dy = -100;
			if(event.keyCode == 35) dy = -1*((fullHeight) - $('#images').height() + lastHeight * 2);
		}		
	);
	
	
	
	function countChildElements(parent, child) {
        var parent = document.getElementById(parent);
        var childCount = parent.getElementsByTagName(child).length;
		return childCount;
    }

	$('ul#images li').hover(
		function() {
			$(this).css('box-shadow','0px 0px 10px #747474, 0px 0px 10px #747474');
			$(this).css('-moz-box-shadow','0px 0px 10px #747474, 0px 0px 10px #747474');
			$(this).css('-webkit-box-shadow','0px 0px 10px #747474, 0px 0px 10px #747474');
			$(this).css('-o-box-shadow','0px 0px 10px #747474, 0px 0px 10px #747474');
		}
		,
		function() {
			$(this).css('box-shadow','none');
			$(this).css('-moz-box-shadow','none');
			$(this).css('-webkit-box-shadow','none');
			$(this).css('-o-box-shadow','none');
		}
	)
	
	function update(){		
		y = $('#images li').offset().top;
		y += (dy-y)*s;
		//$('ul#images li').html(y);
		$('#images li').css('top', y);
	}
}*/	
