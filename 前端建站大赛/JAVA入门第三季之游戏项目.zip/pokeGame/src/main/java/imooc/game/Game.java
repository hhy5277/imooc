package imooc.games;

import java.util.Collections;
import java.util.ArrayList;
import java.util.Random;
import java.util.Comparator;

// decorse sort
class CardComparator implements Comparator<Card>{

    @Override
    public int compare(Card card1, Card card2) {
    	if (card1.points.compareTo(card2.points) > 0 ) {
    		return  -1;
    	}
    	else if (card1.points.compareTo(card2.points) < 0) {
    		return 1;
    	}
    	else
    	{
    		if (card1.color.compareTo(card2.color) > 0) {
    			return 1;
    		}
    		else if (card1.color.compareTo(card2.color) < 0) {
    			return -1;
    		}
    		else
    		{
    			return 0;
    		}
    	}
    }
}

public class Game{

	public void runGame() throws Exception
	{
		// generate Cards
		CardsFactory cf = new CardsFactory();
		ArrayList<Card> cards = cf.getCards();

		// random cards
		System.out.println("-----------------------------");
		System.out.println("Begin random the cards...");
		cards = randomCards(cards);
		System.out.println("Done random cards.");
		System.out.println("-----------------------------");

		// show cards
		//showCards(cards);

		// create players
		PlayerFactory pf = new PlayerFactory();
		pf.createPlayers();
		ArrayList<Player> players = pf.getPlayers();

		// hand out the cards
		System.out.println("-----------------------------");
		System.out.println("Handing out cards...");
		for (int i = 0; i < Player.MaxCard; ++i) 
		{
			for (int j = 0; j < PlayerFactory.MaxPlayer; ++j) 
			{
				Card card = cards.get(i*PlayerFactory.MaxPlayer + j);
				System.out.println("Player: " + players.get(j).getName() + " is getting the "+ (i+1) +" cards..."+ (i*j+j)+" - " + card);
				players.get(j).addHandCards(card);
			}			
		}
		System.out.println("Done! has hand out cards.");
		System.out.println("-----------------------------");

		// who is win
		ArrayList<Card> playerOneCards = players.get(0).getHandCards();
		ArrayList<Card> playerTwoCards = players.get(1).getHandCards();

		CardComparator cardComparator = new CardComparator();
		Collections.sort(playerOneCards, cardComparator);
		Collections.sort(playerTwoCards, cardComparator);

		Card cardOne = playerOneCards.get(0);
		Card cardTwo = playerTwoCards.get(0);

		System.out.println("-----------------------------");
		if (cardComparator.compare(cardOne, cardTwo) > 0) {
			System.out.println(players.get(1).getName() + "Win.");
		}
		else if (cardComparator.compare(cardOne, cardTwo) < 0) {
			System.out.println(players.get(0).getName() + "Win.");
		}
		System.out.println("-----------------------------");

		// show each one's handCards
		System.out.println("-----------------------------");
		for (int i = 0; i < PlayerFactory.MaxPlayer; ++i) 
		{
			ArrayList<Card> handCards = players.get(i).getHandCards();
			System.out.print("\n"+players.get(i) + " has cards: ");
			for (int j = 0; j < handCards.size(); ++j) 
			{
				System.out.print(handCards.get(j) + " ");
			}	
			System.out.print("\n");		
		}
		System.out.println("-----------------------------");
		System.out.println("Game Over!");
		System.out.println("-----------------------------");
	}

	// random shufft algorithm
	private ArrayList<Card> randomCards(ArrayList<Card> cards)
	{
		Random random = new Random();
		for (int i = cards.size() - 1; i > 0; --i) {
			int j = random.nextInt(i);
			Collections.swap(cards, i, j);
		}
		return cards;
	}

	public void showCards(ArrayList<Card> cards)
	{
		System.out.println("\nWe have those Cards:");

		System.out.println("{ ");
		for (int i = 0; i < cards.size(); ++i) {
			Card card = cards.get(i);
			System.out.print(card);
			if ((i != 0) && ((i + 1) % Card.CardPoints.length == 0)) {
				System.out.print("\n");
			}
			else {
				System.out.print(",");
			}
			
		}
		System.out.println(" }");
	}
	
	public static void main(String[] args) throws Exception
	{
		Game game = new Game();

		game.runGame();
	}
}