package imooc.games;

enum CardColor
{
	SPADES, HEARTS, DIAMONDS, CLUBS;
}

public class Card
{
	public static String[] CardPoints = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};

	public String points;
	public CardColor color;

	public Card(CardColor cc, String cp)
	{
		this.points = cp;
		this.color = cc;
	}

	public String toString()
	{
		return "[" + color + ", " + points + "] ";
	}
}