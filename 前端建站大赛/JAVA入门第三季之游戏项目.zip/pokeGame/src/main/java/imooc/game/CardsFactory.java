package imooc.games;

import java.util.ArrayList;
import java.util.EnumSet;

class CardsFactory
{
	private static ArrayList<Card> cards = new ArrayList<Card>();

	CardsFactory()
	{
		generateCards();

		showCards();
	}

	private void generateCards()
	{
		System.out.println("-----------------------------");
		System.out.println("Generating cards, please wait...");

		for (CardColor color : EnumSet.range(CardColor.SPADES, CardColor.CLUBS)) {
			for (String points : Card.CardPoints) {
				cards.add(new Card(color, points));
			}			
		}

		System.out.println("Generating cards, Finished! :)");
		System.out.println("-----------------------------");
	}

	public ArrayList<Card> getCards()
	{
		return cards;
	}

	public void showCards()
	{
		System.out.println("-----------------------------");
		System.out.println("\nWe have those Cards:");

		System.out.println("{ ");
		for (int i = 0; i < cards.size(); ++i) {
			Card card = cards.get(i);
			System.out.print(card);
			if ((i != 0) && ((i + 1) % Card.CardPoints.length == 0)) {
				System.out.print("\n");
			}
			else {
				System.out.print(",");
			}
			
		}
		System.out.println(" }");
		System.out.println("-----------------------------");
	}

	public static void main(String[] args) {
		CardsFactory cf = new CardsFactory();
	}
}