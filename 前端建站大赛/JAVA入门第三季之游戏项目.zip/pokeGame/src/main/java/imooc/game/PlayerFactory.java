package imooc.games;

import java.util.ArrayList;
import java.util.Scanner;

public class PlayerFactory
{
	public final static int MaxPlayer = 2;
	private ArrayList<Player> players = new ArrayList<Player>();
	
	public void showPlayers()
	{
		System.out.println("-----------------------------");
		for (Player player : players) {
			System.out.println("welcome player: " + player);
		}
		System.out.println("-----------------------------");
	}

	public PlayerFactory(){ }

	public ArrayList<Player> getPlayers()
	{
		return this.players;
	}

	public void createPlayers() throws Exception
	{
		generatePlayers();

		showPlayers();
	}

	public void restart()
	{
		for ( int i = 0; i < MaxPlayer; ++i ) {
			players.get(i).clearHandCards();
		}
	}

	private void generatePlayers() throws Exception
	{
		while (players.size() < MaxPlayer) {
			System.out.println("Please input the " + (players.size()+1) + " players's ID And name.");

			Scanner sc = new Scanner(System.in);
			int id = 0;
			try
			{
				id = sc.nextInt();
			}
			catch (Exception e) {
				System.out.println("Please input the Integer id!");
				id = sc.nextInt();
				continue;
			}

			if (containsPlayer(String.valueOf(id))) {
				System.out.println("The id has been registed, please try another id.");
				continue;
			}

			System.out.println("Please input the " + (players.size()+1) + " players's name.");
			String name = sc.next();

			players.add(new Player(String.valueOf(id), name));
		}
	}

	public boolean containsPlayer(String id)
	{
		for ( int i = 0; i < players.size(); ++i ) {
			if(players.get(i).getId().equals(id))
			{
				return true;
			}
		}
		return false;
	}

	public static void main(String[] args) throws Exception{
		PlayerFactory pf = new PlayerFactory();
		pf.createPlayers();
	}
}