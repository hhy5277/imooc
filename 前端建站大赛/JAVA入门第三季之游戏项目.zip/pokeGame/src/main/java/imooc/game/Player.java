package imooc.games;

import java.util.ArrayList;

public class Player
{
	public final static int MaxCard = 2;
	private String id;
	private String name;
	private ArrayList<Card> handCards = new ArrayList<Card>();

	public Player(String id, String name)
	{
		this.id = id;
		this.name = name;
	}

	public String getId()
	{
		return this.id;
	}

	public String getName()
	{
		return this.name;
	}
	
	public ArrayList<Card> getHandCards()
	{
		return handCards;
	}

	public void addHandCards(Card card)
	{
		if (handCards.size() >= MaxCard) {
			System.out.println("Every Player at most have "+ MaxCard + " cards.");
			return;
		}

		handCards.add(card);
	}

	public void clearHandCards()
	{
		handCards.clear();
	}

	public String toString()
	{
		return "id:" + this.id + " name:" + this.name;
	}
}