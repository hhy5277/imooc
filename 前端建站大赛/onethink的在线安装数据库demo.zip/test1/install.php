<?php
/**
 * Created by PhpStorm.
 * User: XL
 * Date: 2015/8/24
 * Time: 15:34
 */
if(version_compare(PHP_VERSION,'5.3.0','<')) die('require PHP > 5.3.0 !');

$_GET['m'] = 'Install';
/**
 * 系统调试设置
 * 项目正式部署后请设置为false
 */
define ( 'APP_DEBUG', true );

/**
 * 应用目录设置
 * 安全期间，建议安装调试完成后移动到非WEB目录
 */
define ( 'APP_PATH', './App/' );
//缓存目录
define('RUNTIME_PATH','./Runtime/');

require './ThinkPHP/ThinkPHP.php';