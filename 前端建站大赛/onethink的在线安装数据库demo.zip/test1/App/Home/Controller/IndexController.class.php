<?php
/**
 * Created by PhpStorm.
 * User: XL
 * Date: 2015/8/25
 * Time: 16:51
 */
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        echo "这是首页<br />";
    }
}