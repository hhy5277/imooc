<?php
/**
 * Created by PhpStorm.
 * User: XL
 * Date: 2015/8/24
 * Time: 15:22
 */
if(version_compare(PHP_VERSION,'5.3.0','<')) die('require PHP > 5.3.0 !');

define('APP_DEBUG',true);
//应用目录
define('APP_PATH','App/');

if(!is_file(APP_PATH.'Install/Data/install.lock')){
    header('Location: ./install.php');//安装数据库
    exit;
}

//缓存目录
define('RUNTIME_PATH','Runtime/');

require_once 'ThinkPHP/ThinkPHP.php';