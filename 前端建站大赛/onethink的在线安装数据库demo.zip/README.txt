<p>这是从onethink扒下来的数据库在线安装demo</p><p><br/></p><p>将App/Install/Data/install.lock文件删除即重新安装(记得删除数据库)</p><p><br/></p><p>Runtime和Uploads这两个文件夹只是环境检测的时候验证是否有读写权限的</p><p><br/></p><p>使用: 将自己的sql文件放在App/Install/Data/下重命名为install.sql即可,</p><p>&nbsp; &nbsp; &nbsp; 不重命名自己修改function.php的创建数据表函数改为读取自己的sql文件;</p><p><br/></p><p>ps: ThinkPHP就不保留了，自己去官网下，放在项目根目录下(App同级目录)即可</p><p><br/></p>

