锘縰sing UnityEngine;
using System.Collections;

public class StoryBoard1 : MonoBehaviour {
	float[] timeArray = new float[]{7,9,11,13,15,17};
	int index;
	
	public GameObject particle;
	public GameObject bat;
	public GameObject face;
	public GameObject word;
	bool canClick;
	// Use this for initialization
	void Start () {
		particle.SetActive (false);
		bat.SetActive (false);
		face.SetActive (false);
		word.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
		if (index < timeArray.Length && Time.realtimeSinceStartup >= timeArray [index]) {
			OnTime(index);
			index++;
		}
//		if (canClick && Input.GetMouseButtonUp (0)) {
//			word.SetActive(true);
//		}
	}
	void OnTime(int index)
	{
		Debug.Log (index);
		switch(index)
		{
		case 0:
			particle.SetActive(true);
			break;
		case 1:
			bat.SetActive(true);
			break;
		case 2:
			bat.GetComponent<AudioSource>().Play();
			break;
		case 3:
			face.SetActive(true);
			break;
		case 4:
			face.GetComponent<AudioSource>().Play();
			break;
		
		case 5:
			word.SetActive(true);
			break;
		}
	}

}
