package com.newtion.controller;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.newtion.daoimp.CinemaDAOImp;
import com.newtion.daoimp.HallSessionDAOImp;
import com.newtion.model.Cinema;
import com.newtion.view.Message_View;

/**
 * 控制管理员模式下管理影院界面的逻辑实现
 * 
 * @author Administrator
 *
 */
public class ControlAdminManCinema_View {

	/**
	 * 将所有影院信息显示到管理员界面的影院管理JTable中
	 * 
	 * @return
	 */
	public static Object[][] showCinemas() {
		List<Cinema> cinemas = new CinemaDAOImp().showCinemas();
		int len = cinemas.size();
		Object[][] obj = new Object[len][4];
		List<Integer> halls = new ArrayList<Integer>();
		int j = 0;
		for (Cinema cinema : cinemas) {
			int cid = cinema.getCid();
			String cname = cinema.getCname();
			String address = cinema.getAddress();
			halls = new HallSessionDAOImp().findHalls(cid);
			Object[] oj = { cid, cname, address, halls };
			for (int i = 0; i < 4; i++) {
				obj[j][i] = oj[i];
			}
			j++;
		}
		return obj;
	}

	/**
	 * 管理员模式--影院管理界面--显示所选一行到对应文本框中
	 */
	public static void adminToShowAll(JTable table, JTextField cinema_id,
			JTextField cinema_name, JTextField cinema_address,
			JTextField halls, int selRow) {
		String cid, cname, caddress,hallss;
		cid = table.getValueAt(selRow, 0).toString().trim();
		cname = table.getValueAt(selRow, 1).toString().trim();
		caddress = table.getValueAt(selRow, 2).toString().trim();
		hallss = table.getValueAt(selRow, 3).toString().trim();
		cinema_id.setText(cid);
		cinema_name.setText(cname);
		cinema_address.setText(caddress);
		halls.setText(hallss+" 号");
	}

	/**
	 * 管理员添加影院
	 */
	public static void adminToaddCinema(String cname, String address,
			JTable table) {

		// 添加影院时，影院名一定不能为空
		if (cname.length() == 0) {
			Message_View.warningDialog("影院名称不能为空！");
		} else {
			Cinema cinema = new Cinema();
			cinema.setCname(cname);
			cinema.setAddress(address);
			boolean bool = new CinemaDAOImp().addCinema(cinema);
			if (bool == true) {
				Message_View.infoDialog("添加影院成功，系统自动分配ID!");
				table.setModel(new DefaultTableModel(ControlAdminManCinema_View
						.showCinemas(), new String[] { "ID",
						"\u5F71\u9662\u540D\u5B57", "\u5F71\u9662\u5730\u5740",
						"\u573A\u5385" }));
			} else {
				Message_View.infoDialog("该影院名已存在，请重新添加!");
			}
		}
	}

	/**
	 * 管理员删除影院
	 */
	public static void adminToDeleteCinema(String cname, JTable table) {
		// 删除影院时，影院名一定不能为空
		if (cname.length() == 0) {
			Message_View.warningDialog("影院名称不能为空！");
		} else {
			Cinema cinema = new Cinema();
			cinema.setCname(cname);
			boolean bool = new CinemaDAOImp().deleteCinemaByName(cinema);
			if (bool == true) {
				Message_View.infoDialog("删除影院成功!");
				table.setModel(new DefaultTableModel(ControlAdminManCinema_View
						.showCinemas(), new String[] { "ID",
						"\u5F71\u9662\u540D\u5B57", "\u5F71\u9662\u5730\u5740",
						"\u573A\u5385" }));
			} else {
				Message_View.infoDialog("该影院不存在，请确定影院后重新删除!");
			}
		}
	}

	/**
	 * 管理员通过影院名查看影院信息
	 */
	public static void adminToSelectCinema(JTextField cinema_id, String cname,
			JTextField cinema_address) {
		// 查询用户时，用户名和ID一定不能同时为空

		if (cname.length() == 0) {
			Message_View.warningDialog("查询影院时，影院名不能为空！");
		} else {
			Cinema cinema = new CinemaDAOImp().findCinemaByName(cname);
			if (cinema == null) {
				Message_View.infoDialog("该影院不存在，请确定影院后重新查找！");
			} else {
				cinema_id.setText(cinema.getCid() + "");
				cinema_address.setText(cinema.getAddress());
				Message_View.showCinema(cinema);
			}
		}
	}

	/**
	 * 管理员修改影院地址信息
	 */
	public static void adminToUpdateCinema(String cname, String address,
			JTable table) {
		// 修改影院地址时，影院名一定不能为空
		if (cname.length() == 0) {
			Message_View.warningDialog("影院名称不能为空！");
		} else {
			if (address.length() == 0) {
				Message_View.infoDialog("请填写该影院的最新地址!");
			} else {
				Cinema cinema = new Cinema();
				cinema.setCname(cname);
				boolean bool = new CinemaDAOImp().findCinemaByName(cinema);
				if (bool == true) {
					new CinemaDAOImp().updateCinemaAddress(cname, address);
					Message_View.infoDialog("修改影院地址成功!");
					table.setModel(new DefaultTableModel(
							ControlAdminManCinema_View.showCinemas(),
							new String[] { "ID", "\u5F71\u9662\u540D\u5B57",
									"\u5F71\u9662\u5730\u5740", "\u573A\u5385" }));
				} else {
					Message_View.infoDialog("该影院不存在，请重新选择!");
				}
			}
		}
	}
}
