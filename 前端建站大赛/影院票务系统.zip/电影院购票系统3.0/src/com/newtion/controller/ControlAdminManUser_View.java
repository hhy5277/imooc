package com.newtion.controller;

import java.util.List;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.newtion.daoimp.UserDAOImp;
import com.newtion.model.User;
import com.newtion.view.Message_View;

/**
 * 控制管理员模式下的管理用户界面的逻辑实现
 * 
 * @author Administrator
 *
 */
public class ControlAdminManUser_View {

	/**
	 * 将所有用户信息显示到管理员界面的用户管理JTable中
	 * 
	 * @return
	 */
	public static Object[][] showUsers() {

		UserDAOImp udi = new UserDAOImp();
		List<User> users = udi.showUsers();
		int len = users.size();
		Object[][] obj = new Object[len][5];
		int j = 0;
		for (User user : users) {
			int id = user.getId();
			String name = user.getName();
			String password = user.getPassword();
			int level = user.getLevel();
			Double balance = user.getBalance();
			Object[] oj = { id, name, password, level, balance };
			for (int i = 0; i < 5; i++) {
				obj[j][i] = oj[i];
			}
			j++;
		}
		return obj;
	}

	/**
	 * 管理员添加用户
	 */
	public static void adminToaddUser(String name, String password, JTable table) {
		User user = null;
		// 添加用户时，用户名一定不能为空
		if (name.trim().length() == 0) {
			Message_View.warningDialog("用户名不能为空！");
		} else {
			if (password.length() == 0) {
				user = new User(name, 000);
			} else {
				user = new User(name, password);
			}
			boolean bool = new UserDAOImp().addUser(user);
			if (bool == true) {
				Message_View.infoDialog("添加用户成功!");
				refreshTable(table);
			} else {
				Message_View.infoDialog("该用户名已存在，请重新添加！");
			}
		}
	}

	/**
	 * 管理员删除用户
	 */

	public static void adminToDeleteUser(String name, JTable table) {
		boolean bool;
		// 无法删除管理员
		if ("admin".equals(name)) {
			Message_View.warningDialog("无法删除管理员帐号!");
		} else {
			// 根据用户名删除用户
			if (name.trim().length() != 0) {
				User user = new User(name);
				bool = new UserDAOImp().deleteByName(user);
				if (bool == true) {
					Message_View.infoDialog("删除用户成功!");
					refreshTable(table);
				} else {
					Message_View.infoDialog("删除用户失败! 该帐号尚存余额，或尚未注册。");
				}
			}
			// 删除用户失败---必须指定用户名
			else {
				Message_View.warningDialog("用户名不能为空！");
			}
		}
	}

	/**
	 * 管理员修改用户信息
	 */

	public static void adminToUpdate(String name, String password, JTable table) {

		User user = adminSelectUser(name);
		if (user != null) {
			// 无法修改管理员信息
			if ("admin".equals(name)) {
				Message_View.warningDialog("无法修改管理员信息!");
			} else {
				if (password.length() == 0) {
					password = "000";
				}
				user.setName(name);
				user.setPassword(password);
				boolean flag = new UserDAOImp().adminUpdateUser(user);
				if (flag == true) {
					Message_View.infoDialog("该用户密码修改成功！");
					refreshTable(table);
				} else {
					Message_View.infoDialog("修改失败！");
				}
			}
		}
	}

	/**
	 * 管理员通过用户名查询用户信息
	 */
	public static User adminSelectUser(String name) {
		User user = null;
		// 查询用户时，用户名不能为空
		if (name.length() == 0) {
			Message_View.warningDialog("用户名不能为空！");
		} else {
			user = new UserDAOImp().findUserByName(new User(name));
			if (user == null) {
				Message_View.infoDialog("该用户名尚未注册，请重新查找！");
			} else {
				return user;
			}
		}
		return null;
	}

	/**
	 * 管理员模式--用户管理界面--显示所选一行到对应文本框中
	 */

	public static void adminToShowAll(JTable table, JTextField user_id,
			JTextField user_name, JTextField user_password,
			JTextField user_level, JTextField user_balance, int selRow) {

		String id, name, password, level, balance;
		id = table.getValueAt(selRow, 0).toString().trim();
		name = table.getValueAt(selRow, 1).toString().trim();
		password = table.getValueAt(selRow, 2).toString().trim();
		level = table.getValueAt(selRow, 3).toString().trim();
		balance = table.getValueAt(selRow, 4).toString().trim();
		user_id.setText(id);
		user_name.setText(name);
		user_password.setText(password);
		user_level.setText(level);
		user_balance.setText(balance);
	}

	public static void refreshTable(JTable table) {
		table.setModel(new DefaultTableModel(

		ControlAdminManUser_View.showUsers(),// 显示所有用户

				new String[] { "ID", "\u59D3\u540D", "\u5BC6\u7801",
						"\u7B49\u7EA7", "\u4F59\u989D" }) {
			private static final long serialVersionUID = 1L;
			@SuppressWarnings("rawtypes")
			Class[] columnTypes = new Class[] { Integer.class, String.class,
					String.class, Integer.class, Double.class };

			public Class<?> getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
	}
}
