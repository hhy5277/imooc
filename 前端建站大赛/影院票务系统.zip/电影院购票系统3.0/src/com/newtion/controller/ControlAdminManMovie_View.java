package com.newtion.controller;

import java.util.List;

import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.newtion.daoimp.MovieDAOImp;
import com.newtion.model.Movie;
import com.newtion.view.Message_View;

/**
 * 控制管理员模式下管理电影界面的逻辑实现
 * 
 * @author Administrator
 *
 */
public class ControlAdminManMovie_View {

	/**
	 * 将所有影片信息显示到管理员界面的电影管理JTable中
	 * 
	 * @return
	 */
	public static Object[][] showMovies() {

		MovieDAOImp mdi = new MovieDAOImp();
		List<Movie> movies = mdi.showMovies();
		int len = movies.size();
		Object[][] obj = new Object[len][6];
		int j = 0;
		for (Movie movie : movies) {
			int cid = movie.getMid();
			String cname = movie.getMname();
			String type = movie.getType();
			String actor = movie.getActors();
			int duration = movie.getDuration();
			String detail = movie.getDetail();
			Object[] oj = { cid, cname, type, actor, duration, detail };
			for (int i = 0; i < 6; i++) {
				obj[j][i] = oj[i];
			}
			j++;
		}
		return obj;
	}

	/**
	 * 管理员模式--影片管理界面--显示所选一行到对应文本框中
	 */
	public static void adminToShowAll(JTable table, JTextField movie_id,
			JTextField movie_name, JTextField movie_type,
			JTextField movie_actors, JTextField movie_duration,
			JTextArea movie_detail, int selRow) {
		String mid, mname, type, actors, duration, detail;
		mid = table.getValueAt(selRow, 0).toString().trim();
		mname = table.getValueAt(selRow, 1).toString().trim();
		type = table.getValueAt(selRow, 2).toString().trim();
		actors = table.getValueAt(selRow, 3).toString().trim();
		duration = table.getValueAt(selRow, 4).toString().trim();
		detail = table.getValueAt(selRow, 5).toString().trim();
		movie_id.setText(mid);
		movie_name.setText(mname);
		movie_type.setText(type);
		movie_actors.setText(actors);
		movie_duration.setText(duration);
		movie_detail.setText(detail);
	}

	/**
	 * 管理员添加电影
	 */
	public static void adminToaddMovie(Movie movie, JTable table) {
		// 添加电影时，电影名一定不能为空
		if(movie.getMname().length() != 0){
			boolean bool = new MovieDAOImp().addMovie(movie);
			if (bool == true) {
				Message_View.infoDialog("添加影片成功，系统自动分配ID!");
				table.setModel(new DefaultTableModel(
				// 刷新列表
						ControlAdminManMovie_View.showMovies(), new String[] {
								"ID", "\u7247\u540D", "\u7C7B\u578B",
								"\u4E3B\u6F14", "\u65F6\u957F",
								"\u5F71\u7247\u4ECB\u7ECD" }));
			} else {
				Message_View.infoDialog("该影片名已存在，请重新添加!");
			}
		}else{
			Message_View.warningDialog("新添加的电影名不能为空!");
		}
	}

	/**
	 * 管理员删除影片
	 */
	public static void adminToDeleteMovie(String mname, JTable table) {
		// 删除电影时，影片名一定不能为空
		if (mname.length() == 0) {
			Message_View.warningDialog("影片名称不能为空！");
		} else {
			Movie movie = new Movie();
			movie.setMname(mname);
			boolean bool = new MovieDAOImp().deleteMovieByName(movie);
			if (bool == true) {
				Message_View.infoDialog("删除影片成功!");
				table.setModel(new DefaultTableModel(
				// 刷新列表
						ControlAdminManMovie_View.showMovies(), new String[] {
								"ID", "\u7247\u540D", "\u7C7B\u578B",
								"\u4E3B\u6F14", "\u65F6\u957F",
								"\u5F71\u7247\u4ECB\u7ECD" }));
			} else {
				Message_View.infoDialog("该影片不存在，请确定后重新删除!");
			}
		}
	}

	/**
	 * 管理员通过电影名查看电影信息
	 */
	public static void adminToSelectMovie(String mname, JTextField movie_id,
			JTextField movie_name, JTextField movie_type,
			JTextField movie_actors, JTextField movie_duration,
			JTextArea movie_detail) {
		// 查询电影时，电影名一定不能为空
		if (mname.length() == 0) {
			Message_View.warningDialog("查询影片时，影片名不能为空！");
		} else {
			Movie movie = new MovieDAOImp().findMovieByName(mname);
			if (movie == null) {
				Message_View.infoDialog("该影片不存在，请确定影片后重新查找！");
			} else {
				Message_View.infoDialog("查询成功！");
				movie_id.setText(movie.getMid() + "");
				movie_name.setText(movie.getMname());
				movie_type.setText(movie.getType());
				movie_actors.setText(movie.getActors());
				movie_duration.setText(movie.getDuration() + "");
				movie_detail.setText(movie.getDetail());
			}
		}
	}

	/**
	 * 管理员修改影片信息
	 */
	public static void adminToUpdateMovie(Movie movie, JTable table) {
		// 修改影片时，影片名一定不能为空
		if (movie.getMname().length() == 0) {
			Message_View.warningDialog("影片名称不能为空！");
		} else {
			boolean bool = new MovieDAOImp().findMovieByName02(movie);
			if (bool == true) {
				new MovieDAOImp().updateMovie(movie);
				Message_View.infoDialog("修改影片信息成功!");
				//刷新列表
				table.setModel(new DefaultTableModel(
				ControlAdminManMovie_View.showMovies(), new String[] { "ID",
						"\u7247\u540D", "\u7C7B\u578B", "\u4E3B\u6F14",
						"\u65F6\u957F", "\u5F71\u7247\u4ECB\u7ECD" }));
			} else {
				Message_View.infoDialog("该影片不存在，请重新选择!");
			}

		}
	}
}
