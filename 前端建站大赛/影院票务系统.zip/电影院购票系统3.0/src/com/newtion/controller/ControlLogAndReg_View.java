package com.newtion.controller;
import com.newtion.daoimp.UserDAOImp;
import com.newtion.model.User;

public class ControlLogAndReg_View {

	/**
	 * 用户登录方法
	 * @param user
	 * @return
	 */

	public static boolean UserLog(User user) {
		UserDAOImp udi = new UserDAOImp();
		boolean bool = udi.findUser(user);
		if (bool == true) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 管理员登录方法
	 */
	public static boolean AdminLog(User user) {
		UserDAOImp udi = new UserDAOImp();
		boolean bool = udi.findAdminByName(user);
		if (bool == true) {
			return true;
		} else {
			return false;
		}
	}
	
	
	/**
	 * 用户注册方法
	 */
	public static boolean UserReg(User user) {
		UserDAOImp udi = new UserDAOImp();
		boolean bool = udi.addUser(user);
		if (bool == true) {
			return true;
		} else {
			return false;
		}
	}
}
