package com.newtion.controller;

import java.awt.Choice;

import com.newtion.daoimp.UserDAOImp;

public class ControlUserAddMoney_View {

	private static UserDAOImp udi = new UserDAOImp();

	/**
	 * 用户充值
	 * @param name
	 * @param money
	 */
	public static void addMoney(String name, double money) {
		
		udi.updateBalance(name, money);
	}
	
	
	/**
	 * 显示可以充值的面额
	 * @param choice
	 */
	public static void showMoney(Choice choice){
		
		for (int i = 50; i <= 1000; i = i + 50) {
			choice.add(i + "");
		}
	}
}
