package com.newtion.controller;

import java.awt.TextField;

import javax.swing.JTextField;

import com.newtion.daoimp.UserDAOImp;
import com.newtion.view.Message_View;

/**
 * 控制用户修改个人信息的类
 * 
 * @author Administrator
 *
 */
public class ControlUserModif_View {

	public static void userModif(TextField newPassword,
			TextField newPassword02, JTextField user_name) {
		if (newPassword.getText().length() == 0
				|| newPassword02.getText().length() == 0) {
			Message_View.warningDialog("用户名或密码不能为空！");
		} else if (newPassword.getText().equals(newPassword02.getText()) == false) {
			Message_View.warningDialog("两次输入的密码不相同，请重新输入！");
		} else {
			new UserDAOImp().userUpdateNamePass(newPassword.getText().trim(),
					user_name.getText().trim());
			Message_View.infoDialog("更改密码成功！");
		}
	}
}
