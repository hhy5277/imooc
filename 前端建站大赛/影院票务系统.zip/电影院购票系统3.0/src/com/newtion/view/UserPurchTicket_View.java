package com.newtion.view;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.newtion.controller.ControlAdminManHST_View;
import com.newtion.controller.ControlUserPurchTicket_View;
import com.newtion.daoimp.MovieDAOImp;
import com.newtion.model.Movie;
import com.newtion.model.Session;
import com.newtion.model.User;

//管理员对电影的场厅场次的管理界面
public class UserPurchTicket_View extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTextField hs_id;
	private JTextField hs_hid;
	private JTextField hs_cname;
	private JTextField hs_mname;
	private Choice choice_row;
	private Choice choice_colum;
	private int level01;
	public SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
	private JTextField hs_time;
	private JTextField hs_price;
	private JTextField hs_sites;
	private JTextField textField_Cost;
	private JTextField textField_discount;
	private Session session;
	private JButton btnA_1;
	private JButton btnA_2;
	private JButton btnA_3;
	private JButton btnA_4;
	private JButton btnA_5;
	private JButton btnA_6;

	private JButton btnB_1;
	private JButton btnB_2;
	private JButton btnB_3;
	private JButton btnB_4;
	private JButton btnB_5;
	private JButton btnB_6;

	private JButton btnC_1;
	private JButton btnC_2;
	private JButton btnC_3;
	private JButton btnC_4;
	private JButton btnC_5;
	private JButton btnC_6;

	private JButton btnD_1;
	private JButton btnD_2;
	private JButton btnD_3;
	private JButton btnD_4;
	private JButton btnD_5;
	private JButton btnD_6;

	private JButton btnE_1;
	private JButton btnE_2;
	private JButton btnE_3;
	private JButton btnE_4;
	private JButton btnE_5;
	private JButton btnE_6;

	private JButton btnF_1;
	private JButton btnF_2;
	private JButton btnF_3;
	private JButton btnF_4;
	private JButton btnF_5;
	private JButton btnF_6;

	private JButton button_4;

	private JButton[] jbts;// 36个座位按钮
	private JLabel label_8;

	/**
	 * Create the frame.
	 */
	public UserPurchTicket_View() {
		jbts = new JButton[] { btnA_1, btnA_2, btnA_3, btnA_4, btnA_5, btnA_6,
				btnB_1, btnB_2, btnB_3, btnB_4, btnB_5, btnB_6, btnC_1, btnC_2,
				btnC_3, btnC_4, btnC_5, btnC_6, btnD_1, btnD_2, btnD_3, btnD_4,
				btnD_5, btnD_6, btnE_1, btnE_2, btnE_3, btnE_4, btnE_5, btnE_6,
				btnF_1, btnF_2, btnF_3, btnF_4, btnF_5, btnF_6 };

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setIconImage(Toolkit.getDefaultToolkit().getImage("images\\user.jpg"));
		setResizable(false);
		setTitle("\u7528\u6237\u6A21\u5F0F--\u8D2D\u7968\u754C\u9762");
		setBounds(100, 100, 853, 637);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 5, 837, 242);
		contentPane.add(scrollPane);
		table = new JTable();
		table.getTableHeader().setReorderingAllowed(false);
		table.addMouseListener(new MouseAdapter() {

			@Override
			// 选中JTable表的某一行:将这一行信息显示到对应的TextField里。对应场次所有已卖的座位变红。显示对应电影信息。
			public void mouseClicked(MouseEvent e) {
				int selRow = table.getSelectedRow();
				ControlUserPurchTicket_View
						.userToShowAll(table, hs_id, hs_hid, hs_cname,
								hs_mname, hs_time, hs_price, hs_sites, selRow);
				double money = ControlUserPurchTicket_View.getSumCost(hs_price,
						level01);
				textField_Cost.setText(money + "");

				jbts = new JButton[] { btnA_1, btnA_2, btnA_3, btnA_4, btnA_5,
						btnA_6, btnB_1, btnB_2, btnB_3, btnB_4, btnB_5, btnB_6,
						btnC_1, btnC_2, btnC_3, btnC_4, btnC_5, btnC_6, btnD_1,
						btnD_2, btnD_3, btnD_4, btnD_5, btnD_6, btnE_1, btnE_2,
						btnE_3, btnE_4, btnE_5, btnE_6, btnF_1, btnF_2, btnF_3,
						btnF_4, btnF_5, btnF_6 };// 36个座位按钮

				int sid = Integer.parseInt(hs_id.getText());
				String cname = hs_cname.getText();
				int hall_id = Integer.parseInt(hs_hid.getText());
				String mname = hs_mname.getText();
				String time = hs_time.getText();
				int price = Integer.parseInt(hs_price.getText());
				int remain = Integer.parseInt(hs_sites.getText());
				session = new Session(sid, cname, hall_id, mname, time, price,
						remain);// 场次对象
				String uname = Log_View.uv.user_name.getText();// 登录的用户对象用户名
				ControlUserPurchTicket_View.setBtnRed(jbts, session, uname);
			}
		});
		table.setModel(new DefaultTableModel(
				
		// 将影片放映的信息显示到JTable中
				ControlAdminManHST_View.showHSPlay(0), new String[] {
						"\u573A\u6B21ID", "\u7535\u5F71\u9662", "\u573A\u5385",
						"\u7535\u5F71", "\u5F00\u59CB\u65F6\u95F4",
						"\u4EF7\u683C", "\u5269\u4F59\u5EA7\u4F4D" }));
		table.getColumnModel().getColumn(0).setPreferredWidth(71);
		scrollPane.setViewportView(table);

		JPanel panel = new JPanel();
		panel.setBounds(5, 257, 832, 342);
		contentPane.add(panel);
		panel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(390, 10, 434, 172);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JLabel label = new JLabel("\u5F00\u59CB\u65F6\u95F4\uFF1A");
		label.setBounds(32, 105, 69, 15);
		panel_1.add(label);

		JLabel label_1 = new JLabel("\u573A  \u5385\uFF1A");
		label_1.setBounds(43, 78, 54, 15);
		panel_1.add(label_1);

		JLabel label_4 = new JLabel("\u573A\u6B21ID\uFF1A");
		label_4.setBounds(43, 49, 54, 15);
		panel_1.add(label_4);

		hs_id = new JTextField();
		hs_id.setEditable(false);
		hs_id.setFont(new Font("宋体", Font.BOLD, 13));
		hs_id.setForeground(Color.BLACK);
		hs_id.setColumns(10);
		hs_id.setBounds(107, 46, 138, 21);
		panel_1.add(hs_id);

		hs_mname = new JTextField();
		hs_mname.addMouseListener(new MouseAdapter() {
			/**
			 * 点击电影名打开影片介绍界面
			 */
			@Override
			public void mouseClicked(MouseEvent e) {
				// 打开电影介绍界面
				MoviesInformation_View miv = new MoviesInformation_View();
				miv.setVisible(true);
				miv.getMovie_name().setText(hs_mname.getText());
				Movie movie = new MovieDAOImp().findMovieByName(hs_mname
						.getText());
				if (movie != null) {
					miv.getMovie_type().setText(movie.getType());
					miv.getMovie_actor().setText(movie.getActors());
					miv.getMovie_duration().setText(movie.getDuration() + "分钟");
					miv.getMovie_detail().setText(
							"  影片介绍:\n" + "      " + movie.getDetail());
				} else {
					miv.getMovie_name().setText("无");
					miv.getMovie_type().setText("无");
					miv.getMovie_actor().setText("无");
					miv.getMovie_duration().setText("0分钟");
				}
			}
		});
		hs_mname.setEditable(false);
		hs_mname.setFont(new Font("Dialog", Font.BOLD, 13));
		hs_mname.setForeground(Color.BLACK);
		hs_mname.setBounds(304, 49, 120, 21);
		panel_1.add(hs_mname);

		JLabel label_5 = new JLabel("\u7247\u540D\uFF1A");
		label_5.setBounds(255, 52, 43, 15);
		panel_1.add(label_5);

		hs_hid = new JTextField();
		hs_hid.setEditable(false);
		hs_hid.setFont(new Font("Dialog", Font.BOLD, 13));
		hs_hid.setForeground(Color.BLACK);
		hs_hid.setBounds(108, 78, 137, 21);
		panel_1.add(hs_hid);

		hs_time = new JTextField();
		hs_time.setEditable(false);
		hs_time.setFont(new Font("Dialog", Font.BOLD, 13));
		hs_time.setForeground(Color.BLACK);
		hs_time.setBounds(107, 107, 138, 21);
		panel_1.add(hs_time);

		JLabel label_6 = new JLabel("\u4EF7\u683C\uFF1A");
		label_6.setBounds(255, 114, 43, 15);
		panel_1.add(label_6);

		JLabel label_7 = new JLabel("\u4F59\u4F4D\uFF1A");
		label_7.setBounds(256, 81, 43, 15);
		panel_1.add(label_7);

		hs_sites = new JTextField();
		hs_sites.setEditable(false);
		hs_sites.setFont(new Font("Dialog", Font.BOLD, 13));
		hs_sites.setForeground(Color.BLACK);
		hs_sites.setBounds(305, 81, 119, 21);
		panel_1.add(hs_sites);

		JLabel label_3 = new JLabel("\u7535\u5F71\u9662\uFF1A");
		label_3.setBounds(42, 135, 54, 15);
		panel_1.add(label_3);

		hs_cname = new JTextField();
		hs_cname.setEditable(false);
		hs_cname.setFont(new Font("Dialog", Font.BOLD, 13));
		hs_cname.setForeground(Color.BLACK);
		hs_cname.setBounds(106, 134, 318, 21);
		panel_1.add(hs_cname);

		hs_price = new JTextField();
		hs_price.setEditable(false);
		hs_price.setFont(new Font("Dialog", Font.BOLD, 13));
		hs_price.setForeground(Color.BLACK);
		hs_price.setBounds(304, 110, 120, 21);
		panel_1.add(hs_price);

		JLabel label_9 = new JLabel("");
		label_9.setIcon(new ImageIcon("images\\bg2.png"));
		label_9.setBounds(0, 0, 434, 180);
		panel_1.add(label_9);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(390, 192, 432, 124);
		panel.add(panel_2);
		panel_2.setLayout(null);

		JLabel label_42 = new JLabel("\u6298\u6263\uFF1A");
		label_42.setBounds(213, 10, 43, 15);
		panel_2.add(label_42);

		// 折扣文本框
		textField_discount = new JTextField();
		textField_discount.setEditable(false);
		textField_discount.setFont(new Font("Dialog", Font.BOLD, 13));
		textField_discount.setForeground(Color.BLACK);
		textField_discount.setBounds(262, 10, 123, 21);
		level01 = Integer.parseInt(Log_View.uv.user_level.getText());
		ControlUserPurchTicket_View.getDiscount(level01, textField_discount);
		panel_2.add(textField_discount);

		/**
		 * 确定购买按钮
		 */
		JButton button_1 = new JButton("\u786E\u5B9A\u8D2D\u4E70");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String rowInfo = choice_row.getSelectedItem();
				String columnInfo = choice_colum.getSelectedItem();

				jbts = new JButton[] { btnA_1, btnA_2, btnA_3, btnA_4, btnA_5,
						btnA_6, btnB_1, btnB_2, btnB_3, btnB_4, btnB_5, btnB_6,
						btnC_1, btnC_2, btnC_3, btnC_4, btnC_5, btnC_6, btnD_1,
						btnD_2, btnD_3, btnD_4, btnD_5, btnD_6, btnE_1, btnE_2,
						btnE_3, btnE_4, btnE_5, btnE_6, btnF_1, btnF_2, btnF_3,
						btnF_4, btnF_5, btnF_6 };

				if (hs_id.getText().length() == 0) {
					Message_View.warningDialog("请选择电影!");
				} else {
					// 用户买票的逻辑实现
					int sid = Integer.parseInt(hs_id.getText());
					String cname = hs_cname.getText();
					int hall_id = Integer.parseInt(hs_hid.getText());
					String mname = hs_mname.getText();
					String time = hs_time.getText();
					int price = Integer.parseInt(hs_price.getText());
					int remain = Integer.parseInt(hs_sites.getText());
					session = new Session(sid, cname, hall_id, mname, time,
							price, remain);// 场次对象
					String infos = rowInfo + columnInfo;// 座位号
					String uname = Log_View.uv.user_name.getText();// 登录的用户对象用户名
					double balance = Double
							.parseDouble(Log_View.uv.user_balance.getText()); // 登录用户的账户余额
					double cost = Double.parseDouble(textField_Cost.getText());// 买电影票实际所花金额
					User user = new User(uname, balance);// 登录的用户对象
					// 检查购买电影票是否成功
					boolean bool = ControlUserPurchTicket_View.checkPurchase(
							session, infos, user, cost);
					// 购买电影票成功后 --刷新场次信息列表--对应座位变蓝--用户帐号等级+1--出票,
					if (bool == true) {
						// 刷新场次信息列表
						table.setModel(new DefaultTableModel(
								ControlAdminManHST_View.showHSPlay(0),
								new String[] { "\u573A\u6B21ID",
										"\u7535\u5F71\u9662", "\u573A\u5385",
										"\u7535\u5F71",
										"\u5F00\u59CB\u65F6\u95F4",
										"\u4EF7\u683C",
										"\u5269\u4F59\u5EA7\u4F4D" }));

						// 对应座位变蓝
						ControlUserPurchTicket_View.getButtonColor(jbts, infos);

						// 用户帐号等级+1
						int level01 = Integer.parseInt(Log_View.uv.user_level
								.getText());
						int level02 = level01 + 1;
						Log_View.uv.user_level.setText(level02 + "");
						ControlUserPurchTicket_View.addLevel(uname, level02);

						// 出票
						UserTicket_View utv = new UserTicket_View(hs_mname
								.getText(), hs_time.getText(), hs_cname
								.getText(), hs_hid.getText(), (choice_row
								.getSelectedItem() + choice_colum
								.getSelectedItem()), textField_Cost.getText()
								+ "元");
						utv.setVisible(true);
					}
				}

			}
		});
		button_1.setBounds(69, 91, 94, 23);
		panel_2.add(button_1);

		JLabel label_43 = new JLabel("\u5EA7\u4F4D\u884C\uFF1A");
		label_43.setHorizontalAlignment(SwingConstants.CENTER);
		label_43.setBounds(34, 15, 54, 15);
		panel_2.add(label_43);

		JLabel label_44 = new JLabel("\u5408\u8BA1\uFF1A");
		label_44.setHorizontalAlignment(SwingConstants.CENTER);
		label_44.setBounds(202, 43, 54, 15);
		panel_2.add(label_44);

		// 电影票打折后的金额文本框
		textField_Cost = new JTextField();
		textField_Cost.setEditable(false);
		textField_Cost.setFont(new Font("Dialog", Font.BOLD, 13));
		textField_Cost.setForeground(Color.BLACK);
		textField_Cost.setBounds(262, 37, 123, 21);
		panel_2.add(textField_Cost);

		table.addMouseListener(new MouseAdapter() {
			@Override
			// 选中JTable表的某一行，这一行的信息显示在对应的Text文本框中
			public void mouseClicked(MouseEvent e) {
				int selRow = table.getSelectedRow();
				ControlUserPurchTicket_View
						.userToShowAll(table, hs_id, hs_hid, hs_cname,
								hs_mname, hs_time, hs_price, hs_sites, selRow);
			}
		});
		JLabel label_45 = new JLabel("\u5EA7\u4F4D\u5217\uFF1A");
		label_45.setHorizontalAlignment(SwingConstants.CENTER);
		label_45.setBounds(34, 42, 54, 15);
		panel_2.add(label_45);

		// 座位行号
		choice_row = new Choice();
		choice_row.add("A");
		choice_row.add("B");
		choice_row.add("C");
		choice_row.add("D");
		choice_row.add("E");
		choice_row.add("F");

		choice_row.setForeground(Color.BLACK);
		choice_row.setFont(new Font("Dialog", Font.BOLD, 13));
		choice_row.setBounds(94, 10, 109, 22);
		panel_2.add(choice_row);

		// 座位列号
		choice_colum = new Choice();
		for (int i = 1; i <= 6; i++) {
			choice_colum.add(i + "");
		}
		choice_colum.setForeground(Color.BLACK);
		choice_colum.setFont(new Font("Dialog", Font.BOLD, 13));
		choice_colum.setBounds(94, 41, 109, 22);
		panel_2.add(choice_colum);

		// 返回用户界面按钮
		JButton button = new JButton("\u8FD4\u56DE");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				Log_View.uv.setVisible(true);
			}
		});
		button.setBounds(291, 91, 94, 23);
		panel_2.add(button);

		// 查看用户购票记录按钮
		JButton button_2 = new JButton("\u8D2D\u7968\u8BB0\u5F55");
		button_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new UserPurchNotes_View().setVisible(true);
			}
		});
		button_2.setBounds(180, 91, 94, 23);
		panel_2.add(button_2);

		JLabel label_10 = new JLabel("");
		label_10.setIcon(new ImageIcon("images\\bg2.png"));
		label_10.setBounds(0, -12, 432, 136);
		panel_2.add(label_10);

		btnA_1 = new JButton("A1");
		btnA_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("A");
				choice_colum.select("1");
			}
		});
		btnA_1.setFont(new Font("Dialog", Font.BOLD, 8));
		btnA_1.setForeground(Color.BLACK);
		btnA_1.setBackground(Color.WHITE);
		btnA_1.setBounds(21, 50, 45, 23);
		panel.add(btnA_1);

		btnA_2 = new JButton("A2");
		btnA_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("A");
				choice_colum.select("2");
			}
		});
		btnA_2.setFont(new Font("Dialog", Font.BOLD, 8));
		btnA_2.setForeground(Color.BLACK);
		btnA_2.setBackground(Color.WHITE);
		btnA_2.setBounds(76, 50, 45, 23);
		panel.add(btnA_2);

		btnA_3 = new JButton("A3");
		btnA_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("A");
				choice_colum.select("3");
			}
		});
		btnA_3.setFont(new Font("Dialog", Font.BOLD, 8));
		btnA_3.setForeground(Color.BLACK);
		btnA_3.setBackground(Color.WHITE);
		btnA_3.setBounds(134, 50, 45, 23);
		panel.add(btnA_3);

		btnA_4 = new JButton("A4");
		btnA_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("A");
				choice_colum.select("4");
			}
		});
		btnA_4.setFont(new Font("Dialog", Font.BOLD, 8));
		btnA_4.setForeground(Color.BLACK);
		btnA_4.setBackground(Color.WHITE);
		btnA_4.setBounds(189, 50, 45, 23);
		panel.add(btnA_4);

		btnA_5 = new JButton("A5");
		btnA_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("A");
				choice_colum.select("5");
			}
		});
		btnA_5.setFont(new Font("Dialog", Font.BOLD, 8));
		btnA_5.setForeground(Color.BLACK);
		btnA_5.setBackground(Color.WHITE);
		btnA_5.setBounds(244, 50, 45, 23);
		panel.add(btnA_5);

		btnA_6 = new JButton("A6");
		btnA_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("A");
				choice_colum.select("6");
			}
		});
		btnA_6.setFont(new Font("Dialog", Font.BOLD, 8));
		btnA_6.setForeground(Color.BLACK);
		btnA_6.setBackground(Color.WHITE);
		btnA_6.setBounds(301, 50, 45, 23);
		panel.add(btnA_6);

		btnB_1 = new JButton("B1");
		btnB_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("B");
				choice_colum.select("1");
			}
		});
		btnB_1.setFont(new Font("Dialog", Font.BOLD, 8));
		btnB_1.setForeground(Color.BLACK);
		btnB_1.setBackground(Color.WHITE);
		btnB_1.setBounds(21, 94, 45, 23);
		panel.add(btnB_1);

		btnB_2 = new JButton("B2");
		btnB_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("B");
				choice_colum.select("2");
			}
		});
		btnB_2.setFont(new Font("Dialog", Font.BOLD, 8));
		btnB_2.setForeground(Color.BLACK);
		btnB_2.setBackground(Color.WHITE);
		btnB_2.setBounds(79, 94, 45, 23);
		panel.add(btnB_2);

		btnB_3 = new JButton("B3");
		btnB_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("B");
				choice_colum.select("3");
			}
		});
		btnB_3.setFont(new Font("Dialog", Font.BOLD, 8));
		btnB_3.setForeground(Color.BLACK);
		btnB_3.setBackground(Color.WHITE);
		btnB_3.setBounds(134, 94, 45, 23);
		panel.add(btnB_3);

		btnB_4 = new JButton("B4");
		btnB_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("B");
				choice_colum.select("4");
			}
		});
		btnB_4.setFont(new Font("Dialog", Font.BOLD, 8));
		btnB_4.setForeground(Color.BLACK);
		btnB_4.setBackground(Color.WHITE);
		btnB_4.setBounds(189, 94, 45, 23);
		panel.add(btnB_4);

		btnB_5 = new JButton("B5");
		btnB_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("B");
				choice_colum.select("5");
			}
		});
		btnB_5.setFont(new Font("Dialog", Font.BOLD, 8));
		btnB_5.setForeground(Color.BLACK);
		btnB_5.setBackground(Color.WHITE);
		btnB_5.setBounds(244, 94, 45, 23);
		panel.add(btnB_5);

		btnB_6 = new JButton("B6");
		btnB_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("B");
				choice_colum.select("6");
			}
		});
		btnB_6.setFont(new Font("Dialog", Font.BOLD, 8));
		btnB_6.setForeground(Color.BLACK);
		btnB_6.setBackground(Color.WHITE);
		btnB_6.setBounds(301, 94, 45, 23);
		panel.add(btnB_6);

		btnC_1 = new JButton("C1");
		btnC_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("C");
				choice_colum.select("1");
			}
		});
		btnC_1.setFont(new Font("Dialog", Font.BOLD, 8));
		btnC_1.setForeground(Color.BLACK);
		btnC_1.setBackground(Color.WHITE);
		btnC_1.setBounds(21, 139, 45, 23);
		panel.add(btnC_1);

		btnC_2 = new JButton("C2");
		btnC_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("C");
				choice_colum.select("2");
			}
		});
		btnC_2.setFont(new Font("Dialog", Font.BOLD, 8));
		btnC_2.setForeground(Color.BLACK);
		btnC_2.setBackground(Color.WHITE);
		btnC_2.setBounds(76, 139, 45, 23);
		panel.add(btnC_2);

		btnC_3 = new JButton("C3");
		btnC_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("C");
				choice_colum.select("3");
			}
		});
		btnC_3.setFont(new Font("Dialog", Font.BOLD, 8));
		btnC_3.setForeground(Color.BLACK);
		btnC_3.setBackground(Color.WHITE);
		btnC_3.setBounds(134, 139, 45, 23);
		panel.add(btnC_3);

		btnC_4 = new JButton("C4");
		btnC_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("C");
				choice_colum.select("4");
			}
		});
		btnC_4.setFont(new Font("Dialog", Font.BOLD, 8));
		btnC_4.setForeground(Color.BLACK);
		btnC_4.setBackground(Color.WHITE);
		btnC_4.setBounds(189, 139, 45, 23);
		panel.add(btnC_4);

		btnC_5 = new JButton("C5");
		btnC_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("C");
				choice_colum.select("5");
			}
		});
		btnC_5.setFont(new Font("Dialog", Font.BOLD, 8));
		btnC_5.setForeground(Color.BLACK);
		btnC_5.setBackground(Color.WHITE);
		btnC_5.setBounds(244, 139, 45, 23);
		panel.add(btnC_5);

		btnC_6 = new JButton("C6");
		btnC_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("C");
				choice_colum.select("6");
			}
		});
		btnC_6.setFont(new Font("Dialog", Font.BOLD, 8));
		btnC_6.setForeground(Color.BLACK);
		btnC_6.setBackground(Color.WHITE);
		btnC_6.setBounds(301, 139, 45, 23);
		panel.add(btnC_6);

		btnD_1 = new JButton("D1");
		btnD_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("D");
				choice_colum.select("1");
			}
		});
		btnD_1.setFont(new Font("Dialog", Font.BOLD, 8));
		btnD_1.setForeground(Color.BLACK);
		btnD_1.setBackground(Color.WHITE);
		btnD_1.setBounds(21, 183, 45, 23);
		panel.add(btnD_1);

		btnD_2 = new JButton("D2");
		btnD_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("D");
				choice_colum.select("2");
			}
		});
		btnD_2.setFont(new Font("Dialog", Font.BOLD, 8));
		btnD_2.setForeground(Color.BLACK);
		btnD_2.setBackground(Color.WHITE);
		btnD_2.setBounds(79, 183, 45, 23);
		panel.add(btnD_2);

		btnD_3 = new JButton("D3");
		btnD_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("D");
				choice_colum.select("3");
			}
		});
		btnD_3.setFont(new Font("Dialog", Font.BOLD, 8));
		btnD_3.setForeground(Color.BLACK);
		btnD_3.setBackground(Color.WHITE);
		btnD_3.setBounds(134, 183, 45, 23);
		panel.add(btnD_3);

		btnD_4 = new JButton("D4");
		btnD_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("D");
				choice_colum.select("4");
			}
		});
		btnD_4.setFont(new Font("Dialog", Font.BOLD, 8));
		btnD_4.setForeground(Color.BLACK);
		btnD_4.setBackground(Color.WHITE);
		btnD_4.setBounds(189, 183, 45, 23);
		panel.add(btnD_4);

		btnD_5 = new JButton("D5");
		btnD_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("D");
				choice_colum.select("5");
			}
		});
		btnD_5.setFont(new Font("Dialog", Font.BOLD, 8));
		btnD_5.setForeground(Color.BLACK);
		btnD_5.setBackground(Color.WHITE);
		btnD_5.setBounds(244, 183, 45, 23);
		panel.add(btnD_5);

		btnD_6 = new JButton("D6");
		btnD_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("D");
				choice_colum.select("6");
			}
		});
		btnD_6.setFont(new Font("Dialog", Font.BOLD, 8));
		btnD_6.setForeground(Color.BLACK);
		btnD_6.setBackground(Color.WHITE);
		btnD_6.setBounds(301, 183, 45, 23);
		panel.add(btnD_6);

		btnE_1 = new JButton("E1");
		btnE_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("E");
				choice_colum.select("1");
			}
		});
		btnE_1.setFont(new Font("Dialog", Font.BOLD, 8));
		btnE_1.setForeground(Color.BLACK);
		btnE_1.setBackground(Color.WHITE);
		btnE_1.setBounds(21, 229, 45, 23);
		panel.add(btnE_1);

		btnE_2 = new JButton("E2");
		btnE_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("E");
				choice_colum.select("2");
			}
		});
		btnE_2.setFont(new Font("Dialog", Font.BOLD, 8));
		btnE_2.setForeground(Color.BLACK);
		btnE_2.setBackground(Color.WHITE);
		btnE_2.setBounds(76, 229, 45, 23);
		panel.add(btnE_2);

		btnE_3 = new JButton("E3");
		btnE_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("E");
				choice_colum.select("3");
			}
		});
		btnE_3.setFont(new Font("Dialog", Font.BOLD, 8));
		btnE_3.setForeground(Color.BLACK);
		btnE_3.setBackground(Color.WHITE);
		btnE_3.setBounds(134, 229, 45, 23);
		panel.add(btnE_3);

		btnE_4 = new JButton("E4");
		btnE_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("E");
				choice_colum.select("4");
			}
		});
		btnE_4.setFont(new Font("Dialog", Font.BOLD, 8));
		btnE_4.setForeground(Color.BLACK);
		btnE_4.setBackground(Color.WHITE);
		btnE_4.setBounds(189, 229, 45, 23);
		panel.add(btnE_4);

		btnE_5 = new JButton("E5");
		btnE_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("E");
				choice_colum.select("5");
			}
		});
		btnE_5.setFont(new Font("Dialog", Font.BOLD, 8));
		btnE_5.setForeground(Color.BLACK);
		btnE_5.setBackground(Color.WHITE);
		btnE_5.setBounds(245, 229, 45, 23);
		panel.add(btnE_5);

		btnE_6 = new JButton("E6");
		btnE_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("E");
				choice_colum.select("6");
			}
		});
		btnE_6.setFont(new Font("Dialog", Font.BOLD, 8));
		btnE_6.setForeground(Color.BLACK);
		btnE_6.setBackground(Color.WHITE);
		btnE_6.setBounds(301, 229, 45, 23);
		panel.add(btnE_6);

		btnF_1 = new JButton("F1");
		btnF_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("F");
				choice_colum.select("1");
			}
		});
		btnF_1.setFont(new Font("Dialog", Font.BOLD, 8));
		btnF_1.setForeground(Color.BLACK);
		btnF_1.setBackground(Color.WHITE);
		btnF_1.setBounds(21, 273, 45, 23);
		panel.add(btnF_1);

		btnF_2 = new JButton("F2");
		btnF_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("F");
				choice_colum.select("2");
			}
		});
		btnF_2.setFont(new Font("Dialog", Font.BOLD, 8));
		btnF_2.setForeground(Color.BLACK);
		btnF_2.setBackground(Color.WHITE);
		btnF_2.setBounds(79, 273, 45, 23);
		panel.add(btnF_2);

		btnF_3 = new JButton("F3");
		btnF_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("F");
				choice_colum.select("3");
			}
		});
		btnF_3.setFont(new Font("Dialog", Font.BOLD, 8));
		btnF_3.setForeground(Color.BLACK);
		btnF_3.setBackground(Color.WHITE);
		btnF_3.setBounds(134, 273, 45, 23);
		panel.add(btnF_3);

		btnF_4 = new JButton("F4");
		btnF_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("F");
				choice_colum.select("4");
			}
		});
		btnF_4.setFont(new Font("Dialog", Font.BOLD, 8));
		btnF_4.setForeground(Color.BLACK);
		btnF_4.setBackground(Color.WHITE);
		btnF_4.setBounds(189, 273, 45, 23);
		panel.add(btnF_4);

		btnF_5 = new JButton("F5");
		btnF_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("F");
				choice_colum.select("5");
			}
		});
		btnF_5.setFont(new Font("Dialog", Font.BOLD, 8));
		btnF_5.setForeground(Color.BLACK);
		btnF_5.setBackground(Color.WHITE);
		btnF_5.setBounds(245, 273, 45, 23);
		panel.add(btnF_5);

		btnF_6 = new JButton("F6");
		btnF_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice_row.select("F");
				choice_colum.select("6");
			}
		});
		btnF_6.setFont(new Font("Dialog", Font.BOLD, 8));
		btnF_6.setForeground(Color.BLACK);
		btnF_6.setBackground(Color.WHITE);
		btnF_6.setBounds(301, 273, 45, 23);
		panel.add(btnF_6);

		label_8 = new JLabel(
				"\u6CE8\uFF1A\u7EA2\u8272\u8868\u793A\u5DF2\u5356\u5EA7\u4F4D");
		label_8.setForeground(Color.RED);
		label_8.setFont(new Font("仿宋", Font.BOLD, 10));
		label_8.setBounds(21, 301, 126, 15);
		panel.add(label_8);

		button_4 = new JButton("\u7535\u5F71\u5C4F\u5E55");
		button_4.setBackground(Color.WHITE);
		button_4.setFont(new Font("宋体", Font.BOLD, 15));
		button_4.setEnabled(false);
		button_4.setBounds(77, 10, 214, 23);
		panel.add(button_4);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon("images\\bg2.png"));
		label_2.setBounds(0, 10, 380, 306);
		panel.add(label_2);

		JLabel label_11 = new JLabel(
				"\u70B9\u7247\u540D\u67E5\u770B\u5F71\u7247\u4FE1\u606F");
		label_11.setForeground(Color.RED);
		label_11.setFont(new Font("仿宋", Font.BOLD, 10));
		label_11.setBounds(21, 317, 126, 15);
		panel.add(label_11);
	}
}
