package com.newtion.view;

import java.awt.Checkbox;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.newtion.controller.ControlLogAndReg_View;
import com.newtion.model.User;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;

//登录界面
public class Log_View extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane1;
	public static JTextField textField_UserName;
	private JPasswordField textField_UserPassword;
	public static User_View uv;

	public void showMain() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Log_View frame = new Log_View();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Log_View() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage("images\\logo.jpg"));
		setTitle("\u7535\u5F71\u9662\u7968\u52A1\u7CFB\u7EDF-\u767B\u5F55\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 394, 261);
		contentPane1 = new JPanel();
		contentPane1.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane1);
		contentPane1.setLayout(null);

		JLabel label = new JLabel("\u7528\u6237\u540D");
		label.setBounds(42, 114, 70, 28);
		contentPane1.add(label);
		label.setFont(new Font("黑体", Font.BOLD, 16));

		textField_UserName = new JTextField();
		textField_UserName.setBounds(101, 114, 145, 28);
		contentPane1.add(textField_UserName);
		textField_UserName.setToolTipText("");
		textField_UserName.setFont(new Font("宋体", Font.BOLD, 18));

		final Checkbox checkbox_admin = new Checkbox(
				"\u7BA1\u7406\u5458\u6A21\u5F0F");
		checkbox_admin.setBackground(Color.WHITE);
		checkbox_admin.setBounds(289, 62, 99, 31);
		contentPane1.add(checkbox_admin);

		JLabel label_1 = new JLabel("\u5BC6  \u7801");
		label_1.setBounds(41, 152, 61, 43);
		contentPane1.add(label_1);
		label_1.setFont(new Font("黑体", Font.BOLD, 16));

		textField_UserPassword = new JPasswordField();
		textField_UserPassword.setBounds(101, 160, 145, 28);
		contentPane1.add(textField_UserPassword);
		textField_UserPassword.setFont(new Font("宋体", Font.BOLD, 18));
		textField_UserPassword.setColumns(18);

		// 登录按钮
		JButton btnNewButton = new JButton("\u767B\u5F55");
		btnNewButton.addMouseListener(new MouseAdapter() {
		});
		btnNewButton.setBounds(293, 115, 61, 28);
		contentPane1.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = textField_UserName.getText();// 获取用户名
				String password = new String(textField_UserPassword
						.getPassword());// 获取用户密码
				User user = new User(name, password);
				if (user.getName().length() == 0
						|| user.getPassword().length() == 0) {
					Message_View.warningDialog("用户名或密码不能为空，请重新登录!");
				} else {
					boolean bool = checkbox_admin.getState();// 选择框状态：选择用户或者管理员
					if (bool == false) {
						boolean bool2 = ControlLogAndReg_View.UserLog(user);// 用户登录
						if (bool2 == true) {
							setVisible(false);
							uv = new User_View();
							uv.setVisible(true);
							uv.user_name.setText(name);
							uv.user_level.setText(user.getLevel() + "");
							uv.user_balance.setText(user.getBalance() + "");
						} else {
							Message_View.infoDialog("用户名或密码不正确，请重新登录！");
						}

					} else {
						boolean bool3 = ControlLogAndReg_View.AdminLog(user);// 管理员登录
						if (bool3 == true) {
							// 登录成功，打开管理员界面
							setVisible(false);
							Admin_View frame = new Admin_View();
							frame.setVisible(true);
						} else {
							Message_View.infoDialog("管理员名或密码不正确，请重新登录！");
						}
					}
				}
			}
		});
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setFont(new Font("宋体", Font.BOLD, 12));

		// 注册按钮
		JButton button = new JButton("\u6CE8\u518C");
		button.setBounds(293, 161, 61, 28);
		contentPane1.add(button);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean bool = checkbox_admin.getState();// 单选框状态:用户模式？管理员模式？
				if (bool == false) {
					setVisible(false);
					new Reg_View().regStart();
				} else {
					Message_View.warningDialog("该系统，无法注册管理员!");// 系统默认管理员为admin且只有一个
				}
			}
		});
		button.setForeground(Color.BLACK);
		button.setFont(new Font("宋体", Font.BOLD, 12));

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon("images\\dl.jpg"));
		label_2.setBounds(0, -51, 443, 345);
		contentPane1.add(label_2);
	}
}
