package com.newtion.view;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.newtion.model.Cinema;
import com.newtion.model.User;

//ϵͳ��ʾ����

public class Message_View {

	public static final String MESSAGE_WARNING = " ���棡";
	public static final String MESSAGE_INFORMATION = " ��Ϣ";
	public static final String MESSAGE_ERROR = " ����";

	private Message_View() {

		throw new Error("Don't let anyone instantiate this class.");

	}

	/***
	 * ������ʾ��
	 * 
	 * @param mesg
	 */
	public static void warningDialog(String mesg) {
		JOptionPane.showMessageDialog(null,
				"<html><font color=\"red\"  style=\"font-weight:bold;"
						+ "background-color:white\" >" + mesg
						+ "</font></html>", MESSAGE_WARNING,
				JOptionPane.WARNING_MESSAGE);
	}

	/***
	 * error ������ʾ��
	 * 
	 * @param mesg
	 */
	public static void errorDialog(String mesg) {
		JOptionPane.showMessageDialog(null,
				"<html><font color=\"red\"  style=\"font-weight:bold;"
						+ "background-color:white\" >" + mesg
						+ "</font></html>", MESSAGE_ERROR,
				JOptionPane.ERROR_MESSAGE);
	}

	/***
	 * information ֪ͨ��ʾ��
	 * 
	 * @param mesg
	 */
	public static void infoDialog(String mesg) {
		JOptionPane.showMessageDialog(null,
				"<html><font color=\"black\"  style=\"font-weight:bold;\" >"
						+ mesg + "</font></html>", MESSAGE_INFORMATION,
				JOptionPane.INFORMATION_MESSAGE);
	}

	/***
	 * information ��ѯ�û��ɹ�����ʾ���û���Ϣ
	 * 
	 * @param mesg
	 */
	public static void showUser(User user, JTextField user_password,
			JTextField user_level, JTextField user_balance) {
		user_password.setText("");
		user_level.setText("");
		user_balance.setText("");
		JOptionPane
				.showMessageDialog(
						null,
						"<html><font color=\"blue\"  style=\"font-weight:bold;\" >"
								+ "---------------------------��ѯ�ɹ���---------------------------"
								+ "</style></font></html>"
								+ "\n"
								+ user.toString()
								+ "\n"
								+ "<html><font color=\"blue\"  style=\"font-weight:bold;\" >"
								+ "----------------------------------------------------------------------"
								+ "</style></font></html>",
						MESSAGE_INFORMATION, JOptionPane.INFORMATION_MESSAGE);
	}

	/***
	 * information ��ѯӰԺ�ɹ�����ʾ��ӰԺ��Ϣ
	 * 
	 * @param mesg
	 */
	public static void showCinema(Cinema cinema) {
		JOptionPane.showMessageDialog(
						null,
						"<html><font color=\"blue\"  style=\"font-weight:bold;\" >"
								+ "------------------------��ѯ�ɹ���---------------------------"
								+ "</style></font></html>"
								+ "\n"
								+ cinema.toString()
								+ "\n"
								+ "<html><font color=\"blue\"  style=\"font-weight:bold;\" >"
								+ "-------------------------------------------------------------------"
								+ "</style></font></html>",
						MESSAGE_INFORMATION, JOptionPane.INFORMATION_MESSAGE);
	}
}
