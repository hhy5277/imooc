package com.newtion.view;

import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

public class UserTicket_View extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField mname;
	private JTextField time;
	private JTextField cname;
	private JTextField hallid;
	private JTextField sites;
	private JTextField price;

	/**
	 * Create the frame.
	 */
	public UserTicket_View(String smname, String stime, String scname,
			String shallid, String ssites, String sprice) {
		setType(Type.POPUP);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("\u7535\u5F71\u7968");
		setBounds(100, 100, 391, 282);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// 电影名称
		mname = new JTextField();
		mname.setFont(new Font("宋体", Font.BOLD, 12));
		mname.setEditable(false);
		mname.setBounds(127, 23, 191, 21);
		mname.setText(smname);
		contentPane.add(mname);
		mname.setColumns(10);

		// 放映时间
		time = new JTextField();
		time.setFont(new Font("宋体", Font.BOLD, 12));
		time.setEditable(false);
		time.setText(stime);
		time.setColumns(10);
		time.setBounds(127, 58, 191, 21);
		contentPane.add(time);

		// 影院名称
		cname = new JTextField();
		cname.setFont(new Font("宋体", Font.BOLD, 12));
		cname.setEditable(false);
		cname.setColumns(10);
		cname.setBounds(127, 93, 191, 21);
		cname.setText(scname);
		contentPane.add(cname);

		// 场厅编号
		hallid = new JTextField();
		hallid.setFont(new Font("宋体", Font.BOLD, 12));
		hallid.setEditable(false);
		hallid.setColumns(10);
		hallid.setBounds(127, 128, 191, 21);
		hallid.setText(shallid + "号厅");
		contentPane.add(hallid);

		// 座位号
		sites = new JTextField();
		sites.setFont(new Font("宋体", Font.BOLD, 12));
		sites.setEditable(false);
		sites.setColumns(10);
		sites.setBounds(127, 202, 191, 21);
		sites.setText(ssites);
		contentPane.add(sites);

		// 票价
		price = new JTextField();
		price.setFont(new Font("宋体", Font.BOLD, 12));
		price.setEditable(false);
		price.setColumns(10);
		price.setBounds(127, 163, 191, 21);
		price.setText(sprice);
		contentPane.add(price);

		JLabel label_6 = new JLabel("\u7968\u4EF7\uFF1A");
		label_6.setForeground(Color.BLACK);
		label_6.setFont(new Font("宋体", Font.BOLD, 15));
		label_6.setBounds(69, 163, 62, 29);
		contentPane.add(label_6);

		JLabel label_1 = new JLabel("\u7247\u540D\uFF1A");
		label_1.setForeground(Color.BLACK);
		label_1.setFont(new Font("宋体", Font.BOLD, 15));
		label_1.setBounds(69, 23, 62, 29);
		contentPane.add(label_1);

		JLabel label_2 = new JLabel("\u65F6\u95F4\uFF1A");
		label_2.setForeground(Color.BLACK);
		label_2.setFont(new Font("宋体", Font.BOLD, 15));
		label_2.setBounds(69, 58, 62, 29);
		contentPane.add(label_2);

		JLabel label_3 = new JLabel("\u5F71\u9662\uFF1A");
		label_3.setForeground(Color.BLACK);
		label_3.setFont(new Font("宋体", Font.BOLD, 15));
		label_3.setBounds(69, 93, 62, 29);
		contentPane.add(label_3);

		JLabel label_4 = new JLabel("\u573A\u5385\uFF1A");
		label_4.setForeground(Color.BLACK);
		label_4.setFont(new Font("宋体", Font.BOLD, 15));
		label_4.setBounds(69, 128, 62, 29);
		contentPane.add(label_4);

		JLabel label_5 = new JLabel("\u5EA7\u4F4D\u53F7\uFF1A");
		label_5.setForeground(Color.BLACK);
		label_5.setFont(new Font("宋体", Font.BOLD, 15));
		label_5.setBounds(58, 202, 71, 29);
		contentPane.add(label_5);

		JLabel label = new JLabel("");
		label.setIcon(null);
		label.setBounds(10, 10, 365, 236);
		contentPane.add(label);

		JLabel label_7 = new JLabel("");
		label_7.setIcon(new ImageIcon("images\\bg2.png"));
		label_7.setBounds(10, 10, 365, 236);
		contentPane.add(label_7);
	}
}
