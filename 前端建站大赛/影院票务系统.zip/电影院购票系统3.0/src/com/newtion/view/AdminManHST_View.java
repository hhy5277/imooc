package com.newtion.view;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.newtion.controller.ControlAdminManHST_View;

//管理员对电影的场厅场次的管理界面
public class AdminManHST_View extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTextField hs_id;
	private Choice hs_hid;
	private Choice hs_cname;
	private Choice hs_mname;
	private JTextField hs_price;
	private JTextField hs_sites;
	private Choice choice_m;
	private Choice choice_h;
	private Choice choice_y;
	private Choice choice_d;

	/**
	 * Create the frame.
	 */
	public AdminManHST_View() {
		setIconImage(Toolkit
				.getDefaultToolkit()
				.getImage(
						"E:\\AndroidEng\\projects\\Eclipse\\\u7535\u5F71\u9662\u8D2D\u7968\u7CFB\u7EDF2.0\\admin.png"));
		setResizable(false);
		setTitle("\u7BA1\u7406\u5458\u6A21\u5F0F-\u653E\u6620\u7BA1\u7406\u754C\u9762");
		setBounds(100, 100, 852, 542);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 5, 837, 281);
		contentPane.add(scrollPane);
		table = new JTable();
		table.getTableHeader().setReorderingAllowed(false);
		table.addMouseListener(new MouseAdapter() {
			@Override
			// 选中JTable表的某一行，这一行的信息显示在对应的Text文本框中
			public void mouseClicked(MouseEvent e) {
				int selRow = table.getSelectedRow();
				ControlAdminManHST_View.adminToShowAll(table, hs_id, hs_hid,
						hs_cname, hs_mname, hs_price, hs_sites, selRow);
			}
		});
		table.setModel(new DefaultTableModel(
		// 将影片放映的信息显示到管理员界面的放映管理JTable中
				ControlAdminManHST_View.showHSPlay(1), new String[] {
						"\u573A\u6B21ID", "\u7535\u5F71\u9662", "\u573A\u5385",
						"\u7535\u5F71", "\u5F00\u59CB\u65F6\u95F4",
						"\u4EF7\u683C", "\u5269\u4F59\u5EA7\u4F4D" }));
		table.getColumnModel().getColumn(0).setPreferredWidth(71);
		scrollPane.setViewportView(table);

		JPanel panel = new JPanel();
		panel.setBounds(5, 288, 837, 223);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u573A\u6B21ID\uFF1A");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setFont(new Font("宋体", Font.BOLD, 15));
		lblNewLabel.setBounds(46, 25, 72, 44);
		panel.add(lblNewLabel);

		hs_id = new JTextField();
		hs_id.setEditable(false);
		hs_id.setForeground(new Color(0, 0, 0));
		hs_id.setBounds(123, 38, 146, 21);
		panel.add(hs_id);
		hs_id.setColumns(10);

		JLabel label = new JLabel("\u7535\u5F71\u9662\uFF1A");
		label.setForeground(Color.BLACK);
		label.setFont(new Font("宋体", Font.BOLD, 15));
		label.setBounds(46, 79, 72, 43);
		panel.add(label);

		// 获取所有电影院的名称到Choice选择栏
		hs_cname = new Choice();
		ControlAdminManHST_View.getAllCinemaName(hs_cname);
		hs_cname.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if (hs_hid.getItemCount() != 0) {
					hs_hid.removeAll();
				}
			}
		});
		hs_cname.setForeground(new Color(0, 0, 0));
		hs_cname.setBounds(123, 88, 146, 21);
		panel.add(hs_cname);

		JLabel label_1 = new JLabel("\u573A \u5385\uFF1A");
		label_1.setForeground(Color.BLACK);
		label_1.setFont(new Font("宋体", Font.BOLD, 15));
		label_1.setBounds(46, 108, 66, 62);
		panel.add(label_1);

		// 获取所有场厅ID到Choice选择栏
		hs_hid = new Choice();
		hs_hid.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				ControlAdminManHST_View.getAllHallId(hs_hid, hs_cname);
			}
		});
		hs_hid.setForeground(new Color(0, 0, 0));
		hs_hid.setBounds(123, 132, 146, 21);
		panel.add(hs_hid);

		JLabel label_2 = new JLabel("\u7247\u540D\uFF1A");
		label_2.setForeground(Color.BLACK);
		label_2.setFont(new Font("宋体", Font.BOLD, 15));
		label_2.setBounds(313, 108, 48, 75);
		panel.add(label_2);

		// 获取所有电影的名称到Choice选择栏
		hs_mname = new Choice();
		ControlAdminManHST_View.getAllMovieName(hs_mname);
		hs_mname.setForeground(new Color(0, 0, 0));
		hs_mname.setBounds(371, 133, 160, 21);
		panel.add(hs_mname);

		JLabel label_4 = new JLabel("\u4EF7 \u683C\uFF1A");
		label_4.setForeground(Color.BLACK);
		label_4.setFont(new Font("宋体", Font.BOLD, 15));
		label_4.setBounds(313, 160, 72, 32);
		panel.add(label_4);

		hs_price = new JTextField();
		hs_price.setForeground(new Color(0, 0, 0));
		hs_price.setBounds(371, 168, 160, 21);
		panel.add(hs_price);

		JLabel label_5 = new JLabel("\u4F59 \u5EA7\uFF1A");
		label_5.setForeground(Color.BLACK);
		label_5.setFont(new Font("宋体", Font.BOLD, 15));
		label_5.setBounds(46, 151, 66, 62);
		panel.add(label_5);

		hs_sites = new JTextField();
		hs_sites.setEditable(false);
		hs_sites.setForeground(new Color(0, 0, 0));
		hs_sites.setBounds(123, 171, 146, 21);
		hs_sites.setText("36");
		panel.add(hs_sites);

		// 添加电影场次按钮
		JButton btnNewButton = new JButton("\u589E\u52A0");
		btnNewButton.setFont(new Font("宋体", Font.BOLD, 12));
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String time = 2015 + "-" + choice_y.getSelectedItem() + "-"
						+ choice_d.getSelectedItem() + " "
						+ choice_h.getSelectedItem() + ":"
						+ choice_m.getSelectedItem();

				ControlAdminManHST_View.addSession(hs_hid, hs_cname, hs_mname,
						hs_price, hs_sites, time);
				table.setModel(new DefaultTableModel(
				// 将影片放映的信息显示到管理员界面的放映管理JTable中
						ControlAdminManHST_View.showHSPlay(1), new String[] {
								"\u573A\u6B21ID", "\u7535\u5F71\u9662",
								"\u573A\u5385", "\u7535\u5F71",
								"\u5F00\u59CB\u65F6\u95F4", "\u4EF7\u683C",
								"\u5269\u4F59\u5EA7\u4F4D" }));
			}
		});
		btnNewButton.setBounds(635, 109, 72, 40);
		panel.add(btnNewButton);

		// 删除按钮
		JButton button = new JButton("\u5220\u9664");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ControlAdminManHST_View.adminToDeleteSession(hs_id, hs_sites,
						table);
			}
		});
		button.setFont(new Font("宋体", Font.BOLD, 12));
		button.setForeground(Color.BLACK);
		button.setBounds(635, 157, 72, 40);
		panel.add(button);

		// 返回按钮
		JButton button_2 = new JButton("\u8FD4\u56DE");
		button_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				new Admin_View().setVisible(true);
			}
		});
		button_2.setForeground(Color.BLACK);
		button_2.setFont(new Font("宋体", Font.BOLD, 12));
		button_2.setBounds(716, 108, 94, 88);
		panel.add(button_2);

		// 小时
		choice_h = new Choice();
		choice_h.setForeground(Color.BLACK);
		choice_h.setBounds(371, 101, 68, 21);
		panel.add(choice_h);
		
				JLabel label_3 = new JLabel("\u65F6\u95F4\uFF1A");
				label_3.setForeground(Color.BLACK);
				label_3.setFont(new Font("宋体", Font.BOLD, 15));
				label_3.setBounds(313, 40, 48, 75);
				panel.add(label_3);

		JLabel label_6 = new JLabel("\uFF1A");
		label_6.setFont(new Font("宋体", Font.BOLD, 15));
		label_6.setBounds(448, 100, 16, 21);
		panel.add(label_6);

		// 月份
		choice_y = new Choice();
		choice_y.setForeground(Color.BLACK);
		choice_y.setBounds(371, 66, 71, 21);
		panel.add(choice_y);

		// 日
		choice_d = new Choice();
		choice_d.setForeground(Color.BLACK);
		choice_d.setBounds(463, 66, 68, 21);
		panel.add(choice_d);
		// 分钟
		choice_m = new Choice();
		choice_m.setForeground(Color.BLACK);
		choice_m.setBounds(463, 101, 68, 21);
		panel.add(choice_m);
		new ControlAdminManHST_View();
		ControlAdminManHST_View
				.showTime(choice_y, choice_d, choice_h, choice_m);
		JLabel hs_time_1 = new JLabel("");
		hs_time_1.setIcon(new ImageIcon("images\\bg2.png"));
		hs_time_1.setBounds(0, 0, 837, 223);
		panel.add(hs_time_1);
	}
}
