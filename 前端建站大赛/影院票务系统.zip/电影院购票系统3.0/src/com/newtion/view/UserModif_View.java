package com.newtion.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.newtion.controller.ControlUserModif_View;

import java.awt.TextField;

public class UserModif_View extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public JTextField user_name;
	private TextField newPassword;
	private TextField newPassword02;

	/**
	 * Create the frame.
	 */
	public UserModif_View() {
		setIconImage(Toolkit
				.getDefaultToolkit()
				.getImage(
						"E:\\AndroidEng\\projects\\Eclipse\\\u7535\u5F71\u9662\u8D2D\u7968\u7CFB\u7EDF2.0\\user.jpg"));
		setTitle("\u7528\u6237\u6A21\u5F0F--\u4E2A\u4EBA\u8BBE\u7F6E\u754C\u9762");
		setResizable(false);
		setBounds(100, 100, 401, 255);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 376, 207);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel label = new JLabel("\u65B0\u5BC6\u7801\uFF1A");
		label.setFont(new Font("宋体", Font.BOLD, 14));
		label.setBounds(178, 55, 60, 37);
		panel.add(label);


		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(0, 10, 156, 126);
		panel.add(lblNewLabel);
		lblNewLabel
				.setIcon(new ImageIcon(
						"images\\touxiang.png"));

		JLabel label_1 = new JLabel("\u7528\u6237\u540D\uFF1A");
		label_1.setFont(new Font("宋体", Font.BOLD, 14));
		label_1.setBounds(178, 28, 60, 29);
		panel.add(label_1);

		JPanel panel_4 = new JPanel();
		panel_4.setBounds(10, 10, 143, 126);
		panel.add(panel_4);
		panel_4.setLayout(null);

		/**
		 * 个人设置界面显示用户名
		 */
		user_name = new JTextField();
		user_name.setFont(new Font("宋体", Font.BOLD, 12));
		user_name.setEditable(false);
		user_name.setBounds(243, 32, 107, 21);
		user_name.setText(Log_View.uv.user_name.getText());
		panel.add(user_name);
		user_name.setColumns(10);
		
		// 新密码输入框01
		newPassword = new TextField();
		newPassword.setFont(new Font("Dialog", Font.BOLD, 12));
		newPassword.setBounds(243, 63, 107, 21);
		// 新密码输入框02
		newPassword02 = new TextField();
		newPassword02.setFont(new Font("Dialog", Font.BOLD, 12));
		newPassword02.setBounds(243, 98, 107, 21);
		panel.add(newPassword);
		panel.add(newPassword02);

		/**
		 * 修改确定按钮
		 */
		JButton button_1 = new JButton("\u786E\u5B9A");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ControlUserModif_View.userModif(newPassword, newPassword02,
						user_name);
			}
		});
		button_1.setForeground(Color.BLACK);
		button_1.setFont(new Font("宋体", Font.BOLD, 12));
		button_1.setBounds(213, 134, 60, 29);
		panel.add(button_1);

		// 返回按钮
		JButton button = new JButton("\u8FD4\u56DE");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				new Log_View();
				Log_View.uv.setVisible(true);
			}
		});
		button.setForeground(Color.BLACK);
		button.setFont(new Font("宋体", Font.BOLD, 12));
		button.setBounds(284, 134, 66, 29);

		panel.add(button);

		JLabel label_2 = new JLabel("\u65B0\u5BC6\u7801\uFF1A");
		label_2.setFont(new Font("宋体", Font.BOLD, 14));
		label_2.setBounds(178, 87, 60, 37);
		panel.add(label_2);

	}
}
