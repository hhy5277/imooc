package com.newtion.view;

import java.awt.Toolkit;
import java.awt.event.MouseAdapter;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.newtion.controller.ControlUserPurchTicket_View;

public class UserPurchNotes_View extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;

	/**
	 * Create the frame.
	 */
	public UserPurchNotes_View() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("images\\user.jpg"));
		setResizable(false);
		setTitle("\u7528\u6237\u6A21\u5F0F--\u8D2D\u7968\u8BB0\u5F55\u754C\u9762");
		setBounds(100, 100, 533, 310);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		/**
		 * 用户购票记录
		 */
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 5, 518, 272);
		contentPane.add(scrollPane);
		table = new JTable();
		table.getTableHeader().setReorderingAllowed(false);
		table.addMouseListener(new MouseAdapter() {
		});
		new ControlUserPurchTicket_View();
		table.setModel(new DefaultTableModel(ControlUserPurchTicket_View
				.showUserNotes(Log_View.uv.user_name.getText()), new String[] {
				"\u573A\u6B21ID", "\u7535\u5F71\u9662", "\u573A\u5385",
				"\u5EA7\u4F4D\u53F7", "\u7535\u5F71",
				"\u5F00\u59CB\u65F6\u95F4" }));
		table.getColumnModel().getColumn(0).setPreferredWidth(71);
		scrollPane.setViewportView(table);
	}
}
