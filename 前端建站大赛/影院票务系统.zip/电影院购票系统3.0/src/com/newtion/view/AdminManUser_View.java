package com.newtion.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.newtion.controller.ControlAdminManUser_View;
import com.newtion.model.User;

public class AdminManUser_View extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTextField user_id;
	private JTextField user_name;
	private JTextField user_password;
	private JTextField user_level;
	private JTextField user_balance;

	/**
	 * Create the frame.
	 */
	public AdminManUser_View() {
		setResizable(false);
		setIconImage(Toolkit
				.getDefaultToolkit()
				.getImage(
						"E:\\AndroidEng\\projects\\Eclipse\\\u7535\u5F71\u9662\u8D2D\u7968\u7CFB\u7EDF2.0\\admin.png"));
		setTitle("\u7BA1\u7406\u5458\u6A21\u5F0F - \u7528\u6237\u7BA1\u7406\u754C\u9762");
		setBounds(100, 100, 453, 407);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(2, 1, 0, 0));

		JScrollPane scrollPane = new JScrollPane();
		scrollPane
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		contentPane.add(scrollPane);

		// 管理员模式--用户管理界面 -- 用户信息JTable
		table = new JTable();
		table.getTableHeader().setReorderingAllowed(false);
		table.setColumnSelectionAllowed(true);
		table.addMouseListener(new MouseAdapter() {
			@Override
			// 选中JTable表的某一行，这一行的信息显示在对应的Text文本框中
			public void mouseClicked(MouseEvent e) {
				int selRow = table.getSelectedRow();
				ControlAdminManUser_View.adminToShowAll(table, user_id,
						user_name, user_password, user_level, user_balance,
						selRow);
			}
		});
		table.setCellSelectionEnabled(true);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setToolTipText("");
		table.setFillsViewportHeight(true);
		table.setModel(new DefaultTableModel(
		// 显示所有用户
				ControlAdminManUser_View.showUsers(), new String[] { "ID",
						"\u59D3\u540D", "\u5BC6\u7801", "\u7B49\u7EA7",
						"\u4F59\u989D" }) {
			private static final long serialVersionUID = 1L;
			@SuppressWarnings("rawtypes")
			Class[] columnTypes = new Class[] { Integer.class, String.class,
					String.class, Integer.class, Double.class };

			public Class<?> getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table.getColumnModel().getColumn(4).setResizable(false);
		scrollPane.setViewportView(table);

		JPanel panel = new JPanel();
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblId = new JLabel("\u7528\u6237ID\uFF1A");
		lblId.setFont(new Font("宋体", Font.BOLD, 15));
		lblId.setBounds(31, 10, 66, 31);
		panel.add(lblId);

		JLabel label = new JLabel("\u7B49\u7EA7\uFF1A");
		label.setFont(new Font("宋体", Font.BOLD, 15));
		label.setBounds(244, 48, 66, 21);
		panel.add(label);

		JLabel label_1 = new JLabel("\u59D3\u540D\uFF1A");
		label_1.setFont(new Font("宋体", Font.BOLD, 15));
		label_1.setBounds(244, 18, 54, 15);
		panel.add(label_1);

		JLabel label_2 = new JLabel("\u5BC6  \u7801\uFF1A");
		label_2.setFont(new Font("宋体", Font.BOLD, 15));
		label_2.setBounds(31, 51, 66, 15);
		panel.add(label_2);

		JLabel label_3 = new JLabel("\u4F59 \u989D \uFF1A");
		label_3.setFont(new Font("宋体", Font.BOLD, 15));
		label_3.setBounds(31, 76, 76, 21);
		panel.add(label_3);

		user_id = new JTextField();
		user_id.setEditable(false);
		user_id.setBounds(107, 15, 127, 21);
		panel.add(user_id);
		user_id.setColumns(10);

		user_name = new JTextField();
		user_name.setToolTipText("");
		user_name.setColumns(10);
		user_name.setBounds(300, 15, 114, 21);
		panel.add(user_name);

		user_balance = new JTextField();
		user_balance.setEditable(false);
		user_balance.setColumns(10);
		user_balance.setBounds(107, 79, 307, 21);
		panel.add(user_balance);

		user_password = new JTextField();
		user_password.setColumns(10);

		user_password.setBounds(107, 48, 127, 21);
		panel.add(user_password);

		user_level = new JTextField();
		user_level.setEditable(false);
		user_level.setColumns(10);
		user_level.setBounds(300, 48, 114, 21);
		panel.add(user_level);

		// 管理员模式--用户管理界面--添加按钮
		JButton button_add = new JButton("\u6DFB\u52A0");
		button_add.setToolTipText("");
		button_add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = user_name.getText();
				String password = user_password.getText();
				if (password.trim().equals("")) {
					password = "000";
				}
				ControlAdminManUser_View.adminToaddUser(name, password, table);// 管理员添加用户方法
			}
		});

		button_add.setFont(new Font("宋体", Font.BOLD, 11));
		button_add.setForeground(Color.BLACK);
		button_add.setBounds(195, 110, 58, 31);
		panel.add(button_add);

		// 管理员模式--用户管理界面--删除按钮
		JButton button_delete = new JButton("\u5220\u9664");
		button_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = user_name.getText().trim();
				ControlAdminManUser_View.adminToDeleteUser(name, table);// 管理员删除用户方法
			}
		});
		button_delete.setToolTipText("");
		button_delete.setForeground(Color.BLACK);
		button_delete.setFont(new Font("宋体", Font.BOLD, 11));
		button_delete.setBounds(195, 151, 58, 31);
		panel.add(button_delete);

		// 管理员模式--用户管理界面--修改按钮
		JButton button_update = new JButton("\u4FEE\u6539");
		button_update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = user_name.getText();
				String password = user_password.getText();
				ControlAdminManUser_View.adminToUpdate(name, password, table);// 管理员修改用户密码
			}
		});
		button_update.setFont(new Font("宋体", Font.BOLD, 11));
		button_update.setForeground(Color.BLACK);
		button_update.setBounds(265, 110, 58, 31);
		panel.add(button_update);

		// 管理员模式--用户管理界面--查询按钮
		JButton button_select = new JButton("\u67E5\u8BE2");
		button_select.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = user_name.getText();
				User user = ControlAdminManUser_View.adminSelectUser(name);
				if (user != null) {
					Message_View.showUser(user, user_password, user_level,
							user_balance);
				}
			}
		});
		button_select.setForeground(Color.BLACK);
		button_select.setFont(new Font("宋体", Font.BOLD, 11));
		button_select.setBounds(263, 151, 58, 31);
		panel.add(button_select);

		// 返回按钮
		JButton button = new JButton("\u8FD4\u56DE");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				new Admin_View().setVisible(true);
			}
		});
		button.setForeground(Color.BLACK);
		button.setFont(new Font("宋体", Font.BOLD, 11));
		button.setBounds(333, 110, 81, 72);
		panel.add(button);

		JLabel label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon("images\\admin.png"));
		label_4.setBounds(0, 10, 437, 175);
		panel.add(label_4);
	}
}
