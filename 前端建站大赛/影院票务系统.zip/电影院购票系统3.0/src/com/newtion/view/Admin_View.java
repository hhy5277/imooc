package com.newtion.view;

import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;

//管理员界面
public class Admin_View extends JFrame {

	private static final long serialVersionUID = 1L;
	AdminManUser_View adminManUser_view = new AdminManUser_View();

	/**
	 * Create the frame.
	 */
	public Admin_View() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("\u7535\u5F71\u9662\u7968\u52A1\u7CFB\u7EDF-\u7BA1\u7406\u5458\u6A21\u5F0F");
		setIconImage(Toolkit.getDefaultToolkit().getImage("images\\admin.png"));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 608, 462);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu menu = new JMenu("  \u7528\u6237\u7BA1\u7406");
		menu.addMouseListener(new MouseAdapter() {

			/**
			 * 管理员界面--打开用户管理界面
			 */
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				AdminManUser_View frame = new AdminManUser_View();
				frame.setVisible(true);
			}
		});
		menuBar.add(menu);

		JMenu menu_3 = new JMenu("  \u5F71\u9662\u7BA1\u7406");
		menu_3.addMouseListener(new MouseAdapter() {
			
			/**
			 * 管理员界面--打开影院管理界面菜单
			 */
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				AdminManCinema_View frame = new AdminManCinema_View();
				frame.setVisible(true);
			}
		});
		menuBar.add(menu_3);

		JMenu menu_2 = new JMenu("  \u7535\u5F71\u7BA1\u7406");
		menu_2.addMouseListener(new MouseAdapter() {

			/**
			 * 管理员界面--打开电影管理界面菜单
			 */
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				AdminManMovie_View frame = new AdminManMovie_View();
				frame.setVisible(true);
			}
		});
		menuBar.add(menu_2);

		JMenu menu_4 = new JMenu("  \u653E\u6620\u7BA1\u7406");
		menu_4.addMouseListener(new MouseAdapter() {

			/**
			 * 管理员界面--打开放映管理界面菜单
			 */
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				AdminManHST_View frame = new AdminManHST_View();
				frame.setVisible(true);
			}
		});
		menuBar.add(menu_4);

		JMenu menu_5 = new JMenu("  \u8FD4\u56DE\u767B\u5F55");
		menu_5.addMouseListener(new MouseAdapter() {

			/**
			 * 管理员界面--返回到登录界面
			 */
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				new Log_View().showMain();
			}
		});
		menuBar.add(menu_5);
		getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("images\\dyy.jpg"));
		lblNewLabel.setBounds(0, 0, 607, 413);
		getContentPane().add(lblNewLabel);
	}
}
