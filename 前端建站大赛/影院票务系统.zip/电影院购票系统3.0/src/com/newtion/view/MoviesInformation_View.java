package com.newtion.view;

import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;

//电影介绍界面
public class MoviesInformation_View extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane1;
	private JTextField movie_name;
	private JTextField movie_actor;
	private JTextField movie_type;
	private JTextField movie_duration;
	private JTextArea movie_detail;
	private JLabel label;

	public JTextArea getMovie_detail() {
		return movie_detail;
	}

	public void setMovie_detail(JTextArea movie_detail) {
		this.movie_detail = movie_detail;
	}

	public JTextField getMovie_name() {
		return movie_name;
	}

	public void setMovie_name(JTextField movie_name) {
		this.movie_name = movie_name;
	}

	public JTextField getMovie_actor() {
		return movie_actor;
	}

	public void setMovie_actor(JTextField movie_actor) {
		this.movie_actor = movie_actor;
	}

	public JTextField getMovie_type() {
		return movie_type;
	}

	public void setMovie_type(JTextField movie_type) {
		this.movie_type = movie_type;
	}

	public JTextField getMovie_duration() {
		return movie_duration;
	}

	public void setMovie_duration(JTextField movie_duration) {
		this.movie_duration = movie_duration;
	}

	/**
	 * Create the frame.
	 */
	public MoviesInformation_View() {
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setResizable(false);
		setIconImage(Toolkit
				.getDefaultToolkit()
				.getImage(
						"E:\\AndroidEng\\projects\\Eclipse\\\u7535\u5F71\u9662\u8D2D\u7968\u7CFB\u7EDF2.0\\logo.jpg"));
		setTitle("\u7535\u5F71\u9662\u7968\u52A1\u7CFB\u7EDF-\u5F71\u7247\u4ECB\u7ECD");
		setBounds(100, 100, 492, 426);
		contentPane1 = new JPanel();
		contentPane1.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane1);
		contentPane1.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 486, 81);
		contentPane1.add(panel);
		panel.setLayout(null);

		movie_name = new JTextField();
		movie_name.setEditable(false);
		movie_name.setFont(new Font("宋体", Font.BOLD, 13));
		movie_name.setBounds(60, 10, 166, 21);
		panel.add(movie_name);
		movie_name.setColumns(10);

		movie_actor = new JTextField();
		movie_actor.setEditable(false);
		movie_actor.setFont(new Font("宋体", Font.BOLD, 13));
		movie_actor.setColumns(10);
		movie_actor.setBounds(307, 10, 151, 21);
		panel.add(movie_actor);

		movie_type = new JTextField();
		movie_type.setEditable(false);
		movie_type.setFont(new Font("宋体", Font.BOLD, 13));
		movie_type.setColumns(10);
		movie_type.setBounds(60, 40, 166, 21);
		panel.add(movie_type);

		movie_duration = new JTextField();
		movie_duration.setEditable(false);
		movie_duration.setFont(new Font("宋体", Font.BOLD, 13));
		movie_duration.setColumns(10);
		movie_duration.setBounds(307, 40, 151, 21);
		panel.add(movie_duration);

		JLabel label_1 = new JLabel("\u7247\u540D\uFF1A");
		label_1.setFont(new Font("宋体", Font.BOLD, 12));
		label_1.setBounds(10, 13, 54, 15);
		panel.add(label_1);

		JLabel label_2 = new JLabel("\u7C7B\u578B\uFF1A");
		label_2.setFont(new Font("宋体", Font.BOLD, 12));
		label_2.setBounds(10, 41, 54, 15);
		panel.add(label_2);

		JLabel label_3 = new JLabel("\u4E3B\u6F14\uFF1A");
		label_3.setFont(new Font("宋体", Font.BOLD, 12));
		label_3.setBounds(254, 13, 54, 15);
		panel.add(label_3);

		JLabel label_4 = new JLabel("\u65F6\u957F\uFF1A");
		label_4.setFont(new Font("宋体", Font.BOLD, 12));
		label_4.setBounds(254, 43, 54, 15);
		panel.add(label_4);
		
				movie_detail = new JTextArea();
				movie_detail.setBounds(0, 79, 486, 173);
				contentPane1.add(movie_detail);
				movie_detail.setEditable(false);
				movie_detail.setLineWrap(true);
				
				label = new JLabel("");
				label.setIcon(new ImageIcon("images\\logo.jpg"));
				label.setBounds(-129, 226, 867, 594);
				contentPane1.add(label);
	}
}
