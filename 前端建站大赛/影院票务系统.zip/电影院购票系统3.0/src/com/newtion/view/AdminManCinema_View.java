package com.newtion.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.newtion.controller.ControlAdminManCinema_View;
import com.newtion.daoimp.HallSessionDAOImp;

public class AdminManCinema_View extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTextField cinema_id;
	private JTextField cinema_name;
	private JTextField cinema_address;
	private JTextField halls;
	private JTextField capacity;

	/**
	 * Create the frame.
	 */
	public AdminManCinema_View() {
		setResizable(false);
		setIconImage(Toolkit
				.getDefaultToolkit()
				.getImage(
						"E:\\AndroidEng\\projects\\Eclipse\\\u7535\u5F71\u9662\u8D2D\u7968\u7CFB\u7EDF2.0\\admin.png"));
		setTitle("\u7BA1\u7406\u5458\u6A21\u5F0F - \u5F71\u9662\u7BA1\u7406\u754C\u9762");
		setBounds(100, 100, 540, 456);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(2, 1, 0, 0));

		JScrollPane scrollPane = new JScrollPane();
		scrollPane
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		contentPane.add(scrollPane);

		// 管理员模式--影院管理界面 -- 影院信息JTable
		table = new JTable();
		table.getTableHeader().setReorderingAllowed(false);
		table.setColumnSelectionAllowed(true);
		table.addMouseListener(new MouseAdapter() {

			@Override
			// 选中JTable表的某一行，这一行的信息显示在对应的Text文本框中
			public void mouseClicked(MouseEvent e) {
				int selRow = table.getSelectedRow();
				ControlAdminManCinema_View.adminToShowAll(table, cinema_id,
						cinema_name, cinema_address, halls, selRow);
			}
		});
		table.setCellSelectionEnabled(true);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setToolTipText("");
		table.setFillsViewportHeight(true);

		table.setModel(new DefaultTableModel(ControlAdminManCinema_View
				.showCinemas(), new String[] { "ID",
				"\u5F71\u9662\u540D\u5B57", "\u5F71\u9662\u5730\u5740",
				"\u573A\u5385" }));
		table.getColumnModel().getColumn(0).setPreferredWidth(104);
		table.getColumnModel().getColumn(1).setPreferredWidth(220);
		table.getColumnModel().getColumn(2).setPreferredWidth(233);
		scrollPane.setViewportView(table);

		JPanel panel = new JPanel();
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblId = new JLabel("\u7535\u5F71\u9662ID\uFF1A");
		lblId.setFont(new Font("宋体", Font.BOLD, 15));
		lblId.setBounds(16, 10, 100, 31);
		panel.add(lblId);

		JLabel label_1 = new JLabel("\u540D\u79F0\uFF1A");
		label_1.setFont(new Font("宋体", Font.BOLD, 15));
		label_1.setBounds(244, 18, 54, 15);
		panel.add(label_1);

		cinema_id = new JTextField();
		cinema_id.setEditable(false);
		cinema_id.setBounds(94, 15, 140, 21);
		panel.add(cinema_id);
		cinema_id.setColumns(10);

		cinema_name = new JTextField();
		cinema_name.setToolTipText("");
		cinema_name.setColumns(10);
		cinema_name.setBounds(300, 15, 202, 21);
		panel.add(cinema_name);

		// 管理员模式--影院管理界面--添加按钮
		JButton button_add = new JButton("\u6DFB\u52A0");
		button_add.setToolTipText("");
		button_add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cname = cinema_name.getText();
				String address = cinema_address.getText();
				ControlAdminManCinema_View.adminToaddCinema(cname, address,
						table);// 管理员添加影院方法
			}
		});

		button_add.setFont(new Font("宋体", Font.BOLD, 12));
		button_add.setForeground(Color.BLACK);
		button_add.setBounds(193, 120, 89, 31);
		panel.add(button_add);

		// 管理员模式--影院管理界面--删除按钮
		JButton button_delete = new JButton("\u5220\u9664");
		button_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = cinema_name.getText();
				ControlAdminManCinema_View.adminToDeleteCinema(name, table);// 管理员删除影院方法

			}
		});
		button_delete.setToolTipText("");
		button_delete.setForeground(Color.BLACK);
		button_delete.setFont(new Font("宋体", Font.BOLD, 12));
		button_delete.setBounds(300, 120, 93, 31);
		panel.add(button_delete);

		// 管理员模式--影院管理界面--修改按钮
		JButton button_update = new JButton("\u4FEE\u6539");
		button_update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cname = cinema_name.getText();
				String address = cinema_address.getText();
				// 管理员修改影院信息(只能修改影院地址)
				ControlAdminManCinema_View.adminToUpdateCinema(cname, address,
						table);

			}
		});
		button_update.setFont(new Font("宋体", Font.BOLD, 12));
		button_update.setForeground(Color.BLACK);
		button_update.setBounds(193, 161, 89, 31);
		panel.add(button_update);

		// 管理员模式--影院管理界面--查询按钮
		JButton button_select = new JButton("\u67E5\u8BE2");
		button_select.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cname = cinema_name.getText();
				ControlAdminManCinema_View.adminToSelectCinema(cinema_id,
						cname, cinema_address);
			}
		});
		button_select.setForeground(Color.BLACK);
		button_select.setFont(new Font("宋体", Font.BOLD, 12));
		button_select.setBounds(300, 161, 93, 31);
		panel.add(button_select);

		JLabel label = new JLabel("\u5F71\u9662\u5730\u5740\uFF1A");
		label.setFont(new Font("宋体", Font.BOLD, 15));
		label.setBounds(16, 77, 100, 18);
		panel.add(label);

		cinema_address = new JTextField();
		cinema_address.setToolTipText("");
		cinema_address.setColumns(10);
		cinema_address.setBounds(94, 72, 408, 26);
		panel.add(cinema_address);

		JButton button = new JButton("\u8FD4\u56DE");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				new Admin_View().setVisible(true);
			}
		});
		button.setToolTipText("");
		button.setForeground(Color.BLACK);
		button.setFont(new Font("宋体", Font.BOLD, 12));
		button.setBounds(408, 161, 94, 31);
		panel.add(button);

		JLabel label_2 = new JLabel("\u573A   \u5385\uFF1A");
		label_2.setFont(new Font("宋体", Font.BOLD, 15));
		label_2.setBounds(16, 32, 100, 47);
		panel.add(label_2);

		// 场厅容量，默认36
		halls = new JTextField();
		halls.setEditable(false);
		halls.setToolTipText("");
		halls.setColumns(10);
		halls.setBounds(94, 42, 140, 26);
		panel.add(halls);

		// 添加场厅按钮
		JButton button_1 = new JButton("\u6DFB\u52A0\u573A\u5385");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String cid = cinema_id.getText();
				new HallSessionDAOImp().addHall(cid);
				table.setModel(new DefaultTableModel(ControlAdminManCinema_View
						.showCinemas(), new String[] { "ID",
						"\u5F71\u9662\u540D\u5B57", "\u5F71\u9662\u5730\u5740",
						"\u573A\u5385" }));
			}
		});
		button_1.setToolTipText("");
		button_1.setForeground(Color.BLACK);
		button_1.setFont(new Font("宋体", Font.BOLD, 12));
		button_1.setBounds(408, 120, 94, 31);
		panel.add(button_1);

		JLabel label_3 = new JLabel("\u5BB9\u91CF\uFF1A");
		label_3.setFont(new Font("宋体", Font.BOLD, 15));
		label_3.setBounds(244, 32, 65, 47);
		panel.add(label_3);

		capacity = new JTextField();
		capacity.setToolTipText("");
		capacity.setEditable(false);
		capacity.setColumns(10);
		capacity.setBounds(300, 42, 202, 26);
		capacity.setText("36");
		panel.add(capacity);

		JLabel label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon("images\\admin.png"));
		label_4.setBounds(0, 0, 524, 192);
		panel.add(label_4);
	}
}
