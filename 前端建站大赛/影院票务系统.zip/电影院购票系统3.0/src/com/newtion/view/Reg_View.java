package com.newtion.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.newtion.controller.ControlLogAndReg_View;
import com.newtion.model.User;

//注册界面
public class Reg_View extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_UserName;
	private JPasswordField textField_UserPassword;
	private JPasswordField textField_UserPassword2;

	/**
	 * Launch the application.
	 */
	public void regStart() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reg_View frame = new Reg_View();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Reg_View() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("images\\logo.jpg"));
		setTitle("\u7535\u5F71\u9662\u7968\u52A1\u7CFB\u7EDF-\u6CE8\u518C\u754C\u9762");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 360, 271);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel_0 = new JPanel();
		panel_0.setBounds(5, 5, 344, 58);
		contentPane.add(panel_0);
		panel_0.setLayout(null);

		JLabel label = new JLabel("\u7528\u6237\u540D");
		label.setFont(new Font("黑体", Font.BOLD, 18));
		label.setBounds(53, 22, 63, 15);
		panel_0.add(label);

		textField_UserName = new JTextField();
		textField_UserName.setBounds(137, 16, 164, 32);
		panel_0.add(textField_UserName);
		textField_UserName.setColumns(10);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(5, 63, 344, 58);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JLabel label_1 = new JLabel("\u5BC6 \u7801");
		label_1.setBounds(58, 15, 57, 21);
		label_1.setFont(new Font("黑体", Font.BOLD, 18));
		panel_1.add(label_1);

		textField_UserPassword = new JPasswordField();
		textField_UserPassword.setColumns(10);
		textField_UserPassword.setBounds(138, 12, 163, 32);
		panel_1.add(textField_UserPassword);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(5, 121, 344, 58);
		contentPane.add(panel_2);
		panel_2.setLayout(null);

		JLabel label_2 = new JLabel("\u786E\u8BA4\u5BC6\u7801");
		label_2.setBounds(48, 10, 76, 21);
		label_2.setFont(new Font("黑体", Font.BOLD, 18));
		panel_2.add(label_2);

		textField_UserPassword2 = new JPasswordField();
		textField_UserPassword2.setBounds(138, 5, 163, 31);
		textField_UserPassword2.setColumns(10);
		panel_2.add(textField_UserPassword2);

		JPanel panel_3 = new JPanel();
		panel_3.setBounds(5, 179, 344, 58);
		contentPane.add(panel_3);
		panel_3.setLayout(null);

		/**
		 * 返回按钮：返回登录界面
		 */
		JButton button = new JButton("\u8FD4\u56DE");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				new Log_View().setVisible(true);
			}
		});
		button.setFont(new Font("宋体", Font.BOLD, 12));
		button.setForeground(Color.BLUE);
		button.setBounds(237, 10, 66, 23);
		panel_3.add(button);

		/**
		 * 注册按钮的触发事件
		 */
		JButton button_1 = new JButton("\u786E\u5B9A");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// 获取用户名
				String name = textField_UserName.getText();
				// 获取用户密码01
				String password01 = new String(textField_UserPassword
						.getPassword());

				// 获取用户密码02
				String password02 = new String(textField_UserPassword2
						.getPassword());

				// 检查两次输入密码是否一致
				if (password01.equals(password02) == false) {
					Message_View.warningDialog("两次输入的密码不同，请重新注册！");
					// 两次输入的密码不一致就清空密码框
					textField_UserPassword.setText("");
					textField_UserPassword2.setText("");

				} else {
					User user = new User(name, password01);
					if (user.getName().trim().length() == 0
							|| user.getPassword().length() == 0) {
						Message_View.warningDialog("用户名或密码不能为空，请重新注册!");
					} else {

						// 用户注册
						boolean bool = ControlLogAndReg_View.UserReg(user);
						if (bool == true) {
							Message_View.infoDialog("注册成功!");
							setVisible(false);
							new Log_View().setVisible(true);
						} else {
							Message_View.infoDialog("该用户名已存在，请重新注册!");
						}
					}
				}
			}
		});
		button_1.setForeground(Color.BLUE);
		button_1.setFont(new Font("宋体", Font.BOLD, 12));
		button_1.setBounds(161, 10, 66, 23);
		panel_3.add(button_1);
	}
}
