package com.newtion.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import com.newtion.controller.ControlAdminManMovie_View;
import com.newtion.model.Movie;

public class AdminManMovie_View extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTextField movie_id;
	private JTextField movie_name;
	private JTextField movie_type;
	private JTextField movie_actors;
	private JTextField movie_duration;
	private JTextArea movie_detail_1;

	/**
	 * Create the frame.
	 */
	public AdminManMovie_View() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage("images\\admin.png"));
		setTitle("\u7BA1\u7406\u5458\u6A21\u5F0F - \u7535\u5F71\u7BA1\u7406\u754C\u9762");
		setBounds(100, 100, 540, 480);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 5, 524, 183);
		scrollPane
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		contentPane.add(scrollPane);

		// 管理员模式--电影管理界面 -- 电影信息JTable
		table = new JTable();
		table.getTableHeader().setReorderingAllowed(false);
		table.setColumnSelectionAllowed(true);
		table.addMouseListener(new MouseAdapter() {

			@Override
			// 选中JTable表的某一行，这一行的信息显示在对应的Text文本框中
			public void mouseClicked(MouseEvent e) {
				int selRow = table.getSelectedRow();
				ControlAdminManMovie_View.adminToShowAll(table, movie_id,
						movie_name, movie_type, movie_actors, movie_duration,
						movie_detail_1, selRow);
			}
		});
		table.setCellSelectionEnabled(true);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setToolTipText("");
		table.setFillsViewportHeight(true);
		table.setModel(new DefaultTableModel(
		// 显示所有电影到JTable中
				ControlAdminManMovie_View.showMovies(), new String[] { "ID",
						"\u7247\u540D", "\u7C7B\u578B", "\u4E3B\u6F14",
						"\u65F6\u957F", "\u5F71\u7247\u4ECB\u7ECD" }));
		table.getColumnModel().getColumn(0).setPreferredWidth(44);
		table.getColumnModel().getColumn(1).setPreferredWidth(95);
		table.getColumnModel().getColumn(2).setPreferredWidth(78);
		table.getColumnModel().getColumn(3).setPreferredWidth(131);
		table.getColumnModel().getColumn(5).setPreferredWidth(156);
		scrollPane.setViewportView(table);

		JPanel panel = new JPanel();
		panel.setBounds(5, 191, 524, 263);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblId = new JLabel("\u5F71\u7247ID \uFF1A");
		lblId.setFont(new Font("宋体", Font.BOLD, 15));
		lblId.setBounds(16, 10, 100, 31);
		panel.add(lblId);

		JLabel label_1 = new JLabel("\u7247\u540D\uFF1A");
		label_1.setFont(new Font("宋体", Font.BOLD, 15));
		label_1.setBounds(171, 18, 54, 15);
		panel.add(label_1);

		movie_id = new JTextField();
		movie_id.setEditable(false);
		movie_id.setBounds(107, 15, 54, 21);
		panel.add(movie_id);
		movie_id.setColumns(10);

		movie_name = new JTextField();
		movie_name.setToolTipText("");
		movie_name.setColumns(10);
		movie_name.setBounds(227, 15, 100, 21);
		panel.add(movie_name);

		// 管理员模式--电影管理界面--添加按钮
		JButton button_add = new JButton("\u6DFB\u52A0");
		button_add.setToolTipText("");
		button_add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mname = movie_name.getText();
				String type = movie_type.getText();
				String actors = movie_actors.getText();
				int duration = 0;
				String dur = movie_duration.getText();
				if (dur.length() != 0) {
					try {
						duration = Integer.parseInt(dur);
						if (duration <= 0) {
							Message_View.warningDialog("电影时长不正确！");
						} else {
							String detail = movie_detail_1.getText();
							Movie movie = new Movie(mname, type, actors,
									duration, detail);
							ControlAdminManMovie_View.adminToaddMovie(movie,
									table);// 管理员添加影片方法
						}
					} catch (NumberFormatException e1) {
						Message_View.warningDialog("电影时长必须是数字！");
					}
				} else {
					Message_View.warningDialog("新添加的电影时长不能为空!");
				}
			}
		});

		button_add.setFont(new Font("宋体", Font.BOLD, 12));
		button_add.setForeground(Color.BLACK);
		button_add.setBounds(265, 185, 65, 31);
		panel.add(button_add);

		// 管理员模式--影片管理界面--删除按钮
		JButton button_delete = new JButton("\u5220\u9664");
		button_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mname = movie_name.getText();
				ControlAdminManMovie_View.adminToDeleteMovie(mname, table);// 管理员删除电影方法
			}
		});
		button_delete.setToolTipText("");
		button_delete.setForeground(Color.BLACK);
		button_delete.setFont(new Font("宋体", Font.BOLD, 12));
		button_delete.setBounds(265, 219, 65, 31);
		panel.add(button_delete);

		// 管理员模式--影片管理界面--修改按钮
		JButton button_update = new JButton("\u4FEE\u6539");
		button_update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mname = movie_name.getText();
				String type = movie_type.getText();
				String actors = movie_actors.getText();
				String detail = movie_detail_1.getText();
				Movie movie = new Movie(mname, type, actors, detail);
				ControlAdminManMovie_View.adminToUpdateMovie(movie, table);

			}
		});
		button_update.setFont(new Font("宋体", Font.BOLD, 12));
		button_update.setForeground(Color.BLACK);
		button_update.setBounds(340, 185, 65, 31);
		panel.add(button_update);

		// 管理员模式--电影管理界面--查询按钮
		JButton button_select = new JButton("\u67E5\u8BE2");
		button_select.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String mname = movie_name.getText();
				// 通过电影的名称查询电影信息
				ControlAdminManMovie_View.adminToSelectMovie(mname, movie_id,
						movie_name, movie_type, movie_actors, movie_duration,
						movie_detail_1);
			}
		});
		button_select.setForeground(Color.BLACK);
		button_select.setFont(new Font("宋体", Font.BOLD, 12));
		button_select.setBounds(340, 219, 65, 31);
		panel.add(button_select);

		JLabel label = new JLabel("\u5F71\u7247\u4ECB\u7ECD\uFF1A");
		label.setFont(new Font("宋体", Font.BOLD, 15));
		label.setBounds(16, 85, 80, 18);
		panel.add(label);

		JScrollPane movie_detail = new JScrollPane();
		movie_detail
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		movie_detail
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		movie_detail.setBounds(107, 77, 395, 88);
		panel.add(movie_detail);

		movie_detail_1 = new JTextArea();
		movie_detail_1.setLineWrap(true);
		movie_detail.setViewportView(movie_detail_1);

		movie_type = new JTextField();
		movie_type.setToolTipText("");
		movie_type.setColumns(10);
		movie_type.setBounds(388, 15, 100, 21);
		panel.add(movie_type);

		JLabel label_2 = new JLabel("\u7C7B\u578B\uFF1A");
		label_2.setFont(new Font("宋体", Font.BOLD, 15));
		label_2.setBounds(336, 18, 54, 15);
		panel.add(label_2);

		JLabel label_3 = new JLabel("\u4E3B  \u6F14 \uFF1A");
		label_3.setFont(new Font("宋体", Font.BOLD, 15));
		label_3.setBounds(16, 44, 100, 31);
		panel.add(label_3);

		movie_actors = new JTextField();
		movie_actors.setColumns(10);
		movie_actors.setBounds(107, 49, 220, 21);
		panel.add(movie_actors);

		JLabel label_5 = new JLabel("\u65F6\u957F\uFF1A");
		label_5.setFont(new Font("宋体", Font.BOLD, 15));
		label_5.setBounds(336, 49, 54, 15);
		panel.add(label_5);

		Label label_6 = new Label("\u5206\u949F");
		label_6.setBounds(456, 50, 29, 15);
		panel.add(label_6);

		movie_duration = new JTextField();
		movie_duration.setToolTipText("");
		movie_duration.setColumns(10);
		movie_duration.setBounds(388, 46, 100, 21);
		panel.add(movie_duration);

		// 返回按钮
		JButton button = new JButton("\u8FD4\u56DE");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				new Admin_View().setVisible(true);
			}
		});
		button.setForeground(Color.BLACK);
		button.setFont(new Font("宋体", Font.BOLD, 12));
		button.setBounds(420, 185, 82, 65);
		panel.add(button);

		JLabel label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon("images\\admin.png"));
		label_4.setBounds(0, 10, 524, 216);
		panel.add(label_4);
	}
}
