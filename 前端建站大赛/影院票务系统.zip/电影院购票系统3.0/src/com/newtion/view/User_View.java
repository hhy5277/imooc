package com.newtion.view;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class User_View extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public JTextField user_name;
	public JTextField user_balance;
	public JTextField user_level;

	/**
	 * Create the frame.
	 */
	public User_View() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setIconImage(Toolkit
				.getDefaultToolkit()
				.getImage(
						"E:\\AndroidEng\\projects\\Eclipse\\\u7535\u5F71\u9662\u8D2D\u7968\u7CFB\u7EDF2.0\\user.jpg"));
		setTitle("\u7535\u5F71\u9662\u7968\u52A1\u7CFB\u7EDF--\u7528\u6237\u754C\u9762");
		setResizable(false);
		setBounds(100, 100, 506, 424);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 10, 499, 146);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel label = new JLabel("\u7528\u6237\u540D\uFF1A");
		label.setFont(new Font("宋体", Font.BOLD, 14));
		label.setBounds(163, 24, 70, 37);
		panel.add(label);

		user_name = new JTextField();
		user_name.setFont(new Font("宋体", Font.BOLD, 12));
		user_name.setEditable(false);
		user_name.setBounds(243, 32, 238, 21);

		user_name.setText("");
		panel.add(user_name);
		user_name.setColumns(10);

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(0, 10, 143, 126);
		panel.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon("images\\touxiang.png"));

		JLabel label_1 = new JLabel("\u4F59 \u989D\uFF1A");
		label_1.setFont(new Font("宋体", Font.BOLD, 14));
		label_1.setBounds(163, 66, 59, 29);
		panel.add(label_1);

		user_balance = new JTextField();
		user_balance.setFont(new Font("宋体", Font.BOLD, 12));
		user_balance.setEditable(false);
		user_balance.setColumns(10);
		user_balance.setBounds(243, 70, 90, 21);
		panel.add(user_balance);

		JPanel panel_4 = new JPanel();
		panel_4.setBounds(10, 10, 143, 126);
		panel.add(panel_4);
		panel_4.setLayout(null);

		JLabel label_2 = new JLabel("\u5E10\u53F7\u7B49\u7EA7\uFF1A");
		label_2.setFont(new Font("宋体", Font.BOLD, 14));
		label_2.setBounds(345, 66, 80, 29);
		panel.add(label_2);

		user_level = new JTextField();
		user_level.setFont(new Font("宋体", Font.BOLD, 12));
		user_level.setEditable(false);
		user_level.setColumns(10);
		user_level.setBounds(428, 70, 53, 21);
		panel.add(user_level);

		/**
		 * 充值按钮
		 */
		JButton button_1 = new JButton("\u5145\u503C");
		button_1.setFont(new Font("宋体", Font.BOLD, 12));
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				UserAddMoney_View.userAddMoney_ViewStart();
				setVisible(false);
			}
		});
		button_1.setBounds(173, 107, 70, 31);
		panel.add(button_1);

		/**
		 * 购买影票按钮
		 */
		JButton button_2 = new JButton("\u8D2D\u7968");
		button_2.setFont(new Font("宋体", Font.BOLD, 12));
		button_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				UserPurchTicket_View upv = new UserPurchTicket_View();
				upv.setVisible(true);
			}
		});
		button_2.setBounds(333, 107, 70, 31);
		panel.add(button_2);

		/*
		 * 返回登录界面按钮
		 */
		JButton button_3 = new JButton("\u9000\u51FA");
		button_3.setFont(new Font("宋体", Font.BOLD, 12));
		button_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				new Log_View().setVisible(true);
			}
		});
		button_3.setBounds(413, 105, 70, 33);
		panel.add(button_3);
		
		/**
		 * 修改密码按钮
		 */
		JButton button = new JButton("\u6539\u5BC6");
		button.setFont(new Font("宋体", Font.BOLD, 12));
		button.setBounds(253, 107, 70, 31);
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				UserModif_View uamv = new UserModif_View();
				uamv.setVisible(true);
			}
		});
		panel.add(button);
		
		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon("images\\dy.jpg"));
		label_3.setBounds(0, 155, 499, 253);
		contentPane.add(label_3);
	}
}
