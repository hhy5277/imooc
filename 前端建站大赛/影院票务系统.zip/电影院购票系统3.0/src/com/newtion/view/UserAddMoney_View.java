package com.newtion.view;

import java.awt.Choice;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.newtion.controller.ControlUserAddMoney_View;

public class UserAddMoney_View extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public JTextField user_balance;
	private Choice choice;

	/**
	 * Launch the application.
	 */
	public static void userAddMoney_ViewStart() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserAddMoney_View uamv = new UserAddMoney_View();
					uamv.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserAddMoney_View() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setIconImage(Toolkit
				.getDefaultToolkit()
				.getImage(
						"E:\\AndroidEng\\projects\\Eclipse\\\u7535\u5F71\u9662\u8D2D\u7968\u7CFB\u7EDF2.0\\user.jpg"));
		setTitle("\u7528\u6237\u6A21\u5F0F--\u5145\u503C\u754C\u9762");
		setResizable(false);
		setBounds(100, 100, 401, 198);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 376, 150);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel label = new JLabel("\u5145 \u503C\uFF1A");
		label.setFont(new Font("宋体", Font.BOLD, 14));
		label.setBounds(178, 55, 60, 37);
		panel.add(label);

		/**
		 * 充值界面显示余额
		 */
		user_balance = new JTextField();
		user_balance.setFont(new Font("宋体", Font.BOLD, 12));
		user_balance.setEditable(false);
		user_balance.setBounds(243, 32, 107, 21);
		user_balance.setText(Log_View.uv.user_balance.getText());
		panel.add(user_balance);
		user_balance.setColumns(10);

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(10, 10, 126, 126);
		panel.add(lblNewLabel);
		lblNewLabel
				.setIcon(new ImageIcon(
						"images\\touxiang.png"));

		JLabel label_1 = new JLabel("\u4F59 \u989D\uFF1A");
		label_1.setFont(new Font("宋体", Font.BOLD, 14));
		label_1.setBounds(178, 28, 60, 29);
		panel.add(label_1);

		JPanel panel_4 = new JPanel();
		panel_4.setBounds(10, 10, 143, 126);
		panel.add(panel_4);
		panel_4.setLayout(null);

		/**
		 * 充值确定按钮
		 */
		JButton button_1 = new JButton("\u786E\u5B9A");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String money = choice.getSelectedItem();
				double rentMoney = (Double.parseDouble(user_balance.getText()
						.trim()) + Integer.parseInt(money.trim()));
				// 数据库更新用户余额
				ControlUserAddMoney_View.addMoney(Log_View.uv.user_name.getText(), rentMoney);
				Message_View.infoDialog("成功充值" + money + "元!");
				String rentMoney2 = Double.toString(rentMoney);
				user_balance.setText(rentMoney2);
				Log_View.uv.user_balance.setText(rentMoney2);

			}
		});
		button_1.setForeground(Color.BLACK);
		button_1.setFont(new Font("宋体", Font.BOLD, 12));
		button_1.setBounds(220, 107, 60, 29);
		panel.add(button_1);
		
		// 显示可充值面额：50/100/150....
		choice = new Choice();
		choice.setBounds(243, 63, 107, 21);
		ControlUserAddMoney_View.showMoney(choice);
		panel.add(choice);
		
		/**
		 * 返回按钮
		 */
		JButton button = new JButton("\u8FD4\u56DE");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				new Log_View();
				Log_View.uv.setVisible(true);
			}
		});
		button.setForeground(Color.BLACK);
		button.setFont(new Font("宋体", Font.BOLD, 12));
		button.setBounds(290, 107, 60, 29);

		panel.add(button);
	}
}
