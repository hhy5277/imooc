package com.newtion.dao;

import java.sql.SQLException;

import com.newtion.model.Session;
import com.newtion.model.User;

public interface TicketDAO {

	/**
	 * 通过座位号找对应的票
	 * 
	 * @param seat
	 * @return
	 */
	public boolean findTicketSeat(String seat, int sid) throws SQLException;

	/**
	 * 向ticket表添加票
	 * 
	 * @param seat
	 * @param user
	 * @param session
	 */
	public void addTicketSeat(String seat, User user, Session session);

}
