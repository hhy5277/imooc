package com.newtion.dao;

import java.util.List;

import com.newtion.model.Movie;

//电影表操作接口
public interface MovieDAO {

	/**
	 * 向数据库的电影表中添加新的电影
	 * 
	 * @param movie
	 * @return
	 */
	public boolean addMovie(Movie movie);

	/**
	 * 通过电影名查找电影
	 * 
	 * @param cinema
	 * @return
	 */
	public boolean findMovieByName02(Movie movie);

	/**
	 * 通过电影名查找电影
	 * 
	 * @param movie
	 * @return Movie对象
	 */
	public Movie findMovieByName(String mname);

	/**
	 * 显示数据库中所有电影
	 * 
	 * @return
	 */
	public List<Movie> showMovies();

	/**
	 * 删除影院 By mname
	 * 
	 * @param movie
	 * @return
	 */
	public boolean deleteMovieByName(Movie movie);

	/**
	 * 管理员修改电影信息
	 * 
	 * @param mname
	 * @param
	 * @return
	 */
	public boolean updateMovie(Movie movie);

	/**
	 * 获取所有电影名名称
	 * @return
	 */
	public List<String> showMoviesName();
	
}
