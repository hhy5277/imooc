package com.newtion.dao;

import java.util.List;

import com.newtion.model.User;

//用户表操作接口
public interface UserDAO {
	/**
	 * 查看数据库的用户表中是否存在某个用户
	 * 
	 * @param user
	 * @return 存在返回true,不存在返回false
	 */
	public boolean findUser(User user);

	/**
	 * 向数据库的用户表中添加某个用户
	 * 
	 * @param user
	 * @return
	 */
	public boolean addUser(User user);

	/**
	 * 通过姓名查找用户
	 * @param user
	 * @return
	 */
	public User findUserByName(User user);

	/**
	 * 通过姓名查找用户
	 * 
	 * @param user
	 *            ,i
	 * @return 返回该用户
	 */
	public User findUserByNameIdR(User user, int i);

	/**
	 * 通过ID和姓名查找用户
	 * 
	 * @param user
	 * @return
	 */
	public boolean findUserByIdName(User user);

	/**
	 * 通过ID查找用户
	 * 
	 * @param user
	 * @return
	 */
	public boolean findUserById(User user);

	/**
	 * 查找用户是否存在，
	 * 
	 * @param user
	 * @param i
	 *            模式
	 * @return
	 */
	public boolean findUserByName(User user, int i);

	/**
	 * 通过姓名查找管理员
	 * 
	 * @param user
	 * @return
	 */
	public boolean findAdminByName(User user);

	/**
	 * 显示数据库中所有用户的信息
	 * 
	 * @return
	 */
	public List<User> showUsers();

	/**
	 * 删除用户 By name
	 * 
	 * @param user
	 * @return
	 */
	public boolean deleteByName(User user);

	

	/**
	 * 更新用户信息
	 * 
	 * @param user
	 * @return
	 */
	public boolean adminUpdateUser(User user);

	/**
	 * 用户充值
	 * 
	 * @param uname
	 * @param money
	 */
	public void updateBalance(String uname, double money);

	/**
	 * 用户修改用户名和密码
	 * 
	 * @param password
	 * @param name
	 * @return
	 */
	public void userUpdateNamePass(String password, String name);

	/**
	 * 检查用户余额是否>=买票所花金额
	 * 
	 * @param user
	 * @param cost
	 */
	public boolean CheckUserBalance(User user, double cost);

	/**
	 * 找用户ID
	 * 
	 * @param user
	 * @return
	 */
	public int getUid(User user);

	/**
	 * 更新用户帐号等级
	 * 
	 * @param name
	 * @param level
	 */
	public void updateLevel(String name, int level);
	
}
