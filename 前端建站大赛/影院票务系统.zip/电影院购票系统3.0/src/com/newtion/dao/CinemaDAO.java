package com.newtion.dao;

import java.util.List;

import com.newtion.model.Cinema;

//影院表操作接口
public interface CinemaDAO {
	
	/**
	 * 向数据库的影院表中添加新的影院
	 * @param cinema
	 * @return
	 */
	public boolean addCinema(Cinema cinema);
	
	/**
	 * 通过影院名查找影院
	 * @param cinema
	 * @return
	 */
	public boolean findCinemaByName(Cinema cinema);
	
	/**
	 * 通过影院名查找影院
	 * @param cinema
	 * @return Cinema对象
	 */
	public Cinema findCinemaByName(String cname);
	
	/**
	 * 显示数据库中所有影院的信息
	 * @return
	 */
	public List<Cinema> showCinemas();
	
	/**
	 * 删除影院 By cname
	 * @param cinema
	 * @return
	 */
	public boolean  deleteCinemaByName(Cinema cinema);
	
	/**
	 * 管理员修改影院信息(只能修改影院地址)
	 * @param cname
	 * @param address
	 * @return
	 */
	public boolean updateCinemaAddress(String cname,String address);
	
	/**
	 * 输出所有电影院名称
	 * @return
	 */
	public List<String> showCinemasName();
	
	/**
	 * 通过电影院名字查询影院ID
	 * @param cname
	 * @return
	 */
	public int findCinemaIdByCname(String cname);
}
