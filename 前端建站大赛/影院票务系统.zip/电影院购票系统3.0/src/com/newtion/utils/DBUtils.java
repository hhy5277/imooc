package com.newtion.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

//数据库工具类
public class DBUtils {

	private static String DRIVER;// 驱动
	private static String URL;// 数据库连接路径
	private static ResourceBundle rb = ResourceBundle
			.getBundle("com.newtion.utils.db-config");

	// 加载JDBC驱动
	static {
		DRIVER = rb.getString("jdbc-driver");
		URL = rb.getString("jdbc-url");

		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println("加载驱动失败！");
		}
	}

	// 连接数据库
	public static Connection getConnection() {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(URL);
		} catch (SQLException e) {
			System.out.println("连接数据库失败！");
		}
		return conn;
	}

	// 关闭数据库
	public static void closeAll(ResultSet rs, PreparedStatement ps,
			Connection conn) {

		try {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {

			System.out.println("关闭数据库失败！");
		}
	}
}
