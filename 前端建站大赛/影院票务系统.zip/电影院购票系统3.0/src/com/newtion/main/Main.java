package com.newtion.main;

import com.newtion.view.Log_View;

//�ͻ���

public class Main {

	public static void main(String[] args) {
		
		Log_View lv = new Log_View();
		lv.showMain();

	}
}
