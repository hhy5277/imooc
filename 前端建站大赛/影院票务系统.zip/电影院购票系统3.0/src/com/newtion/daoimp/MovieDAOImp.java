package com.newtion.daoimp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.newtion.dao.MovieDAO;
import com.newtion.model.Movie;
import com.newtion.utils.DBUtils;

public class MovieDAOImp extends DBUtils implements MovieDAO {

	@Override
	public boolean addMovie(Movie movie) {
		boolean bool = findMovieByName02(movie);
		if (bool == false) {
			Connection conn = super.getConnection();
			PreparedStatement ps = null;
			try {
				String sql = "insert into movies(mname,type,actors,duration,detail)values(?,?,?,?,?);";
				ps = conn.prepareStatement(sql);
				ps.setString(1, movie.getMname());
				ps.setString(2, movie.getType());
				ps.setString(3, movie.getActors());
				ps.setInt(4, movie.getDuration());
				ps.setString(5, movie.getDetail());
				ps.executeUpdate();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				super.closeAll(null, ps, conn);
			}
		}
		return false;
	}

	@Override
	public boolean findMovieByName02(Movie movie) {
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "select mid,mname,type,actors,duration,detail from movies where mname = ? ;";
			ps = conn.prepareStatement(sql);
			ps.setString(1, movie.getMname());
			rs = ps.executeQuery();
			while (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return false;
	}

	@Override
	public Movie findMovieByName(String name) {
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "select mid,mname,type,actors,duration,detail from movies where mname = ? ;";
			ps = conn.prepareStatement(sql);
			ps.setString(1, name);
			rs = ps.executeQuery();
			while (rs.next()) {
				return new Movie(rs.getInt(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getInt(5),
						rs.getString(6));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return null;
	}

	@Override
	public List<Movie> showMovies() {
		String sql = "select mid,mname,type,actors,duration,detail from movies;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Movie> movies = new ArrayList<Movie>();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				movies.add(new Movie(rs.getInt(1), rs.getString(2), rs
						.getString(3), rs.getString(4), rs.getInt(5), rs
						.getString(6)));
			}
			return movies;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return null;
	}

	@Override
	public boolean deleteMovieByName(Movie movie) {
		boolean bool = findMovieByName02(movie);
		if (bool == true) {
			String sql = "delete from movies where mname =? ";
			Connection conn = super.getConnection();
			PreparedStatement ps = null;
			try {
				ps = conn.prepareStatement(sql);
				ps.setString(1, movie.getMname());
				ps.executeUpdate();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				super.closeAll(null, ps, conn);
			}
		}
		return false;
	}

	@Override
	public boolean updateMovie(Movie movie) {
		boolean bool = findMovieByName02(movie);
		if (bool == true) {
			String sql = "update movies set mname=?,type=?,actors=?,detail=? where mname =?;";
			Connection conn = super.getConnection();
			PreparedStatement ps = null;
			try {
				ps = conn.prepareStatement(sql);
				ps.setString(1, movie.getMname());
				ps.setString(2, movie.getType());
				ps.setString(3, movie.getActors());
				ps.setString(4, movie.getDetail());
				ps.setString(5, movie.getMname());
				ps.executeUpdate();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				super.closeAll(null, ps, conn);
			}
		}
		return false;
	}

	@Override
	public List<String> showMoviesName(){
		String sql = "select mname from movies;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<String> mnames = new ArrayList<String>();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				mnames.add(rs.getString("mname"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return mnames;
	}
}
