package com.newtion.daoimp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.newtion.dao.HallSessionDAO;
import com.newtion.model.Movie;
import com.newtion.model.Session;
import com.newtion.model.Ticket;
import com.newtion.model.User;
import com.newtion.utils.DBUtils;
import com.newtion.view.Message_View;

//�������νӿ�ʵ����
public class HallSessionDAOImp extends DBUtils implements HallSessionDAO {

	@Override
	public List<Session> showsessions(int i) {
		String sql = "select sid,cname,hall_id,mname,time,price,remain"
				+ " from session,movies,hall,cinema "
				+ "where hall_id = hid and movies_id = mid and cinema_id = cid;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Session> session = new ArrayList<Session>();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				Session ses = new Session(rs.getInt(1), rs.getString(2),
						rs.getInt(3), rs.getString(4), rs.getString(5),
						rs.getInt(6), rs.getInt(7));
				Date d1 = new Date(); // ��ǰʱ��
				DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
				try {
					// ���ڱȽ�
					String nowys = df1.format(d1);// ��ǰ����
					String seeys = rs.getString(5).substring(0, 11);// ��������
					String nowyss[] = nowys.split("-");
					int nowyi = Integer.parseInt(nowyss[0]+nowyss[1]);
					String seeyss[] = seeys.split("-");
					int seeyi = Integer.parseInt(seeyss[0]+seeyss[1]);
					int div = nowyi - seeyi;
					// ʱ��Ƚ�
					SimpleDateFormat f2 = new SimpleDateFormat("HH:mm");
					int nowInt = Integer.parseInt(f2.format(d1).toString()
							.replace(":", "")); // ����һ��ʱ���ʽ����תΪint
					String sesInfo = rs.getString(5).substring(11)
							.replace(":", ""); // ����ʱ��String��ʽ
					int sesInt = Integer.parseInt(sesInfo);// ���ڶ���ʱ���ʽ����תΪint
					if (i == 0) {
						if (nowInt < sesInt
								&& div <= 0) {
							session.add(ses);// �û�ģʽչʾ�����Թ���ĳ���
						}
					} else {
						session.add(ses);// ����Աģʽչʾ���г���
					}
				} catch (Exception exception) {
					exception.printStackTrace();
				}
			}
			return session;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return null;
	}

	@Override
	public List<Integer> showHallId(String cname) {
		int cid = new CinemaDAOImp().findCinemaIdByCname(cname);
		String sql = "select hid from hall where cinema_id =?;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Integer> ids = new ArrayList<Integer>();
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, cid);
			rs = ps.executeQuery();
			while (rs.next()) {
				ids.add(rs.getInt(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return ids;
	}

	@Override
	public Session findSessionBySid(int sid) {
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "select remain from session where sid = ? ;";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, sid);
			rs = ps.executeQuery();
			while (rs.next()) {
				return new Session(rs.getInt(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return null;
	}

	@Override
	public Ticket findTicketBySeatName(String seat) {
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "select user_id,session_id,seat from ticket where seat = ? ;";
			ps = conn.prepareStatement(sql);
			ps.setString(1, seat);
			rs = ps.executeQuery();
			User user = new User(rs.getInt(1));
			Session session = new Session();
			session.setSid(rs.getInt(2));
			while (rs.next()) {
				return new Ticket(user, session, rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return null;
	}

	@Override
	public void updateRemain(int sid) {
		Session session = findSessionBySid(sid);
		String sql = "update session set remain= ? where sid =?;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, session.getRemain() - 1);
			ps.setInt(2, sid);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(null, ps, conn);
		}
	}

	@Override
	public boolean checkRemain(int sid) {
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "select remain from session where sid = ? ;";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, sid);
			rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getInt(1) > 0) {
					return true;
				} else {
					return false;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return false;
	}

	@Override
	public List<Session> showNotes(String uname) {
		int uid = new UserDAOImp().getUid(new User(uname));
		String sql = "select session_id,cname,hall_id,seat,mname,time from ticket,session,movies,cinema,hall where session_id = sid and movies_id = mid and hall_id = hid and cinema_id = cid and user_id = ?;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Session> session = new ArrayList<Session>();
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, uid);
			rs = ps.executeQuery();
			while (rs.next()) {
				session.add(new Session(rs.getInt(1), rs.getString(2), rs
						.getInt(3), rs.getString(4), rs.getString(5), rs
						.getString(6)));
			}
			return session;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return null;
	}

	@Override
	public boolean deleteSessionById(int sid, int remain) {
		Session session = findSessionBySid(sid);
		if (session == null) {
			return false;
		}
		if (remain == 36) {
			String sql = "delete from session where sid = ? ;";
			Connection conn = super.getConnection();
			PreparedStatement ps = null;
			try {
				ps = conn.prepareStatement(sql);
				ps.setInt(1, sid);
				ps.executeUpdate();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				super.closeAll(null, ps, conn);
			}
		}
		return false;
	}

	@Override
	public boolean findSessionByHidTime(int hid, String time) {
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "select sid from session where hall_id = ? and time = ?;";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, hid);
			ps.setInt(1, hid);
			ps.setString(2, time);
			rs = ps.executeQuery();
			while (rs.next()) {
				return true;
			}	
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return false;
	}

	@Override
	public void updateSession(int hid, String mname, String time, int price,
			int remain) {
		Movie movie = new MovieDAOImp().findMovieByName(mname);
		String sql = "insert into session(hall_id,movies_id,time,price,remain)values(?,?,?,?,?);";
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = super.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setInt(1, hid);
			ps.setInt(2, movie.getMid());
			ps.setString(3, time);
			ps.setInt(4, price);
			ps.setInt(5, 36);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(null, ps, conn);
		}
	}

	@Override
	public void addHall(String cid) {
		if (cid.length() == 0) {
			Message_View.warningDialog("����ѡ���ӰԺ��");
		} else {
			String sql;
			Connection conn = null;
			PreparedStatement ps = null;
			try {
				int cinema_id = Integer.parseInt(cid);
				sql = "insert into hall(cinema_id,capacity)values(?,?);";
				conn = super.getConnection();
				ps = conn.prepareStatement(sql);
				ps.setInt(1, cinema_id);
				ps.setInt(2, 36);
				ps.executeUpdate();
				Message_View.infoDialog("��ӰԺ�����³����ɹ���");
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				super.closeAll(null, ps, conn);
			}
		}
	}

	@Override
	public List<Integer> findHalls(int cinema_id) {
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Integer> hids = new ArrayList<Integer>();
		try {
			String sql = "select hid from hall where cinema_id = ? ;";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, cinema_id);
			rs = ps.executeQuery();
			while (rs.next()) {
				hids.add(rs.getInt(1));
			}
			return hids;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return null;
	}

}
