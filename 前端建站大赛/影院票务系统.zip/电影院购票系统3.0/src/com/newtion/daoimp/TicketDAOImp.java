package com.newtion.daoimp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.newtion.dao.TicketDAO;
import com.newtion.model.Session;
import com.newtion.model.User;
import com.newtion.utils.DBUtils;

public class TicketDAOImp extends DBUtils implements TicketDAO {

	@Override
	public boolean findTicketSeat(String seat, int sid) {
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "select seat from ticket where session_id =? and seat=?;";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, sid);
			ps.setString(2, seat);
			rs = ps.executeQuery();
			while (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return false;
	}

	@Override
	public void addTicketSeat(String seat, User user, Session session) {
		int uid = new UserDAOImp().getUid(user);
		String sql = "insert into ticket values(null,?,?,?);";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, uid);
			ps.setInt(2, session.getSid());
			ps.setString(3, seat);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(null, ps, conn);
		}
	}
}
