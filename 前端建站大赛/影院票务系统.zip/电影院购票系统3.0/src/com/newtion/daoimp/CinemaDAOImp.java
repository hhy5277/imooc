package com.newtion.daoimp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.newtion.dao.CinemaDAO;
import com.newtion.model.Cinema;
import com.newtion.utils.DBUtils;
import com.newtion.view.Message_View;

//影院表操作类
public class CinemaDAOImp extends DBUtils implements CinemaDAO {

	@Override
	public boolean findCinemaByName(Cinema cinema) {

		String sql = "select * from cinema where cname = ? ;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, cinema.getCname());
			rs = ps.executeQuery();
			while (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return false;
	}

	@Override
	public boolean addCinema(Cinema cinema) {
		boolean bool = findCinemaByName(cinema);
		if (bool == false) {
			String sql = "insert into cinema(cname,address)values(?,?);";
			Connection conn = super.getConnection();
			PreparedStatement ps = null;
			try {
				ps = conn.prepareStatement(sql);
				ps.setString(1, cinema.getCname());
				ps.setString(2, cinema.getAddress());
				ps.executeUpdate();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				super.closeAll(null, ps, conn);
			}
		}
		return false;
	}

	@Override
	public List<Cinema> showCinemas() {
		String sql = "select cid,cname,address from cinema;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Cinema> cinemas = new ArrayList<Cinema>();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				cinemas.add(new Cinema(rs.getInt(1), rs.getString(2), rs
						.getString(3)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return cinemas;
	}

	@Override
	public boolean deleteCinemaByName(Cinema cinema) {
		boolean bool = findCinemaByName(cinema);
		if (bool == true) {
			String sql = "delete from cinema where cname =? ";
			Connection conn = super.getConnection();
			PreparedStatement ps = null;
			try {
				ps = conn.prepareStatement(sql);
				ps.setString(1, cinema.getCname());
				ps.executeUpdate();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				super.closeAll(null, ps, conn);
			}
		}
		return false;
	}

	@Override
	public Cinema findCinemaByName(String cname) {
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "select cid,cname,address from cinema where cname = ? ;";
			ps = conn.prepareStatement(sql);
			ps.setString(1, cname);
			rs = ps.executeQuery();
			while (rs.next()) {
				return new Cinema(rs.getInt(1), rs.getString(2),
						rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return null;
	}

	@Override
	public boolean updateCinemaAddress(String name, String address) {
		String sql = "update cinema set address = ? where cname = ?";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, address);
			ps.setString(2, name);
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(null, ps, conn);
		}
		return false;
	}

	@Override
	public List<String> showCinemasName() {
		String sql = "select cname from cinema;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<String> cnames = new ArrayList<String>();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				cnames.add(rs.getString(1));
			}
		} catch (SQLException e) {
			Message_View.warningDialog("数据库连接异常！");
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return cnames;
	}

	public int findCinemaIdByCname(String cname) {
		String sql = "select cid from cinema where cname = ? ;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, cname);
			rs = ps.executeQuery();
			while (rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return -1;
	}
}
