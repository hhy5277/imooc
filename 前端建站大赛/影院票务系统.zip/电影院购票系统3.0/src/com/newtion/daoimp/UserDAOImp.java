package com.newtion.daoimp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.newtion.dao.UserDAO;
import com.newtion.model.User;
import com.newtion.utils.DBUtils;

//用户表操作类
public class UserDAOImp extends DBUtils implements UserDAO {

	@Override
	public boolean findUser(User user) {

		// 将用户表中uid =1 设置为固定管理员admin/admin
		String sql = "select uid ,name,level,balance from users where name = ? and password = ? and uid <> 1;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getName());
			ps.setString(2, user.getPassword());
			rs = ps.executeQuery();
			while (rs.next()) {
				user.setId(rs.getInt(1));
				user.setName(rs.getString(2));
				user.setLevel(rs.getInt(3));
				user.setBalance(rs.getDouble(4));
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return false;

	}

	@Override
	public User findUserByName(User user) {

		String sql = "select name,password,level,balance from users where name = ? ;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getName());
			rs = ps.executeQuery();
			while (rs.next()) {

				return new User(rs.getString(1), rs.getString(2), rs.getInt(3),
						rs.getDouble(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return null;
	}

	@Override
	public boolean addUser(User user) {
		User u = findUserByName(user);
		if (u == null) {
			String sql = "insert into users(name,password)values(?,?);";
			Connection conn = super.getConnection();
			PreparedStatement ps = null;
			try {
				ps = conn.prepareStatement(sql);
				ps.setString(1, user.getName());
				ps.setString(2, user.getPassword());
				ps.executeUpdate();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				super.closeAll(null, ps, conn);
			}
		}
		return false;
	}

	@Override
	public boolean findAdminByName(User user) {
		String sql = "select * from users where uid = ? and name = ? and password = ?;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, 1);
			ps.setString(2, user.getName());
			ps.setString(3, user.getPassword());
			rs = ps.executeQuery();
			while (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return false;
	}

	@Override
	public List<User> showUsers() {
		String sql = "select uid,name,password,level,balance from users;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<User> users = new ArrayList<User>();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				users.add(new User(rs.getInt(1), rs.getString(2), rs
						.getString(3), rs.getInt(4), rs.getDouble(5)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}

		return users;
	}

	@Override
	public boolean deleteByName(User user) {
		User u = findUserByName(user);	
		if (u != null ) {
			if(u.getBalance() == 0){
			String sql = "delete from users where name =? ;";
			Connection conn = super.getConnection();
			PreparedStatement ps = null;
			try {
				ps = conn.prepareStatement(sql);
				ps.setString(1, u.getName());
				ps.executeUpdate();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				super.closeAll(null, ps, conn);
			}
			}
		}
		return false;
	}

	@Override
	public boolean findUserByName(User user, int i) {
		if (user == null) {
			return false;
		}
		String sql = null;
		if (i == 0) {
			sql = "select * from users where name = ? ;";
		} else {
			sql = "select * from users where uid=? or name = ? ;";
		}
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			if (i == 0) {
				ps.setString(1, user.getName());
			} else {
				ps.setInt(1, user.getId());
				ps.setString(2, user.getName());
			}
			rs = ps.executeQuery();
			while (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return false;
	}

	@Override
	public boolean findUserById(User user) {
		if (user == null) {
			return false;
		}
		String sql = "select * from users where uid = ? ;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, user.getId());
			rs = ps.executeQuery();
			while (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return false;
	}

	@Override
	public boolean findUserByIdName(User user) {
		if (user == null) {
			return false;
		}
		String sql = "select * from users where uid = ? and name =? ;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, user.getId());
			ps.setString(2, user.getName());
			rs = ps.executeQuery();
			while (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return false;
	}

	@Override
	public User findUserByNameIdR(User user, int i) {
		String sql = null;
		if (i == 0) {
			sql = "select uid,name,level,balance from users where uid = ? ;";
		} else if (i == 1) {
			sql = "select uid,name,level,balance from users where  name = ? ;";
		} else {
			sql = "select uid,name,level,balance from users where uid = ? and name = ? ;";
		}
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			if (i == 0) {
				ps.setInt(1, user.getId());
			} else if (i == 1) {
				ps.setString(1, user.getName());
			} else {
				ps.setInt(1, user.getId());
				ps.setString(2, user.getName());
			}

			rs = ps.executeQuery();
			while (rs.next()) {
				return new User(rs.getInt(1), rs.getString(2), rs.getInt(3),
						rs.getDouble(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return null;
	}

	@Override
	public boolean adminUpdateUser(User user) {
		String sql = "update users set password = ?  where name = ?;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getPassword());
			ps.setString(2, user.getName());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(null, ps, conn);
		}
		return false;
	}

	@Override
	public void updateBalance(String uname, double money) {
		String sql = "update users set balance = ?  where name = ?;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setDouble(1, money);
			ps.setString(2, uname);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(null, ps, conn);
		}
	}

	@Override
	public void userUpdateNamePass(String newpassword, String name) {

		String sql = "update users set password = ? where name = ?;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, newpassword);
			ps.setString(2, name);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(null, ps, conn);
		}

	}

	@Override
	public boolean CheckUserBalance(User user, double cost) {
		String sql = "select balance from users where name = ?;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getName());
			rs = ps.executeQuery();
			while (rs.next()) {
				double balance = rs.getDouble(1);
				if (balance >= cost) {
					return true;
				} else {
					return false;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return false;
	}

	@Override
	public int getUid(User user) {
		String sql = "select uid from users where name = ?;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getName());
			rs = ps.executeQuery();
			while (rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, conn);
		}
		return -1;
	}

	@Override
	public void updateLevel(String name, int level) {
		String sql = "update users set level = ? where name = ?;";
		Connection conn = super.getConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, level);
			ps.setString(2, name);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			super.closeAll(null, ps, conn);
		}

	}
}
