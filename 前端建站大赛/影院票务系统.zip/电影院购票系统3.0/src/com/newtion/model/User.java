package com.newtion.model;

//用户类
public class User {

	private int id;
	private String name;// 用户名
	private String password;// 密码
	private int level;// VIP等级
	private double balance;// 余额

	public User() {
		super();
	}

	public User(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}

	public User(int id) {
		super();
		this.id = id;
	}

	public User(String name) {
		super();
		this.name = name;
	}

	public User(String name, double balance) {
		super();
		this.name = name;
		this.balance = balance;
	}

	public User(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public User(String name, int level, double balance) {
		super();
		this.name = name;
		this.level = level;
		this.balance = balance;
	}

	public User(String name, String password, int level, double balance) {
		super();
		this.name = name;
		this.password = password;
		this.level = level;
		this.balance = balance;
	}

	public User(int id, String name, String password, int level, double balance) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.level = level;
		this.balance = balance;
	}

	public User(int id, String name,  int level, double balance) {
		super();
		this.id = id;
		this.name = name;
		this.level = level;
		this.balance = balance;
	}

	
	public User(int id, String name, String password, int level) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.level = level;
	}
	
	

	public User(String name, String password, int level) {
		super();
		this.name = name;
		this.password = password;
		this.level = level;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		
		return "用户名: "+name+" 等级: "+level+"级"+" 账户余额: "+balance+"元";
	}
}
