package com.newtion.model;

//电影类
public class Movie {
	private int mid;// ID
	private String mname;// 片名
	private String type;// 片种
	private String actors;// 主演
	private int duration;// 时长
	private String detail;// 详情

	
	public Movie() {
		super();
	}

	public Movie(int mid, String mname, String type, String actors,
			int duration, String detail) {
		super();
		this.mid = mid;
		this.mname = mname;
		this.type = type;
		this.actors = actors;
		this.duration = duration;
		this.detail = detail;
	}

	public Movie(String mname, String type, String actors, int duration,
			String detail) {
		super();
		this.mname = mname;
		this.type = type;
		this.actors = actors;
		this.duration = duration;
		this.detail = detail;
	}



	public Movie(String mname, String type, String actors, String detail) {
		super();
		this.mname = mname;
		this.type = type;
		this.actors = actors;
		this.detail = detail;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getActors() {
		return actors;
	}

	public void setActors(String actors) {
		this.actors = actors;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	@Override
	public String toString() {
		return "Movie [mid=" + mid + ", mname=" + mname + ", type=" + type
				+ ", actors=" + actors + ", duration=" + duration + ", detail="
				+ detail + "]";
	}
}
