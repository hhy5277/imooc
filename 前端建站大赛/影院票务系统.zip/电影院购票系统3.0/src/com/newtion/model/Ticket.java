package com.newtion.model;

//影票类
public class Ticket {
	private int tid;// 影票ID
	private User user;// 所属用户
	private Session session;// 所属场次
	private String seat;// 座位号
	private int flag = 1;//座位标签

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public String getSeat() {
		return seat;
	}

	public void setSeat(String seat) {
		this.seat = seat;
	}

	public Ticket(User user, Session session, String seat) {
		super();
		this.user = user;
		this.session = session;
		this.seat = seat;
	}

	
}
