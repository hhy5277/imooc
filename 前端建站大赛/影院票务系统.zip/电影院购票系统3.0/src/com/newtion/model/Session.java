package com.newtion.model;

//������
public class Session {
	private int sid;
	private int hall_id;
	private int movies_id;
	private String time;
	private int price;
	private int remain;
	
	private String cname;
	private String mname;
	private String seat;

	public Session() {
		super();
	}

	public Session(int remain) {
		super();
		this.remain = remain;
	}

	public Session(int sid, String cname, int hall_id, String mname,
			String time, int price, int remain) {
		super();
		this.sid = sid;
		this.cname = cname;
		this.hall_id = hall_id;
		this.mname = mname;
		this.time = time;
		this.price = price;
		this.remain = remain;
	}

	public Session(int sid, String cname, int hall_id,  String seat,String mname,
			String time){
		super();
		this.sid = sid;
		this.cname = cname;
		this.hall_id = hall_id;
		this.mname = mname;
		this.time = time;
		this.seat = seat;
	}

	
	public Session(int hall_id, int movies_id, String time, int price,
			int remain) {
		super();
		this.hall_id = hall_id;
		this.movies_id = movies_id;
		this.time = time;
		this.price = price;
		this.remain = remain;
	}

	public int getMovies_id() {
		return movies_id;
	}

	public void setMovies_id(int movies_id) {
		this.movies_id = movies_id;
	}

	public String getSeat() {
		return seat;
	}

	public void setSeat(String seat) {
		this.seat = seat;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public int getHall_id() {
		return hall_id;
	}

	public void setHall_id(int hall_id) {
		this.hall_id = hall_id;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getRemain() {
		return remain;
	}

	public void setRemain(int remain) {
		this.remain = remain;
	}

}
