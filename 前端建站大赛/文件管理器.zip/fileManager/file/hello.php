<?
echo \'hello\';
?>