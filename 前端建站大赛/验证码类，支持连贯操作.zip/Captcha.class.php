<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/6/17 0017
 * Time: 下午 11:32
 **/
class  Captcha{
    private $image;
    private $backup;
    private $info;
    private $dictionary;
    private $ttf;

    //以下属性为自动化处理定义，使用时可忽略
    private $addTtfFlag;
    private $addTextFlag;
    private $addPixelFlag;
    private $addLineFlag;

    //构造宽度$width,高度$height，背景色$bg的真彩图，
    //并初始化english,arabic,mix三种验证码字符集词典，
    //保存宽度高度信息在$info,
    //验证码备份$backup初始化为'',backup
    //所有的自动化标记Flag设置为false
    public function __construct($width, $height, $bg=array('red'=>255, 'green'=>255, 'blue'=>255)){
        $this->image = imagecreatetruecolor($width, $height);
        $bg = imagecolorallocate($this->image, $bg['red'], $bg['green'], $bg['blue']);
        imagefill($this->image, 0, 0, $bg);

        $this->backup = '';
        $this->info[0] = $width;
        $this->info[1] = $height;
        $this->dictionary['english'] =  "abcdefghijklmnopqrstuvwxyz";
        $this->dictionary['arabic'] =  "0123456789";
        $this->dictionary['mix'] =  "abcdefghjklmnpqrstuvwxyz23456789";

        $this->addTtfFlag=false;
        $this->addTextFlag=false;
        $this->addPixelFlag=false;
        $this->addLineFlag=false;
    }
    
    

    //用于以关联数组形式新添字符集词典于dectionary，返回上下文，支持连贯操作
    public function setCharDic($str, $key=null){
        if($key===null)
            $this->dictionary['char'] =  $str;
        else
            $this->dictionary[$key] = $str;
        return $this;
    }

    //设置字体$ttf为路径名，返回上下文,支持连贯操作
    public function setTtf($ttf){
        $this->ttf="$ttf";
        $this->addTtfFlag=true;
        return $this;
    }

    //添加文字水印，$dic支持词典选择，$num字符个数设置，$font字体大小设置，
    //$color字体颜色设置，$color为索引数组：array(RED,GREEN,BLUE)；RED GREEN-BLUE:数值取0-255
    //返回上下文，支持连贯操作
    public function addText($text=null,$dic=null, $num=null, $font=null, $color=null){

        $dic_keys = array_keys($this->dictionary);
        if(($dic!==null&&$dic!=='')&&!(in_array($dic, $dic_keys)||$dic==="chinese")){
            exit("Error: Dictionary was not set correctly!\n");
        }
        if($font===null||$font==='')
            $font = $this->info[1]/3;
        if($dic===null||$dic==='')
            $dic='english';
        if($num===null||$num==='')
            $num=4;
        if($text===null||$text===''){
            if($dic!=="chinese"){
                $dic_to_arr = str_split($this->dictionary[$dic]);
                $dic_length = sizeof($dic_to_arr);
                for($i=0; $i<$num; $i++){
                    $letter = $dic_to_arr[rand(0, $dic_length-1)];
                    if(rand(1, 100)>40)
                        $letter = strtoupper($letter);

                    $this->writeOneLetter($letter, $num, $font, $color, $i);
                }
            }
            else{
                if($dic==='chinese'){
                    for($i=0; $i<$num; $i++){
                        $letter = rand(0X4E00,0X9FA5);
                        $letter = '\u'.base_convert($letter, 10, 16);
                        $letter = $this->unicode_decode($letter);

                        $this->writeOneLetter($letter, $num, $font, $color, $i);
                    }
                }
            }
        }

        $this->addTextFlag=true;
        return $this;
    }

    //返回备份的验证码字符串,如验证码未制作完成此函数就被调用，就会报错
    public function getBackUp(){
        if($this->addTextFlag)
            return $this->backup;
        else
            exit("Error: Captcha has not been added yet!\n");
    }

    //私有方法，内部调用，每次调用都会想验证码图片中添加一个字符，
    private function writeOneLetter($letter, $num, $font, $color, $i){

        $this->backup.= $letter;
        $x = ($i*($this->info[0])/$num)+rand($font/2, $font);
        $y=rand($font*3/2, $this->info[1]-$font/2);

        $color = $color==null? imagecolorallocate($this->image, rand(0,120), rand(0,120), rand(0,120))
            :imagecolorallocate($this->image, $color[0], $color[1], $color[2]);
        if(!$this->addTtfFlag)
            imagestring($this->image, $font, $x, $y, $letter, $color);
        else{
            imagettftext($this->image , $font, rand(-45, 45) , $x , $y , $color , $this->ttf, $letter );
        }
    }


    //私有方法，用于把UNICODE转为UTF-8汉字
    private function unicode_decode($name)
    {
        // 转换编码，将Unicode编码转换成可以浏览的utf-8编码
        $pattern = '/([\w]+)|(\\\u([\w]{4}))/i';
        preg_match_all($pattern, $name, $matches);
        if (!empty($matches))
        {
            $name = '';
            for ($j = 0; $j < count($matches[0]); $j++)
            {
                $str = $matches[0][$j];
                if (strpos($str, '\\u') === 0)
                {
                    $code = base_convert(substr($str, 2, 2), 16, 10);
                    $code2 = base_convert(substr($str, 4), 16, 10);
                    $c = chr($code).chr($code2);
                    $c = iconv('UCS-2', 'UTF-8', $c);
                    $name .= $c;
                }
                else
                {
                    $name .= $str;
                }
            }
        }
        return $name;
    }

    //增加干扰像素，可自动设置数目,
    //返回上下文，支持连贯操作
    public function addPixels($num=null){
        if($num===null){
            $num=$this->info[0]*$this->info[1]/10;
        }

        for($i=0; $i<$num; $i++){
            $pixelColor = imagecolorallocate($this->image, rand(50, 200), rand(50, 200), rand(50, 200));
            imagesetpixel($this->image, rand(1,$this->info[0]), rand(1,$this->info[1]), $pixelColor);
        }


        $this->addPixelFlag=true;
        return $this;
    }

    //增加干扰线段，可自动设置数目，
    //返回上下文，支持连贯操作
    public function addLines($num=null){

        if($num===null){
            $num=$this->info[1]/15;
        }

        for($i=0; $i<$num; $i++){
            $pixelColor = imagecolorallocate($this->image, rand(50, 200), rand(50, 200), rand(50, 200));
            imageline($this->image, rand(1,$this->info[0]), rand(1, $this->info[1]),  rand(1,$this->info[0]), rand(1, $this->info[1]), $pixelColor);
        }

        $this->addLineFlag=true;
        return $this;
    }

    //私有方法，用于确保验证码制作过完整，且所有工序都被执行切执行一次
    private function everythingMustBeAdded($text=null,$dic=null){

        if(!$this->addTextFlag)
            $this->addText($text, $dic);
        if(!$this->addPixelFlag)
            $this->addPixels();
        if(!$this->addLineFlag)
            $this->addLines();


        $this->addTextFlag=true;
        $this->addPixelFlag=true;
        $this->addLineFlag=true;
    }

    public function show($text=null, $dic=null){
        $this->everythingMustBeAdded($text, $dic);
        header("Content-type:image/png");
        imagepng($this->image);
        return $this;
    }

    public function getImage($text=null, $dic=null){
        $this->everythingMustBeAdded($text, $dic);
        return $this->image;
    }
}

