package timetask;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.htmlparser.Node;
import org.htmlparser.NodeFilter;
import org.htmlparser.Parser;
import org.htmlparser.beans.LinkBean;
import org.htmlparser.filters.HasAttributeFilter;
import org.htmlparser.filters.LinkRegexFilter;
import org.htmlparser.tags.LinkTag;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;

import utils.DBUtils;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;

public class GetLinks {
    
	
	/**
	 * @param url-确定所需要的链接集
	 * @param regex-匹配所需要的链接
	 * @param aim-识别是哪部分
	 * @return
	 * @throws ParserException
	 */
	public static List<DBObject> filterNews(String url,String regex) throws ParserException{
	    
		Parser parser = new Parser();
		parser.setURL(url);
        parser.setEncoding("UTF-8");
		
		System.out.println(regex);
		NodeFilter filter = new LinkRegexFilter(regex);  //根据正则创建链接过滤器
		NodeList list = parser.extractAllNodesThatMatch(filter);  //根据过滤器筛选节点
		List<DBObject> links = new ArrayList<DBObject>();
		
		NodeFilter attrFilter = new HasAttributeFilter("target");  //创建属性过滤器
		NodeList linkList = list.extractAllNodesThatMatch(attrFilter);  //筛选节点
		for (int i = 0 , max = linkList.size() ; i < max ; i++ ){
			    
			LinkTag linkTag = (LinkTag) linkList.elementAt(i);
				
			String link = linkTag.getLink(); //获取链接目标地址
			System.out.println(link);
				
			String text = linkTag.getLinkText();//获取链接文本
			System.out.println(text);
				
			DBObject linkObj = new BasicDBObject("link",link);
			linkObj.put("linkText", text);
				
			links.add(linkObj);
		}
		
		return links;
	}
	
	public static void newsInLib() throws ParserException{
		
		//目标页面
		String sdibt="http://www.ccec.edu.cn/index/ssxw.htm";
		
		//正则表达式
		String sdibtRegex = "..\\/info\\/\\d{4}\\/\\d{5}\\.htm";
		
		//目标页面
		String jwc = "http://jwc.sdibt.edu.cn/SmallClass.asp?BigClassName=%D0%C5%CF%A2%B7%A2%B2%BC&SmallClassName=%D0%C2%CE%C5%B6%AF%CC%AC";
		
		//正则表达式
		String jwcRegex = "ReadNews\\.asp\\?NewsID=\\d{4}\\&BigClassName=信息发布\\&SmallClassName=新闻动态\\&SpecialID=0";
		
		DBCollection newsCol = DBUtils.getCollection("sdibtNews");//获取数据库连接集合,数据库使用的是MongoDB,方法在DBUtils中定义
		
		System.out.println("Sdibt:");
		List<DBObject> linkSdibt = filterNews(sdibt,sdibtRegex);//调用筛选方法,获取链接集合
		
		newsCol.drop();//清空数据表
		int sdibtN = newsCol.insert(linkSdibt).getN();//入库并获取返回结果
		System.out.println(sdibtN); //输出入库结果
		
		newsCol = DBUtils.getCollection("jwcNews");
		System.out.println("Jwc:");
		
		List<DBObject> linkJwc = filterNews(jwc,jwcRegex);
		newsCol.drop();//清空数据表
		
		int jwcN = newsCol.insert(linkJwc).getN();//入库并获取返回结果
		System.out.println(jwcN); //输出入库结果
	}
	
	
	public static void main(String[] args) throws Exception {
		newsInLib();
	}

}

