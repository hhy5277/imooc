var webpack = require('webpack');
module.exports = {
  entry: {
    app: "./main.js",
    vendor: ['jquery'],
  },
  output: {
    path: "./build",
    publicPath: "/build/",
    filename: "build.js"
  },
  module: {
    loaders: [
      { test: /\.vue$/, loader: 'vue' },
      { test: /\.css$/, loader: 'style!css' },
      { test: /\.less$/,loader: 'style!css!less' },
      { test: /\.scss$/,loader: 'style!css!sass' },
      { test: /\.html$/, loader: 'html' },
      { test: /\.(gif|jpg|png|woff|woff2|svg|eot|ttf)$/, loader: 'url-loader' },
      { test: /\.js$/, exclude: /node_modules|vue\/dist/, loader: 'babel'}
    ]
  },
  plugins:[
    new webpack.ProvidePlugin({
            $: 'jquery',
            jQuery: "jquery"
    }),
    new webpack.optimize.CommonsChunkPlugin('vendor', 'vendor.js')
  ],
  babel: {
    presets: ['es2015', 'stage-0'],
    plugins: ['transform-runtime']
  },
  resolve: {
    extensions: ['', '.js', '.json', '.scss', '.vue']
  }
};

