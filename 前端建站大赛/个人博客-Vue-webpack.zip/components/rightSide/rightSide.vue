<template>
	<div class="right-side-container col l2 hide-on-med-and-down blue-grey text-light">
		<audio :src="this.path+currentSong.src"
				v-if="!listEmpty" 
				autoplay="autoplay" 
				@timeupdate="setProgress" 
				@ended="nextSong"
				@play="setAudioState"
				@pause="setAudioState"
				v-el:audio>
				浏览器不支持本网站播放音频</audio>
		<div class="music-player-container">
			<div class="music-info">
				<div class="music-cover">
					<img :src="coverPath + currentSong.coverSrc">
				</div>
				<div class="music-name">
					<template v-if="listEmpty">
						<a href="">在‘音乐’列表中</a>
						<a href="">添加一首歌到播放列表</a>
					</template>
					<template v-else> 
						<a href="">{{currentSong.singer}}</a>
						<a href="">{{currentSong.name}}</a>
					</template>
				</div>
			</div>
			<div class="music-control-pannel">
				<div class="music-progress-bar"
				@click="setCurrentTime($event)"
				v-el:progress-bar>
					<div class="music-progress-cur teal"
						:style="{ width: listEmpty?0:progress+'%'}">
					</div>
				</div>
				<div class="music-opera">
					<a class="iconfont music-pre" @click="preSong">&#xe607;</a>
					<a class="iconfont music-pause" @click="playToggle">{{{playIcon}}}</a>
					<a class="iconfont music-next" @click="nextSong">&#xe608;</a>
				</div>
			</div>
		</div>
		<div class="music-list">
		<div class="music-list-title">
			<p>播放列表</p>
		</div>
			<ul>
				<li v-for="song in playList" :class="{'playing': $index === currentSongIndex}">
					<p class="music-name" 
						@click="setCurrentSong($index)" >{{song.name}}</p>
					<i class="iconfont" @click="removeSong(song)">&#xe60c;</i>
					<span class="music-time">{{song.time | songTimeFmt}}</span>
				</li>
			</ul>
		</div>
	</div>
	<div class="music-footer col s12 hide-on-large-only">
		<div class="img">
			<img :src="coverPath + currentSong.coverSrc">
		</div>
		<div class="info">
			<p>{{currentSong.name}}</p>
			<p>{{currentSong.singer}}</p>
		</div>
		<div class="control">
			<a class="iconfont" @click="playToggle">{{{playIcon}}}</a>
			<a class="iconfont" @click="nextSong">&#xe608;</a>
		</div>
	</div>
</template>
<script>
	require ('./style.less');
	import * as actions from '../../vue-tools/vuex/actions.js'
	export default{
		ready(){
		},
		data(){
			return {
				coverPath: '../../static/covers/',
				path: '../../static/music/',
				progress: 0,
				playIcon: '&#xe609;'
			}
		},
		vuex: {
			getters: {
				playList: function (state) {
			    	return state.playList
			    },
			    currentSongIndex: function(state){
			    	return state.currentSongIndex
			    },
				currentSong: function(state){
					return state.playList[state.currentSongIndex]
				},
				listEmpty: function(state){
					return state.listEmpty
				}
			},
			actions: actions
		},
		computed: {
		},
		methods: {
			playToggle: function(){
				var audio = this.$els.audio;
				if(!audio)
					return
				if(audio.paused){
					audio.play();
					return
				}
				audio.pause();
			},
			setProgress: function(){
				var audio = this.$els.audio;
				this.progress =  (audio.currentTime/audio.duration)*100;
			},
			setCurrentTime: function(e){
				var x = e.screenX;
				var audio = this.$els.audio;
				var progressBar = this.$els.progressBar;
				var progressX = progressBar.offsetLeft;
				var progressWidth = progressBar.offsetWidth;
				var ratio = (x - progressX)/progressWidth;
				this.progress = ratio * 100;
				audio.currentTime = audio.duration * ratio;
			},
			setAudioState: function(){
				this.playIcon = this.$els.audio.paused?"&#xe609;":"&#xe60a;"
			}
		}
	}
</script>