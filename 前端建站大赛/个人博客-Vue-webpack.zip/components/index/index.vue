<template>
	<h1>Index</h1>
</template>
<script >
	export default {
		
	}
</script>