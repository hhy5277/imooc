<template>
    <div class="center-container index-container col m12 l10">
        <div class="blog">
            <div class="top-bar row container">
                <div class="type col s10 m10 l11">
                    <p>{{typeStr}}</p>
                </div>
                <a class='dropdown-button btn col s2 m2 l1' data-beloworigin="true" data-activates='dropdown1'>排序</a>
                <ul id='dropdown1' class='dropdown-content'>
                    <li><a @click=setSort(1)>时间最远</a></li>
                    <li class="divider"></li>
                    <li><a @click=setSort(-1)>时间最近</a></li>
                    
                </ul>
            </div>
            <ul class="row container">
                <li class="col s6 m4 "
                    v-for="post in postList | orderBy 'createdAt' sortBy">
                    <div class="card small container">
                        <div class="card-image"
                            v-link="{ name: 'post', params: { postId: post.id}}">
                            <img src="../../../static/img/1.jpg">
                        </div>
                        <div class="card-content">
                            <p class="truncate card-content-title"
                            v-link="{ name: 'post', params: { postId: post.id}}">{{post.title }}</p>
                            <p><span class="truncate text-gray">{{post.createdAt | timeFmt false true}}</span></p>
                        </div>
                    </div>
                </li>
            </ul>
                
        </div>
    </div>
</template>
<script>
    require('./style.less');
    import sha1  from  '../../../lib/sha1.js';
    export default {
        ready (){
            $('.dropdown-button').dropdown({});
        },
        data(){
            return {
                type: '',
                typeStr: '',
                postList: [],
                baseWidth: 0,
                sortBy: -1
            }
        },
        computed: {
            ulWidth: function(){
                return this.baseWidth;
            },
            space: function(){
                return this.baseWidth*0.03;
            },
            imgHeight: function(){
                return this.ulWidth * 0.22 * 10/16;
            },
            sortStr: function(){
                return this.sortBy == '-1'?'时间最近':'时间最远';
            }
        },
        route: {
            data(transition){
                this.type = transition.to.params.type;
                this.getPosts();
                switch(this.type){
                    case 'all':
                        this.typeStr = "全部";
                        break;
                    case 'fe':
                        this.typeStr = "前端";
                        break;
                    case 'life':
                        this.typeStr = "随笔";
                        break;
                    case 'other':
                        this.typeStr = "其他";
                        break;
                }
            }
        },
        methods: {
            getPosts (){
                var _self = this;
                var now = Date.now();
                var appKey = sha1.hex_sha1("A6982930175882"+"UZ"+"2EF33E90-7BB1-1506-4949-68539D7C8DE7"+"UZ"+now)+"."+now;
                var res = [];
                //类型筛选
                var t = (this.type=='all')?'':"\"type\":\""+this.type+"\"";
                var url = "{\"where\":{"+t+"}}";
                var filterEnStr = encodeURIComponent(url);
                $.ajax({
                    "url": "https://d.apicloud.com/mcm/api/posts?filter="+filterEnStr,
                    "method": "GET",
                    "cache": false,
                    "headers": {
                        "X-APICloud-AppId": "A6982930175882",
                        "X-APICloud-AppKey": appKey
                    }
                }).success(function (data, status, header) {
                    _self.postList = data;
                }).fail(function (header, status, errorThrown) {
                });

            },
            setSort(num){
                if(num == 1 || num == -1){
                    this.sortBy = num;
                }
            }
        },

    }
</script>

