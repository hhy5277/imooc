<template>
	<div class="center-container post-container col m12 l10">
		<div class="position-fix container">
			<div class="title-container">
				<h1>The Title of the article</h1>
				<span>分类: <a href="">前端</a></span>
				<i class="iconfont">&#xe605;</i><span>2006/01/01</span>
			</div>
			<div class="article-container">
				<h1>MainHeading 1</h1>
				<p>hjagshjdg hdgasjdgauiq hsda dyatdhj adh udathjgda jhdagjh dtayghj 
				dahj hjdgaj tyada h dhadkja hjagdjhas iydasghjhjgda  dhad adgsdjha jhda
				hdagdhja dahd oq odja oda oakh kjdakj kjasd dakj da jk akjh dakhda kjdaj
				adhjak adjh dakdhs adka askjd ajsdhk asdkj dajdah jdah dakjdh kjak kad  </p>
				<h2>MainHeading 1</h2>
				<p>hjagshjdg hdgasjdgauiq hsda dyatdhj adh udathjgda jhdagjh dtayghj 
				dahj hjdgaj tyada h dhadkja hjagdjhas iydasghjhjgda  dhad adgsdjha jhda
				hdagdhja dahd oq odja oda oakh kjdakj kjasd dakj da jk akjh dakhda kjdaj
				adhjak adjh dakdhs adka askjd ajsdhk asdkj dajdah jdah dakjdh kjak kad  </p>
				<img src="../../../static/img/index.png">
				<h3>MainHeading 1</h3>
				<p>hjagshjdg hdgasjdgauiq hsda dyatdhj adh udathjgda jhdagjh dtayghj 
				dahj hjdgaj tyada h dhadkja hjagdjhas iydasghjhjgda  dhad adgsdjha jhda
				hdagdhja dahd oq odja oda oakh kjdakj kjasd dakj da jk akjh dakhda kjdaj
				adhjak adjh dakdhs adka askjd ajsdhk asdkj dajdah jdah dakjdh kjak kad  </p>
				<img src="../../../static/img/1.jpg">
			</div>
			<div class="return-button">
				<a href="">返回列表</a>
			</div>
		</div>
	</div>
</template>
<script>
	require('./style.less');
	function addjustPage(){
        $(".post-container").height($(window).height() - $(".header").height());
    }
    export default {
        ready (){
            addjustPage();
        }
    }
</script>