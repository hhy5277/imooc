<template>
<div class="container">
    <a class="menu hide-on-large-only"
        @click="callMenu"
        ><i class="iconfont">&#xe60b;</i></a>
</div>
<div class="mask"
    v-if="in"
    @click="closeMenu"></div>
<aside id="nav-mobile" class="left-side-container sidebar blue-grey text-light"
        :class="{ 'in': in}">
    <div class="teal lighten-1 logo">
        <img src="../../static/img/p.jpg" alt="" class="circle">
        <p class="truncate">霖浩/大三狗/切图的</p>
    </div>
    <ul class="collapsible z-depth-0" data-collapsible="accordion">
        <li v-for="sort in sorts"  
        :class="{ 'active': sort.title == selectedSort }">
            <div class="collapsible-header waves-effect waves-light blue-grey"><i class="iconfont">{{{sort.icon}}}</i>{{sort.title}}</div>
            <div class="collapsible-body">
                <ul>
                    <li class="grey-text blue-grey text-lighten-3 "
                        v-for="cell in list[$index]"
                        @click="choose(cell.name,sort.title)"
                        :class="{ 'active': cell.name === selected }">
                        <a v-link="{ name: sort.routeName, params: { type: cell.type}}"
                            @click="closeMenu">{{cell.name}}</a>
                    </li>
                </ul>
            </div>
        </li>
   </ul>
</aside>
</template>
<script type="text/javascript">
	require('./style.scss');
	export default {
        ready(){
        },
        data(){
        	return {
                in: false,
        		selected: '',
        		selectedSort: '',
        		sorts:[
        			{title:'博文',icon:'&#xe603;',routeName:'list'},
        			{title:'音乐',icon:'&#xe600;',routeName:'music'},
        			{title:'关于我',icon:'&#xe604;',routeName:'resume'},
        		],
        		list: [
        			[
        				{name:'全部', type: 'all'},
        				{name:'前端', type: 'fe'},
        				{name:'随笔', type: 'life'},
        				{name:'其他', type: 'other'},
        			],
        			[
        				{name:'最爱', type: 'fav'},
        				{name:'歌单', type: 'all'}
        			],
        			[
        				{name:'简历',type: ''}
        			]
        		]
        	}
        },
        computed:{
            maskOpacity: function(){
                return this.in?1:0
            }
        },
        methods: {
        	choose:function (name,sort) {
            	this.selected = name;
            	this.selectedSort = sort;
        	},
            callMenu: function (){
                this.in = true;
            },
            closeMenu: function(){
                this.in = false;
            }
        }
    };
</script>