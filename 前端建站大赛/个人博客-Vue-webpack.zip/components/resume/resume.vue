<template>
	<div class="center-container resume col s12 m12 l10 row">
		<div class="container center col s12 m4 offset-m4">
			<div class="name">
				<p class="">姚霖浩</p>
			</div>
			<div class="info">
				<p><i class="iconfont">&#xe60e;</i>广州</p>
				<p>仲恺农业工程学院</p>
				<p>22岁/大三</p>
			</div>
			<img class="photo" src="../../static/img/p.jpg">
			<div class="desc">			
				<ul>
					<li><h5 class="teal-text">前端技能</h5></li>
					<li><p>熟练使用HTML/CSS/JS 独立快速开发静态页面</p></li>
					<li><p>熟练使用前端 UI 框架，如 Bootstrap/Materialize</p></li>
					<li><p>熟悉 Javascript 框架，如 vue.js/angular.js</p></li>
					<li><p>熟练使用webpack/yeoman/gulp</p></li>
					<li><p>等前端构建工具完成代码整合、压缩等流程</p></li>
					<br>
					<li><h5 class="teal-text">后端技能</h5></li>
					<li><p>掌握Java语言以及Javaweb相关知识</p></li>
					<li><p>掌握基于servlet、DAO模式的javaweb程序</p></li>
					<li><p>熟悉数据库相关知识</p></li>
					<li><p>熟悉使用数据库软件如SQL Server、MySQL</p></li>
					<br>
					<li><h5 class="teal-text">自我认知</h5></li>
					<li><p>乐于接触新事物</p></li>
					<li><p>乐于学习，善于学习</p></li>
					<li><p>自我驱动能力强</p></li>
					<li><p>有良好的沟通能力和团队能力</p></li>
					<li><h5 class="teal-text">联系我</h5></li>
					<li><p>TEL: 15626040348</p></li>
					<li><p>EMAIL: 724333708@qq.com</p></li>
				</ul>
			</div>
		</div>
	</div>
</template>
<script>
	require('./style.scss');
	export default {
		ready(){
			$(window).resize();
		}
	}
</script>