<template>
	<div class="center-container music-list-container col m12 l10">
		<div class="progress container"
			 v-if="!loadingDone">
	    	<div class="indeterminate"></div>
	  	</div>
		<ul class="row container">
			<li class="col s6 m4 l3"
				v-for="song in songList">
				<div class="card music-list container">
					<div class="card-image waves-effect waves-block waves-light">
						<img class="activator" :src="this.path+song.coverSrc">
					</div>
					<div class="card-content">
						<span class="card-title activator">{{song.name}} - {{song.singer}}</span>
					</div>
					<div class="card-reveal">
						<span class="card-title truncate">{{song.name}}<i class="iconfont right card-close">&#xe60d;</i></span>
						<p class="card-desc truncate">原唱：{{song.original}}</p>
						<p class="card-desc truncate">填词：{{song.lyricist}}</p>
						<p class="card-desc truncate">谱曲： {{song.composer}}</p>
						<p class="card-desc truncate">专辑：{{song.album}}</p>
						<p class="card-opera">
							<a @click="playSong(song)"><i class="iconfont">&#xe613;</i></a>
							<a @click="addToList(song)"><i class="iconfont">&#xe610;</i></a>
						</p>
					</div>
				</div>
			</li>
		</ul>
	</div>
</template>
<script>
	require('./style.scss');
	import sha1  from  '../../lib/sha1.js';
	import * as actions from '../../vue-tools/vuex/actions.js'
	export default{
		data(){
			return {
				path: '../../static/covers/',
				songList: [],
				type: '',
				loadingDone: false
			}
		},
		vuex: {
			getters: {
				playList: function (state) {
			    	return state.playList
			    }
			},
			actions: actions
		},
		route: {
            data(transition){
                this.type = transition.to.params.type;
                this.getSongs();
                // switch(this.type){
                //     case 'all':
                //         this.typeStr = "全部";
                //         break;
                //     case 'fe':
                //         this.typeStr = "前端";
                //         break;
                //     case 'life':
                //         this.typeStr = "随笔";
                //         break;
                //     case 'other':
                //         this.typeStr = "其他";
                //         break;
                // }
            }
        },
		methods: {
			getSongs (){
                var _self = this;
                var now = Date.now();
                var appKey = sha1.hex_sha1("A6982930175882"+"UZ"+"2EF33E90-7BB1-1506-4949-68539D7C8DE7"+"UZ"+now)+"."+now;
                //筛选是否favorite
                if(this.type == 'fav'){
                	var where = {'isFav': true}
                }else{
                	var where = {}
                }

                var filter = {
				    "fields":{
				    	"id":false,
				    	"updatedAt":false
					},
				    "where": where
					};
                $.ajax({
                    "url": "https://d.apicloud.com/mcm/api/songs?filter="+encodeURIComponent(JSON.stringify(filter)),
                    "method": "GET",
                    "cache": false,
                    "headers": {
                        "X-APICloud-AppId": "A6982930175882",
                        "X-APICloud-AppKey": appKey
                    }
                }).success(function (data, status, header) {
                    _self.songList = data;
                    _self.loadingDone = true;
                }).fail(function (header, status, errorThrown) {
                });

            }
		}
	}
</script>