<template>
<left-side></left-side>	
<main class="bg row">
	<g-header></g-header>
	<router-view></router-view>
	<right-side></right-side>
</main>

		
</template>
<style>
	main {
		padding-left: 240px;
	}
	@media only screen and (max-width: 1101px){
		main{
	    padding-left: 0;
		}
	}
</style>
<script>
	//全局Css样式
	require ('../static/iconfont/iconfont.css');
	require ('../lib/materialize/materialize.js');
	//组件
	import gHeader from '../components/header/header.vue';
	import leftSide from '../components/leftSide/leftSide.vue';
	import rightSide from '../components/rightSide/rightSide.vue';
	//vuex
	import store from '../vue-tools/vuex/store.js';
	export default {
		store,
		ready (){
			$(window).resize();
        },
		components: { gHeader,leftSide,rightSide }
	}
    $(window).resize(function(){
        adjustPage();
    });
    var adjustPage = function(){
		var wHeight = $(window).height();
		var hHeight = $(".header").height();
        $(".right-side-container").height(wHeight - hHeight);
        $(".center-container").height(wHeight - hHeight);
    }
</script>