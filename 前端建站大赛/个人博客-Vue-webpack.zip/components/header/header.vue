<template>
    <nav class="header col s12">
        <a href="#!" class="brand-logo center">This is my Website</a>
        <div class="nav-wrapper grey darken-3">  
            <ul class="right hide-on-med-and-down ">
                <li>
                    <form>
                        <div class="input-field">
                          <input id="search" type="search" required placeholder="">
                          <label for="search"><i class="iconfont">&#xe602;</i></label>
                          <i class="iconfont">&#xe60c;</i>
                        </div>
                    </form>
                </li>
            </ul>
        </div>
    </nav>
</template>
<style >
    
</style>
<script>
    require("./style.less");
    export default {
        ready(){
             
        }
    }
</script>

