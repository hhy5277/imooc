module.exports = function(router){
	router.map({
		'/':{				//棣栭〉
            name:'index',
            component: function(resolve){
                require(['../components/music/music.vue'],resolve);
            }
        },
		'*': {				//棣栭〉
            name:'index',
            component: function(resolve){
                require(['../components/music/music.vue'],resolve);
            }
    	},
        '/blog/list/:type': {
            name: 'list',
            component: function(resolve){
                require(['../components/blog/list/list.vue'],resolve);
            }
        },
        '/blog/post/:postId': {
            name: 'post',
            component: function(resolve){
                require(['../components/blog/post/post.vue'],resolve);
            }
        },
        '/music/:type': {
            name: 'music',
            component: function(resolve){
                require(['../components/music/music.vue'],resolve);
            }
        },
        '/resume': {
            name: 'resume',
            component: function(resolve){
                require(['../components/resume/resume.vue'],resolve);
            }
        }
    })
}