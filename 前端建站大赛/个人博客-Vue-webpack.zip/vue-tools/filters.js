"use strict"

import utils from '../lib/utils.js'

exports.timeFmt = function(time, friendly, simply){
    if (friendly) {
        return utils.MillisecondToDate(new Date() - new Date(time));
    } else {
    	if(simply){
    		return utils.fmtDate(new Date(time),'yyyy/MM/dd');
    	}else{
    		return utils.fmtDate(new Date(time),'yyyy-MM-dd hh:mm');
    	}
        
    }
}

exports.titleLimit = function(title){
	if(title.length > 18){
		return title.substring(0,17) + "...";
	}else{
		return title
	}
}

exports.songTimeFmt = function(secconds){
    var seccond = ((secconds%60)<10)?('0'+secconds%60):(secconds%60);
    return parseInt(secconds/60)+":"+seccond;
}