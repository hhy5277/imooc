import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

// root state object.
// each Vuex instance is just a single state tree.
const state = {
	listEmpty: false,
	currentSongIndex: 0,
 	playList: [
	  	{
	    "name": "浪费",
	    "src": "langfei.mp3",
	    "time": "307",
	    "isFav": true,
	    "singer": "林宥嘉",
	    "lyricist": "陈信延",
	    "composer": "郑楠",
	    "original": "林宥嘉",
	    "album": "大小说家",
	    "coverSrc": "linyoujia.jpg",
	    "createdAt": "2016-03-27T05:10:57.711Z",
	  },
	  {
	    "name": "天天",
	    "src": "tiantian.mp3",
	    "time": "274",
	    "isFav": true,
	    "singer": "陶喆",
	    "lyricist": "娃娃",
	    "composer": "陶喆",
	    "original": "陶喆",
	    "album": "IM OK",
	    "coverSrc": "taozhe.png",
	    "createdAt": "2016-03-27T05:10:57.711Z",
	  },
	  {
	    "name": "知道",
	    "src": "zhidao.mp3",
	    "time": "282",
	    "isFav": true,
	    "singer": "韦礼安",
	    "lyricist": "韦礼安",
	    "composer": "韦礼安",
	    "original": "郭静",
	    "album": "下一个天亮",
	    "coverSrc": "weilian.png",
	    "createdAt": "2016-03-27T05:10:57.711Z",
	  },
  	]
};

const mutations = {
    SETCURRENTSONG (state, index) {
    	state.currentSongIndex = index
    },
    PRESONG (state, index){
    	state.currentSongIndex--
    },
    NEXTSONG (state, index){
    	state.currentSongIndex++
    },
    REMOVESONG (state, item){
    	state.playList.$remove(item)
    	console.log(state.playList.length)
    },
    SETEMPTYSTATE (state, bool){
    	state.listEmpty = bool;
    },
    ADDTOLIST (state, item){
    	state.playList.push(item);
    }
 }
export default new Vuex.Store({
  state,
  mutations
})