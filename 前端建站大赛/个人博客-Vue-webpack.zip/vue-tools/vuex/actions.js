export const setCurrentSong = ({dispatch, state},index) => {
	if(state.playList.length > index){
		dispatch('SETEMPTYSTATE',false)
		dispatch('SETCURRENTSONG',index)
	}
};
export const preSong = ({dispatch, state}) => {
	if(state.currentSongIndex > 0){
		dispatch('PRESONG')
	}else{
		dispatch('SETEMPTYSTATE',true)
	}
};
export const nextSong = ({dispatch, state}) => {
	if(state.playList.length > (state.currentSongIndex + 1)){
		dispatch('NEXTSONG')
	}else{
		dispatch('SETEMPTYSTATE',true)
	}
}
export const removeSong = ({dispatch, state}, item) => {
	var index = state.playList.indexOf(item);
	var length = state.playList.length;
	if (index == length - 1) {
		if(length != 1){
			dispatch('SETCURRENTSONG',(index - 1));
		}else{
			dispatch('SETEMPTYSTATE',true)
		}
	}
	
	dispatch('REMOVESONG',item);
}

export const addToList = ({dispatch, state}, item) => {
	if($.inArray(item,state.playList) != -1){
		return
	}
	dispatch('ADDTOLIST', item);

}

export const playSong = ({dispatch, state}, item) => {
	var itemIndex = $.inArray(item,state.playList);
	console.log(itemIndex);
	if( itemIndex == -1){
		dispatch('ADDTOLIST', item);
		dispatch('SETCURRENTSONG',state.playList.length-1);
	}else{
		dispatch('SETCURRENTSONG',itemIndex)
	}
}