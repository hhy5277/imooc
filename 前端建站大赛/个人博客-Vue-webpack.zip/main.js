import Vue from 'vue';
import App from './components/App.vue'
import VueRouter from 'vue-router'
import VueAsyncData from 'vue-async-data';
import VueResource from 'vue-resource';
import routerMap from './vue-tools/router.js'
import filters from './vue-tools/filters'

Vue.config.debug = true;
Vue.use(VueResource);
Vue.use(VueRouter);
Vue.use(VueAsyncData);

import Velocity from './lib/velocity.js'

//修复velocity不能绑定到全局Jquery的bug
$.fn.velocity = Velocity.animate;
$.fn.velocity.defaults = Velocity.defaults;


Object.keys(filters).forEach(k => Vue.filter(k, filters[k]));

let router = new VueRouter({
    hashbang: true,
    history: false,
    saveScrollPosition: true,
    transitionOnLoad: true,
    linkActiveClass: 'active'
})
routerMap(router)
router.start(App, 'app')
