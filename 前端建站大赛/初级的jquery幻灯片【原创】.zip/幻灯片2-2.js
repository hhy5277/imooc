<!--
function a(width,height,url,text){     //url是选择器名称。
	var $url=url;  
	var $text=text;
   $("#zhezhao").fadeIn(1000);
	document.getElementById("contents").style.left=(parseInt(document.getElementById("contents").style.width)-width)/2+document.getElementById("contents").offsetLeft+'px';
	document.getElementById("contents").style.width=width+'px';
	document.getElementById("contents").style.height=height+'px';
	document.getElementById("contents").style.background=$($url).css("background");
	if(text!=""&&text!=null){
    document.getElementById("contents2").style.background="#000";
	document.getElementById("contents2").innerHTML=$text;
	}
	}
function b(){
	$("#zhezhao").fadeOut(600);
	document.getElementById("contents").style.left=512+'px';
	document.getElementById("contents").style.width="";
	document.getElementById("contents").style.height="";
	document.getElementById("contents").style.background="";
	document.getElementById("contents2").innerHTML="";
	 document.getElementById("contents2").style.background="";
}
-->
/*function c(direction){   //direction是箭头方向（1-左，2-右）
	if(direction==1){                    
	   a(400,400,li1);
	}
	else if(direction==2){                    
	   a(400,400,li3);
	}	
}*/
var counter=0;//计数器，不解释
function c(){
	if(counter<1){
	$("ul").animate({
		left:"-=250px"
	},1000)
	counter++;
	}
}
function d(){
	if(counter>0){
	$("ul").animate({
		left:"+=250px"
	},1000)
	counter--;
	}
}