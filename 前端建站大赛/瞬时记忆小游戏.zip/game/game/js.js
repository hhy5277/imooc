﻿function GetRandomNum(Min,Max){/*随机函数  */
    var Range = Max - Min;
    var Rand = Math.random();
    return(Min + Math.round(Rand * Range));
}
var lesson_NUM;
var oldCir = new Array();
var CIR_NUM = 0;
function game_start(){/* 游戏开始 */
    lesson_NUM = 0;
    next_round();
    document.getElementById("start-button").style.display = "none";
}
function setCir(cir){/* 创建新点位置 */
    var cir_style = GetRandomNum(40,80);
    var left_NUM = GetRandomNum(0,515);
    var top_NUM = GetRandomNum(0,515);
    for(var i = 0;i < CIR_NUM;i++){
        if((cir_style > Math.abs(oldCir[i].left - left_NUM))&&(cir_style > Math.abs(oldCir[i].top - top_NUM))){
            return "against";
        }
    }
    cir.style.width = cir_style;
    cir.style.height = cir_style;
    cir.style.borderRadius = cir_style/2 +'px';
    cir.style.left = left_NUM + 'px';
    cir.style.top = top_NUM + 'px';
    CIR_NUM ++;
    oldCir[i] = {CNum:i,left:left_NUM,top:top_NUM,radius:cir_style};
    return "success";
}
function addCir(){/* 增加圆点 */
    var parent = document.getElementById("back");
    var new_cir = document.createElement("div");
    var bool = 0;
    new_cir.value = 0;
    new_cir.className = "cirs";
    setCir(new_cir);
    while(bool==0){
        var true_cir = setCir(new_cir);
        if(true_cir == "against"){
            setCir(new_cir);
        }else{
            bool=1;
        }
    }
    new_cir.onclick = function right(){
        if(this.value == 0){
            this.value = 1;
            next_round();
        }else{
            this.style.background = "#ff9797";
            var pingyu;
            if(lesson_NUM <= 5){
                pingyu = "请你认真玩游戏!";
            }
            else if(lesson_NUM > 5 && lesson_NUM <= 10){
                pingyu = "鱼?";
            }
            else if(lesson_NUM > 10 && lesson_NUM <= 15){
                pingyu = "还可以,再来一把!";
            }
            else if(lesson_NUM > 15){
                pingyu = "这游戏应该是被你发现BUG了!";
            }
            document.getElementById("score").innerHTML = "得分&nbsp;" + lesson_NUM;
            document.getElementById("remark").innerHTML = pingyu;
            document.getElementById("over").style.zIndex = "4";
            document.getElementById("over").style.display = "block";

        }
    };
    parent.appendChild(new_cir);
}
function next_round(){/* 下一关 */
    document.getElementById("lesson").style.backgroundColor = "#fff";
    document.getElementById("lesson").style.zIndex = "4";
    lesson_NUM++;
    if(lesson_NUM == 1){

        document.getElementById("info").innerHTML = "选出新出现的圆点";
    }else{
        document.getElementById("info").innerHTML = "";
    }
    document.getElementById("lesson_num").innerHTML = lesson_NUM;
    if(lesson_NUM == 1){
        setTimeout("white_back()",4000);
    }else{
        setTimeout("white_back()",1000);
    }

}
function white_back(){/* 背景白色 */
    addCir();
    document.getElementById("lesson").style.backgroundColor = "#222";
    document.getElementById("lesson").style.zIndex = "2";
}
function again_game(){
    window.location.reload();
}