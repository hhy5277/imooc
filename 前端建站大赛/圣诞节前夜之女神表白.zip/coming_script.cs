﻿using UnityEngine;
using System.Collections;

public class coming_script : MonoBehaviour {
    public float Duration = 2.0f;  //持续时间---可编辑的变量
    float elapse;    //记录时间的变量
	// Use this for initialization
	void Start () {
        SetAlpha(0);
	}

    void SetAlpha(float a)  //  设置alpha
    {
        var sp = GetComponent<SpriteRenderer>();  //定义变量sp
        var c = sp.color;
        c.a = a;
        sp.color = c;
    }
	
	// Update is called once per frame
	void Update () {

        if (elapse < Duration) 
        {
            elapse += Time.deltaTime;
            SetAlpha (elapse / Duration);
        }
	
	}
}
