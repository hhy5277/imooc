﻿using UnityEngine;
using System.Collections;

public class storyBoard : MonoBehaviour
{

    float[] timeArray = new float[] {  4, 6, 8, 10, 12 ,14,16,23,26,28,
                                       30,32,34,36,40,42,44,46,48,50,
                                       52,54,58,60,62,64,66,70,75,80,
                                       83,86,90,98,100,103,106
                                    };    //定义时间轴，进行流程控制  --- 长度为36
    int index;   //数组下标
    bool canClick;   //鼠标点击

    public GameObject ball;   //映射游戏对象
    public GameObject car;
    public GameObject snower;
    public GameObject deers;
    public GameObject wan0;
    public GameObject oldman;
    public GameObject hat;
    public GameObject word;

    public GameObject background;
    public GameObject word0;
    public GameObject word1;
    public GameObject word2;
    public GameObject bg2;
    public GameObject word3;
    public GameObject word4;
    public GameObject bg3;
    public GameObject word6;
    public GameObject word7;
    public GameObject bg4;
    public GameObject word8;
    public GameObject word9;
    public GameObject word10;
    public GameObject lufei;
    public GameObject hacker;
    public GameObject bg5;
//    public GameObject word11;
//    public GameObject bg6;
    public GameObject wan1;
    public GameObject wan2;
    public GameObject wan3;
    public GameObject wan4;
    public GameObject word12;
    public GameObject night0;
    public GameObject fly;
    public GameObject bg7;
    public GameObject word13;
    public GameObject ping;
    public GameObject end;
//    public GameObject esc;
    public GameObject bg8;
    public GameObject word14;
    public GameObject word15;
    public GameObject word16;
    public GameObject word17;

    // Use this for initialization
    void Start()
    {
        //       bg1.SetActive(false);
        ball.SetActive(false);
        car.SetActive(false);
        snower.SetActive(false);
        deers.SetActive(false);
        word.SetActive(false);
        oldman.SetActive(false);
        wan0.SetActive(false);
        hat.SetActive(false);

        background.SetActive(false);
        word0.SetActive(false);
        word1.SetActive(false);
        word2.SetActive(false);
        bg2.SetActive(false);
        word3.SetActive(false);
        word4.SetActive(false);
        bg3.SetActive(false);
        word6.SetActive(false);
        word7.SetActive(false);
        bg4.SetActive(false);
        word8.SetActive(false);
        word9.SetActive(false);
        word10.SetActive(false);
        lufei.SetActive(false);
        hacker.SetActive(false);
        bg5.SetActive(false);
       
        wan1.SetActive(false);
        wan2.SetActive(false);
        wan3.SetActive(false);
        wan4.SetActive(false);
        word12.SetActive(false);
        night0.SetActive(false);
        fly.SetActive(false);
        bg7.SetActive(false);
        word13.SetActive(false);
        ping.SetActive(false);
        end.SetActive(false);
  //      esc.SetActive(false);
        bg8.SetActive(false);
        word14.SetActive(false);
        word15.SetActive(false);
        word16.SetActive(false);
        word17.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (index < timeArray.Length && Time.realtimeSinceStartup >= timeArray[index])
        {
            OnTime(index);
            index++;
        }

    }

    void OnTime(int index)
    {
        Debug.Log(index); //打日志,方便调试

        switch (index)
        {
            case 0:
                {
                    ball.SetActive(true);
                }
                break;
            case 1:
                {
                    car.SetActive(true);
                }
                break;
            case 2:
                {
                    snower.SetActive(true);
                  
                }
                break;
            case 3:
                {
                    deers.SetActive(true);
                }
                break;
            case 4:
                {
                    wan0.SetActive(true);

                }
                break;
            case 5:
                {
                    hat.SetActive(true);
                    oldman.SetActive(true);
                } break;
            case 6:
                {
                    word.SetActive(true);
                }
                break;
            case 7:
                {
                    background.SetActive(true);
                }
                break;
            case 8:
                {
                    word0.SetActive(true);
                    
                }
                break;
            case 9:
                {
                    word1.SetActive(true);
                    
                }
                break;
            case 10:
                {
                    word2.SetActive(true);
                    
                }
                break;
            case 11:
                {
                    bg2.SetActive(true);
                    
                }
                break;
            case 12:
                {
                    word3.SetActive(true);
                    
                }
                break;
            case 13:
                {
                    word4.SetActive(true);
                    
                }
                break;
            case 14:
                {
                    bg3.SetActive(true);
                    
                }
                break;
            case 15:
                {
                    word6.SetActive(true);
                    
                }
                break;
            case 16:
                {
                    word7.SetActive(true);
                    
                }
                break;
            case 17:
                {
                    bg4.SetActive(true);
                    
                }
                break;
            case 18:
                {
                    word8.SetActive(true);
                    
                }
                break;
            case 19:
                {
                    word9.SetActive(true);
                    
                }
                break;
            case 20:
                {
                    word10.SetActive(true);
                    
                    
                }
                break;
            case 21:
                {
                    lufei.SetActive(true);
                    hacker.SetActive(true);
                    
                }
                break;
            case 22:
                {
                    bg5.SetActive(true);
                }
                break;
            case 23:
                {
                    wan1.SetActive(true);
                }
                break;
            case 24:
                {
                    wan2.SetActive(true);
                }
                break;
            case 25:
                {
                    wan3.SetActive(true);
                }
                break;
            case 26:
                {
                    wan4.SetActive(true);
                }
                break;
            case 27:
                {
                    word12.SetActive(true);
                }
                break;
            case 28:
                {
                    night0.SetActive(true);
                    fly.SetActive(true);
                }
                break;
            case 29:
                {
                    bg7.SetActive(true);
                }
                break;
            case 30:
                {
                    word13.SetActive(true);
                }
                break;
            case 31:
                {
                    ping.SetActive(true);
                }
                break;
            case 32:
                {
                    end.SetActive(true);
     
                  
                }
                break;
            case 33:
                {
                    bg8.SetActive(true);
                   

                }
                break;
            case 34:
                {

                    word14.SetActive(true);

                }
                break;
            case 35:
                {

                    word15.SetActive(true);

                }
                break;
            case 36:
                {

                    word16.SetActive(true);
                    word17.SetActive(true);

                }
                break;
         
        }
    }

    void OnGUI()   //制作退出按钮
   {                
    if(Input.GetKeyDown(KeyCode.Escape))   //键盘按ESC键弹出退出按钮
        canClick = true;  
    if (canClick)
        {  
        if(GUI.Button(new Rect(350,400,200,150),"EXIT"))
        {
            Application.Quit();
        }
}
}
}
