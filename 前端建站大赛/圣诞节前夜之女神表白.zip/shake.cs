﻿using UnityEngine;
using System.Collections;

public class shake : MonoBehaviour {

    Vector3 origPos;  //记录位置
    float elapse;  //持续时间

    public float Interval = 0.05f;    //间隔   定义为public会映射到编辑器上
    public float Range = 0.05f;  //范围

	// Use this for initialization
	void Start () {
        origPos = transform.position;  //记录原位置
	
	}
	
	// Update is called once per frame
	void Update () {
        elapse += Time.deltaTime;
        if(elapse > Interval)
        {
            var pos = transform.position;
            pos.x = origPos.x + Random.Range(-Range,Range);
            pos.y = origPos.y + Random.Range(-Range, Range);
            transform.position = pos;
            elapse = 0.0f;
        }
	
	}
}
