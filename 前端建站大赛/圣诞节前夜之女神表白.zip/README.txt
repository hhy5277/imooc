<p>coming_script.cs 是渐进效果代码，</p><p>shake.cs 是抖动效果代码，</p><p>storyBoard.cs 是整个游戏的流程控制代码。。</p>

