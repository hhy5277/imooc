<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<script type="text/javascript"  src="file:///F|/DW2/jquery-1.11.3.js"></script>
</head>

<body>
<div>div的内容</div>
        <div>Hello world!</div>
        <script type="text/javascript">
          $("div").html("hello hiihihi");
        </script>
</body>
</html>

