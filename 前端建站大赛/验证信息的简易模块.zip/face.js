window.onload=function()
{
	var oinput=document.getElementsByTagName('input');/*输入框*/
	var omail=oinput[0];
	var oname=oinput[1];
	var onick=oinput[2];
	var opwd=oinput[5];
	var opwd2=oinput[6];
	
	var mail=document.getElementById('mail');
	var pwd=document.getElementById('pwd');
	
	
	omail.onblur=function(){
		checkmail(omail.value);//调用
	}
	oname.onblur=function(){
		checkname(oname.value);
	}
	onick.onblur=function(){
		checknick(onick.value);
	}
	opwd.onblur=function(){
		checkpwd(opwd.value);
	}
	opwd2.onblur=function()//再次输入密码，验证是否相等
	{
		if(this.value=="")
		{
			alert("密码不能为空！")
		}
		else if(this.value==opwd.value)
		{
			pwddd.innerHTML="√验证通过！"
		}
		else
		{
			alert("两次输入密码不一致，请检查后再输！")
		}
	}
	mail.onblur=function(){
		checkmail(mail.value);
	}
	pwd.onblur=function(){
		checkpwd(pwd.value);
	}
}
//验证邮箱
function checkmail(str)
{	
	var oimg=document.getElementsByTagName("img");
	var reg=/^[0-9a-z][a-z0-9\._-]{1,}@[a-z0-9-]{1,}[a-z0-9]\.[a-z\.]{1,}[a-z]$/; 
	if(str=="")
	{
		mailtxt.innerHTML="×不能为空！"
		maill.innerHTML="×不能为空！"
		oimg[0].style.display="none";
		oimg[1].style.display="block";
		oimg[8].style.display="none";
		oimg[9].style.display="block";
	}
	else if(reg.test(str))
	{
		oimg[0].style.display="block";
		oimg[1].style.display="none";
		oimg[8].style.display="block";
		oimg[9].style.display="none";
		
		maill.innerHTML="√通过！"
		mailtxt.innerHTML="√通过！"
	}
	else{
		alert("请输入正确的邮箱地址！");
	}
}
//验证姓名
function checkname(str)
{
	var oimg=document.getElementsByTagName("img");
	var reg = /^[\u4E00-\u9FA5]{2,4}$/;
	if(str=="")
	{
		oimg[2].style.display="none";
		oimg[3].style.display="block";
		
		namee.innerHTML="×不能为空！"
	}
	else if(reg.test(str))
	{
		oimg[2].style.display="block";
		oimg[3].style.display="none";
		
		namee.innerHTML="√通过！";
	}
	else 
	{
		alert("请输入正确的姓名！")
	}
}
//验证昵称
function checknick(str)
{
	var oimg=document.getElementsByTagName("img");
	if(str=="")
	{
		oimg[4].style.display="none";
		oimg[5].style.display="block";
		nickk.innerHTML="×不能为空！"
	}
	else
	{
		oimg[4].style.display="block";
		oimg[5].style.display="none";
		
		nickk.innerHTML="√通过！";
	}
}
//验证密码
function checkpwd(str)
{
	var oimg=document.getElementsByTagName("img");
	var reg=/^[0-9_a-zA-Z]{6,20}$/;
	if(str=="")
	{
		oimg[6].style.display="none";
		oimg[7].style.display="block";
		pwdtxt.innerHTML="×不能为空！"
		pwdd.innerHTML="×不能为空！"
	}
	else if(reg.test(str))
	{
		oimg[6].style.display="block";
		oimg[7].style.display="none";
		
		pwdd.innerHTML="√通过！";
		
	}
	else 
	{
		alert("请输入正确的密码格式！")
	}
	
}
//切换选项卡
function setTab(divId,divName,divCount)
{
var i=0;
for(i=0;i<divCount;i++)
{
	document.getElementById(divName+i).style.display="none";
	document.getElementById(divName+divId).style.display="block";
}
};
//登录页面注册成功提示框
function success()
{
	if(mail.value!="")
	{
		alert("注册成功！")}
	else{
		alert("注册失败！")
		}
};
//注册页面注册成功提示框
function register()
{
	var oinput=document.getElementsByTagName('input');/*输入框*/
	var omail=oinput[0];
	var oname=oinput[1];/*出了omail,oname的定义范围，要想使用必须重新定义*/
		if((oname.value!="")&&(omail.value!="")&&(opwd.value!=""))
		{alert("注册成功！")}
		else{
		alert("注册失败！")}
};
//重置按钮

function resets()
{
	document.getElementById("maill").innerHTML = "";
	document.getElementById("namee").innerHTML = "";
	document.getElementById("nickk").innerHTML = "";
	document.getElementById("pwdd").innerHTML = "";
	document.getElementById("pwddd").innerHTML = "";
	document.getElementById("mailtxt").innerHTML="";
	document.getElementById("pwdtxt").innerHTML="";
	
	document.getElementsByTagName("img")[0].style.display="none";
	document.getElementsByTagName("img")[1].style.display="none";
	document.getElementsByTagName("img")[2].style.display="none";
	document.getElementsByTagName("img")[3].style.display="none";
	document.getElementsByTagName("img")[4].style.display="none";
	document.getElementsByTagName("img")[5].style.display="none";
	document.getElementsByTagName("img")[6].style.display="none";
	document.getElementsByTagName("img")[7].style.display="none";
	document.getElementsByTagName("img")[8].style.display="none";
	document.getElementsByTagName("img")[9].style.display="none";
}