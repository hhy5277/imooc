<p>调用typed.js实现打字效果！！</p><p>插件地址 :https://github.com/mattboldt/typed.js/&nbsp;</p><p>文字内容原创！</p><p>自己创的歌单地址:<a href="http://music.163.com/#/playlist?id=136962369" _src="http://music.163.com/#/playlist?id=136962369">http://music.163.com/#/playlist?id=136962369</a></p><p>作品毫无亮点，无创新！个人感觉就音乐有那么点能听听！！</p>

