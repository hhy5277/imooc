<?php
    header("content-type:text/html;charset=utf-8");
    $conn = mysql_connect("localhost","root","") or die("连接服务器失败");
    mysql_select_db("students");
    mysql_query("set names utf8");
?>