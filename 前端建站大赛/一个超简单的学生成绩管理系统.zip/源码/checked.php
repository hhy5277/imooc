<?php
include_once 'conn.php';
header("Content-type:text/html;charset=utf-8");
$old_pwd = $_POST['old_pwd'];
$new_pwd = $_POST['new_pwd'];
$user = $_POST['username'];
    $sql = "select * from admin where password='{$old_pwd}' and username='{$user}'";
    $r = mysql_query($sql);
    $row = mysql_fetch_array($r);
        if ($row) {
            $rr = "update admin set password='{$new_pwd}' where password='{$old_pwd}'";
            mysql_query($rr);
            echo "<script>alert('恭喜！！！修改成功');location = 'index.php';</script>";
        } else {
            echo "<script>alert('出错了！请致我邮箱:626607984@qq.com');location = 'index.php';</script>";
        }
       
    
?>