<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>登陆</title>

<style type="text/css">
/*     body{background-image:url(images/bj.gif); text-color:white;} */
</style>
<script >
	function showstu(){
		var xmlhttp=new window.XMLHttpRequest();
		var km = document.getElementById("km").value;
		xmlhttp.open("GET","showstu.php?km="+km,true);
		xmlhttp.send();
		xmlhttp.onreadystatechange=function(){
			if(xmlhttp.readyState==4 && xmlhttp.status==200){
				document.getElementById("tbl").innerHTML = xmlhttp.responseText;
				xmlhttp = null;
			}
		}
	}
	
	function show(){
		var xmlhttp=new window.XMLHttpRequest();
		
		var xm=document.getElementById("xh").value;
		xmlhttp.open("GET","showstu.php?xh="+xh,true);
		xmlhttp.send();
		xmlhttp.onreadystatechange=function(){
			if(xmlhttp.readyState==4 && xmlhttp.status==200){
				document.getElementById("tbl").innerHTML = xmlhttp.responseText;
				xmlhttp = null;
			}
		}
	}
	
	
</script>
</head>

<body>
请选择班级：
<select name="km" id="km" onchange="showstu()" style="font-size: 100">
<option value="">没有选择</option>
<?php
	include_once("conn.php");
	$sql = 'select distinct km from grade';
	mysql_query($sql);
	$r = mysql_query($sql);
	while($row = mysql_fetch_array($r)){
		echo "<option value='$row[0]'>$row[0]</option>";
	}
?>
</select>
<?php 
    echo '学生学号：<input type="text" id="xh" />';
	echo '<input type="button" onclick="show()" value="查询"/>';
?>

<div id="tbl">
</body>
</html>