<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Ñ§Éú³É¼¨¹ÜÀíÏµÍ³</title>
<style type="text/css">
<!--
.STYLE13 {font-size: 18px; color: #FF0000; font-weight: bold; }
-->
</style>
</head>
<body background="pic/bg.gif">
<form action="doinsert_student.php" method="post">
<table width="767" height="732" border="0" align="center">
 <tr>
    <td height="228" colspan="5" background="images/study.jpg" style="width:767px; height:260px">    </td>
  </tr>
<tr>
   <td width="152" height="29" background="pic/main1.gif"><div align="center" class="STYLE13"><a href="admin_face.php">主页</a></div></td>
    <td width="152" height="29" background="pic/main1.gif"><div align="center" class="STYLE13"><a href="admin_result.php">查询学生的信息</a></div></td>
    <td width="152" background="pic/main1.gif"><div align="center" class="STYLE13"><a href="select_all.php">查看全部学生成绩</a></div></td>
    <td width="150" background="pic/main1.gif"><div align="center" class="STYLE13"><a href="insert_student.php">录入新的学生</a></div></td>
    <td width="144" background="pic/main1.gif"><div align="center" class="STYLE13"><a href="inser_grade.php">录入学生的成绩</a></div></td>
  </tr>
  </tr>
  <tr>
    <td colspan="5" style="background-color: #47c9af"><table width="431" height="280" border="0" align="center">
  <tr>
    <td width="95">学号</td>
    <td width="320"><input type="text" name="xh" /></td>
  </tr>
  <tr>
    <td>姓名</td>
    <td><input type="text" name="xm" /></td>
  </tr>
   <tr>
    <td>性别</td>
    <td><input type="text" name="sex"  /></td>
  </tr>
  <tr>
    <td>班级</td>
    <td><input type="text" name="class"  /></td>
  </tr>
  <tr>
    <td><input type="submit" value="确定提交" /></td>
    <td>&nbsp;</td>
  </tr>
</table></td>
  </tr>
</table>
</form>
</body>
</html>
