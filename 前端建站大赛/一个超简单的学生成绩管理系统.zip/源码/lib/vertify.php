<?php 
      session_start();

      $image=imagecreatetruecolor(150, 35);
      $bgcolor=imagecolorallocate($image, 255, 255, 255);
      imagefill($image, 0, 0, $bgcolor);
      
      $fontface='a.ttf'; //字体一定要命名为英文
	  
      $str = "的 一 是 在 了 不 和 有 大 这 主 中 人 上 为 们 地 个 用 工 时 要 动 国 产 以 我 到 他 会 作 来 分 生 对 于 学 下 级 就 年 阶 义 发 成 部 民 可 出 能 方 进 同 行 面 说 种 过 命 度 革 而 多 子 后 自 社 加 小 机 也 经 力 线 本 电 高 量 长 党 得 实 家 定 深 法 表 着 水 理 化 争 现 所 二 起 政 三 好 十"; 
      $strdb = explode(" ", $str);
     
//       $strdb=array('吕' , '尚' ,'尖' ,'喏~' ); 
//       $strdb=str_split($str,3); //将字符串转换为数组 3为每一段长度
      //header('content-type:text/html; charset=utf-8');
//       var_dump($strdb);
//       die();
     $captch_code='';
     for($i=0;$i<3;$i++)//写汉字       
     { 
         $fontcolor=imagecolorallocate($image,rand(0,120), rand(0,120), rand(0,120));//字体颜色
        
           $index = rand(0, (count($strdb)-1)); //计算数组中的单元数目或对象中的属性个数
            $cn = $strdb[$index];
            $captch_code.=$cn;

         imagettftext($image, mt_rand(20,24), mt_rand(-20,60),(40*$i+20), mt_rand(30,35),  $fontcolor, $fontface, $cn);
         //imagettftext(image, size, angle, x, y, color, fontfile, text)
         //用 TrueType 字体向图像写入文本
         //angle 更高数值表示逆时针旋转
       } 
      

       $_SESSION['authcode']=$captch_code;

      for ($i=0; $i < 200; $i++) //干扰点
      { 
      	$pointcolor=imagecolorallocate($image, rand(50,200), rand(50,200), rand(50,200));
      	imagesetpixel($image, rand(1,199), rand(1,59), $pointcolor);
      }
      
       for ($i=0; $i < 3; $i++) //干扰线
      { 
      	$linecolor=imagecolorallocate($image, rand(80,220), rand(80,220), rand(80,220));
      	imageline($image, rand(1,199), rand(1,59),rand(1,199), rand(1,59), $linecolor);
      }

      header('content-type: image/png');
      imagepng($image);

      imagedestroy($image);
      
?>