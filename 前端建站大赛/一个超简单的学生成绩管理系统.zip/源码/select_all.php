<?php
session_start(); 
include_once 'conn.php';
@checkLogined();
$query = "select *  from grade order by xh";
$r = mysql_query($query);
$num_result = mysql_num_rows($r);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>学生成绩管理系统</title>
</head>
<body background="pic/bg.gif">
<form name="form1" method="post">
<table width="767" height="324" border="0" align="center" style="background-color: #47c9af">
  <tr>
    <td height="228" colspan="5" background="images/study.jpg" style="width:767px; height:260px">    </td>
  </tr>
  <tr>
    <td width="110" height="28" >学号 </td>
    <td width="115" >科目</td>
    <td width="111" >分数</td>
    <td width="67" >修改</td>
  </tr><?php for($i = 0; $i < $num_result; $i++)
  {
  $row = mysql_fetch_assoc($r);
  ?>
  <tr> 
    <td background="pic/in_20.gif"><?php echo stripslashes($row['xh']);?></td>
    <td background="pic/in_20.gif"><?php echo stripslashes($row['km']); ?></td>
    <td background="pic/in_20.gif"><?php echo stripslashes($row['cj']); ?></td>
    <td background="pic/in_20.gif"><a href="changed_stu_grade.php">修改</a></td>
  </tr>
  <?php
  }
  //$result->free();
//   $db->close();

  ?>
</table>
</form>
</body>
</html>
