<?php 
session_start();
/**
 * 检测是否有管理员登陆.
 */
function checkLogined(){
	if(@$_SESSION['adminName']==""){
		echo"<script>alert('一、如果你是普通用户，别急~先登录亲~\\n二、如果你是haker，请攻破我的后台再直接进入吧,谢谢合作~');location = 'index.php';</script>";
	}
}
/**
 * 注销管理员
 */
function logout(){

	$_SESSION=array();
	if(isset($_COOKIE[session_name()])){
		setcookie(session_name(),"",time()-1);
	}
	if(isset($_COOKIE['adminId'])){
		setcookie("adminId","",time()-1);
	}
	if(isset($_COOKIE['adminName'])){
		setcookie("adminName","",time()-1);
	}
	session_destroy();
	echo"<script>alert('退出成功');location = 'index.php';</script>";
// 	header("location:index.php");
}
?>
