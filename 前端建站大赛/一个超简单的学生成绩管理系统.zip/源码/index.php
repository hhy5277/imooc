<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>登陆</title>
<link type="text/css" rel="stylesheet" href="styles/reset.css">
<link type="text/css" rel="stylesheet" href="styles/main.css">
<link  type="text/css" rel="stylesheet" href="css/changed.css">
<script type="text/javascript" src="js/changed.js"></script>
<style type="text/css">
body{padding:0 margin:0;border:0}
 .wrapper{width:100%; height:770px;background-image:url(images/girl3.gif);background-size:100% 100%}
.login_cont{background:white;opacity:0.7};
.ui-dialog{}
.loginBox {position:relative;top:200px;}
</style>
</head>

<body>
<div class="wrapper">
<div class="headerBar">
<!-- 	<img border="0" src="images/girl.png" width="1200px" height=770px></p> -->
<div class="loginBox">
	<div class="login_cont">
	<form action="dologin.php" method="post">
			<ul class="login">
				<li class="l_tit">请输入账号</li>
				<li class="mb_10"><input type="text"  name="username" placeholder="请输入帐号"class="login_input user_icon"></li>
				<li class="l_tit">密码</li>
				<li class="mb_10"><input type="password" placeholder="请输入密码" name="password" class="login_input password_icon"></li>
				<li class="l_tit">验证码</li>
				<li class="mb_10"><input type="text" name="authcode" id="authcode" placeholder="验证码"  class="login_input password_icon" style="width: 100px">
				   <img onClick="changeImg(this)" src="./lib/vertify.php" alt="" id="img" />
				    <a href="javascript:void(0)" onClick="document.getElementById('img').src='./lib/vertify.php?r='+Math.random()">换一个?</a>
				   
				</li>
				
				<li><a href="javascript:showDialog();">修改密码</a></li>
				<li><input type="submit" value="" class="login_btn"></li>
			</ul>
	</form>
	</div>
</div>
</div>
<div class="ui-mask" id="mask"></div>
<div class="ui-dialog" id="dialogMove"> 
	<div class="ui-dialog-title" id="dialogDrag" >
		<p align="center" >密码修改</p>
		<a class="ui-dialog-closebutton" href="javascript:hideDialog();"></a>
    </div>
	<form action="checked.php" method="post">
    	<div class="ui-dialog-content">
    		<div class="ui-dialog-l40 ui-dialog-pt15">
    			<input type="text" class="ui-dialog-input ui-dialog-input-username" placeholder="请输入账号" name="username"/>
    		</div>
    		<div class="ui-dialog-l40 ui-dialog-pt15">
    			<input type="password" class="ui-dialog-input ui-dialog-input-password" placeholder="请输入旧密码" name="old_pwd" />
    		</div>
    		<div class="ui-dialog-l40 ui-dialog-pt15">
    			<input type="password" class="ui-dialog-input ui-dialog-input-password2" placeholder="请输入新密码" name="new_pwd" />
    		</div>
    		<div class="ui-dialog-submit">
    			<input type="submit"  value="修改"/>
    		</div>
    	</div>
	</form>
</div>


</div>


</body>
</html>