<?php
    session_start();
    include_once 'conn.php';
    header("Content-type:text/html;charset=utf-8");
    $username = $_POST['username'];
    $password = $_POST['password'];
    $authcode = $_POST['authcode'];
    $authcode1 = $_SESSION['authcode'];
    if ($authcode == $authcode1) {
        $sql="select * from admin where username='{$username}' and password='{$password}'";
        $r = mysql_query($sql);
        $row = mysql_fetch_array($r);
        if($row)
           {
               setcookie("adminId",$row['id'],time()+60);
               setcookie("adminName",$row['username'],time()+60);
               $_SESSION['adminName']=$row['username'];
               $_SESSION['adminId']=$row['id'];
               echo"<script>alert('登陆成功');location = 'admin_face.php';</script>";
           }else
           {
               echo"<script>alert('账号或密码错误');location = 'index.php';</script>";
           }
    }else {
        echo"<script>alert('验证码错误');location = 'index.php';</script>";
    }
//     echo "<script>alert(".$_SESSION['adminId'].") </script>";
   
?>
