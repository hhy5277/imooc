<?php
session_start();
header("content-type:text/html;charset=utf-8");
include_once 'conn.php';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>
<?php
$xh = $_POST['xh'];
$km = $_POST['km'];
$cj = $_POST['cj'];
$sql = "update grade set xh='$xh',km='$km',cj='$cj' where xh='$xh'";
if ($r = mysql_query($sql)) {
    
    echo "<script>alert('修改成功');location = 'admin_result.php';</script>";
} else {
    echo "<script>;alert('修改失败，可能存在同名的学号');location = 'goback(-1)';</script>";
}
?>
<body>
</body>
</html>
