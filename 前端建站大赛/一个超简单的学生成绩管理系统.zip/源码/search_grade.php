<?php
session_start(); 
include_once 'conn.php';
@checkLogined();
header("Content-type:text/html;charset=utf-8");
$xh = $_POST['xh'];
$query = "select * from stu_inf where xh = '".$xh."'";
$result = mysql_query($query);
$num_result = mysql_num_rows($result);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>学生成绩管理系统</title>
</head>
<body background="pic/bg.gif">
<form name="form1" method="post">
<table width="767" height="324" border="0" align="center">
 <tr>
    <td height="228" colspan="5" background="images/study.jpg" style="width:767px; height:260px">    </td>
  </tr>
  <tr>
    <td width="110" height="28" background="pic/in_20.gif">学号 </td>
    <td width="136" background="pic/in_20.gif">姓名</td>
    <td width="132" background="pic/in_20.gif">性别</td>
    <td width="115" background="pic/in_20.gif">班级</td>
<!--     <td width="111" background="pic/in_20.gif">分数</td> -->
    <td width="67" background="pic/in_20.gif">&nbsp;</td>
    <td width="66" background="pic/in_20.gif">&nbsp;</td>
  </tr>
  <?php for($i = 0; $i < $num_result; $i++)
  {
  $row = mysql_fetch_assoc($result);
  ?>
  <tr> 
    <td background="pic/in_20.gif"><?php echo stripslashes($row['xh']);?></td>
    <td background="pic/in_20.gif"><?php echo stripslashes($row['xm']);?></td>
    <td background="pic/in_20.gif"><?php echo stripslashes($row['sex']);?></td>
    <td background="pic/in_20.gif"><?php echo stripslashes($row['class']);?></td>
    
  <td background="pic/in_20.gif"><a href="delete.php">删除</a></td>
    <td background="pic/in_20.gif"><a href="changed_stu_inf.php">修改</a></td>
  </tr>
  <?php
  }
  $_SESSION['deletename'] = $xh;
  $_SESSION['updatename'] = $xh;
//   $result->free();
//   $db->close();
  ?>
</table>
</form>
</body>
</html>
