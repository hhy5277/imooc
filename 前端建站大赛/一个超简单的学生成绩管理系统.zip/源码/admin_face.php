 <?php 
include_once 'admin.inc.php';
checkLogined();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<style type="text/css">
<!--
.STYLE13 {font-size: 18px; color: #FF0000; font-weight: bold; }
-->
.clearfix:after,
.clearfix:before{content: ""; display: table;}
.clearfix:after{ clear: both;}
.clearfix{zoom:1;}
.operation_user{font:12px/2.5 "微软雅黑";padding: 0 10px; background-color: rgb(225, 224, 224);}
.icon{padding-left: 18px; background-position: left center; background-repeat: no-repeat;}
.icon_i{background-image: url(./icon/i.png);}
.icon_j{background-image: url(./icon/j.png);}
.icon_t{background-image: url(./icon/t.png);}
.icon_n{background-image: url(./icon/n.png);}
.icon_e{background-image: url(./icon/e.png);}
.link span{font-family: "宋体"; font-weight: 500; padding: 0 10px;}
.link a{color: #000;}
.fr{float: right;}



</style>
<script>
function tosubmit1()
{
document.form1.action = "search_grade.php";
documenr.form1.submit();
}
function tosubmit2()
{
document.form1.action = "search_student.php";
document.form1.submit();
}
</script>
</head>



<body background="pic/bg.gif">
<div class="operation_user clearfix">
       <!--   <div class="link fl"><a href="#">慕课</a><span>&gt;&gt;</span><a href="#">商品管理</a><span>&gt;&gt;</span>商品修改</div>-->
        <div class="link fr">
            <b>欢迎您
            <?php 
				if(isset($_SESSION['adminName'])){
					echo $_SESSION['adminName'];
				}elseif(isset($_COOKIE['adminName'])){
					echo $_COOKIE['adminName'];
				}
            ?>
            
            </b>&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" class="icon icon_i">首页</a><span></span><a href="#" class="icon icon_j">前进</a><span></span><a href="#" class="icon icon_t">后退</a><span></span><a href="#" class="icon icon_n">刷新</a><span></span><a href="doAdminAction.php?act=logout" class="icon icon_e">退出</a>
        </div>
    </div>
  
<form name="form1" method="post">
<table width="767" height="732" border="0" align="center">
  <tr>
    <td height="228" colspan="5" background="images/study.jpg" style="width:767px; height:260px">    </td>
  </tr>
  
  <tr>
   <td width="152" height="29" background="pic/main1.gif"><div align="center" class="STYLE13"><a href="admin_face.php">主页</a></div></td>
    <td width="152" height="29" background="pic/main1.gif"><div align="center" class="STYLE13"><a href="admin_result.php">查询学生的信息</a></div></td>
    <td width="152" background="pic/main1.gif"><div align="center" class="STYLE13"><a href="select_all.php">查看全部学生成绩</a></div></td>
    <td width="150" background="pic/main1.gif"><div align="center" class="STYLE13"><a href="insert_student.php">录入新的学生</a></div></td>
    <td width="144" background="pic/main1.gif"><div align="center" class="STYLE13"><a href="inser_grade.php">录入学生的成绩</a></div></td>
  </tr>
  <tr>
    <td colspan="5" style="background-color: #47c9af">
  <table width="291" height="109" border="0" align="center" style="background-color: #47c9af">
     <tbody>							  
				
					<tr><td>服务器版本</td><td><?php echo  phpversion();   ?></td></tr>
					<tr><td>服务器</td><td><?php echo  php_sapi_name ();   ?></td></tr>
					
              </tbody>
      
    </table></td>
  </tr>
</table>
</form>
</body>
</html>
