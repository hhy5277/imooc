<?php
session_start();
header("content-type:text/html;charset=utf-8");
include_once 'conn.php';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>
<?php

$xh = $_SESSION['deletename'];
$sql = "delete from stu_inf where xh = '" . $xh . "'";
$r = mysql_query($sql);

if (!$r) {
    
    echo "<script>alert('删除不成功');location = 'index.php';</script>";
} else {
    echo "<script>;alert('删除成功');location = 'admin_result.php';</script>";
}
?>
<body>
</body>
</html>
