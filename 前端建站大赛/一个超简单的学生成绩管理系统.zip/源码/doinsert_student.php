<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>
<body>
<center>
<h1></h1>
<?php
include_once 'conn.php';
$xh = $_POST['xh'];
$xm = $_POST['xm'];
$sex = $_POST['sex'];
$class = $_POST['class'];
if(!$xh || !$xm ||!$sex )
{
echo "请全部填写";
exit;
}

$sxh = addslashes($xh);
$sxm = addslashes($xm);
$ssex = addslashes($sex);
$sclass = addslashes($class);

$query = "insert into stu_inf values('".$sxh."','".$sxm."','".$ssex."','".$sclass."')";
$r = mysql_query($query);
if($r)
{

echo mysql_affected_rows()."插入成功";
}
else
{

echo mysql_affected_rows()."插入失败";
}
?>
</center>
</body>
</html>
