<?php
session_start(); 
include_once 'conn.php';
@checkLogined();
$xh = $_POST['xh'];
$query = "select * from grade join stu_inf on grade.xh = stu_inf.xh";
$result = mysql_query($query);
$num_result = mysql_num_rows($result);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>学生成绩管理系统</title>
</head>
<body background="pic/bg.gif">
<form name="form1" method="post">
<table width="767" height="324" border="0" align="center" style="background-color: #47c9af">
  <tr>
    <td height="228" colspan="7" background="images/study.jpg">    </td>
  </tr>
    <td height="28" background="pic/in_20.gif">学号 </td>
    <td background="pic/in_20.gif">姓名</td>
    <td background="pic/in_20.gif">班级</td>
    <td background="pic/in_20.gif">性别</td>
    <td background="pic/in_20.gif">科目</td>
    <td background="pic/in_20.gif">成绩</td>
  </tr><?php for($i = 0; $i < $num_result; $i++)
  {
  $row = mysql_fetch_assoc($result);
  ?>
  <tr> 
    <td background="pic/in_20.gif"><?php echo stripslashes($row['xh']);?></td>
    <td background="pic/in_20.gif"><?php echo stripslashes($row['xm']);?></td>
    <td background="pic/in_20.gif"><?php echo stripslashes($row['class']);?></td>
    <td background="pic/in_20.gif"><?php echo stripslashes($row['sex']);?></td>
    <td background="pic/in_20.gif"><?php echo stripslashes($row['km']); ?></td>
    <td background="pic/in_20.gif"><?php echo stripslashes($row['cj']); ?></td>
  </tr>
  <?php
  }
//   $result->free();
//   $db->close();
  ?>
</table>
</form>
</body>
</html>
