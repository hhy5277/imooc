<!doctype>
<html>
  <head>
     <meta charset="utf-8">
     <title>用户登录</title>
     <script type="text/javascript" src="./js/log.js"></script>
  </head>
<?php
@session_start();
require_once 'db.php';  //引入相关文件
@$user=$_POST['user'];
@$password=$_POST['password'];
$query = "select * from register where user='$user' and password='$password'"; //对比输入的数据和数据库里的数据
$res=mysql_query($query);
@$row=mysql_fetch_array($res);
    if(isset($_POST['submit'])){
	if($_POST['user']=$row['user'] and $_POST['password']=$row['password']){
		$_SESSION['user']=$user;
		$_SESSION['id']=@$result['id'];
		echo $user,'欢迎你！进入<a href="admin.php">个人中心</a><br/>';
		echo '点击此处<a href="login.php?action=logout">注销</a>';
        exit;
	}else{
		echo "<script>alert('要么是用户名错了，要么是密码错了，再检查一下呗！')</script>",mysql_error();
		echo "点击<a href='javascript:history.back(-1);'>返回上一步</a>重试";
	}
	die;
}
?>
<?php 
 if(@$_GET['action']=='logout'){
      unset($_SESSION['id']);
      unset($_SESSION['user']);
      echo '注销成功，点击此处<a href="login.php">重新登陆</a>';
      exit;
  }
?>
<body>
  <form ation="" method="post" name="login" onsubmit="return log()">
    用户名:<input type="user" name="user"><br/><br/>
    密    码:<input type="password" name="password"><br/><br/>
    <input type="submit" name="submit" value="登录">
  </form>
</body>
</html>

