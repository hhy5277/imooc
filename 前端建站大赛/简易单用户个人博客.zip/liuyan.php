<?php 
include_once 'db.php';
require_once'./inc/header.php'; 
?>
<?php

if(isset($_POST['submit'])){
    if($_POST['tc']=='田超'){
	$query = "insert into `liuyan` (`id`,`name`,`content`,`time`) values (NULL,'".$_POST['name']."','".$_POST['content']."',now())";
	if(mysql_query($query)){
        echo "恭喜你，留言成功啦！";
        include_once './js/tz.js';
	}else{
		echo '抱歉啊，失败了，再试试吧？',mysql_error();
	}
	die;
    }else{
      echo "您未通过验证！";
    }
}

?>
<!DOCTYPE>
<html>
<head>
  <title>留言板-田超的博客|原创独立个人博客</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="./css/style.css" rel="stylesheet" type="text/css">
  <script type="text/javascript" src="./js/ly.js"></script>
    <form action=""  method="post" name="lyb" onsubmit="return ly()" >
	<div class="add_k" style="margin-top:10px;">
        称呼：<input type="text" name="name" size="20"><br/><br/>
        内容：<textarea name="content" rows="10" cols="120" placeholder="不超过200个字"></textarea><br/><br/>
        验证：<input type="text" name="tc" size="12"placeholder="答案是两个字！"><span style="font-size:10px;color:#ccc;">（这是谁的博客？）</span><br/><br/>
	<input type="submit" name="submit" value="好了，发布吧">
	</div>
</form>
<?php
//设定每页显示的文章数
$pagesize=7;
//确定页数P的参数
@$p=$_GET['p']?$_GET['p']:1;
//数据指针
$offset=($p-1)*$pagesize;
//查询本页显示的数据
$query = "select * from `liuyan` order by id DESC limit $offset,$pagesize";
$result = mysql_query($query);
while ($row = mysql_fetch_array($result)){
	?>
<body>
	<div class="ly">
        <div class="ly_o"><div class="ly_t"><p style="font-size:14px;color:#c47b40" title="这是第<?php echo $row['id'] ?>条留言"><?php echo $row['name'] ?> 说：</p><span style="font-family: Arial, Helvetica, sans-serif; font-size: 14px;"><?php echo iconv_substr($row['content'],0,200,'utf-8');?></span></div><div class="ly_f"><?php echo $row['time'] ?></div></div>
	</div>
<?php
}
?>
    <div class="fy">  
<?php 
//计算留言总数
$count_result=mysql_query("select count(*) as count from liuyan");
$count_array=mysql_fetch_array($count_result);
//计算总页数
$pagenum=ceil($count_array['count']/$pagesize);

//输出各个页数和链接
if($pagenum>1){
    for($i=1;$i<=$pagenum;$i++){
        if($i==$p){
            echo '[',$i,']';
        }else{
            echo "&nbsp".'<a href="liuyan.php?p=',$i,'">',$i,'&nbsp</a>';
        }
    }
}
if($p>5){
echo '<a href="liuyan.php?p=',$pagenum,'">末页</a>'; 
}
echo "&nbsp".'共',$count_array['count'],'条留言';
?>
</div>

</body>
<?php require_once'./inc/footer.php'; ?>
</html> 