<?php
session_start();
if(!isset($_SESSION['user'])){
    header("location:login.php");
    exit;
}
include_once 'db.php';
$query = "delete from `arts` where `id`='".$_GET['del']."'";

if(mysql_query($query)){
	echo '<script>alert("删除成功");window.location.href="admin.php"</script>';
}else{
	echo '删除失败';
}
?>