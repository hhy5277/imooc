<?php
include_once'./inc/header.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>音乐-田超的博客|原创独立个人博客</title>
</head>
<body>
    <div style="width:990px;margin:0 auto;text-align:center"><iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=520 height=520 src="http://music.163.com/outchain/player?type=0&id=101789921&auto=1&height=430"></iframe></div>
</body>
</html>
<?php
include_once'./inc/footer.php';
?>

