-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2015 年 12 月 30 日 07:18
-- 服务器版本: 5.6.12-log
-- PHP 版本: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `blog`
--
CREATE DATABASE IF NOT EXISTS `blog` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `blog`;

-- --------------------------------------------------------

--
-- 表的结构 `arts`
--

CREATE TABLE IF NOT EXISTS `arts` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `time` date NOT NULL,
  `content` text NOT NULL,
  `hits` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `arts`
--

INSERT INTO `arts` (`id`, `title`, `time`, `content`, `hits`) VALUES
(1, 'æµ‹è¯•æ ‡é¢˜', '2015-12-24', 'æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹', 0),
(2, 'æµ‹è¯•', '2015-12-25', 'æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹æµ‹è¯•å†…å®¹', 0),
(3, 'é›ªèŠ±ç¥¨å‘€', '2015-12-25', 'é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€é›ªèŠ±ç¥¨å‘€', 3);

-- --------------------------------------------------------

--
-- 表的结构 `liuyan`
--

CREATE TABLE IF NOT EXISTS `liuyan` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `content` text NOT NULL,
  `time` date NOT NULL,
  `reply` text,
  `replytime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- 转存表中的数据 `liuyan`
--

INSERT INTO `liuyan` (`id`, `name`, `content`, `time`, `reply`, `replytime`) VALUES
(1, 'ç”°è¶…', 'æµ‹è¯•ç•™è¨€æ¿', '2015-12-24', NULL, NULL),
(2, 'ç”°è¶…', 'æµ‹è¯•ç•™è¨€æ¿', '2015-12-24', NULL, NULL),
(3, 'ç”°è¶…', 'æµ‹è¯•ç•™è¨€æ¿', '2015-12-24', NULL, NULL),
(4, 'ç”°è¶…', 'æµ‹è¯•ç•™è¨€æ¿', '2015-12-24', NULL, NULL),
(5, 'ç”°è¶…', 'æµ‹è¯•ç•™è¨€æ¿', '2015-12-24', NULL, NULL),
(6, 'ç”°è¶…', 'ç”°è¶…', '2015-12-24', NULL, NULL),
(7, 'ç”°è¶…', 'ç”°è¶…', '2015-12-24', NULL, NULL),
(8, 'ç”°è¶…', 'ç”°è¶…', '2015-12-24', NULL, NULL),
(9, 'ç”°è¶…', 'ç”°è¶…', '2015-12-24', NULL, NULL),
(10, 'ç”°è¶…', 'ç”°è¶…', '2015-12-24', NULL, NULL),
(11, 'ç”°è¶…', 'ç”°è¶…', '2015-12-24', NULL, NULL),
(12, 'ç”°è¶…', 'ç”°è¶…', '2015-12-24', NULL, NULL),
(13, 'ç”°è¶…', 'ç”°è¶…', '2015-12-24', NULL, NULL),
(14, 'ç”°è¶…', 'ç”°è¶…', '2015-12-24', NULL, NULL),
(15, 'ç”°è¶…', 'ç”°è¶…', '2015-12-24', NULL, NULL),
(16, 'ç”°è¶…', 'ç”°è¶…', '2015-12-24', NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `me`
--

CREATE TABLE IF NOT EXISTS `me` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` int(4) NOT NULL,
  `age` varchar(10) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `qq` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `weibo` int(50) NOT NULL,
  `blog` varchar(50) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `user` varchar(8) NOT NULL,
  `password` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `register`
--

INSERT INTO `register` (`id`, `user`, `password`) VALUES
(1, 'admin', 'admin1');

-- --------------------------------------------------------

--
-- 表的结构 `say`
--

CREATE TABLE IF NOT EXISTS `say` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `time` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `say`
--

INSERT INTO `say` (`id`, `content`, `time`) VALUES
(1, 'æµ‹è¯•è¯´è¯´!', '2015-12-24'),
(2, 'æµ‹è¯•è¯´è¯´2', '2015-12-30'),
(3, 'æµ‹è¯•è¯´è¯´3', '2015-12-30');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
