<?php
//引入文件
  require_once 'db.php';
  include_once'./inc/header.php';
  ?>
<?php include_once'./inc/header.php'?>
<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<title>归档—田超的博客|原创独立个人博客</title>
        <link rel="stylesheet" type="text/css" href="css/pb.css" />
        <script id="jquery_183" type="text/javascript" class="library" src="js/jquery-1.6.2.min.js"></script>
        <script type="text/javascript" class="library" src="js/pb.js"></script>
        <meta property="wb:webmaster" content="0fb690f3664a39de" />
	</head>
	<body>   
    <div id="wrapper">
  <div class="brand-list">
    <div class="brand-bd cle" id="brand-waterfall">        
<?php
$query = "select * from `arts` order by id DESC";
$result = mysql_query($query);
while ($row = mysql_fetch_array($result)){
	?>
        <div class="item" id="brand-a">
            <h3><a href="view.php?id=<?php echo $row['id']?>" target="_blank"><?php echo $row['title']?></a></h3>
            <!-- <p><?php echo iconv_substr($row['content'],0,100,'utf-8');?>……</p> -->
        </div>
<?php
}
?>
</div>
  </div>
</div>
<?php include_once'./inc/footer.php'?>

