<?php
//发布文章检测用户是否是登录的
session_start();
if(!isset($_SESSION['user'])){
    header("location:login.php");
    exit;
}
include_once './db.php';
 if(isset($_POST['submit'])){
	 $query = "insert into `say` (`id`,`content`,`time`) values (NULL,'".$_POST['content']."',now())";
	 if(mysql_query($query)){
		  echo '<script>alert("恭喜你，发布成功！");window.location.href="./admin.php"</script>';
		 }else{
			   echo '抱歉啊，失败了，再试试吧？',mysql_error();
			 }
			 die;
	 }
?>
<!DOCTYPE>
<html>
<head>
<title>发布文章-田超的博客</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    </head>    
<body>
 <form action="" method="post">
  <textarea name="content" rows="10" cols="120" placeholder="说说"></textarea><br/><br/>
  <input type="submit" name="submit" value="好了，发布吧">
 </form>
</body>
</html>    