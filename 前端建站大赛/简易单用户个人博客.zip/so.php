<!doctype html>
<head>
  <title>站内搜索—田超的博客|原创独立个人博客</title>
  <meta charset="utf-8">
  <link type="text/css" href="css/style.css" rel=stylesheet>
</head>
<body>
<?php include_once './inc/header.php'; ?>
  <form action="" method="GET" style="text-align:center;margin-bottom:10px;">
   <p>搜索关键字</p>
    <input type="text" name="search" placeholder="文章标题" style="width:450px;height:30px;">
    <button type="submit" name="submit" value="搜索" style="width: 100px;height:36px;">搜索</button>
  </form>
</body>
  <?php 
    include_once'db.php';
    if(isset($_GET['submit'])){
        //获取搜索关键字
        $search=trim($_GET["search"]);
        //检查是否为空
        if($search==""){
            echo "您要搜索的关键字不能为空".'<br/>';
            echo "点击<a href='javascript:history.back(-1);'>返回上一步</a>重搜";
            exit;//结束程序
        }
        if($search=="0"){
			echo "对不起，搜不到数据……".'<br/>';
			echo "点击<a href='javascript:history.back(-1);'>返回上一步</a>重搜";
            exit;//结束程序
			}
        //查询数据库内容
        $so="select * from `arts` where `title` like '%".$_GET['search']."%'";
        $rel=mysql_query($so);
    }
    //输出循环
        while (($row=@mysql_fetch_array($rel))!=false){
?>
<div class="nav_new">
  <ul>
    <li><a href="view.php?id=<?php echo $row['id']?>" target="_blank"><?php echo $row['title']?></a><br/></li>
  </ul>  
</div>
<?php
 }
?>
