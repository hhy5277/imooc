<?php
//引入文件
  require_once 'db.php';
  include_once'./inc/header.php';
  ?>
<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<title>首页-田超的博客|原创独立个人博客</title>
        <link href="css/timeline.css" rel="stylesheet" type="text/css" />
        <script src="js/modernizr.js"></script>
        <script src="js/jquery-1.8.3.min.js"></script>
	</head>
	<body>
<section id="cd-timeline" class="cd-container">
<?php
//设定每页显示的文章数
$pagesize=7;
//确定页数P的参数
@$p=$_GET['p']?$_GET['p']:1;
//数据指针
$offset=($p-1)*$pagesize;
//查询本页显示的数据
$query = "select * from `arts` order by id DESC limit $offset,$pagesize";
$result = mysql_query($query);
while ($row = mysql_fetch_array($result)){
	?>


		<div class="cd-timeline-block">
			<div class="cd-timeline-img cd-picture">
				<img src="images/cd-icon-picture.svg" alt="Picture">
			</div><!-- cd-timeline-img -->

			<div class="cd-timeline-content">
				<h2><a href="view.php?id=<?php echo $row['id']?>" target="_blank"><?php echo $row['title']?></a></h2>
                <p><?php echo iconv_substr($row['content'],0,140,'utf-8');?>……</p><br/>
				<a href="view.php?id=<?php echo $row['id']?>" target="_blank" class="cd-read-more">阅读更多</a>
				<span class="cd-date"><?php echo $row['time'] ?></span>
			</div> <!-- cd-timeline-content -->
		</div> <!-- cd-timeline-block -->

<?php
}
?>
    <div class="fy">  
<?php 
//计算文章总数
$count_result=mysql_query("select count(*) as count from arts");
$count_array=mysql_fetch_array($count_result);
//计算总页数
$pagenum=ceil($count_array['count']/$pagesize);

//输出各个页数和链接
if($pagenum>1){
    for($i=1;$i<=$pagenum;$i++){
        if($i==$p){
            echo '[',$i,']';
        }else{
            echo "&nbsp".'<a href="?p=',$i,'">',$i,'&nbsp</a>';
        }
    }
}
if($p>5){
echo '<a href="?p=',$pagenum,'">末页</a>'; 
}
echo "&nbsp".'共',$count_array['count'],'篇文章';
?>
</div>
        
         <!-- cd-timeline-block --><!-- cd-timeline-block --><!-- cd-timeline-block --><!-- cd-timeline-block --><!-- cd-timeline-block -->
	</section> <!-- cd-timeline -->
    <script>
$(function(){
	var $timeline_block = $('.cd-timeline-block');
	//hide timeline blocks which are outside the viewport
	$timeline_block.each(function(){
		if($(this).offset().top > $(window).scrollTop()+$(window).height()*0.75) {
			$(this).find('.cd-timeline-img, .cd-timeline-content').addClass('is-hidden');
		}
	});
	//on scolling, show/animate timeline blocks when enter the viewport
	$(window).on('scroll', function(){
		$timeline_block.each(function(){
			if( $(this).offset().top <= $(window).scrollTop()+$(window).height()*0.75 && $(this).find('.cd-timeline-img').hasClass('is-hidden') ) {
				$(this).find('.cd-timeline-img, .cd-timeline-content').removeClass('is-hidden').addClass('bounce-in');
			}
		});
	});
});
</script>
	</body>
</html>
<?php include_once'./inc/footer.php'?>

