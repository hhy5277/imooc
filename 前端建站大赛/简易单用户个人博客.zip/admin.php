<?php
session_start();
if(!isset($_SESSION['user'])){
    header("location:login.php");
    exit;
}
include_once './inc/header.php'; 
include_once './db.php';
//设定每页显示的文章数
$pagesize=7;
//确定页数P的参数
@$p=$_GET['p']?$_GET['p']:1;
//数据指针
$offset=($p-1)*$pagesize;
//查询本页显示的数据
$query = "select * from `arts` order by id DESC limit $offset,$pagesize";
$result = mysql_query($query);
while ($row = mysql_fetch_array($result)){
	?>
<body>	
	<div class="ad_kuang">
        <div class="ad_kuang_one"><a href="view.php?id=<?php echo $row['id']?>" target="_blank"><?php echo $row['title']?></a> | 
            <a href="edit.php?edit=<?php echo $row['id']?>">编辑</a> | <a href="del.php?del=<?php echo $row['id']?>">删除</a> | <a href="javascript:;">点击量：<?php echo $row['hits']?></a>
            | <?php echo $row['time']?></div>
	<div class="ad_kuang_two"><?php echo iconv_substr($row['content'],0,70,'utf-8');?>...</div>
	</div>
</body>	
<?php
}
?>
    <div class="fy">  
<?php 
//计算留言总数
$count_result=mysql_query("select count(*) as count from arts");
$count_array=mysql_fetch_array($count_result);
//计算总页数
$pagenum=ceil($count_array['count']/$pagesize);

//输出各个页数和链接
if($pagenum>1){
    for($i=1;$i<=$pagenum;$i++){
        if($i==$p){
            echo '[',$i,']';
        }else{
            echo "&nbsp".'<a href="admin.php?p=',$i,'">',$i,'&nbsp</a>';
        }
    }
}
if($p>5){
echo '<a href="liuyan.php?p=',$pagenum,'">末页</a>'; 
}
echo "&nbsp".'共',$count_array['count'],'条文章';
?>
</div>
<div class="admin_zl">
<?php echo '<a href="add_talk.php">发布说说</a>'; ?> | <?php echo '<a href="add_artcle.php">发布文章</a>'; ?><br/><br/>
<?php 
   @session_start();
  if(!isset($_SESSION['user'])){
      header("location: login.php");
      exit;
  }
  $id=$_SESSION['id'];
  $user=$_SESSION['user'];
  $user_query=mysql_query("select * from registe where id=$id limit 1");
  @$row=mysql_fetch_array($user_query);
  //echo '用户ID：',$id,'<br/>';
echo '您好，',$user,'&nbsp;&nbsp;&nbsp;';
  echo '<a href="login.php?action=logout">注销</a>';
  exit;
?>
</div>

