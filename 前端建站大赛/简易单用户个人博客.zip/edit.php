<?php
session_start();
if(!isset($_SESSION['user'])){
    header("location:login.php");
    exit;
}
include_once 'db.php';
$id = $_GET['edit'];
$query = "select * from `arts` where `id`='$id' limit 1";
$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
if(isset($_POST['submit'])){
	$query = "update `arts` set `title`='".$_POST['title']."',`content`='".$_POST['content']."',`time`=now() where `id`='$id' limit 1";
	$result = mysql_query($query);
	if($result){
		echo '<script>alert("编辑成功");window.location.href="index.php"</script>';
	}
}
?>
<?php include_once'./inc/header.php'?>
<!DOCTYPE>
<html>
<head>
<title>编辑文章</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script type="text/javascript" src="./js/jquery-1.4.4.min.js"></script>
<script type="text/javascript" src="./js/xheditor-1.2.1.min.js"></script>
<script type="text/javascript" charset="utf-8" src="./js/xheditor_lang/zh-cn.js"></script>
<link href="./css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<form action="" method="post">
	<table align="center">
		<tr>
			<td>标题：<input type="text" name="title" size="30" value="<?php echo $row['title'];?>"></td>
		</tr>
		<tr>
			<td>内容：<textarea name="content" class="xheditor" rows="30" cols="120"><?php echo $row['content'];?></textarea></td>
		</tr>
		<tr>
			<td><input type="submit" name="submit" value="发表"></td>
		</tr>
	</table>
</form>
</body>
</html>
<?php require_once'./inc/footer.php'?>