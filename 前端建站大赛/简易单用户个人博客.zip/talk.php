<?php
//引入文件
  require_once 'db.php';
  include_once'./inc/header.php';
  ?>
<!DOCTYPE>
<html>
<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>闲言碎语—田超的博客|原创独立个人博客</title>
		<link rel="stylesheet" type="text/css" href="css/default.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<script src="js/modernizr.custom.js"></script>   
</head>

<body>
    
		<div class="container">
			<div class="main">
                <?php 
//设定每页显示的文章数
$pagesize=7;
//确定页数P的参数
@$p=$_GET['p']?$_GET['p']:1;
//数据指针
$offset = ($p-1)*$pagesize;
//查询本页显示的数据
  $query = "select * from `say` order by id DESC limit $offset,$pagesize";  //查询数据
  $res=mysql_query($query);
  while ($row=mysql_fetch_array($res)){ //循环开始
?>
				<ul class="cbp_tmtimeline">
				<li>
						<time class="cbp_tmtime" datetime="2013-04-10 18:30"><span>
						<?php echo $row['id']?></span></time>
						<div class="cbp_tmicon cbp_tmicon-phone"></div>
						<div class="cbp_tmlabel">
							<h4><a><?php echo $row['time']?></a></h4>
							<p><?php echo iconv_substr($row['content'],0,200,'utf-8');?></p>
						</div>
					</li>	
				</ul>
<?php 
  }
?> 
		</div>
		</div>
        <div class="fy">  
<?php 
//计算留言总数
$count_result=mysql_query("select count(*) as count from say");
$count_array=mysql_fetch_array($count_result);
//计算总页数
$pagenum=ceil($count_array['count']/$pagesize);

//输出各个页数和链接
if($pagenum>1){
    for($i=1;$i<=$pagenum;$i++){
        if($i==$p){
            echo '[',$i,']';
        }else{
            echo "&nbsp".'<a href="talk.php?p=',$i,'">',$i,'&nbsp</a>';
        }
    }
}
if($p>5){
echo '<a href="talk.php?p=',$pagenum,'">末页</a>'; 
}
echo "&nbsp".'共',$count_array['count'],'条说说';
?>
</div>
</body>
</html>
<?php include_once'./inc/footer.php'?>