<?php
include_once '../db.php';
$id = $_GET['id'];
$query = "select * from `arts` where `id`='$id' limit 1";
$result = mysql_query($query);
$row = mysql_fetch_array($result);
$query = "update `arts` set `hits`=hits+1 where `id`='$id'";
$result = mysql_query($query);
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta name="viewport" content="width=device-width, initial-scale=0.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<meta content="yes" name="apple-mobile-web-app-capable">
<meta content="black" name="apple-mobile-web-app-status-bar-style">
<meta content="telephone=no" name="format-detection">
<script>
var logined = 0
</script>
<title><?php echo $row['title'] ?></title>
</head>

<body>
		<div id="menu">
		<div class="search_wrap">
			<form action="" method="get">
				<input type="text" name="search" class="search_input" placeholder="关键字查找" />
				<i class="reset_input"><i></i></i>
			</form>
		</div>
		<ul>
			<li class="nav_index"><a href="index.php"><i></i><span>首页</span><b></b><div class="clear"></div></a></li>
			<li class="nav_site"><a href="talk.html"><i></i><span>说说</span><b></b><div class="clear"></div></a></li>
			<li class="nav_help"><a href="liuyan.html"><i></i><span>留言板</span><b></b><div class="clear"></div></a></li>
			<li class="nav_about"><a href="about.html"><i></i><span>关于博客</span><b></b><div class="clear"></div></a></li>
		</ul>
	</div>
	<div id="header" class="head">
		<div class="wrap">
			<i class="menu_back"><a href="index.php"></a></i>
			<div class="title">
				<span class="title_d"><p><?php echo $row['title'] ?></p></span>
				<div class="clear"></div>
			</div>
			<i class="menu_share"></i>
		</div>
	</div>
	
	<div id="container">
		<div id="content">
						<div style="height:1px"></div>
						
			<div id="works">
				<div class="pd5">
				
					<div class="list_info_i" style="margin-top:5px;">
						<dl class="list_info_views">
							<dt></dt>
							<dd><?php echo $row['hits']?></dd>
							<div class="clear"></div>
						</dl>
						<dl class="works_view">
							<dt></dt>
							<dd><?php echo $row['time']?></dd>
							<div class="clear"></div>
						</dl>
						<div class="clear"></div>
					</div>

										
										<div class="clear"></div>
											<div class="article_ct">
                                                <p><?php echo $row['content']?></p>
						</div>
						<div class="clear"></div>
										
				</div>
			</div>
		</div>

	</div>
	<div id="us_panel_menu">
		<div class="us_panel_msk"></div>
		<div class="us_panel_menu_t">
			<table width="100%" cellspacing="0">
				<tr>
					<td valign="top" class="us_panel_menu_index">
						<a href="index.php"><i></i><span>首页</span></a>
					</td>
					<td valign="top" class="us_panel_menu_designer">
						<a href="talk.php"><i></i><span>说说</span></a>
					</td>
					<td valign="top" class="us_panel_menu_help">
						<a href="liuyan.php"><i></i><span>留言板</span></a>
					</td>
					<td valign="top" class="us_panel_menu_about">
						<a href="about.html"><i></i><span>关于博客</span></a>
					</td>
				</tr>
			</table>
		</div>
	</div>
	<div id="share">
		<div class="share_msk"></div>
		<div class="share">
			<table width="100%" cellspacing="10" border="0">
				<tr>
					<td class="sina"><a href="http://service.weibo.com/share/share.php?url=http://www.tianchaoc.sinaapp.com/view.php?id=<?php echo $row['id']?>&title=<?php echo iconv_substr($row['content'],0,100,'utf-8');?>&appkey=3206975293" target="_blank"></a></td>
				</tr>
			</table>
			<div class="pd10">
				<div class="cancel_share"><a href="" onclick="return false;">取消分享</a></div>
			</div>
		</div>
	</div>
	<script language="javascript" src="js/zepto.min.js"></script>
	<script language="javascript" src="js/fx.js"></script>
	<script language="javascript" src="js/script.js"></script>

</body>
</html>