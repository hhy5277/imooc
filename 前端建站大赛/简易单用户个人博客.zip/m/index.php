<!doctype html>
<?php
require_once '../db.php';
?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta name="viewport" content="width=device-width, initial-scale=0.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
<meta name="keywords" content="田超个人博客，田超的个人博客|原创独立个人博客|一个80后,喜欢文字和音乐的码农，分享生活里的那些事，可以在这里找到我的最新的心情，随笔，小说，以及一切我想写的东西。" />
<meta name="description" content="田超的博客">
<meta name="author" content="田超" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<meta content="yes" name="apple-mobile-web-app-capable">
<meta content="black" name="apple-mobile-web-app-status-bar-style">
<meta content="telephone=no" name="format-detection">
<link rel="apple-touch-icon-precomposed">
<script>
var logined = 0
</script>
<title>田超的博客——手机版</title>
</head>

<body>
<script>
var now_page = 1,
search_value = '';
</script>

		<div id="menu">
		<div class="search_wrap">
			<form action="" method="get">
				<input type="text" name="search" class="search_input" placeholder="暂未开发！" />
				<i class="reset_input"><i></i></i>
			</form>
		</div>
		<ul>
			<li class="nav_index menu_cur"><a href="index.php"><i></i><span>首页</span><b></b><div class="clear"></div></a></li>
			<li class="nav_site"><a href="talk.php"><i></i><span>说说</span><b></b><div class="clear"></div></a></li>
			<li class="nav_help"><a href="liuyan.php"><i></i><span>留言板</span><b></b><div class="clear"></div></a></li>
			<li class="nav_about"><a href="about.html"><i></i><span>关于博客</span><b></b><div class="clear"></div></a></li>
		</ul>
	</div>
		<div id="user">
					<div class="account">
				<div class="login_b_t">	
                    <h2>关于我</h2>
				</div>
			</div>
			<div class="pd10">
                <div class="vivw_right"><img src="images/1.jpg"><br/><br/><br/>
						微博：<a href="http://weibo.com/724434512" target="_blank">@田超7C</a><br/><br/><br/>
						梦想：<a href="http://site.douban.com/tianchao/" target="_blank">豆瓣音乐人</a><br/><br/><br/>
				</div>
			</div>
			</div>	
	<div id="header">
		<div class="wrap">
			<i class="menu_open"></i>
			<div class="logo"><a href="#" title="田超的博客"><img src="css/logo.png" /></a></div>
			<i class="search_open"></i>
		</div>
		<div class="logo_msk"></div>
	</div>
	<div id="container">
		<div id="content">	
			<div id="list">
				<ul>
				<?php
$query = "select * from `arts` order by id DESC";
$result = mysql_query($query);
while ($row = mysql_fetch_array($result)){
	?>
    	<li>
						<div class="wrap">
							<a class="alist" href="view.php?id=<?php echo $row['id']?>">
								<div class="list_litpic fl"><img src="images/img.jpg" /></div>
								<div class="list_info">
									<h4><?php echo $row['title']?></h4>
									<h5>by<span>田超</span><em><?php echo $row['time'] ?></em></h5>
									<div class="list_info_i">
										<dl class="list_info_views">
											<dt></dt>
											<dd><?php echo $row['hits'] ?></dd>
											<div class="clear"></div>
										</dl>
										<div class="clear"></div>
									</div>
								</div>
								<div class="clear"></div>
							</a>
						</div>
					</li>
<?php
}
?>             
									</ul>
				<div class="list_loading"><i></i><span>努力加载中...</span></div>
			</div>
		</div>
	</div>
	<div class="loading_dark"></div>
	<script language="javascript" src="js/zepto.min.js"></script>
	<script language="javascript" src="js/fx.js"></script>
	<script language="javascript" src="js/script.js"></script>
</body>
</html>