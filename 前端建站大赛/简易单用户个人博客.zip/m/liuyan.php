<?php 
include_once '../db.php';
?>
<?php

if(isset($_POST['submit'])){
    if($_POST['tc']=='田超'){
	$query = "insert into `liuyan` (`id`,`name`,`content`,`time`) values (NULL,'".$_POST['name']."','".$_POST['content']."',now())";
	if(mysql_query($query)){
        echo "chenggong！";
	}else{
		echo '抱歉啊，失败了，再试试吧？',mysql_error();
	}
	die;
    }else{
      echo "您未通过验证！";
    }
}
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta name="viewport" content="width=device-width, initial-scale=0.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<meta content="yes" name="apple-mobile-web-app-capable">
<meta content="black" name="apple-mobile-web-app-status-bar-style">
<meta content="telephone=no" name="format-detection">
<script>
var logined = 0
</script>
<title>留言板</title>
</head>

<body>
		<div id="menu">
		<div class="search_wrap">
			<form action="" method="get">
				<input type="text" name="search" class="search_input" placeholder="关键字查找" />
				<i class="reset_input"><i></i></i>
			</form>
		</div>
		<ul>
			<li class="nav_index"><a href="index.php"><i></i><span>首页</span><b></b><div class="clear"></div></a></li>
			<li class="nav_site"><a href="talk.html"><i></i><span>说说</span><b></b><div class="clear"></div></a></li>
			<li class="nav_help"><a href="liuyan.html"><i></i><span>留言板</span><b></b><div class="clear"></div></a></li>
			<li class="nav_about"><a href="about.html"><i></i><span>关于博客</span><b></b><div class="clear"></div></a></li>
		</ul>
	</div>
	<div id="header" class="head">
		<div class="wrap">
			<i class="menu_back"><a href="index.php"></a></i>
			<div class="title">
				<span class="title_d"><p>留言板</p></span>
				<div class="clear"></div>
			</div>
			<i class="menu_share"></i>
		</div>
	</div>
	
	<div id="container">
		<div id="content">
		 <form action=""  method="post" name="lyb">
	<div class="add_k" style="margin-top:50px;">
        称呼：<input type="text" name="name" size="20"><br/><br/>
        内容：<textarea name="content" rows="8" cols="50" placeholder="不超过200个字"></textarea><br/><br/>
        验证：<input type="text" name="tc" size="12"placeholder="答案是两个字！"><span style="font-size:10px;color:#ccc;">（这是谁的博客？）</span><br/><br/>
	<input type="submit" name="submit" value="好了，发布吧">
	</div>
</form>
		</div>
	</div>
	<div id="us_panel_menu">
		<div class="us_panel_msk"></div>
		<div class="us_panel_menu_t">
			<table width="100%" cellspacing="0">
				<tr>
					<td valign="top" class="us_panel_menu_index">
						<a href="index.php"><i></i><span>首页</span></a>
					</td>
					<td valign="top" class="us_panel_menu_designer">
						<a href="talk.php"><i></i><span>说说</span></a>
					</td>
					<td valign="top" class="us_panel_menu_help">
						<a href="liuyan.php"><i></i><span>留言板</span></a>
					</td>
					<td valign="top" class="us_panel_menu_about">
						<a href="about.html"><i></i><span>关于博客</span></a>
					</td>
				</tr>
			</table>
		</div>
	</div>
	<script language="javascript" src="js/zepto.min.js"></script>
	<script language="javascript" src="js/fx.js"></script>
	<script language="javascript" src="js/script.js"></script>
</body>
</html>