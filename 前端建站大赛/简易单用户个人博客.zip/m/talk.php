<?php
//引入文件
  require_once '../db.php';
  ?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta name="viewport" content="width=device-width, initial-scale=0.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<meta content="yes" name="apple-mobile-web-app-capable">
<meta content="black" name="apple-mobile-web-app-status-bar-style">
<meta content="telephone=no" name="format-detection">
<script>
var logined = 0
</script>
<title>说说</title>
</head>

<body>
		<div id="menu">
		<div class="search_wrap">
			<form action="" method="get">
				<input type="text" name="search" class="search_input" placeholder="关键字查找" />
				<i class="reset_input"><i></i></i>
			</form>
		</div>
		<ul>
			<li class="nav_index"><a href="index.php"><i></i><span>首页</span><b></b><div class="clear"></div></a></li>
			<li class="nav_site"><a href="talk.html"><i></i><span>说说</span><b></b><div class="clear"></div></a></li>
			<li class="nav_help"><a href="liuyan.html"><i></i><span>留言板</span><b></b><div class="clear"></div></a></li>
			<li class="nav_about"><a href="about.html"><i></i><span>关于博客</span><b></b><div class="clear"></div></a></li>
		</ul>
	</div>
	<div id="header" class="head">
		<div class="wrap">
			<i class="menu_back"><a href="index.php"></a></i>
			<div class="title">
				<span class="title_d"><p>说说</p></span>
				<div class="clear"></div>
			</div>
			<i class="menu_share"></i>
		</div>
	</div>
	
	<div id="container">
		<div id="content">
<?php 
  $query = "select * from `say` order by id DESC";  //查询数据
  $res=mysql_query($query);
  while ($row=mysql_fetch_array($res)){ //循环开始
?>
		   <div class="say">
               <div class="say_tit"><p><?php echo $row['time']?></p></div>
		      <div class="say_cont"><?php echo iconv_substr($row['content'],0,200,'utf-8');?></div>
		   </div>
<?php 
  }
?> 
		</div>
	</div>

	<div id="us_panel_menu">
		<div class="us_panel_msk"></div>
		<div class="us_panel_menu_t">
			<table width="100%" cellspacing="0">
				<tr>
					<td valign="top" class="us_panel_menu_index">
						<a href="index.php"><i></i><span>首页</span></a>
					</td>
					<td valign="top" class="us_panel_menu_designer">
						<a href="talk.php"><i></i><span>说说</span></a>
					</td>
					<td valign="top" class="us_panel_menu_help">
						<a href="liuyan.php"><i></i><span>留言板</span></a>
					</td>
					<td valign="top" class="us_panel_menu_about">
						<a href="about.html"><i></i><span>关于博客</span></a>
					</td>
				</tr>
			</table>
		</div>
	</div>
	<script language="javascript" src="js/zepto.min.js"></script>
	<script language="javascript" src="js/fx.js"></script>
	<script language="javascript" src="js/script.js"></script>
</body>
</html>