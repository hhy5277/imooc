<?php
include_once 'db.php';
$id = $_GET['id'];
$query = "select * from `arts` where `id`='$id' limit 1";
$result = mysql_query($query);
$row = mysql_fetch_array($result);
$query = "update `arts` set `hits`=hits+1 where `id`='$id'";
$result = mysql_query($query);
?>
<!doctype>
<html>
    <head>
  <title><?php echo $row['title'] ?> —田超的博客|原创独立个人博客</title>
    <meta charset="utf-8">
</head>
<link href="./css/style.css" rel="stylesheet" type="text/css" />
    <?php include_once './inc/header.php'; ?>
<div class="vivw_k">

<div class="vivw_right"><img src="img/1.jpg">
V-XII-MMXI

微博小V：http://weibo.com/724434512

苟延残喘的梦想：http://site.douban.com/tianchao/

平时喜欢踢足球，

是个不入流的吉他手，

坚持原创的业余音乐人，

也是个喜欢写故事的老青年。
</div>
<div class="vivw_t"><h2><?php echo $row['title']?></h2>点击量：<?php echo $row['hits']?> | 时间：<?php echo $row['time']?> | <a href="index.php">返回首页</a></div>
<div class="vivw_con"><?php echo $row['content']?></div>
    <div class="vivw_con_fx"><div class="vivw_con_fx_one">分享到:</div><div class="vivw_con_fx_two"><div class="bdsharebuttonbox"><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博">新浪微博</a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信">微信</a><a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友">QQ好友</a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间">QQ空间</a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博">腾讯微博</a></div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"16"},"share":{"bdSize":16},"image":{"viewList":["tsina","weixin","sqq","qzone","tqq"],"viewText":"分享到：","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["tsina","weixin","sqq","qzone","tqq"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
    </div>
    </div>
<?php require_once'./inc/footer.php' ?>
