/**
 * 注册检测js 
 * powerd by tianchao
 * 2014-08-20
 */
function log(){
    if(login.user.value==""){
      alert("请问大侠尊姓大名？");
        login.user.focus;
        return false;
    }
    if(login.password.value==""){
       alert("大侠报下您的暗号呗~");
        login.password.focus;
        return false;
    
    }

}