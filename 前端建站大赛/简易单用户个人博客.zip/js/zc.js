function zc(){
	if(zhuce.user.value==""){
		alert("用户名不可以为空");
		zhuce.user.focus;
		return false;
	}
	if(zhuce.user.value.length>8){
	alert("用户名不能多于8个字符");
	zhuce.user.focus;
	return false;
	}
	if(zhuce.password.value==""){
		alert("密码不可为空");
		zhuce.password.focus;
		return false;
	}
	if(zhuce.password.value.length<6){
		alert("密码不能少于6个字符");
		zhuce.password.focus;
		return false;
	}
	if(zhuce.password.value!=zhuce.password1.value){
		alert("两次输入的密码不一致");
		zhuce.password.focus;
		return false;
	}
}