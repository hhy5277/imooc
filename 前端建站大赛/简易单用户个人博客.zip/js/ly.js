/*
*   liuyanban js
*   power by tianchao
*   2014-12-05
*/
function ly(){
       if(lyb.name.value==""){
   alert("报上姓名~~ ");
   lyb.content.focus();
   return false;
}
   if(lyb.content.value==""){
   alert("还没想好对我说什么？ ");
   lyb.content.focus();
   return false;
}
   if(lyb.content.value.length>200){
     alert("你太热情了，稍微克制一点吧！");
     lyb.content.focus();
     return false;

   }
}