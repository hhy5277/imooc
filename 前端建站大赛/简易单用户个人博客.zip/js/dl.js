<script type="text/javascript">
function jumurl(){
window.location.href = 'admin.php';
}
setTimeout(jumurl,1000);
</script>

