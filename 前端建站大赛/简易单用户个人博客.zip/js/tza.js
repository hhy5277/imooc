<script type="text/javascript">
function jumurl(){
window.location.href = 'index.php';
}
setTimeout(jumurl,3000);
</script>