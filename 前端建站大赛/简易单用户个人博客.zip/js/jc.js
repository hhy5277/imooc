function jc(){
	if(fbwz.title.value==""){
		alert("标题不可为空");
		fbwz.title.focus();
		return false;
	}
	if(fbwz.content.value.length<2){
		alert("内容不可少于2个字符");
		fbwz.content.focus();
		return false;
	}
}
