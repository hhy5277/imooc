<?php
$sit_link="localhost";
$user="root"; //数据库名称
$pw="";   //数据库密码
$sql="blog";
@$link=mysql_connect($sit_link,$user,$pw) or die ("数据库连接失败");
$blog=mysql_select_db($sql,$link) or die ("数据库连接失败");
mysql_query("SET NAME 'utf-8'");
?>

