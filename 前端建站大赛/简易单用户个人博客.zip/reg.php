<?php
  require_once'db.php';
  @$user=$_POST['user'];
  @$password=$_POST['password'];
  if(isset($_POST['submit'])){
  	$search = "select `user` from register where user='$user'";
  	$res=mysql_query($search);
  	if(mysql_num_rows($res)>0){
  	echo "<script>alert('用户名已经存在！')</script>";
  	}else {
    $query="insert into `register`(`id`,`user`,`password`) values (null,'".$_POST['user']."','".$_POST['password']."')";
  	if(mysql_query($query)){
  		echo '注册成功！', header("location: admin.php");
  	}else{
  		echo '失败，请重新尝试!',mysql_error();
  	}
  	die;
  }
  }
?>
<!doctype>
  <html>
    <head>
      <meta charset="utf-8">
      <title>新用户注册</title>
      <script type="text/javascript" src="./js/zc.js"></script>
    </head>
    <body>
      <form action="" method="POST" name="zhuce" onsubmit="return zc()">
        <table align="center">
          <tr>
            <td>
              用户名：
            </td>
            <td>
              <input type="text" name="user">
            </td>
          </tr>
          <tr>
          <td>
          密码：
          </td>
          <td>
            <input type="password" name="password">
          </td>
          </tr>
          <tr>
          <td>
        重复密码：
          </td>
          <td>
            <input type="password" name="password1">
          </td>
          </tr>
          <tr>
            <td>
              <input type="submit" name="submit" value="注册">
            </td>
            <td>
              <input type="reset" name="reset" value="重置">
            </td>
          </tr>
        </table>
      </form>
      已有账号？点击<a href="login.php" target="_blank">登录</a>吧！
    </body>
  </html>

