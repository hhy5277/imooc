<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>关于我-田超的博客|原创独立个人博客</title>
<link href="./css/style.css" rel="stylesheet" type="text/css">
<?php require_once'./inc/header.php'; ?>
</head>

<body>
<div class="about_con">
  <div class="about_left">
  <h2>About me</h2>
  平时喜欢踢足球，
    
  是个不入流的吉他手， 
  
  坚持原创的业余音乐人，
  
  也是喜欢写故事的老青年。
  
<h2>About my blog </h2>
我觉得会写程序是件很酷的事情，所以，我自己尝试着学习一些编程语言，

在这个博客已经接近衰败的时代，再做一个博客是件很愚蠢的事情，

但是，人生总应该去坚持做一些事情，是那种不在乎结果的坚持，

就像我对博客的喜欢，对音乐的热爱，

我不敢奢望未来能出本书，也不妄想去发唱片，

在心里存着这样一个想法吧，就像网络上很流行的一句话：

<b>“梦想还是要有的，万一实现了呢？”</b>

<h2>The End</h2>
我是个崇尚极简主义的人，写这个程序，希望让博客回归到它最初的本质，
      
就像它刚刚被发明出来一样！
      
      
我是田超，谢谢你来看我的博客。
</div>
  <div class="about_right"><img src="img/1.jpg">
      
V-XII-MMXI / X-XVI-MMXV

网名：田超7C | 爱在枫叶下

职业：Web前端学徒，PHP孵蛋阶段的程序员
      
Email：tianchao7c@sina.com

微博小V：<a href="http://weibo.com/724434512" target="_blank">http://weibo.com/724434512</a>

苟延残喘的梦想：<a href="http://site.douban.com/tianchao/" target="_blank">http://site.douban.com/tianchao/</a>

<iframe width="100%" height="550" class="share_self"  frameborder="0" scrolling="yes" src="http://widget.weibo.com/weiboshow/index.php?language=&width=0&height=550&fansRow=2&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=1&uid=2114765444&verifier=589dc79b&dpc=1"></iframe>
</div>
</div>
</body>
<?php require_once'./inc/footer.php'; ?> 
</html>

