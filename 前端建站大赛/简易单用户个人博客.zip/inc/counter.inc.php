<?php
function get_hitcount($counter_file){

 	$count=0; 
 	if(file_exists($counter_file)){
 		$fp=fopen($counter_file,"r");
 		$count=0+fgets($fp,20);
 		fclose($fp);
 	}
 	$count++;
 	$fp=fopen($counter_file,"w");
 	fputs($fp,$count);
 	fclose($fp);
 	return($count);
 }
?>