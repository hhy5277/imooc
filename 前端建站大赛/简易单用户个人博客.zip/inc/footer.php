<div class="foot">© 2014-2016 Power by  <a href="http://tianchaoc.sinaapp.com/about.php" target="_blank">田超</a> | V1.6.0</div>   
</html>

