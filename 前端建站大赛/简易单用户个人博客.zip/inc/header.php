<!DOCTYPE>
<html>
<head>
<meta charset="utf-8">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<meta name="generator" content="田超的个人博客" />
<meta name="keywords" content="田超，个人博客，田超的博客,PHP程序" />
<meta name="description" content="田超个人博客，田超的个人博客|原创独立个人博客|一个80后,喜欢文字和音乐的码农，分享生活里的那些事，可以在这里找到我的最新的心情，随笔，小说，以及一切我想写的东西。" />  
    </head>
<body>
<div class="top">
<div class="head">
<a href="index.php"title="田超的博客"><div class="logo"></div></a>
<div class="banner"><a href="archive.php">归档</a> | <a href="so.php">搜索</a> </div>
<div class="nav">
    <ul id="menu" class="menu">
    <li><a href="./about.php" title="关于我">关于我</a></li>
    <li><a href="./liuyan.php" title="留言板">留言板</a></li>
    <li><a href="./music.php" title="留言板">音乐</a></li>    
    <li><a href="./talk.php" title="闲言碎语">闲言碎语</a></li>
        <li><a href="./index.php" title="首页">首页</a></li>
  </ul></div>
</div>
</div>

