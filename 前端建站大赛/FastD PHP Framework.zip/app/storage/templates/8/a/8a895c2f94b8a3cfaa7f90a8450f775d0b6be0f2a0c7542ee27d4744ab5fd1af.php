<?php

/* layout/layout.demo.twig */
class __TwigTemplate_8a895c2f94b8a3cfaa7f90a8450f775d0b6be0f2a0c7542ee27d4744ab5fd1af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <title>demo layout</title>
    <meta charset=\"UTF-8\"/>
</head>
<body>
";
        // line 8
        $this->displayBlock('content', $context, $blocks);
        // line 10
        echo "</body>
</html>";
    }

    // line 8
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layout/layout.demo.twig";
    }

    public function getDebugInfo()
    {
        return array (  36 => 8,  31 => 10,  29 => 8,  20 => 1,);
    }
}
