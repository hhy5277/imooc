<?php

/* layout/simple.twig */
class __TwigTemplate_4afdb245068d37dd06f2f4277815e6472e8c7ddf9faee5ae779d856a2580c77c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'css' => array($this, 'block_css'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>
    <meta charset=\"utf-8\">
    <title>JanHuang | Fast-D PHP Simple Framework</title>
    <meta name=\"keywords\" content=\"PHP simple and flexible develop framework.\" />
    <meta name=\"description\" content=\"PHP simple and flexible develop framework.\">
    <meta name=\"author\" content=\"JanHuang\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("s/css/bootstrap.min.css")), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("s/fonts/font-awesome/css/font-awesome.css")), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("s/css/highlight.min.css")), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("s/css/theme.css")), "html", null, true);
        echo "\">
    <link rel=\"shortcut icon\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("s/img/favicon.ico")), "html", null, true);
        echo "\">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
    <script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>
    <![endif]-->
    ";
        // line 23
        $this->displayBlock('css', $context, $blocks);
        // line 25
        echo "</head>

<body>

<!-- 导航 -->
<nav class=\"navbar navbar-default navbar-shrink navbar-shrink-scroll\">
    <div class=\"container\">
        <div class=\"navbar-header page-scroll\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand page-scroll\" style=\"display: block;\" href=\"http://www.fast-d.cn/\"><img src=\"";
        // line 39
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('asset')->getCallable(), array("s/img/logo.jpg")), "html", null, true);
        echo "\" style=\"height: 100%;\" alt=\"logo\"/></a>
        </div>

        <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
            <ul class=\"nav navbar-nav navbar-right\">
                <li class=\"\"><a href=\"http://www.fast-d.cn/documentation.html\">文档</a></li>
                <li class=\"\"><a href=\"http://www.fast-d.cn/articles.html\">博客</a></li>
                <li class=\"\"><a href=\"http://www.fast-d.cn/changelog.html\">更新记录</a></li>
                <li class=\"\"><a href=\"http://www.fast-d.cn/about.html\">关于</a></li>
                <li>
                    <a class=\"page-scroll\" target=\"_blank\" href=\"https://github.com/JanHuang/fastD\"><i class=\"fa fa-github\" style=\"font-size: 20px;\"></i></a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- 内容 -->
";
        // line 56
        $this->displayBlock('content', $context, $blocks);
        // line 58
        echo "<!-- 底部 -->
<footer id=\"footer\">
    <div class=\"container mw1170\">
        <div class=\"row\">
            <div class=\"col-md-6 text-left\">
                <span class=\"copyright text-muted\">Copyright &copy; <b>2015</b> </span>
            </div>
            <div class=\"col-md-6 text-right\">
                <ul class=\"list-inline social-buttons\">
                    <li><a target=\"_blank\" href=\"https://github.com/JanHuang/fastD\"><i class=\"fa fa-github\"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<script src=\"/s/js/vendor/jquery.js\"></script>

<script src=\"/s/js/vendor/bootstrap.min.js\"></script>
<script src=\"/s/js/higtlight.min.js\"></script>
<script>
    \$(function () {
        if (!\$('pre').hasClass('hljs')) {
            \$('pre').addClass('hljs');
        }
        hljs.initHighlightingOnLoad();
    })
</script>
<script>
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement(\"script\");
        hm.src = \"//hm.baidu.com/hm.js?713f8e7b9448124119913cb86b1507e6\";
        var s = document.getElementsByTagName(\"script\")[0];
        s.parentNode.insertBefore(hm, s);
    })();
</script>

</body>
</html>
";
    }

    // line 23
    public function block_css($context, array $blocks = array())
    {
        // line 24
        echo "    ";
    }

    // line 56
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layout/simple.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 56,  147 => 24,  144 => 23,  100 => 58,  98 => 56,  78 => 39,  62 => 25,  60 => 23,  50 => 16,  46 => 15,  42 => 14,  38 => 13,  34 => 12,  21 => 1,);
    }
}
