<p>个人的ghost博客主题，代码放在<a href="https://git.oschina.net/maxwelll/mx-awesome" target="_blank" style="text-decoration: underline;">OSC</a>，欢迎访问<a href="http://vance.ren/" target="_blank">我的主站</a>（暂无内容）！</p>

