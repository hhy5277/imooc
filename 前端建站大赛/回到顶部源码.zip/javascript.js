                window.onload = function(){
                        var clientHeight = document.documentElement.clientHeight || document.body.clientHeight;
                        var btn = document.getElementById('btn');
                        var timer=null,isTop=true;

        		window.onscroll = function(){
                                //每次滚动时都要获取到当前滚动到什么地方了，根据所在的高度来做一些事。
                                var osTop = document.documentElement.scrollTop||document.body.scrollTop;
                                //console.log(osTop);
                                if (osTop>=clientHeight) {
                                        btn.style.display = "block";
                                }else{
                                        btn.style.display = "none";
                                }

        			if (!isTop) {        //!isTop 就是否，当isTop等于true的时候就清除定时器
        				clearInterval(timer);
        			}
        			isTop = false;
                                //流程是这样的
                                //用户点击 触发btn.onclick
                                //产生timer定时器30ms一次执行（isTop=true）
                                //边栏开始滚动，一滚动会触发window.scroll
                                //在window.scroll函数中 !isTop = false;不清除定时器；但是isTop=false;
                                //也就是说下一次触发window.scroll函数，isTop=false，!isTop=false,就会清除定时器。
                                //这个时候会停顿30ms再去执行定时器里面的函数，肉眼是感觉不到的。
                                //也就是说在这30ms内，用户一滚动就会触发window.scroll函数。
                                //就清除了定时器，就不动了。
                                //假如在这30ms之内，你没有去滚动鼠标滚轮，那么在定时器的匿名函数里面、
                                //就会给isTop=true,那么就在window.scroll函数里面又不会清除，定时器了。
        		}

        		btn.onclick = function(){
                                //每次点击都要获取，从你点击时刻起的滚动条高度，开始递减。
                                var osTop = document.documentElement.scrollTop||document.body.scrollTop;
        			timer = setInterval(function(){
        				var speed = Math.floor(-osTop / 6); //floor是先下取整，假如是负数就是向上取整，负的越多就越小。
                                        osTop += speed; //每次减去长度的六分之一。
                                        //这个一定要加上，不能一起合成下面那一句。
        				document.documentElement.scrollTop = document.body.scrollTop = osTop;

                                        // document.documentElement.scrollTop = document.body.scrollTop = osTop + speed;
                                        // 假如是用的这一句，你会发现osTop一直没变，因为减去后并没有赋给自己
        					console.log(speed);
        					isTop=true;
        					if (osTop==0) {
        						clearInterval(timer);
        					}
        			},30);
        		}
        	}