var SCREEN_WIDTH=1024;//画布的宽、高
var SCREEN_HEIGHT=800;

var RADIUS=8;//小圆点的半径

var MARGIN_TOP=50;//距离画布顶部、左边的距离
var MARGIN_LEFT=20;

var curShowtime=0;

//const endtime= new Date(2015,8,18,18,00,00);//表示2015年9月18日，18:00:00时

var balls = [];//存放新添加的小圆点

//新圆点的颜色值的数组
//const colors = ["#33B5E5","#0099CC","#AA66CC","#9933CC","#99CC00","#669900","#FFBB33","#FF8800","#FF4444","#CC0000"];


window.onload=function(){
    var canvas=document.getElementById("canvas");
    canvas.width=SCREEN_WIDTH;
	canvas.height=SCREEN_HEIGHT;
	
	var context=canvas.getContext("2d");
		
	curShowtime = getCurrentShowTime();//获取当前显示的时间--秒数
	
	//每50毫秒刷新一次页面
	setInterval(
	    function(){
			render(context);
			update();
		}
		,30
	);	
}


//获取当前显示的时间--秒数
function getCurrentShowTime(){
	var curTime = new Date();
    var ret = curTime.getHours() * 3600 + curTime.getMinutes() * 60 + curTime.getSeconds();

    return ret;
}

//更新数据显示
function update(){
    var nextShowtime=getCurrentShowTime();//获取最新的时间
	
	//最新的时间
	var nexthours=parseInt(nextShowtime/3600);
	var nextminutes=parseInt(nextShowtime-nexthours*3600)/60;
	var nextseconds=parseInt(nextShowtime%60);
	
	//当前的时间
	var curhours=parseInt(curShowtime/3600);
	var curminutes=parseInt(curShowtime-curhours*3600)/60;
	var curseconds=parseInt(curShowtime%60);
	
	if(nextseconds != curseconds){		
			
	   //随着时间的改变，添加新的小圆点
       addBalls( 0 , 0 , 0 );
		
	   curShowtime = nextShowtime;//更新时间
	}
	
	updateBalls();//更新新的小圆点的位置
}


//更新新的小圆点的位置
function updateBalls(){

    for( var i = 0 ; i < balls.length ; i ++ ){

        balls[i].x += balls[i].vx;

    var c = 1.0;
	if( balls[i].y + RADIUS + balls[i].vy >= SCREEN_HEIGHT ){
	    c = ( SCREEN_HEIGHT - (balls[i].y+ RADIUS) ) / balls[i].vy;
	    console.log( c );	
	}
        
	balls[i].y += balls[i].vy;
	balls[i].vy += c * balls[i].g;;

        if( balls[i].y >= SCREEN_HEIGHT-RADIUS ){
            balls[i].y = SCREEN_HEIGHT-RADIUS;
	    balls[i].vy = - Math.abs(balls[i].vy)*0.5;
        }
    }

    var cnt = 0
    for( var i = 0 ; i < balls.length ; i ++ )
        if( balls[i].x + RADIUS > 0 && balls[i].x -RADIUS < SCREEN_WIDTH )
            balls[cnt++] = balls[i]

    while( balls.length > cnt ){
        balls.pop();
    }
}

//向数组添加新的小圆点
function addBalls( x , y , num ){

    for( var i = 0  ; i < digit[num].length ; i ++ )
        for( var j = 0  ; j < digit[num][i].length ; j ++ )
            if( digit[num][i][j] == 1 ){
                var aBall = {
                    x:x+j*2*(RADIUS+1)+(RADIUS+1),
                    y:y+i*2*(RADIUS+1)+(RADIUS+1),
                    g:1.5+Math.random(),
                    vx:Math.pow( -1 , Math.ceil( Math.random()*1000 ) ) * 4,
                    vy:-5,
                    color: "RED"
                }

                balls.push( aBall )
            }
}

function render(cxt){  
    //删除画布内之前的图形
    cxt.clearRect(0,0,SCREEN_WIDTH, SCREEN_HEIGHT);
	
	//调用函数drawdigit进行绘制
	drawdigit(0,0,0,cxt);
	
	//绘制新添加的小圆
	for( var i = 0 ; i < balls.length ; i ++ ){
        cxt.fillStyle=balls[i].color;

        cxt.beginPath();
        cxt.arc( balls[i].x , balls[i].y , RADIUS , 0 , 2*Math.PI , true );
        cxt.closePath();

        cxt.fill();
    }		
}

function drawdigit(x,y,num,cxt){
    for(var i=0;i<digit[num].length;i++){
	   for(var j=0;j<digit[num][i].length;j++){
		   if(digit[num][i][j]==1){
			 cxt.beginPath();
			 cxt.arc(x+j*2*(RADIUS+1)+(RADIUS+1),y+i*2*(RADIUS+1)+(RADIUS+1),RADIUS,0,2*Math.PI);
			 			 
			 cxt.fillStyle="red";
			 cxt.fill();
		   }
	   }	
	}	 
}	


  

