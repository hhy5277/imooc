<p>这个一个跟进慕课教程搞出来的玩意儿~</p><p>想在线测试或者看看的朋友可以访问：</p><p><a href="http://ztlele.com/crm_test/index.php/home/login/index" _src="http://ztlele.com/crm_test/index.php/home/login/index">http://ztlele.com/crm_test/index.php/home/login/index</a> </p><p>测试管理员账户：admin</p><p>测试密码：test</p><p>当然，功能非常不完善，只是练习练习所学知识而已</p><p>欢迎吐槽~</p>

