<?php 
	function p($arr){
		echo '<pre>'.print_r($arr,true).'</pre>';
	}
 ?>