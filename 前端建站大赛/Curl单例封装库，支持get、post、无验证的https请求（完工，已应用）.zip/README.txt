<p>日常简单的get、post、无SSL验证的https页面抓取，头部信息抓取，http状态码等操作</p><p>有需要SSL验证、代理、cookie的可以自行修改增加！</p>

