<p>UC官网上的jquery焦点图效果，五个图自动切换效果。</p><p>网方网址：http://www.uc.cn/</p>

