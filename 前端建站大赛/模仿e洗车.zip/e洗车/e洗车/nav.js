window.onload=function()
{
         var oNav=document.getElementById("nav")
	 var aNav=oNav.getElementsByTagName("li");
	 
	 for(var i=0;i<aNav.length;i++)
	 {
	     aNav[i].onmouseover=function()
		 {
		     for(var i=0;i<aNav.length;i++)
			 {
			     aNav[i].className="";
			 }
			 this.className="active";
		 }
	 }
}