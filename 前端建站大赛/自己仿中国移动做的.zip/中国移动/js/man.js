$(document).ready(function(){
  $(".query li").mouseenter(function(){
    $(this).find('img').animate({
	
   height:'43px',
   width:'45px'
    },300,function(){
      $(this).animate({
     height:'39px',width:'41px'  },300);});

	
  });
  
  
  $(".inner_activity .inner").mouseenter(function(){
    $(this).find('img').animate({
	
   right:'40px'
  
    },300,function(){
      $(".inner_activity .inner").mouseleave(function(){
	  $(this).find('img').animate({
   right:'0' },200);});})

	
  });  
  
  
   
  $(".inner_siji").mouseenter(function(){
    $(this).find('img').animate({
	
   right:'20px'
  
    },300,function(){
      $(".inner_siji").mouseleave(function(){
	  $(this).find('img').animate({
   right:'0' },200);});})

	
  }); 
  
  
    $(".inner_phone").mouseenter(function(){
    $(this).find('img').animate({
	
   right:'20px'
  
    },300,function(){
      $(".inner_phone").mouseleave(function(){
	  $(this).find('img').animate({
   right:'0' },200);});})

$("#notice").find("li").mouseover(function(){
$("#notice li").each(function (index) {
$(this).removeClass("cur");
$(this).attr("id",index);

})

$(this).addClass("cur");
$("notice-con ul").eq("this.id").attr("display","block")
})





	})
  
});







