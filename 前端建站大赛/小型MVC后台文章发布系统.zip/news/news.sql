-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2015 年 07 月 07 日 14:40
-- 服务器版本: 5.5.35
-- PHP 版本: 5.3.28

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `news`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--
-- 创建时间: 2015 年 04 月 18 日 13:36
-- 最后更新: 2015 年 04 月 18 日 13:36
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `username` varchar(50) NOT NULL COMMENT '管理员用户名',
  `password` varchar(50) NOT NULL COMMENT '管理员密码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'root', 'root');

-- --------------------------------------------------------

--
-- 表的结构 `news`
--
-- 创建时间: 2015 年 04 月 18 日 13:36
-- 最后更新: 2015 年 07 月 07 日 03:50
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `title` char(50) NOT NULL COMMENT '标题',
  `author` varchar(20) NOT NULL COMMENT '作者',
  `from` varchar(20) NOT NULL COMMENT '出处',
  `content` text NOT NULL COMMENT '内容',
  `dateline` int(4) NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `news`
--

INSERT INTO `news` (`id`, `title`, `author`, `from`, `content`, `dateline`) VALUES
(11, '《肖申克的救赎》好看在哪里？', 'Vivian小水，lalala Dema', '知乎', '我心目中第一位的电影。\r\n\r\n大学时候第一次看。当时自己在一个还不错的学校读一个很热门的专业，但是自己不喜欢当时的自己，不喜欢周围的人，不喜欢大学的氛围。\r\n\r\n当时的我有一个梦想，这个梦想对于那时的我来说是那么遥不可及。室友的中伤，嫉妒，冷嘲热讽，生活上的欺凌，让我觉得举步维艰。\r\n\r\n但我还是做了。每天偷偷摸摸地去隔壁学校的自习室背单词，星期五背着书包从郊区的学校出发，公交+大巴+地铁+公交+打的+飞机，飞到香港，星期六考SAT，星期天再飞回来然后同样的交通方式回到学校和同学们一起上学。没有人知道我过去的两天已经去香港转了一圈。就这样偷偷摸摸地考完了雅思，托福两次，SAT三次。12月25号圣诞夜的晚上，别人在庆祝节日，我在隔壁大学的食堂里赶申请deadline。就这样悄悄地做好了几十份申请。\r\n\r\n录取后，悄悄办了退学。暑假的时候把自己的东西全都带走了。\r\n\r\n开学后，室友们看着空空荡荡的床柜，我猜他们当时的心情，大概也和监狱长看到抽屉里的旧皮鞋一样吧。\r\n\r\n承受别人无法承受的，展望别人无法展望的，忍辱负重数十年，最终实现的梦想，在别人眼中或许是富贵荣华，但对那逃离绝望的人而言，有时候或许只是为了你所没法理解的——自由。就像Tim Robbins最后在海边坐着，天空很蓝，海风吹在他脸上。金融家的过去，典狱长的被捕，其实并不重要了。有的鸟儿天生是无法被拘禁的，他的心永远属于天空。\r\n\r\n\r\n\r\n---\r\n\r\n很多人纠结我和室友的关系，我就统一回复吧。\r\n\r\n我那个时候，也觉得自己被室友欺负是自己的错。现在我觉得，也许当时的自己确实幼稚，但被欺负并不是我的错。不合群，是因为那个群体本来就不是我该在的地方。\r\n\r\n不合群并不是最可怕的。很多人都可以用自己的聪明才智，适应一个自己不那么喜欢的群体并且混得不错。但是，人也很容易在这个过程中被institutionalized了，就像那个图书员那样，起初你讨厌它；慢慢地，你习惯了生活在其中；最终你会发现自己不得不依靠它而生存。好像你本来就是属于这个群体的一样。这是最可怕的。\r\n\r\n我感激这部电影，因为它鼓励我拥有心的自由。', 1429538744),
(9, '哈哈哈哈', '宋', '阿斯顿', '阿克苏了大家来看', 1429364626);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
