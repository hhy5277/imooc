<?php
	$paths = array(
		'function/function.php',
		'libs/core/DB.class.php',
		'libs/core/VIEW.class.php',
		'libs/db/mysql.class.php',
		'libs/view/Smarty/Smarty.class.php'
	);
?>