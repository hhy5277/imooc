<?php
	class testView{
		function display($data){//视图的作用是将取得的数据进行组织、美化等，并最终向用户终端输出
			echo $data;
		}
	}
?>