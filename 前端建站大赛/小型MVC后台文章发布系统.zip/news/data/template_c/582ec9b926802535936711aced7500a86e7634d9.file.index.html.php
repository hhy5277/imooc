<?php /* Smarty version Smarty-3.1.16, created on 2015-07-07 14:22:02
         compiled from "tpl\index\index.html" */ ?>
<?php /*%%SmartyHeaderCode:9492559b700a682ba0-43189868%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '582ec9b926802535936711aced7500a86e7634d9' => 
    array (
      0 => 'tpl\\index\\index.html',
      1 => 1436249889,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9492559b700a682ba0-43189868',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
    'news' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_559b700a6d0db6_28537699',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_559b700a6d0db6_28537699')) {function content_559b700a6d0db6_28537699($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>文章列表</title>
</head>
<body>
	<div>
		<div>
			<?php  $_smarty_tpl->tpl_vars['news'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['news']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['data']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['news']->key => $_smarty_tpl->tpl_vars['news']->value) {
$_smarty_tpl->tpl_vars['news']->_loop = true;
?>
			<div>
				<p><?php echo $_smarty_tpl->tpl_vars['news']->value['author'];?>
发布于<span><?php echo $_smarty_tpl->tpl_vars['news']->value['dateline'];?>
</span></p>
				<h2><a href="index.php?controller=index&method=newsshow&id=<?php echo $_smarty_tpl->tpl_vars['news']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['news']->value['title'];?>
</a></h2>
				<div>
					<p><?php echo $_smarty_tpl->tpl_vars['news']->value['content'];?>
</p>
				</div>
			</div>
			<?php } ?>
		</div>
	</div>
</body>
</html><?php }} ?>
