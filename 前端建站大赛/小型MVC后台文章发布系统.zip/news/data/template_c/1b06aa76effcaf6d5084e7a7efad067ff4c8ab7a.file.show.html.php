<?php /* Smarty version Smarty-3.1.16, created on 2015-07-07 14:22:18
         compiled from "tpl\index\show.html" */ ?>
<?php /*%%SmartyHeaderCode:4541559b701ae3b125-13214209%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1b06aa76effcaf6d5084e7a7efad067ff4c8ab7a' => 
    array (
      0 => 'tpl\\index\\show.html',
      1 => 1429538329,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4541559b701ae3b125-13214209',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_559b701ae8d1b3_79999041',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_559b701ae8d1b3_79999041')) {function content_559b701ae8d1b3_79999041($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
    <div id="page">
        <div id="page-bgtop">
            <div id="content">
                <div class="post">
                    <p><?php echo $_smarty_tpl->tpl_vars['data']->value['author'];?>
发布于<span><?php echo date('Y-m-d H:i:s',$_smarty_tpl->tpl_vars['data']->value['dateline']);?>
</span></p>
                    <h2><a href="" title="<?php echo $_smarty_tpl->tpl_vars['data']->value['title'];?>
"><?php echo $_smarty_tpl->tpl_vars['data']->value['title'];?>
</a></h2>
                    <div class="entry">
                        <p><?php echo $_smarty_tpl->tpl_vars['data']->value['content'];?>
</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </body>
</html><?php }} ?>
