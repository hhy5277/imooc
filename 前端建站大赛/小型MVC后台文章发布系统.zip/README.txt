<p>跟着老师做的，前台没做样式，自己喜欢的自己加吧,后台地址http://localhost/kuangjia/admin.php?controller=admin&amp;method=login</p>

