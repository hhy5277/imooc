var edit = {
    getDoc: function(name) {
        return window.frames[name].document;
    },
    isIE: function() {
        if (!!window.ActiveXObject || "ActiveXObject" in window)
            return true;
        else
            return false;
    },
    IE10_: function() {
        return navigator.userAgent.toLowerCase().indexOf('msie') != -1 ? true : false;
    },
    IE11: function() {
        return navigator.userAgent.toLowerCase().indexOf('msie') == -1 && this.isIE();
    },
    getIERange: function(name) {
        if (this.isIE()) {
            if (this.IE11()) {
                return this.getDoc(name).getSelection();
            } else {
                return this.getDoc(name).selection.createRange();
            }

        } else {
            return false;
        }
    },
    getFFRange: function(name) {
        if (!this.isIE()) {
            return window.frames[name].getSelection().getRangeAt(0);
        } else {
            return false;
        }

    },
    insertPics: function(name, src) {
        var iRange = this.getIERange(name);
        if (this.IE10_()) {

            // 判断IE、是否选中文本了
            if (iRange.text !== "") {
                iRange.select();
                iRange.pasteHTML('<img style="vertical-align:bottom;" src="' + src + '">');
            } else {
                this.getDoc(name).body.innerHTML += '<img style="vertical-align:bottom;" src="' + src + '">';
            }

        } else if (this.IE11()) {
            var img = this.getDoc(name).createElement('img');
            img.style.verticalAlign = 'bottom';
            img.src = src;
            iRange.getRangeAt(0).surroundContents(img);
        } else {
            this.getDoc(name).execCommand('insertHtml', false, '<img style="vertical-align:bottom;" src="' + src + '">');
        }
    }
};

