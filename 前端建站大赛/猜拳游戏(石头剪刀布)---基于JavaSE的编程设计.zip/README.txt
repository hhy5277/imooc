<p>基于JavaSE的简单控制台程序，石头剪刀布而已！很简单 。</p><p>提示：基于JDK1.8的开发 &nbsp;在低版本JDK运行会出问题<br/></p><p>本人博客地址：http://blog.csdn.net/u010081661</p>

