package com.newtion.guessgame;

import java.util.Random;

public class Computer {
	String name ="С����";
	int count;
	Random r = new Random();
	int scores = r.nextInt(3)+1;
	public int getType(){
		switch(scores){
		case 1:
			System.out.println(this.name+"����ʯͷ");
			break;
		case 2:
			System.out.println(this.name+"���˼���");
			break;
		case 3:
			System.out.println(this.name+"���˰���");
			break;
		}
		return scores;
	}
}
