<?php
	return array(
		"PUBLIC_PATH"=>'/Admin/public',
		'TRUE_APP_PATH'=>'/var/www/blog',
		"APP_PATH"=>'×××××××××××',
		'ARTICLE_PATH'=>'/var/www/blog/Admin/public/article',
		'DB_TYPE'   => 'mysql', // 数据库类型
		'DB_HOST'   => 'localhost', // 服务器地址'
		'DB_NAME'   => 'blog', // 数据库名
		'DB_USER'   => '×××××××', // 用户名'
		'DB_PWD'    => '×××××××××××', // 密码
		'DB_PORT'   => 3306, // 端口
		//'DB_PREFIX' => '', // 数据库表前缀 
		'DB_CHARSET'  =>'utf8', // 字符集
		//---------SMTP配置
		'SMTPSERVER'  =>"smtp.qq.com",	//SMTP服务器地址
		'SMTPSERVERPORT' =>25,	//STMP端口号
		'SMTPUSERMAIL' =>"××××××××××",	//服务邮箱
		'SMTPUSER' =>"××××××××××",//SMTP服务器的用户帐号 
		'SMTPPASS'=>"×××××××××××", //SMTP服务器的用户密码 
		'MAILTYPE' =>"××××××××××",
	     );
