<?php
	return array(
		//"DB_TYPE"		=>		"mysql",
		"DB_HOST"		=>		"localhost",
		//"DB_PORT"		=>		3306,
		"DB_USER"		=>		"root",
		"DB_PWD"		=>		"",
		"DB_NAME"		=>		"pdo",
		//"DB_PCONN"		=>		"true",
		//"DB_CHAR"		=>		"utf8"
	);
?>

