<?php
header('content-type:text/html;charset=utf-8');
$config = require_once("config.php");
require_once("PDODB.class.php");

$pdo = PDODB::getInstance($config);

$res = $pdo->query("select * from username"); 

//$res = $pdo->execute("update username set money=money-1000 where id = 1"); 

//$res = $pdo->field('name,sum(money)')->group('name')->having('sum(money) >= 30000')->select("username");
//$data = array("name"=>'hyb3',"money"=>200);
//$res = $pdo->data($data)->insert("username");

//$res = $pdo->select("username");
//echo $pdo->getLastSql();

//$res = $pdo->where(array("name"=>"hyb2"))->order("money")->limit(1)->delete("username");

//$data = array("money"=>200);
//$res = $pdo->data($data)->where("name='hyb3'")->order("id")->update();

//$res = $pdo->distinct()->where("name='hyb3'")->count("username1");
//echo $pdo->getLastSql();
//$res = $pdo->showTables();
//$name = "1";
//$sql = "select * from username where name = " . $pdo->quote($name);
//echo $sql;exit;
//$res = $pdo->showTableInfo("username");
//$data['name'] = $pdo->quote("'hyb");
//echo $data['name'];
//$res = $pdo->data($data)->insert("username");
var_dump($res);
?>