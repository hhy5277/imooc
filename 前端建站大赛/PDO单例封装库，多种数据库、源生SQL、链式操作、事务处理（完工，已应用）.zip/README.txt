<p>使用前开启扩展：php.ini开启扩展，php_pdo.dll、php_pdo_mysql.dll，用什么数据库就开启什么扩展。</p><p>&nbsp;1.源生支持：query、execute<br/>&nbsp;2.对象支持：insert、delete、update、select、count<br/>&nbsp;3.链式支持：distinct、field、join、where、group、having、order、limit<br/>&nbsp;4.事务支持：beginTransaction、commit、rollBack、inTransaction<br/>&nbsp;5.其他支持：quote、showTableInfo、showTables、getLastSql、getDbVersion、isConnected</p><p><br/></p><p><br/></p>

