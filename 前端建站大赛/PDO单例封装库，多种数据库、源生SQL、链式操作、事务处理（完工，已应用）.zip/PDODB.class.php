<?php
// +------------------------------------------------------------------------------------
// | PDODB     [PDO封装库，支持多种数据库，链式操作，源生语句，事务处理]
// +------------------------------------------------------------------------------------
// | Time: 2015-10-23
// +------------------------------------------------------------------------------------
// | Author: hyb <76788424@qq.com>
// +------------------------------------------------------------------------------------
// | Tips: php.ini开启扩展，php_pdo.dll、php_pdo_mysql.dll，用什么数据库就开启什么扩展
// +------------------------------------------------------------------------------------
// | Public Function List:
// | 1.源生支持：query、execute
// | 2.对象支持：insert、delete、update、select、count
// | 3.链式支持：distinct、field、join、where、group、having、order、limit
// | 4.事务支持：beginTransaction、commit、rollBack、inTransaction
// | 5.其他支持：quote、showTableInfo、showTables、getLastSql、getDbVersion、isConnected
// +------------------------------------------------------------------------------------

class PDODB{

	//单例
	private static $instance = null;
	//PDO链接
	private static $link = null;
	//PDOStatement对象
	private static $stmt = null;
	//最后执行的sql语句
	private static $lastSql = null;
	//配置项: 数据库类型、主机、端口、用户名、密码、数据库、字符集、长连接
	private static $configItems = array("DB_TYPE", "DB_HOST", "DB_PORT", "DB_USER", "DB_PWD", "DB_NAME", "DB_CHAR", "DB_PCONN");
	//配置
	private static $config = array();
	//数据库版本信息
	private static $dbVersion = null;
	//数据库是否链接成功
	private static $connected = false;
	//链式操作，条件数组
	private static $options = array();
	
	/**
	**	构造函数
	**	@return		boolean
	**
	**/
	private function __construct(){
		if(!class_exists("PDO")){
			self::sendError("不支持PDO，请先开启");return false;
		}
		try{
			//实例PDO：new PDO($dsn, $user, $parrword, $params)
			self::$link = new PDO(self::$config['DB_DSN'], self::$config['DB_USER'], self::$config['DB_PWD'], self::$config['DB_PARAMS']);
		}catch(PDOException $e){
			self::sendError($e->getMessage());return false;
		}
		if(!self::$link){
			self::sendError("PDO链接错误");return false;
		}
		self::$link->exec('SET NAMES ' . self::$config['DB_CHAR']);
		self::$dbVersion = self::$link->getAttribute(constant("PDO::ATTR_SERVER_VERSION"));
		self::$connected = true;
	}
	
	/**
	**	获取单例	
	**	@param		array		$dbConfig		PDO配置文件
	**	@return		object		self::$instance
	**
	**/
	public static function getInstance($dbConfig){
		if(empty(self::$instance)){
			if(self::checkConfig($dbConfig)){
				self::$instance = new self();
			}
		}
		return self::$instance;
	}
	
/****************************************************************/
/************************　　　　　　　　************************/
/************************　源生SQL支持　 ************************/
/************************　　　　　　　　************************/
/****************************************************************/
	
	/**
	**	源生查询
	**	@param		string		$sql
	**	@return		array
	**
	**/
	public static function query($sql = ''){
		if(self::_query($sql)){
			return self::$stmt->fetchAll(constant("PDO::FETCH_ASSOC"));
		}
	}
	
	/**
	**	源生增删改
	**	@param		string		$sql
	**	@return		int
	**
	**/
	public static function execute($sql = ''){
		return self::_execute($sql);
	}
	
/****************************************************************/
/************************　　　　　　　　************************/
/************************　链式操作支持  ************************/
/************************　　　　　　　　************************/
/****************************************************************/

/************************　　链式函数　  ************************/
	
	/**
	**	增
	**	@param		string		$table
	**	@return		int
	**
	**/
	public static function insert($table){
		$sql = "INSERT INTO {$table} " . self::parseDataForInsert();
		return self::execute($sql);			
	}
	
	/**
	**	删
	**	@param		string		$table
	**	@return		int
	**
	**/
	public static function delete($table){
		$sql = "DELETE FROM {$table} " . self::parseWhere()
									   . self::parseOrder()
									   . self::parseLimit();
		return self::execute($sql);
	}
	
	/**
	**	改
	**	@param		string		$table
	**	@return		int
	**
	**/
	public static function update($table){
		$sql = "UPDATE {$table} SET " . self::parseDataForUpdate()
									  . self::parseWhere()
									  . self::parseOrder()
									  . self::parseLimit();
		return self::execute($sql);
	}
	
	/**
	**	查
	**	@param		string		$table
	**	@return		array
	**
	**/
	public static function select($table){
		$sql = "SELECT " . self::parseDistinct()
						 . self::parseField() . $table
						 . self::parseJoin()
						 . self::parseWhere()
						 . self::parseGroup()
						 . self::parseHaving()
						 . self::parseOrder()
						 . self::parseLimit();
		return self::query($sql);
	}

	/**
	**	统计
	**	@param		string		$table
	**	@param		string		[$keyName]		防止主键名不为id的情况发生
	**	@return		int
	**
	**/
	public static function count($table, $keyName = 'id'){
		$sql = "SELECT " . self::parseDistinct()
						 . " count({$keyName}) FROM {$table}"
						 . self::parseJoin()
						 . self::parseWhere();
		$data = self::query($sql);
		return $data[0]["count({$keyName})"];
	}
	
/************************　　链式字段　  ************************/

	/**
	**	去重
	**	@return		object		self::$instance
	**
	**/
	public static function distinct(){
		self::$options['distinct'] = true;
		return self::$instance;
	}

	/**
	**	字段
	**	@param		string/array	$field
	**	@return		object			self::$instance
	**	
	**/
	public static function field($field){
		self::$options['field'] = $field;
		return self::$instance;
	}
	
	/**
	**	关联查询
	**	@param		string		$join
	**	@return		object		self::$instance
	**	@example	$pdo->join('JOIN dpt ON dpt.id = user.dpt')->select('user');
	**
	**/
	public static function join($join){
		self::$options['join'] = trim($join);
		return self::$instance;
	}
	
	/**
	**	条件
	**	@param		string/array	$where
	**	@return		object			self::$instance
	**
	**/
	public static function where($where){
		self::$options['where'] = $where;
		return self::$instance;
	}
	
	/**
	**	分组
	**	@param		string/array	$group
	**	@return		object			self::$instance
	**
	**/
	public static function group($group){
		self::$options['group'] = $group;
		return self::$instance;
	}
	
	/**
	**	分组条件
	**	@param		string		$having
	**	@return		object		self::$instance
	**
	**/
	public static function having($having){
		self::$options['having'] = $having;
		return self::$instance;
	}
	
	/**
	**	排序
	**	@param		string		$order		"2"、"2,3"
	**	@return		object		self::$instance
	**
	**/
	public static function order($order){
		self::$options['order'] = trim($order);
		return self::$instance;
	}
	
	/**
	**	分页
	**	@param		string		$limit
	**	@return		object		self::$instance
	**
	**/
	public static function limit($limit){
		self::$options['limit'] = trim($limit);
		return self::$instance;
	}

	/**
	**	数据
	**	@param		array		$data		以字段名为键的关联数组
	**	@return		object		self::$instance
	**
	**/
	public static function data($data){
		self::$options['data'] = $data;
		return self::$instance;
	}
	
/************************　　链式解析　  ************************/

	/**
	**	update操作data解析
	**	@return		string
	**
	**/
	private static function parseDataForUpdate(){
		if(empty(self::$options['data']) || !is_array(self::$options['data'])){
			self::sendError("DATA参数错误");return false;
		}
		$arr = array();
		foreach(self::$options['data'] as $k => $v){
			$arr[] = $k . ' = "'  .$v . '"';
		}
		return implode(',', $arr);
	}

	/**
	**	insert操作data解析
	**	@return		string
	**
	**/
	private static function parseDataForInsert(){
		if(empty(self::$options['data']) || !is_array(self::$options['data'])){
			self::sendError("DATA参数错误");return false;
		}
		$keys = array_keys(self::$options['data']);
		array_walk($keys,array(self::$instance, "addSpecialChar"));
		$values = array_values(self::$options['data']);
		return ' (' . implode(',', $keys) .') VALUES ("' . implode('","' ,$values) . '")';
	}
	
	/**
	**	limit解析
	**	@return		string
	**
	**/
	private static function parseLimit(){
		if(!empty(self::$options['limit'])){
			return ' LIMIT ' . self::$options['limit'];
		}
	}
	
	/**
	**	order解析
	**	@return		string
	**
	**/
	private static function parseOrder(){
		if(!empty(self::$options['order'])){
			return ' ORDER BY ' . self::$options['order'];
		}	
	}
	
	/**
	**	having解析
	**	@return		string
	**
	**/
	private static function parseHaving(){
		if(!empty(self::$options['having'])){
			return ' HAVING ' . self::$options['having'];
		}
	}
	
	/**
	**	group解析
	**	@return		string
	**
	**/
	private static function parseGroup(){
		if(!empty(self::$options['group'])){
			if(is_string(self::$options['group'])){
				return ' GROUP BY ' . self::$options['group'];
			}elseif(is_array(self::$options['group'])){
				return ' GROUP BY ' . implode(',', self::$options['group']);
			}
		}
	}
	
	/**
	**	where解析
	**	@return		string
	**
	**/
	private static function parseWhere(){
		if(!empty(self::$options['where'])){
			if(is_string(self::$options['where'])){
				return ' WHERE ' . self::$options['where'];
			}elseif(is_array(self::$options['where'])){
				$arr = array();
				foreach(self::$options['where'] as $k => $v){
					$arr[] = $k . ' = "' . $v . '"'; 
				}
				return ' WHERE ' . implode(' AND ', $arr);	
			}
		}
	}
	
	/**
	**	join解析
	**	@return		string
	**
	**/
	private static function parseJoin(){
		if(!empty(self::$options['join'])){
			return ' ' . self::$options['join'];
		}
	}
	
	/**
	**	field解析
	**	@return		string
	**
	**/
	private static function parseField(){
		if(!empty(self::$options['field'])){
			if(is_array(self::$options['field'])){
				//array_walk(array,function,[data]) 函数对数组中的每个元素应用回调函数。如果成功则返回 TRUE，否则返回 FALSE
				array_walk(self::$options['field'], array(self::$instance, "addSpecialChar"));
			}elseif(is_string(self::$options['field'])){
				self::$options['field'] = explode(',', self::$options['field']);
				array_walk(self::$options['field'], array(self::$instance, "addSpecialChar"));
			}
			return implode(',', self::$options['field']) . " FROM ";
		}else{
			return "* FROM ";
		}
	}
	
	/**
	**	反引号字段，防止SQL关键字冲突
	**	@prarm		unknow		&$value		引用
	**	@return		string
	**
	**/
	private static function addSpecialChar(&$value){
		if($value === '*' || strpos($value, '.') !== false || strpos($value, '`') !== false || strpos($value, '(') !== false || strpos($value, ' as ') !== false){
			//不用做处理
		}elseif(strpos($value, '`') === false){
			$value = '`' . trim($value) . '`';
		}
		return $value;
	}
	
	/**
	**	distinct解析
	**	@return		string
	**
	**/
	private static function parseDistinct(){
		if(!empty(self::$options['distinct'])){
			return "DISTINCT ";
		}
	}
	
/****************************************************************/
/************************　　　　　　　　************************/
/************************　　事务支持　　************************/
/************************　　　　　　　　************************/
/****************************************************************/
/************************　　 [DEMO]　　 ************************/
/****************************************************************/
/*	$pdo = PDODB::getInstance($config);							*/
/*	$pdo::beginTransaction();									*/
/*	//var_dump($pdo::inTransaction()); //检测是否在事务中，true */
/*	try{														*/
/*		$res1 = $pdo::execute($sql1);							*/
/*		if(empty($res1)) throw new PDOException("操作失败1");	*/
/*		$res2 = $pdo::execute($sql2);							*/
/*		if(empty($res2)) throw new PDOException("操作失败2");	*/
/*		$pdo::commit();											*/
/*		echo "success";											*/
/*	}catch(PDOException $e){									*/
/*		$pdo::rollBack();										*/
/*		echo $e->getMessage();									*/
/*	}															*/
/****************************************************************/
	/**
	**	开启事务
	**
	**/
	public static function beginTransaction(){
		if(empty(self::$link)){return false;}
		self::$link->setAttribute(PDO::ATTR_AUTOCOMMIT,0);//开启事务的时候关闭自动提交	
		self::$link->beginTransaction();
	}
	
	/**
	**	提交事务
	**
	**/
	public static function commit(){
		if(empty(self::$link)){return false;}
		self::$link->commit();
		self::$link->setAttribute(PDO::ATTR_AUTOCOMMIT,1);//完成事务的时候开启自动提交
	}
	
	/**
	**	事务回滚
	**
	**/
	public static function rollBack(){
		if(empty(self::$link)){return false;}
		self::$link->rollBack();
		self::$link->setAttribute(PDO::ATTR_AUTOCOMMIT,1);//回滚事务的时候开启自动提交
	}
	
	/**
	**	检测是否在事务内
	**	@return		boolean
	**
	**/
	public static function inTransaction(){
		if(empty(self::$link)){return false;}
		return self::$link->inTransaction();
	}
	
/****************************************************************/
/************************　　　　　　　　************************/
/************************　　原始CURD　　************************/
/************************　　　　　　　　************************/
/****************************************************************/
	
	/**
	**	原始增删改
	**	@prarm		string		$sql
	**	@return		int/boolean
	**
	**/
	private static function _execute($sql = ''){
		if(empty(self::$link)){return false;}
		if(!empty(self::$stmt)){self::free();}
		if(!empty(self::$options)){self::clean();}
		self::$lastSql = trim($sql);
		$isInset = strtoupper(substr(self::$lastSql, 0, 6)) == 'INSERT';
		$res = self::$link->exec(self::$lastSql);
		self::isError();
		if($res){
			if($isInset){	//insert操作返回最后插入的AUTO_INCREMENT
				return self::$link->lastInsertId();
			}else{			//update、delete操作返回影响行数
				return $res;
			}
		}else{
			return false;
		}
	}
	
	/**
	**	原始查询
	**	@prarm		string		$sql
	**	@return		boolean
	**
	**/
	private static function _query($sql = ''){
		if(empty(self::$link)){return false;}
		if(!empty(self::$stmt)){self::free();}
		if(!empty(self::$options)){self::clean();}
		self::$lastSql = trim($sql);
		self::$stmt = self::$link->prepare(self::$lastSql);
		$res = self::$stmt->execute();
		self::isError();
		return $res;
	}
	
/****************************************************************/
/************************　　　　　　　　************************/
/************************　　其它函数　　************************/
/************************　　　　　　　　************************/
/****************************************************************/
	
	/**
	**	防注入，返回带引号的字符串，过滤特殊字符
	**	@prarm		string		$str
	**	@return		string
	**
	**/
	public static function quote($str){
		return trim(self::$link->quote($str), "'");
	}
	
	/**
	**	获取表中字段信息
	**	@prarm		string		$table
	**	@return		array
	**
	**/
	public static function showTableInfo($table){
		$res = self::query("SHOW COLUMNS FROM {$table}");
		return $res;
	}
	
	/**
	**	获取数据库中所有的表
	**	@return		array
	**
	**/
	public static function showTables(){
		$tables = array();
		$res = self::query("SHOW TABLES");
		if(!empty($res)){
			foreach($res as $k => $v){
				$tables[] = current($v); //current()数组当前指针所指元素的值
			}
		}
		return $tables;
	}
	
	/**
	**	获取最后执行的SQL
	**	@return		string
	**
	**/
	public static function getLastSql(){
		return self::$lastSql;
	}
	
	/**
	**	获取数据库版本
	**	@return		string
	**
	**/
	public static function getDbVersion(){
		return self::$dbVersion;
	}
	
	/**
	**	数据库连接是否成功
	**	@return		boolean
	**
	**/
	public static function isConnected(){
		return self::$connected;
	}
	
/****************************************************************/
/************************　　　　　　　　************************/
/************************　　工具函数　　************************/
/************************　　　　　　　　************************/
/****************************************************************/

	/**
	**	检查配置文件
	**	@param		array		$dbConfig
	**	@return		boolean
	**
	**/
	private static function checkConfig($dbConfig){
		foreach(self::$configItems as $k => $v){
			if(!isset($dbConfig[$v])){	//默认参数设置
				if($v == "DB_TYPE"){
					self::$config[$v] = "mysql";
				}elseif($v == "DB_PORT"){
					self::$config[$v] = 3306;
				}elseif($v == "DB_CHAR"){
					self::$config[$v] = "utf8";
				}elseif($v == "DB_PCONN"){	//是否为长连接
					self::$config[$v] = false;
				}else{	//其他没有默认参数的配置项，报错
					self::sendError("array[{$v}]未配置");return false;
				}
			}else{
				self::$config[$v] = $dbConfig[$v];
			}
		}
		self::$config['DB_DSN'] = self::$config['DB_TYPE'] . ':host='
								. self::$config['DB_HOST'] . ';port='
								. self::$config['DB_PORT'] . ';dbname='
								. self::$config['DB_NAME'];
		//其他链接属性设置
		if(empty(self::$config['DB_PARAMS'])){
			self::$config['DB_PARAMS'] = array();
			//长连接
			if(!empty(self::$config['DB_PCONN'])){
				self::$config['DB_PARAMS'][constant("PDO::ATTR_PERSISTENT")] = true;
			}
			//其他链接参数
		}
		return true;
	}
	
	/**
	**	检测执行SQL是否有错误
	**	@return		boolean
	**
	**/
	private static function isError(){
		$obj = empty(self::$stmt)?self::$link:self::$stmt;
		$errorArr = $obj->errorInfo();
		if($errorArr[0] != '00000'){	//有错误
			$error = 'SQL_STATE : ' . $errorArr[0] . '<br/>ERROR_INFO : ' . $errorArr[2] . '<br/>ERROR_SQL : ' . self::$lastSql;
			self::sendError($error);return false;
		}
	}
	
	/**
	**	打印错误
	**
	**/
	private static function sendError($errMsg){
		echo "<br/>{$errMsg}<br/>";
	}
	
	/**
	**	释放条件集
	**
	**/
	private static function clean(){
		self::$options = null;
	}
	
	/**
	**	释放结果集
	**
	**/
	private static function free(){
		self::$stmt = null;
	}
	
	/**
	**	防止克隆对象
	**	
	**/
	private function __clone(){
		//防止clone函数克隆对象，破坏单例模式
	}
	
	/**
	**	析构函数
	**
	**/
	public function __destruct(){
		self::$link = null;
	}
	
}
?>