<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/8/21
 * Time: 9:17
 */
require_once "../tools/Db.class.php";
class searchHouseService{


    function totalRecord($pagesSize,$title,$price,$district,$type,$floor){
        $totalRecord=0;//�ܼ�¼��
        $sql="SELECT COUNT(*) FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id";

        if($title!=""){
            $sql=$sql." AND house.title LIKE '%$title%' ";
        }
        if($price!=""){
            //����price
            $prices=explode('-',$price);
            $sql=$sql." AND price BETWEEN $prices[0] AND $prices[1]";
        }
        if($district!=""){
            $sql=$sql." AND street.street_id='$district'";
        }
        if($type!=""){
            $sql=$sql." AND type.type_id='$type'";
        }
        if($floor!=""){
            $floors=explode('-',$floor);
            $sql=$sql." AND house.floor BETWEEN $floors[0] AND $floors[1]";
        }
        $db=new Db();
        $result=$db->demand($sql);
        if($row=$result->fetch_row()){
            $totalRecord=$row[0];
        }
        $result->free();
        $totalPages=ceil($totalRecord/$pagesSize);//������ж���ҳ
        return $totalPages;
    }


    function searchHouse($title,$price,$street,$type,$floor){
        $sql="SELECT house.title,house.description,type.houseType,house.price,house.publish,house.floor,street.street_name,district.district_name,rentuser.username,rentuser.tel FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id";
        if($title!=""){
            $sql=$sql." AND house.title LIKE '%$title%' ";
        }
        if($price!=""){
            //����price
            $prices=explode('-',$price);
            $sql=$sql." AND price BETWEEN $prices[0] AND $prices[1]";
        }
        if($street!=""){
            $sql=$sql." AND street.street_id='$street'";
        }
        if($type!=""){
            $sql=$sql." AND type.type_id='$type'";
        }
        if($floor!=""){
            $floors=explode('-',$floor);
            $sql=$sql." AND house.floor BETWEEN $floors[0] AND $floors[1]";
        }
        $arr = array();
        $i = 0;
        //$sql = "SELECT house.title,house.description,type.houseType,house.price,house.publish,house.floor,street.street_name,district.district_name,rentuser.username,rentuser.tel FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id AND house.title LIKE '%$title%' AND price BETWEEN $prices[0] AND $prices[1]";
        $db = new Db();
        $result = $db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr[$i] = $row;
            $i++;
        }
        $result->free();
        return $arr;
    }

    function paging($nowPage,$pageSize,$title,$price,$district,$type,$floor){
        $num=($nowPage-1)*$pageSize;
        $sql="SELECT house.title,house.description,type.houseType,house.price,house.publish,house.floor,street.street_name,district.district_name,rentuser.username,rentuser.tel,house.house_id,house.image FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id";
        if($title!=""){
            $sql=$sql." AND house.title LIKE '%$title%' ";
        }
        if($price!=""){
            //����price
            $prices=explode('-',$price);
            $sql=$sql." AND price BETWEEN $prices[0] AND $prices[1]";
        }
        if($district!=""){
            $sql=$sql." AND street.street_id='$district'";
        }
        if($type!=""){
            $sql=$sql." AND type.type_id='$type'";
        }
        if($floor!=""){
            $floors=explode('-',$floor);
            $sql=$sql." AND house.floor BETWEEN $floors[0] AND $floors[1]";
        }
        $sql=$sql." ORDER BY house.house_id LIMIT $num,$pageSize";
        $arr=array();
        $i=0;

        $db=new Db();
        $result=$db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr[$i] = $row;
            $i++;
        }
        $result->free();
        return $arr;
    }

    function totalRecord1($pagesSize,$title,$price,$district,$type,$floor,$user_id){
        $totalRecord=0;//�ܼ�¼��
        $sql="SELECT COUNT(*) FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id";

        if($title!=""){
            $sql=$sql." AND house.title LIKE '%$title%' ";
        }
        if($price!=""){
            //����price
            $prices=explode('-',$price);
            $sql=$sql." AND price BETWEEN $prices[0] AND $prices[1]";
        }
        if($district!=""){
            $sql=$sql." AND street.street_id='$district'";
        }
        if($type!=""){
            $sql=$sql." AND type.type_id='$type'";
        }
        if($floor!=""){
            $floors=explode('-',$floor);
            $sql=$sql." AND house.floor BETWEEN $floors[0] AND $floors[1]";
        }
        $sql=$sql." AND house.uesr_id=$user_id";
        $db=new Db();
        $result=$db->demand($sql);
        if($row=$result->fetch_row()){
            $totalRecord=$row[0];
        }
        $result->free();
        $totalPages=ceil($totalRecord/$pagesSize);//������ж���ҳ
        return $totalPages;
    }

    function personSearch($nowPage,$pageSize,$title,$price,$district,$type,$floor,$user_id){
        $num=($nowPage-1)*$pageSize;
        $sql="SELECT house.title,house.description,type.houseType,house.price,house.publish,house.floor,street.street_name,district.district_name,rentuser.username,rentuser.tel,house.house_id,house.image FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id";
        if($title!=""){
            $sql=$sql." AND house.title LIKE '%$title%' ";
        }
        if($price!=""){
            //����price
            $prices=explode('-',$price);
            $sql=$sql." AND price BETWEEN $prices[0] AND $prices[1]";
        }
        if($district!=""){
            $sql=$sql." AND street.street_id='$district'";
        }
        if($type!=""){
            $sql=$sql." AND type.type_id='$type'";
        }
        if($floor!=""){
            $floors=explode('-',$floor);
            $sql=$sql." AND house.floor BETWEEN $floors[0] AND $floors[1]";
        }
        $sql=$sql." AND house.uesr_id=$user_id ORDER BY house.house_id LIMIT $num,$pageSize";
        $arr=array();
        $i=0;

        $db=new Db();
        $result=$db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr[$i] = $row;
            $i++;
        }
        $result->free();
        return $arr;
    }

    function queryHouse($house_id)
    {
        $arr = array();
        $db = new Db();
        $sql = "SELECT house.house_id, house.title,house.description,type.houseType,house.price,house.publish,house.floor,street.street_name,district.district_name,rentuser.username,rentuser.tel FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id AND house.house_id=$house_id";

        $result = $db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr = $row;
        }
        $result->free();
        return $arr;
    }
}