<?php
/**
 * Created by PhpStorm.
 * User: peter
 * Date: 2015/8/26
 * Time: 15:14
 */
require_once "../tools/Db.class.php";
class Add{
    function addHouse($street_id,$type_id,$uesr_id,$title,$description,$price,$publish,$floor,$picName)
    {
        $bool=false;
        $db = new Db();
        $sql = "INSERT INTO house(street_id,type_id,uesr_id,title,description,price,publish,FLOOR,image) VALUES($street_id,$type_id,$uesr_id,'$title','$description','$price','$publish','$floor','$picName')";
        $result = $db->crud($sql);
        if ($result != 0) {
            $bool = true;
        }
        $db->closeLink();
        return $bool;
    }
}