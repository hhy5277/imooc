<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/8/14
 * Time: 10:54
 */
require_once "../tools/Db.class.php";
class HouseService
{
    function addUser($a,$b,$c,$d)
    {
        $bool = false;
        $sql = "INSERT INTO rentuser(NAME,PASSWORD,username,tel,isadmin) VALUES ('$a','$b','$c','$d','fault')";
        $db = new Db();
        $result = $db->crud($sql);
        if ($result != 0) {
            $bool = true;
        }
        $db->closeLink();
        return $bool;
    }

    function queryHouse()
    {
        $arr = array();
        $i = 0;
        $sql = "SELECT house.title,house.description,type.houseType,house.price,house.publish,house.floor,street.street_name,district.district_name,rentuser.username,rentuser.tel FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id";
        $db = new Db();
        $result = $db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr[$i] = $row;
            $i++;
        }
        $result->free();
        return $arr;
    }

    function queryStreet()
{
    $arr = array();
    $i = 0;
    $sql = "SELECT street_id,street_name,district_id FROM street";
    $db = new Db();
    $result = $db->demand($sql);
    while ($row = $result->fetch_row()) {
        $arr[$i] = $row;
        $i++;
    }
    $result->free();
    return $arr;
}
    function getStreet($district_id)
    {
        $arr = array();
        $i = 0;
        $sql = "SELECT street_id,street_name FROM street WHERE district_id=$district_id";
        $db = new Db();
        $result = $db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr[$i] = $row;
            $i++;
        }
        $result->free();
        return $arr;
    }

    function queryDistrict()
    {
        $arr = array();
        $i = 0;
        $sql = "SELECT district_id,district_name FROM district";
        $db = new Db();
        $result = $db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr[$i] = $row;
            $i++;
        }
        $result->free();
        return $arr;
    }

    function queryHouseType()
    {
        $arr = array();
        $i = 0;
        $sql = "SELECT* FROM type";
        $db = new Db();
        $result = $db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr[$i] = $row;
            $i++;
        }
        $result->free();
        return $arr;
    }

    function queryUser($a,$b)
    {
        $arr = array();
        $sql = "SELECT* FROM rentuser WHERE NAME='$a' AND PASSWORD='$b'";
        $db = new Db();
        $result = $db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr = $row;
        }
        $result->free();
        return $arr;
    }

    function checkByNameAndPwd($a, $b)
    {

        $bool = false;
        $sql = "SELECT* FROM rentuser WHERE NAME='$a' AND PASSWORD='$b'";
        $db = new Db();
        $result = $db->demand($sql);
        if ($row = $result->fetch_row()) {
            $bool = true;
        }
        $result->free();
        $db->closeLink();
        return $bool;

    }

    function checkByName($a)
    {

        $bool = false;
        $sql = "SELECT* FROM rentuser WHERE NAME='$a'";
        $db = new Db();
        $result = $db->demand($sql);
        if ($row = $result->fetch_row()) {
            $bool = true;
        }
        $result->free();
        $db->closeLink();
        return $bool;

    }

    function demandHouse($a){
        $arr=array();
        $i=0;
        $sql = "SELECT house.title,house.description,type.houseType,house.price,house.publish,house.floor,street.street_name,district.district_name,rentuser.username,rentuser.tel,house.house_id,house.uesr_id,house.image FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id AND rentuser.name='$a'";
        $db = new Db();
        $result = $db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr[$i] = $row;
            $i++;
        }
        $result->free();
        $db->closeLink();
        return $arr;

    }

    function deleteHouse($a){
        $db=new Db();
        $sql="DELETE FROM house WHERE house_id=$a";
        $result=$db->crud($sql);
        $db->closeLink();
        return $result;
    }


//���Ƕ�ά����
 /*   function updateHousePre($a){
        $arr=array();
        $i=0;

        $db=new Db();
        $sql="SELECT* FROM house WHERE id=$a";
        $result=$db->demand($sql);

        while ($row = $result->fetch_row()) {
            $arr[$i] = $row;
            $i++;
        }
        $result->free();
        return $arr;
    }*/

//����һά����
    function updateHousePre2($house_id){
        $arr=array();

        $db=new Db();
        $sql="SELECT house_id,street.street_name,type_id,uesr_id,title,description,price,FLOOR,image,district.district_id,street.street_id FROM house,street,district WHERE house.street_id = street.street_id AND street.district_id=district.district_id AND house.house_id=$house_id";
        $result=$db->demand($sql);

        while ($row = $result->fetch_row()) {
            $arr= $row;
        }
        $result->free();
        return $arr;
    }

    function updateHouse($street_id,$type_id,$title,$description,$price,$FLOOR,$house_id,$picName){
        $db=new Db();
        if(empty($picName)){
            $sql="UPDATE house SET street_id='$street_id',type_id='$type_id',title='$title',description='$description',price='$price',FLOOR='$FLOOR' WHERE house_id='$house_id'";
        }else{
            $sql="UPDATE house SET street_id='$street_id',type_id='$type_id',title='$title',description='$description',price='$price',FLOOR='$FLOOR',house.image='$picName' WHERE house_id='$house_id'";
        }
        $result=$db->crud($sql);
        return $result;
    }

    function totalRecord($pagesSize){
        $totalRecord=0;//�ܼ�¼��
        $sql="SELECT COUNT(*)FROM house ";
        $db=new Db();
        $result=$db->demand($sql);
        if($row=$result->fetch_row()){
            $totalRecord=$row[0];
        }
        $result->free();
        $totalPages=ceil($totalRecord/$pagesSize);//������ж���ҳ
        return $totalPages;
    }

    function totalRecord2($pagesSize,$username){
        $totalRecord=0;//�ܼ�¼��
        $sql="SELECT COUNT(*) FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id AND rentuser.name='$username'";
        $db=new Db();
        $result=$db->demand($sql);
        if($row=$result->fetch_row()){
            $totalRecord=$row[0];
        }
        $result->free();
        $totalPages=ceil($totalRecord/$pagesSize);//������ж���ҳ
        return $totalPages;
    }
    function checkRecord(){
        $totalRecord=0;//�ܼ�¼��
        $sql="SELECT COUNT(*)FROM house ";
        $db=new Db();
        $result=$db->demand($sql);
        if($row=$result->fetch_row()){
            $totalRecord=$row[0];
        }
        $result->free();
        //$totalPages=ceil($totalRecord/$pagesSize);//������ж���ҳ
        return $totalRecord;
    }

    function paging($nowPage,$pageSize){
        $arr=array();
        $i=0;

        $num=($nowPage-1)*$pageSize;
        $db=new Db();
        $sql="SELECT house.title,house.description,type.houseType,house.price,house.publish,house.floor,street.street_name,district.district_name,rentuser.username,rentuser.tel,house.house_id,house.image FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id ORDER BY house.house_id LIMIT $num,$pageSize";
        $result=$db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr[$i] = $row;
            $i++;
        }
        $result->free();
        return $arr;
    }

    function paging2($nowPage,$pageSize,$username){
        $arr=array();
        $i=0;

        $num=($nowPage-1)*$pageSize;
        $db=new Db();
        $sql="SELECT house.title,house.description,type.houseType,house.price,house.publish,house.floor,street.street_name,district.district_name,rentuser.username,rentuser.tel,house.house_id,house.image FROM house,street,district,rentuser,TYPE WHERE street.district_id=district.district_id AND house.street_id=street.street_id AND house.type_id=type.type_id AND house.uesr_id=rentuser.uesr_id AND rentuser.name='$username' ORDER BY house.house_id LIMIT $num,$pageSize";
        $result=$db->demand($sql);
        while ($row = $result->fetch_row()) {
            $arr[$i] = $row;
            $i++;
        }
        $result->free();
        return $arr;
    }

    /**
     * $count ��ҳ��
     * $page ��ǰҳ��
     * $num ��ʾ��ҳ����
     **/
    function pagebar($count, $page, $num) {
        $num = min($count, $num); //������ʾ��ҳ����������ҳ�������
        if($page > $count || $page < 1) return; //�����Ƿ�ҳ�ŵ����
        $end = $page + floor($num/2) <= $count ? $page + floor($num/2) : $count; //�������ҳ��
        $start = $end - $num + 1; //���㿪ʼҳ��
        if($start < 1) { //������ʼҳ��С��1�����
            $end -= $start - 1;
            $start = 1;
        }
        for($i=$start; $i<=$end; $i++) { //�����ҳ��������������������ʽ
            if($i == $page){
                echo "&nbsp;<a href='../controller/Paging.php?nowPages= $i'>[$i]</a>";
            }
            else {

                echo "&nbsp;|<a href='../controller/Paging.php?nowPages= $i'>$i</a>|";
            }
        }
        //echo "��".$page."ҳ<br />";
    }

    function pagebar1($count, $page, $num) {
        $num = min($count, $num); //������ʾ��ҳ����������ҳ�������
        if($page > $count || $page < 1) return; //�����Ƿ�ҳ�ŵ����
        $end = $page + floor($num/2) <= $count ? $page + floor($num/2) : $count; //�������ҳ��
        $start = $end - $num + 1; //���㿪ʼҳ��
        if($start < 1) { //������ʼҳ��С��1�����
            $end -= $start - 1;
            $start = 1;
        }
        for($i=$start; $i<=$end; $i++) { //�����ҳ��������������������ʽ
            if($i == $page){
                echo "&nbsp;<a href='../controller/loginController.php?nowPages= $i'>[$i]</a>";
            }
            else {

                echo "&nbsp;|<a href='../controller/loginController.php?nowPages= $i'>$i</a>|";
            }
        }
        //echo "��".$page."ҳ<br />";
    }


}