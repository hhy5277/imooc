<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/8/19
 * Time: 10:47
 */
$a=$_POST['name'];
$b=$_POST['password'];
$c=$_POST['username'];
$d=$_POST['telephone'];
require_once "../model/HouseService.php";
$hs=new HouseService();
$bool=$hs ->addUser($a,$b,$c,$d);
if($bool==0){
    header("Location:../register.php?id=1");
    exit;
}else{
    header("Location:../login.php?id=2");
    exit;
}