<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/8/28
 * Time: 15:27
 */
session_start();
session_destroy();
setcookie("name","$a",time()-60*60);

header("Location:../index.html");