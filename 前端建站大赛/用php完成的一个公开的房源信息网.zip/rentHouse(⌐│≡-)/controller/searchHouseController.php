<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/8/20
 * Time: 10:35
 */
session_start();
@$a=$_COOKIE['name'];
$title = $_POST['title'];
setcookie("title", "$title", time() + 60 * 60);
$price = $_POST['price'];
setcookie("price", "$price", time() + 60 * 60);
$street = $_POST['street_id'];
setcookie("street", "$street", time() + 60 * 60);
$type = $_POST['type_id'];
setcookie("type", "$type", time() + 60 * 60);
$floor = $_POST['floorage'];
setcookie("floor", "$floor", time() + 60 * 60);


require_once "../model/HouseService.php";
require_once "../model/searchHouseService.php";
/*$hs = new searchHouseService();
$arr = $hs->searchHouse($title, $price, $street, $type, $floor);*/


//�õ��ֵ�������
$hstreet = new HouseService();
$streetArr = $hstreet->queryStreet();
//�õ���������
$houseType = new HouseService();
$typeArr = $houseType->queryHouseType();


//��ҳ
$hs = new searchHouseService();
$pageSize = 2;
if ($_GET == null) {
    $nowPage = 1;
} else {
    $nowPage = $_GET["nowPages"];
}
$totalPage = $hs->totalRecord($pageSize, $title, $price, $street, $type, $floor);//ȡ����ҳ��
$arr = $hs->paging($nowPage, $pageSize, $title, $price, $street, $type, $floor);
include "../view/searchHouse.php";