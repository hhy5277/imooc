<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/9/10
 * Time: 10:10
 */
$districtId=$_POST['districtId'];
$html='';
require_once "../model/HouseService.php";
//拿到街道数据
$hstreet=new HouseService();
$streetArr=$hstreet->getStreet($districtId);


switch($districtId){
    case 0:
        $html="<option value='0'>选择街道</option>";
        break;
    case $districtId:foreach($streetArr as $v){
        $a=$v[1];
        $b=$v[0];
        $a=mb_convert_encoding($a,'utf-8','gbk');//格式转换
        $b=mb_convert_encoding($b,'utf-8','gbk');
        $html=$html."<option value='$b'>$a</option>";
    }

}
echo $html;