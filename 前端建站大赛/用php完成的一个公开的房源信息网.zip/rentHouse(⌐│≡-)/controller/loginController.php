<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/8/18
 * Time: 17:11
 */
session_start();
if(!empty($_SESSION['name'])){
    $a=$_SESSION['name'];
    $b=$_SESSION['password'];
}else {
    $a=$_POST['name'];
    $b=$_POST['password'];
}
@$id = $_GET['id'];

require_once "../model/HouseService.php";
$hs=new HouseService();
$bool=$hs->checkByNameAndPwd($a,$b);
//$arr=$hs->demandHouse($a);
$row=$hs->queryUser($a,$b);

$pageSize = 2;
if ($_GET == null) {
    $nowPage = 1;
} else {
    $nowPage = $_GET["nowPages"];
}
$totalPage = $hs->totalRecord2($pageSize,$a);//ȡ����ҳ��
$arr = $hs->paging2($nowPage, $pageSize,$a);
//�õ��ֵ�������
$hstreet=new HouseService();
$streetArr=$hstreet->queryStreet();
//�õ���������
$houseType=new HouseService();
$typeArr=$houseType->queryHouseType();
if($bool){
    $_SESSION['user_id']=$row[0];
    setcookie("name","$row[3]",time()+60*60);
//setcookie("password","$b",time()+60*60);
    $_SESSION['name']=$a;
    $_SESSION['password']=$b;
    if ($id == 1) {
        $error = 'ɾ��ʧ��';
        $str = <<<EOD
                                    <script type="text/javascript">
                                            alert("$error");
                                            </script>
EOD;
        echo $str;
    }else if($id == 2){
        $error = '�ύ�ɹ���';
        $str = <<<EOD
                                    <script type="text/javascript">
                                            alert("$error");
                                            </script>
EOD;
        echo $str;
    }else if($id == 3){
        $error = '�޸ĳɹ���';
        $str = <<<EOD
                                    <script type="text/javascript">
                                            alert("$error");
                                            </script>
EOD;
        echo $str;
    }else if($id == 4){
        $error = 'ɾ���ɹ�';
        $str = <<<EOD
                                    <script type="text/javascript">
                                            alert("$error");
                                            </script>
EOD;
        echo $str;
    }

  include "../view/succeed.php";

}
else{
    header("Location:../login.php?id=1");
    exit;
}