<?php
/**
 * Created by PhpStorm.
 * User: peter
 * Date: 2015/8/25
 * Time: 13:58
 */
@$id=$_GET['id'];
@$a=$_COOKIE['name'];
//@$b=$_COOKIE['password'];
require_once "../model/HouseService.php";
$del=new HouseService();
$result=$del->deleteHouse($id);
$hs=new HouseService();
$row=$hs->queryUser($a,$b);
if($result==0){

    header("Location:loginController.php?id=1");
    exit;
}
else{
    header("Location:loginController.php?id=4");
    exit;
}