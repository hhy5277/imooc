<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/9/9
 * Time: 11:56
 */
$name=$_GET['n'];
require_once "../model/HouseService.php";
$user=new HouseService();
$bool=$user->checkByName($name);
if($bool){
    echo "user";
}else{
    echo "can user";
}