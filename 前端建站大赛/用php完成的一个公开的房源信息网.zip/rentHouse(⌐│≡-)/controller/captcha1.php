<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/9/11
 * Time: 14:34
 */
session_start();
$captcha=$_SESSION['auth_code'];
$n=$_GET['n'];
if($n==$captcha){
    echo 'true';
}else{
    echo 'false';
}