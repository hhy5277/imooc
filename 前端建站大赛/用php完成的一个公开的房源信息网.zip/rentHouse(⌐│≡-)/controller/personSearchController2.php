<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/8/20
 * Time: 10:35
 */
session_start();
@$title = $_COOKIE["title"];
@$price = $_COOKIE["price"];
@$street = $_COOKIE["street"];
@$type = $_COOKIE["type"];
@$floor = $_COOKIE["floorage"];
@$a=$_COOKIE['name'];
$user_id=$_SESSION['user_id'];

require_once "../model/HouseService.php";
require_once "../model/searchHouseService.php";
/*$hs = new searchHouseService();
$arr = $hs->searchHouse($title, $price, $street, $type, $floor);*/


//�õ��ֵ�������
$hstreet = new HouseService();
$streetArr = $hstreet->queryStreet();
//�õ���������
$houseType = new HouseService();
$typeArr = $houseType->queryHouseType();


//��ҳ
$hs = new searchHouseService();
$pageSize = 2;
if ($_GET == null) {
    $nowPage = 1;
} else {
    $nowPage = $_GET["nowPages"];
}
$totalPage = $hs->totalRecord1($pageSize, $title, $price, $street, $type, $floor,$user_id);//ȡ����ҳ��
$arr = $hs->personSearch($nowPage, $pageSize, $title, $price, $street, $type, $floor,$user_id);
include "../view/personSearch.php";