<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/9/10
 * Time: 14:05
 */
$districtId=$_POST['districtId'];
$html='';
require_once "../model/HouseService.php";
//�õ��ֵ�����
$hstreet=new HouseService();
$streetArr=$hstreet->getStreet($districtId);


switch($districtId){
    case $districtId:foreach($streetArr as $v){
        $a=$v[1];
        $b=$v[0];
        $a=mb_convert_encoding($a,'utf-8','gbk');//��ʽת��
        $b=mb_convert_encoding($b,'utf-8','gbk');
        $html=$html."<option value='$b'>$a</option>";
    }

}
echo $html;