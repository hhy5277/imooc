<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/8/14
 * Time: 16:56
 */
require_once "../model/HouseService.php";
@$a=$_COOKIE['name'];
$hs = new HouseService();
$pageSize = 2;
if ($_GET == null) {
    $nowPage = 1;
} else {
    $nowPage = $_GET["nowPages"];
}
$totalPage = $hs->totalRecord($pageSize);//ȡ����ҳ��
$arr = $hs->paging($nowPage, $pageSize);
//$totalRecord=$hs->checkRecord();
//�õ��ֵ�������
$hstreet=new HouseService();
$streetArr=$hstreet->queryStreet();
//�õ���������
$houseType=new HouseService();
$typeArr=$houseType->queryHouseType();




include "../view/houseList.php";