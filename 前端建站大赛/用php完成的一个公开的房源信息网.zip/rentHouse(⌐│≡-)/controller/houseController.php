<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/8/21
 * Time: 16:50
 */
$house_id=$_GET['id'];
@$a=$_COOKIE['name'];
require_once "../model/searchHouseService.php";
$hs=new searchHouseService();
$arr=$hs->queryHouse($house_id);
include "../view/housedetail.php";
