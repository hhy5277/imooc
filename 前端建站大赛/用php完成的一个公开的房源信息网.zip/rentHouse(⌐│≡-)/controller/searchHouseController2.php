<?php
/**
 * Created by PhpStorm.
 * User: pettr
 * Date: 2015/8/20
 * Time: 10:35
 */

@$title = $_COOKIE["title"];
@$price = $_COOKIE["price"];
@$street = $_COOKIE["street"];
@$type = $_COOKIE["type"];
@$floor = $_COOKIE["floorage"];
@$a=$_COOKIE['name'];

require_once "../model/HouseService.php";
require_once "../model/searchHouseService.php";
/*$hs = new searchHouseService();
$arr = $hs->searchHouse($title, $price, $street, $type, $floor);*/


//�õ��ֵ�������
$hstreet = new HouseService();
$streetArr = $hstreet->queryStreet();
//�õ���������
$houseType = new HouseService();
$typeArr = $houseType->queryHouseType();


//��ҳ
$hs = new searchHouseService();
$pageSize = 2;
if ($_GET == null) {
    $nowPage = 1;
} else {
    $nowPage = $_GET["nowPages"];
}
$totalPage = $hs->totalRecord($pageSize, $title, $price, $street, $type, $floor);//ȡ����ҳ��
$arr = $hs->paging($nowPage, $pageSize, $title, $price, $street, $type, $floor);
include "../view/searchHouse.php";