/**
 * Created by pettr on 2015/8/25.
 */
function xg(){
    var xg=window.confirm('确定修改要进入修改页面');
    if(xg==true){
        return true;
    }else{
        return false;
    }
}
function del(){
    var del=window.confirm('确定删除');
    if(del==true){
        return true;
    }else{
        return false;
    }
}
function ret(){
    window.location.href="loginController.php";
}