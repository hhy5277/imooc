/**
 * Created by peter on 2015/9/10.
 */
$(function(){
    $('#district').change(function(){
        var v=$(this).val();
        $.post("../controller/street.php",{districtId:v},function(data){
            $('#street').html(data);
        })
    })
});