/**
 * Created by peter on 2015/8/19.
 */
//到服务器检测用户名是否被占用
var xmlHttpReq;
function createXMLHttpRequest() {
    if (window.ActiveXObject) {
        xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
    } else if (window.XMLHttpRequest) {
        xmlHttpReq = new XMLHttpRequest;
    }
}
function RequestCallBack() {
    if (xmlHttpReq.readyState == 4) {
        if (xmlHttpReq.status == 200) {
            if (xmlHttpReq.responseText == "user") {
                document.getElementById('user').innerHTML = '该用户名已被注册';
               /* $(function(){
                    $('input[name=submit]').attr("disabled","disabled")
                })*/
            } else if (xmlHttpReq.responseText == "can user") {
                document.getElementById('user').innerHTML = '该用户名可以使用';
            }
        }
    }
}

function RequestCaptchaBack(){
    if (xmlHttpReq.readyState == 4) {
        if (xmlHttpReq.status == 200) {
            if (xmlHttpReq.responseText == "true") {
                document.getElementById('captcha').innerHTML = '验证码正确';
                document.getElementById('captcha').style.color='green';
                $(function(){
                 $('input[name=submit]').removeAttr('disabled');
                 })
            } else if (xmlHttpReq.responseText == "false") {
                document.getElementById('captcha').innerHTML = '验证码错误';
                document.getElementById('captcha').style.color='red';
                $(function(){
                    $('input[name=submit]').attr("disabled","disabled")
                })
            }
        }
    }
}

function a1() {
    var a = document.getElementById('a').value;
    var a2 = document.getElementById('user');

    if (a == '') {
        a2.innerHTML = '用户名不能为空';
        return false;
    }
    if (a != '') {
        createXMLHttpRequest();
        xmlHttpReq.open("GET", "controller/checkName.php?n=" + a, true);
        xmlHttpReq.send(null);
        xmlHttpReq.onreadystatechange = RequestCallBack;//回调函数
        if (a2.innerHTML =='该用户名可以使用' && xmlHttpReq.responseText == "can user") {
            return true;
        }
    }
    if(a2.innerHTML == '该用户名已被注册' && a!=''){
        return false;
    }
}
function tel() {
    var tel = document.getElementById('tel').value;
    var tel2 = document.getElementById('phone');
    if (tel == '' || tel.length!=11) {
        tel2.innerHTML = '请输入正确的手机号码';
        return false;
    }
    else {
        tel2.innerHTML = '';
        return true;
    }
}

function b1() {
    var b = document.getElementById('b').value;
    var b2 = document.getElementById('ma');
    if (b == '' || b.length < 3) {
        b2.innerHTML = '密码不能为空且密码至少3位';
        return false;
    } else {
        b2.innerHTML = '';
        return true;
    }
}
function c1() {
    var c = document.getElementById('c').value;
    var b = document.getElementById('b').value;
    var c2 = document.getElementById('mi');
    if (c != b) {
        c2.innerHTML = '两次输入的密码不一致';
        return false;
    } else {
        c2.innerHTML = '';
        return true;
    }
}
function d1() {
    var d = document.getElementById('d').value;
    var d2 = document.getElementById('xm');
    for (var i = 0; i < d.length; i++) {
        var d1 = d.charAt(i);
        if (d1 >= 0) {
            d2.innerHTML = '姓名格式不正确';
            return false;
        }
    }
}
$(function(){
    $('#e').blur(function(){

       /* var v=$(this).val();
        $.post("../controller/captcha1.php",{captcha:v},function(data){
            $('captcha').html(data);
        });*/

        createXMLHttpRequest();
        var a=$(this).val();
        xmlHttpReq.open("get", "controller/captcha1.php?n=" + a, true);
        xmlHttpReq.send(null);
        xmlHttpReq.onreadystatechange = RequestCaptchaBack;//回调函数
    })
});
function jy() {
    //如果通过验证，return true 如果不通过验证 return false
    //1.非空校验
    if (a1() == false || b1() == false || c1() == false || d1() == false || tel() == false) {
        alert('您输入的信息有误，请重新填写');
        return false;
    }
    return true;
}

function login(){
    var regUserName = /^[a-zA-Z][a-zA-Z0-9_]*$/;
    var user=document.getElementById('user');
    var err=document.getElementById('userErr');
    if(user.value==''){
        err.innerHTML="登陆名不能为空";
        return false;}
    if(!regUserName.test(user.value.trim())){
        err.innerHTML='您输入的格式不正确';
        return false;
    }
    if(user.value.length<6){
        err.innerHTML='用户名大于6位';
        return false;
    }

    else{
        err.innerHTML='';
        return true;
    }
}
function mmyz(){
    var pwd=document.getElementById('pwd');
    var err=document.getElementById('pwdErr');
    if(pwd.value==''){
        err.innerHTML="密码不能为空";
        return false;}
else{
        err.innerHTML='';
        return true;
    }
}
function qr(){
    if(login()==false||mmyz()==false){
        alert('请输入正确的用户名和密码');
        return false;
    }else{
        return true;
    }
}