/**
 * Created by pettr on 2015/9/10.
 */
$(function(){
    $('#district').change(function(){
        var v=$(this).val();
        $.post("../controller/getStreet.php",{districtId:v},function(data){
            $('#street').html(data);
        })
    })
});