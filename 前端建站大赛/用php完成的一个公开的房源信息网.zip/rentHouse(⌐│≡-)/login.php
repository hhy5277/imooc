<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title></title>
    <link type="text/css" rel="stylesheet" href="css/style.css"/>
    <script type="text/javascript" src="js/jquery-1.6.2.js"></script>
    <script type="text/javascript" src="js/regist.js"></script>
</head>
<body>
<div id="header" class="wrap">
    <div id="logo"><img src="images/logo.gif"/></div>
</div>
<div id="regLogin" class="wrap">
    <div class="dialog">
        <div class="box">
            <h4>�û���¼</h4>

            <form action="controller/loginController.php" method="post" onsubmit="return qr()">
                <div class="infos">
                    <table class="field" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td></td>
                            <td class="err"><?php
                                @$id = $_GET['id'];
                                if ($id == 1) {
                                    $error = '�˺Ż��������';
                                    $str = <<<EOD
                                    <script type="text/javascript">
                                            alert("$error");
                                            </script>
EOD;
                                    echo $str;
                                }
                                if($id==2){
                                   echo  'ע��ɹ���';
                                }
                              /*  $n="";
                                $p="";
                                if(!empty($_COOKIE)){
                                    $n=$_COOKIE["n"];
                                    $p=$_COOKIE["p"];
                                }
                                */?></td>
                        </tr>
                        <tr>
                            <td class="field">�� �� ����</td>
                            <td><input type="text" class="text" name="name" id="user" required="true" style="width: 150px;border: 1px solid grey" onblur="login()" <!--value="--><?php /*echo $n */?>"></td>
                            <td><b id="userErr" style="font: 14px/25px ����; color: red;font-weight: bold"></b></td>
                        </tr>
                        <tr>
                            <td class="field">��&nbsp;&nbsp;&nbsp;&nbsp;�룺</td>
                            <td><input type="password" class="text" name="password" id="pwd" required="true" style="width: 150px;border: 1px solid grey" onblur="mmyz()" <!--value="--><?php /*echo $p */?>"></td>
                            <td><b id="pwdErr" style="font: 14px/25px ����; color: red;font-weight: bold"></b></td>
                        </tr>
                        <!--<tr>
                            <td class="field">7�����¼</td>
                            <td><input type="checkbox" name="mdl"></td>
                        </tr>-->
                        <tr>
                            <td class="field">�� ֤ �룺</td>
                            <td>
                                <input type="text" name="captcha" id="e" style="width: 130px; height: 25px;border:1px solid grey"/>

                            </td>
                            <td ><b id="captcha"></b></td>
                        </tr>
                        <tr>
                            <td class="field"></td>
                            <td><img id="captcha_image" border="1" src="controller/captcha.php?r=<?php echo rand(); ?>" width="100" height="30"><a href="javascript:void(0)" onclick="document.getElementById('captcha_image').src='controller/captcha.php?r='+Math.random()">������?��һ��</a></td>
                        </tr>
                    </table>
                    <div class="buttons">
                        <input type="submit" name="submit" disabled="disabled" value="������¼"/>

                        <input type='button' value='ע��' onclick='document.location="regist.html"'/>

                    </div>
                </div>
            </form>

        </div>
    </div>
</div>
</body>
</html>