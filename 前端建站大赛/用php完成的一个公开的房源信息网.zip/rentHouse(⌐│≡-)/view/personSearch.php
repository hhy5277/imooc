<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
    "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title></title>
    <link type="text/css" rel="stylesheet" href="../css/style.css"/>
</head>
<body>
<div id="header" class="wrap">
    <div id="logo"><img src="../images/logo.gif"/></div>
    <?php if (empty($a)) { ?>
        <div style="font: 13px ����;position: relative;top: 55px;float: right;"><a
                href="../login.php">��¼</a>&nbsp;&nbsp;<a href="../regist.html">ע��</a></div>
    <?php } else { ?>
        <div style="font: 13px ����;position: relative;top: 55px;float: right;">��ӭ�㣬<?php echo $a ?>&nbsp;&nbsp;<a
                href="exitController.php">�˳�</a>&nbsp;&nbsp;<a href="loginController.php">����</a></div>
    <?php } ?>
</div>
<div id="navbar" class="wrap">
    <dl class="search clearfix">
        <form method="post" action="../controller/personSearchController.php" id='sform'>
            <input type="hidden" name="nowPage" id="nowPage"/>

            <dt>
            <ul>
                <li class="bold">������Ϣ</li>
                <li>���⣺<input type="text" class="text" value="<?php echo $title ?>"
                              name="title" id="title"/> <label class="ui-blue"><input
                            type="submit" name="search" value="��������"/></label>
                </li>
            </ul>
            </dt>
            <dd>
                <ul>
                    <li class="first">�۸�</li>

                    <li><select name='price' id="price"><?php if ($price == '') { ?>
                                <option value='' selected="selected">����</option>
                                <option value='0-1000'>1000Ԫ����</option>
                                <option value='1001-2000'>1001Ԫ��2000Ԫ</option>
                                <option value='2001-10000000'>2000Ԫ����</option>
                            <?php } elseif ($price == '0-1000') { ?>
                                <option value=''>����</option>
                                <option value='0-1000' selected="selected">1000Ԫ����</option>
                                <option value='1001-2000'>1001Ԫ��2000Ԫ</option>
                                <option value='2001-10000000'>2000Ԫ����</option>
                            <?php } elseif ($price == '1001-2000') { ?>
                                <option value=''>����</option>
                                <option value='0-1000'>1000Ԫ����</option>
                                <option value='1001-2000' selected="selected">1001Ԫ��2000Ԫ</option>
                                <option value='2001-10000000'>2000Ԫ����</option>

                            <?php } elseif ($price == '2001-10000000') { ?>
                                <option value=''>����</option>
                                <option value='0-1000'>1000Ԫ����</option>
                                <option value='1001-2000'>1001Ԫ��2000Ԫ</option>
                                <option value='2001-10000000' selected="selected">2000Ԫ����</option>
                            <?php } ?> </select></li>

                </ul>
            </dd>
            <dd>
                <ul>
                    <li class="first">����λ��</li>
                    <li><select name='street_id' id='street'>
                            <option value=''>����</option>
                            <?php
                            foreach ($streetArr as $v) {
                                if ($street == $v[0]) {
                                    ?>
                                    <option value='<?php echo $v[0] ?>'
                                            selected="selected"><?php echo $v[1] ?> </option>
                                <?php } else {
                                    ?>
                                    <option value='<?php echo $v[0] ?>'><?php echo $v[1] ?> </option>
                                <?php } ?>
                            <?php } ?>
                        </select></li>
                </ul>
            </dd>
            <dd>
                <ul>
                    <li class="first">����</li>
                    <li><select name='type_id'>
                            <option value=''>����</option>
                            <?php
                            foreach ($typeArr as $v) {
                                if ($type == $v[0]) {
                                    ?>
                                    <option value='<?php echo $v[0] ?>'
                                            selected="selected"><?php echo $v[1] ?> </option>
                                <?php } else {
                                    ?>
                                    <option value='<?php echo $v[0] ?>'><?php echo $v[1] ?> </option>
                                <?php } ?>
                            <?php } ?>
                        </select></li>
                </ul>
            </dd>
            <dd>
                <ul>
                    <li class="first">���</li>

                    <li><select name='floorage'>
                            <?php if ($floor == '') { ?>
                                <option value='' selected="selected">����</option>
                                <option value='0-40'>40����</option>
                                <option value='40-100'>40-100</option>
                                <option value='101-1000000'>100����</option>
                            <?php } ?>
                            <?php if ($floor == '0-40') { ?>
                                <option value=''>����</option>
                                <option value='0-40' selected="selected">40����</option>
                                <option value='40-100'>40-100</option>
                                <option value='101-1000000'>100����</option>
                            <?php } ?>
                            <?php if ($floor == '40-100') { ?>
                                <option value=''>����</option>
                                <option value='0-40'>40����</option>
                                <option value='40-100' selected="selected">40-100</option>
                                <option value='101-1000000'>100����</option>
                            <?php } ?>
                            <?php if ($floor == '101-1000000') { ?>
                                <option value=''>����</option>
                                <option value='0-40'>40����</option>
                                <option value='40-100'>40-100</option>
                                <option value='101-1000000' selected="selected">100����</option>
                            <?php } ?>
                        </select></li>
                </ul>
            </dd>
            <dd>
                <ul>
                    <li class="first"><a href="../controller/addPre.php" class="add">���ӷ�Դ</a>&nbsp;&nbsp;<a href="../controller/loginController.php" class="add">�ҵ�ȫ����Դ</a></li>
                </ul>
            </dd>
        </form>
    </dl>
</div>

<div class="main wrap">
    <table class="house-list">
        <?php if(empty($arr)) { ?>
            <tr><td"><center><img src="../images/nothing.jpg"><h4>�ף�û�и���ķ�ԴŶ��</h4></center></td></tr>
        <?php }
        else {
            foreach($arr as $v){?>
                <tr>
                    <td><img src="../images/<?php echo $v[11] ?>" alt=""></td>
                    <td>
                        <dl>
                            <dt><?php echo $v[0] ?></dt>
                            <dd><?php echo $v[7] ?> <?php echo $v[6] ?>,���<?php echo $v[5] ?>�O<br/>��ϵ��<?php echo $v[8] ?>
                                <br/>��ϵ��ʽ<?php echo $v[9] ?></dd>
                        </dl>
                    </td>
                    <td><?php echo $v[1] ?><br/><?php echo $v[2] ?></td>
                    <td>�۸�:<?php echo $v[3] ?>/��</td>
                    <td><a href="../controller/houseController.php?id='<?php echo $v[10] ?>'">�鿴����</a></td>
                </tr>
            <?php }?>
        <?php }?>
    </table>

    <div class="pager">
        <ul>
            <li class="current"><a href='../controller/personSearchController2.php?nowPages=1'>��ҳ</a></li>
            <li>
                <?php if ($nowPage == 1) { ?><a href="#">��һҳ </a><?php } else { ?>
                    <a href='../controller/personSearchController2.php?nowPages=<?php echo $nowPage - 1 ?>'>��һҳ</a>
                <?php } ?>
            </li>
            <li>
                <?php if ($nowPage == $totalPage) { ?> <a href="#">��һҳ</a><?php } else { ?>
                    <a href='../controller/personSearchController2.php?nowPages=<?php echo $nowPage + 1 ?>'>��һҳ</a>
                <?php } ?>
            </li>
            <li><a href='../controller/personSearchController2.php?nowPages=<?php echo $totalPage ?>'>ĩҳ</a></li>
        </ul>
        <span class="total"><?php echo $nowPage ?>/<?php echo $totalPage ?>ҳ</span>
    </div>
</div>
</body>
</html>