<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title></title>
    <link type="text/css" rel="stylesheet" href="../css/style.css" />
    <script src="../js/house.js" type="text/javascript"></script>
</head>
<body>
<div id="header" class="wrap">
    <div id="logo"><img src="../images/logo.gif"/></div>
    <div style="font: 13px ����;position: relative;top: 55px;float: right;">��ӭ�㣬<?php echo $row[3] ?>&nbsp;&nbsp;<a href="exitController.php">�˳�</a></div>
</div>

<div id="navbar" class="wrap">
    <dl class="search clearfix">
        <form method="post" action="personSearchController.php" id='sform'>
            <input  type="hidden"  name="nowPage" id="nowPage"/>

            <dt>
            <ul>
                <li class="bold">������Ϣ</li>
                <li>���⣺<input type="text" class="text" value=''
                              name="title"  id="title"/> <label class="ui-blue"><input
                        type="submit"  name="search" value="��������" /></label>
                </li>
            </ul>
            </dt>
            <dd>
                <ul>
                    <li class="first">�۸�</li>
                    <li><select name='price' id="price">
                        <option value=''>����</option>
                        <option value='0-1000'>1000Ԫ����</option>
                        <option value='1001-2000'>1000Ԫ��2000Ԫ</option>
                        <option value='2001-10000000'>2000Ԫ����</option>
                    </select></li>
                </ul>
            </dd>
            <dd>
                <ul>
                    <li class="first">����λ��</li>
                    <li><select name='street_id' id='street'>
                        <option value=''>����</option>
                        <?php
                foreach($streetArr as $v){?>
                        <option value='<?php echo $v[0]?>'><?php echo $v[1]?> </option>
                        <?php }?>
                    </select></li>
                </ul>
            </dd>
            <dd>
                <ul>
                    <li class="first">����</li>
                    <li><select name='type_id'>
                        <option value=''>����</option>
                        <?php
                foreach($typeArr as $v){?>
                        <option value='<?php echo $v[0]?>'><?php echo $v[1]?> </option>
                        <?php }?>
                    </select></li>
                </ul>
            </dd>
            <dd>
                <ul>
                    <li class="first">���</li>
                    <li><select name='floorage'>
                        <option value=''>����</option>
                        <option value='0-40'>40����</option>
                        <option value='40-500'>40-500</option>
                        <option value='500-1000000'>500����</option>
                    </select></li>
                </ul>
            </dd>
            <dd>
                <ul>
                    <li class="first"><a href="../controller/addPre.php" class="add">���ӷ�Դ</a>&nbsp;&nbsp;<a href="../controller/Paging.php" class="add">�鿴������Դ</a></li>
                </ul>
            </dd>
        </form>
    </dl>
</div>

<div class="main wrap">
    <table class="house-list" style="font-size: 13px;">
        <?php if(empty($arr)) { ?>
        <tr><td"><center><img src="../images/nothing.jpg"><h4>�ף��㻹û�ϴ�������ԴŶ��</h4></center></td></tr>
        <?php }
         else {
                foreach($arr as $v){?>
        <tr>
            <td><img src="../images/<?php echo $v[11] ?>" alt=""></td>
            <td>
                <dl>
                    <dt style="font-size: 15px;"><?php echo $v[0] ?></dt>
                    <dd> <?php echo $v[7] ?>,<?php echo $v[6] ?>,���:<?php echo $v[5] ?>�O<br/>��ϵ��:<?php echo $v[8] ?><br/>��ϵ��ʽ:<?php echo $v[9] ?></dd>
                </dl>
            </td>
            <td><?php echo $v[1] ?><br/><?php echo $v[2] ?></td>
            <td>�۸�:<?php echo $v[3] ?>/��</td>
            <td>
                <a href="../controller/houseController.php?id='<?php echo $v[10] ?>'">�鿴����</a><br/>
                <a href="changeHouse.php?id='<?php echo $v[10] ?>'"  onclick="return xg()">�޸ķ�Դ</a><br/>
                <a href="delHouse.php?id='<?php echo $v[10] ?>'" onclick="return del()">ɾ����Դ</a>
            </td>
        </tr>
        <?php }?>
        <?php }?>
    </table>
    <div class="pager">
        <ul>
            <li class="current"><a href='../controller/loginController.php?nowPages=1'>��ҳ</a></li>
            <li>
                <?php if($nowPage==1){ ?><a href="#">��һҳ </a><?php }
                else {?>
                    <a href='../controller/loginController.php?nowPages=<?php echo $nowPage -1 ?>'>��һҳ</a>
                <?php } ?>
            </li>
            <li><?php $hs->pagebar1($totalPage,$nowPage,3);?></li>
            <li>
                <?php if($nowPage==$totalPage){ ?> <a href="#">��һҳ</a><?php }
                else {?>
                    <a href='../controller/loginController.php?nowPages=<?php echo $nowPage +1 ?>'>��һҳ</a>
                <?php } ?>
            </li>
            <li><a href='../controller/loginController.php?nowPages=<?php echo $totalPage ?>'>ĩҳ</a></li>
        </ul>
        <span class="total"><?php echo $nowPage ?>/<?php echo $totalPage ?>ҳ</span>
    </div>
</div>
<div id="footer" class="wrap">
    <dl>
        <dt>�����ⷿ &copy; 2012 �������� ��ICP֤1000001��</dt>
        <dd>�������� �� ��ϵ��ʽ �� ������� �� ��������</dd>
    </dl>
</div>
</body>
</html>