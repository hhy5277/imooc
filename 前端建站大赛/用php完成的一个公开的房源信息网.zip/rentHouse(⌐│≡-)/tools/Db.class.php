<?php

/**
 * Created by PhpStorm.
 * User: peter
 * Date: 2015/8/6
 * Time: 11:15
 */
class Db
{
    private $link;

    function __construct(){
        $this->link=new mysqli("127.0.0.1","root","","rent");
        $this->link->query("SET NAMES gbk");
    }

    function demand($sql){
        $result=$this->link->query($sql);
        return $result;
    }

    function crud($sql)
    {
        $result = $this->link->query($sql);
        if ($result==0) {
            return 0;//ʧ��
        } else {
            if (mysqli_affected_rows($this->link) > 0) {
                return 1;
            } else {
                return 2;
            }
        }
    }
    //�ر�����
    function closeLink(){
        $this->link->close();
    }
}