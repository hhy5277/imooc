/*
SQLyog 企业版 - MySQL GUI v8.14 
MySQL - 5.6.17 : Database - rent
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`rent` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `rent`;

/*Table structure for table `district` */

DROP TABLE IF EXISTS `district`;

CREATE TABLE `district` (
  `district_id` int(11) NOT NULL AUTO_INCREMENT,
  `district_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`district_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `district` */

insert  into `district`(`district_id`,`district_name`) values (1,'东城区'),(2,'西城区'),(3,'海淀区'),(4,'丰台区'),(5,'朝阳区');

/*Table structure for table `house` */

DROP TABLE IF EXISTS `house`;

CREATE TABLE `house` (
  `house_id` int(11) NOT NULL AUTO_INCREMENT,
  `street_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `uesr_id` int(11) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `publish` date DEFAULT NULL,
  `floor` int(11) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`house_id`),
  KEY `FK_Relationship_2` (`type_id`),
  KEY `FK_Relationship_3` (`street_id`),
  KEY `FK_Relationship_4` (`uesr_id`),
  CONSTRAINT `FK_Relationship_2` FOREIGN KEY (`type_id`) REFERENCES `type` (`type_id`),
  CONSTRAINT `FK_Relationship_3` FOREIGN KEY (`street_id`) REFERENCES `street` (`street_id`),
  CONSTRAINT `FK_Relationship_4` FOREIGN KEY (`uesr_id`) REFERENCES `rentuser` (`uesr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

/*Data for the table `house` */

insert  into `house`(`house_id`,`street_id`,`type_id`,`uesr_id`,`title`,`description`,`price`,`publish`,`floor`,`contact`,`image`) values (2,4,1,3,'单间','干净卫生，临近公交站',1000,'2015-08-12',70,NULL,'thumb_house.gif'),(3,1,3,2,'家居房','超大面积，家具齐全',4000,'2015-08-07',120,NULL,'thumb_house.gif'),(5,5,2,4,'地铁房','临近地铁，交通方便',1400,'2015-08-20',80,NULL,'thumb_house.gif'),(6,3,1,4,'单间','干净卫生，临近公交站',1100,'2015-08-20',80,NULL,'thumb_house.gif'),(8,4,4,5,'单间','干净卫生，临近公交站',900,'2015-08-21',60,NULL,'thumb_house.gif'),(9,2,4,6,'家居房','超大面积，临近地铁',2000,'2015-08-21',160,NULL,'thumb_house.gif'),(12,3,2,1,'地铁房','临近地铁，交通方便',1200,'2015-08-26',90,NULL,'8a254b3ad8b493b2abace41987eab095.jpg'),(15,4,3,1,'家居房','家具齐全，面积宽广',3000,'2015-08-27',120,NULL,'9ae8064c4f40b6697dfa6e82da0e9865.jpg'),(16,2,1,1,'单间','干净卫生，交通方便',800,'2015-08-28',50,NULL,'7e37ccc787a28840f98c407e8d3d8940.jpg');

/*Table structure for table `rentuser` */

DROP TABLE IF EXISTS `rentuser`;

CREATE TABLE `rentuser` (
  `uesr_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `isadmin` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`uesr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `rentuser` */

insert  into `rentuser`(`uesr_id`,`name`,`password`,`username`,`tel`,`isadmin`) values (1,'zhangsan123','123','张三','18482317031','fault'),(2,'lisi123','123','李四','18243454543','fault'),(3,'wangwu123','123','王五','13925433663','fault'),(4,'zhaoliu123','123','赵六','13456785678','fault'),(5,'qianqi123','123','钱七','13467896789','fault'),(6,'peter123','123','彭田锋','18482137023','fault'),(7,'sunba123','123','孙八','13567899876','fault');

/*Table structure for table `street` */

DROP TABLE IF EXISTS `street`;

CREATE TABLE `street` (
  `street_id` int(11) NOT NULL AUTO_INCREMENT,
  `district_id` int(11) DEFAULT NULL,
  `street_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`street_id`),
  KEY `FK_Relationship_1` (`district_id`),
  CONSTRAINT `FK_Relationship_1` FOREIGN KEY (`district_id`) REFERENCES `district` (`district_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `street` */

insert  into `street`(`street_id`,`district_id`,`street_name`) values (1,5,'朝阳西路'),(2,5,'朝阳东路'),(3,4,'丰台东路'),(4,1,'东城一路'),(5,1,'东城二路'),(6,2,'西城一路'),(7,3,'海淀东路'),(8,4,'丰台西路'),(9,2,'西城二路'),(10,3,'海淀西路');

/*Table structure for table `type` */

DROP TABLE IF EXISTS `type`;

CREATE TABLE `type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `houseType` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `type` */

insert  into `type`(`type_id`,`houseType`) values (1,'一室一厅'),(2,'两室一厅'),(3,'三室一厅'),(4,'四室一厅');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
