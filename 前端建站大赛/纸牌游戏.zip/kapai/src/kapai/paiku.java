package kapai;

public class paiku {
	public int num;
	public String name;
	public paiku(int num,String name){
		this.num=num;
		this.name=name;
	}
	public paiku(){}
}
