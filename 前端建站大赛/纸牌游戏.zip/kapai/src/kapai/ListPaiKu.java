package kapai;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
/**
 * 红桃大于黑桃；黑桃大于方块
 * @author feng
 *
 */
public class ListPaiKu {
	public ListPaiKu(){}
	
	public List<paiku> list=new ArrayList<paiku>();
	public List<Integer> list2=new ArrayList<Integer>();
	public static List<paiku> list3=new ArrayList<paiku>();
	
	public void jinku(){
	list3.removeAll(list3);
	paiku[] pai={new paiku(1, "梅花2"),new paiku(2, "梅花3"),new paiku(3, "梅花4"),
			new paiku(4, "梅花5"),new paiku(5, "梅花6"),new paiku(6, "梅花7"),new paiku(7, "梅花8"),
			new paiku(8, "梅花9"),new paiku(9, "梅花10"),new paiku(10, "梅花J"),new paiku(11, "梅花Q"),
			new paiku(12, "梅花K"),new paiku(13, "梅花A"),new paiku(14, "方块2"),new paiku(15, "方块3"),
			new paiku(16, "方块4"),new paiku(17, "方块5"),new paiku(18, "方块6"),new paiku(19, "方块7"),
			new paiku(20, "方块8"),new paiku(21, "方块9"),new paiku(22, "方块10"),new paiku(23, "方块J"),
			new paiku(24, "方块Q"),new paiku(25, "方块K"),new paiku(26, "方块A"),new paiku(27, "黑桃2"),new paiku(28, "黑桃3"),
			new paiku(29, "黑桃4"),new paiku(30, "黑桃5"),new paiku(31, "黑桃6"),new paiku(32, "黑桃7"),
			new paiku(33, "黑桃8"),new paiku(34, "黑桃9"),new paiku(35, "黑桃10"),new paiku(36, "黑桃J"),
			new paiku(37, "黑桃Q"),new paiku(38, "黑桃K"),new paiku(39, "黑桃A"),new paiku(40, "红桃2"),
			new paiku(41, "红桃3"),new paiku(42, "红桃4"),new paiku(43, "红桃5"),new paiku(44, "红桃6"),
			new paiku(45, "红桃7"),new paiku(46, "红桃8"),new paiku(47, "红桃9"),new paiku(48, "红桃10"),
			new paiku(49, "红桃J"),new paiku(50, "红桃Q"),new paiku(51, "红桃K"),new paiku(52, "红桃A")};
	
	list.addAll(Arrays.asList(pai));
	System.out.println("牌库：");
	for (paiku p:list) {
		System.out.print(p.name+" ");
	}
	System.out.println();
}
	public void luanxu(){
	Random random=new Random();
	int i;
	for(int j=0;j<list.size();j++){
		do{
			i=random.nextInt(list.size());
		}while(list2.contains(i));
		list2.add(i);
		list3.add(list.get(i));
	}
//	for (paiku nam : list3) {
//		System.out.println(nam.name);
//	}
	}
	
}
