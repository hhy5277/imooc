package kapai;

public class GuiZe extends ListPaiKu{
	public static paiku paimian(int i){
		return list3.get(i);	
	}
	public static String max(paiku p1,paiku p2,paiku p3,paiku p4){
		paiku pi=p1;
		if(pi.num<p2.num){
			pi=p2;
		}
		if(pi.num<p3.num){
			pi=p3;
		}
		if(pi.num<p4.num){
			pi=p4;
		}
		if (pi==p1||pi==p3) {
			return "玩家1获胜";
		}
		if(pi==p2||pi==p4){
			return "玩家2获胜";
		}
		return null;
		
	}
}
