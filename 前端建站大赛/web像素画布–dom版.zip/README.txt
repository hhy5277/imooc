<p>简介：使用dom元素制作的像素画布，模拟像素效果。保存只能截屏咯！！！。</p><p>演示地址：http://www.h-five.com/HLpost/144.html</p><p><br/></p>

