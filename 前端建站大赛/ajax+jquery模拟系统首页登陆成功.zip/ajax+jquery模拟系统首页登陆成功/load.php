<?php
// echo "s1.jpg";
$id=$_POST['id'];
// print_r($_POST);
$username=$_POST['username'];
$password=$_POST['password'];
if($username=='admin' && $password=='123'){
	echo "yes";
}else{
	echo "no";
}
?>