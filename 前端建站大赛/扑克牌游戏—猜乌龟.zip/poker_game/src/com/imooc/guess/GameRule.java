package com.imooc.guess;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

//猜王八
public class GameRule {
	private Map<String, Player> match;
	private Set<Poker> cards;

	// 建立三个玩家
	public GameRule() {
		this.match = new HashMap<String, Player>();
		Player player = new Player("10086", "青龙");
		match.put("Long", player);
		player = new Player("10000", "白虎");
		match.put("Hu", player);
		player = new Player("10010", "猎豹");
		match.put("Bao", player);
	}

	// 洗牌
	private void shuffle() {
		cards = new HashSet<Poker>();
		for (int i = 0; i < 52; i++) {
			// System.out.println("Debug"+i);
			Poker card;
			while (true) {
				card = new Poker();
				if (cards.contains(card)) {
					continue;
				} else {
					break;
				}
			}
			this.cards.add(card);
		}
	}

	// 抽牌
	public void draw() {
		shuffle();
		// 随机抽取一张牌
		Poker king = new Poker();
		System.out.println("抽取乌龟牌： " + king.pokerFace());
		cards.remove(king);
		// 打印所有

		// Iterator<Poker> it = cards.iterator();
		// int i=0;
		// while(it.hasNext()){
		// if(i%6==0)
		// System.out.println();
		// i++;
		// System.out.print("\t"+it.next().pokerFace());
		// }
		// 按顺序发牌
		String[] key = { "Long", "Hu", "Bao" };
		int order = 0;
		for (Poker card : cards) {
			if (order == 3) {
				order = 0;
			}
			match.get(key[order]).getHand(card);
			order++;
		}
		System.out.println("==========抽牌阶段============");
		// 显示玩家手牌
		match.get(key[0]).showCards();
		System.out.println(match.get(key[0]).getName() + "玩家的手牌");
		match.get(key[1]).showCards();
		System.out.println(match.get(key[1]).getName() + "玩家的手牌");
		match.get(key[2]).showCards();
		System.out.println(match.get(key[2]).getName() + "玩家的手牌");
		System.out.println("==========弃牌阶段============");
		// 弃牌阶段
		this.discard(match.get(key[0]).getCards());
		System.out.println(match.get(key[0]).getName()+"玩家弃牌");
		this.discard(match.get(key[1]).getCards());
		System.out.println(match.get(key[1]).getName()+"玩家弃牌");
		this.discard(match.get(key[2]).getCards());
		System.out.println(match.get(key[2]).getName()+"玩家弃牌");
	}

	private void discard(List<Poker> cards) {
		Poker card_a = null;
		Poker card_b = null;
		String[] points = { "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A", "2" };
		int line = 0;
		for (String point : points) {

			for (Poker card : cards) {
				if(card.getPoint().equals(point)){
					if(card_a==null){
						card_a = card;
					}else if(card_b==null){
						card_b = card;
					}
				}
			}
			if (!(card_a == null || card_b == null)){				
				if (card_a.getPoint().equals(card_b.getPoint()) && card_a != card_b) {
					cards.remove(card_a);
					cards.remove(card_b);
					if(line%3==0){
						System.out.println();
					}line++;
					System.out.print("   \t"+card_a.pokerFace() + "   \t" + card_b.pokerFace() );
				}
			}
			card_a = null;
			card_b = null;
		}
		System.out.println();
	}

	public void gameBegin() {
		String[] key = { "Long", "Hu", "Bao" };
		boolean judge = true;
		int count = 0;
		int a = 0, b = 0, c = 0;
		List<String> player = new ArrayList<String>();
		player.addAll(Arrays.asList(key));
		while (judge) {
			// 新的回合开始
			System.out.println("--------------第" + (++count) + "回合-----------------");
			this.struggle(player);
			// 轮流向下家抽取随机的牌
			// 手牌和抽取的牌点数一致弃掉
			// 手牌为空的玩家胜出
			// 展示剩余玩家手牌
			for (int i = 0; i < player.size(); i++) {

				match.get(player.get(i)).showCards();
				System.out.println(match.get(player.get(i)).getName() + "玩家的手牌");
			}
			if (player.size() == 1) {
				judge = false;
			}
		}
		a = match.get(key[0]).getCards().size();
		b = match.get(key[1]).getCards().size();
		c = match.get(key[2]).getCards().size();
		if (a != 0)
			System.out.println("\n\t\t" + match.get(key[0]).getName() + "玩家成了小乌龟");
		if (b != 0)
			System.out.println("\n\t\t" + match.get(key[1]).getName() + "玩家成了小乌龟");
		if (c != 0)
			System.out.println("\n\t\t" + match.get(key[2]).getName() + "玩家成了小乌龟");
	}

	private void struggle(List<String> player) {

		int index = 1;
		for (int i = 0; i < player.size(); i++) {
			Poker card = null;
			if (player.size() == 1) {
				break;
			}
			List<Poker> hand_up = match.get(player.get(i)).getCards();
			List<Poker> hand_down = match.get(player.get(index)).getCards();
			String name_up = match.get(player.get(i)).getName();
			String name_down = match.get(player.get(index)).getName();
			// 抽取
			while (true) {
				card = new Poker();
				if (hand_down.contains(card)) {
					hand_down.remove(card);
					System.out.println(name_up + "玩家从" + name_down + "玩家手牌中抽取了一张" + card.pokerFace());
					break;
				} else
					continue;
			}
			// 排除
			boolean judge = false;
			for (Poker hand : hand_up) {
				if (card.getPoint().equals(hand.getPoint())) {
					card = hand;
					judge = true;
					break;
				}
			}
			if (judge) {
				System.out.println(name_up + " --消除-- " + card.pokerFace());
				hand_up.remove(card);
			} else {
				System.out.println(name_up + " ++获得++ " + card.pokerFace());
				hand_up.add(card);
			}
			// 移除玩家1
			for (int n = 0; n < player.size(); n++) {
				if (match.get(player.get(n)).getCards().size() == 0) {
					// match.remove(player.get(n));
					player.remove(n);
					break;
				}
			}
			// 移除玩家2
			for (int n = 0; n < player.size(); n++) {
				if (match.get(player.get(n)).getCards().size() == 0) {
					// match.remove(player.get(n));
					player.remove(n);
					break;
				}
			}

			index++;
			if (index == player.size()) {
				index = 0;
			}
		}
	}

}
