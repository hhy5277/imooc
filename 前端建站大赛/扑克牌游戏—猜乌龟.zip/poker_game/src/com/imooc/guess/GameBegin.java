package com.imooc.guess;

public class GameBegin {
	public static void main(String[] args) {
		GameRule game = new GameRule();
		game.draw();
		game.gameBegin();
		System.out.println("==========��Ϸ����=========");
	}
}
