package com.imooc.poker;

public class GameBegin {
    public static void main(String[] args) {
		GameRule game = new GameRule();
		game.draw();
		game.gameBegin();
		System.out.println("==========游戏结束=========");
	}
}


  

