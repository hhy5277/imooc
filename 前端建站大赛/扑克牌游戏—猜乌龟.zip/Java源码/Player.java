package com.imooc.poker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Player {
    private String ID;
	private String name;
	private List<Poker> cards;
	private static final int MAX = 13;

	public Player(String ID, String name) {
		this.ID = ID;
		this.name = name;
		cards = new ArrayList<Poker>();
	}
	public void getHand(Poker card){
		this.cards.add(card);
	}

	public void dealCards() {
		for (int i = 0; i < MAX; i++) {
			Poker card ;
			while (true) {
				card = new Poker();
				if (cards.contains(card)) {
					continue;
				}else{
					break;
				}
			}
			this.cards.add(card);
		}
		Collections.sort(cards);
	}
	public String getID(){
		return this.ID;
	}
	public String getName(){
		return this.name;
	}
	public List getCards(){
		return this.cards;
	}
	public List showCards(){
		int line=0;
		for (Poker poker : cards) {
			if(line%6==0){
				System.out.println();
			}line++;
			System.out.print("   \t"+poker.pokerFace());
		}
		System.out.println();
		return cards;
	}

}


  

