package com.imooc.project;

import java.util.Scanner;

public class CarFactory
{
	private int carNum;
	private Car[] cars;
	private int cap;

	public CarFactory(int num)
	{
		carNum = 0;
		cars = new Car[num];
		cap = num;
	}

	public int getCarNumbers()
	{
		return carNum;
	}

	public void createCars()
	{
		System.out.println("Creating cars (most 10 cars)...\n0 : TruckCar\t1 : SmartCar\t2 : SuperCar\n");
		Scanner in = new Scanner(System.in);
		while(carNum < cap)
		{
			System.out.println("input a car number, type -1 to finish...");
			int num = in.nextInt();
			if (num == -1) {
				break;
			}
			else if (num == 0) {
				System.out.println("input name:");
				String name = in.next();
				System.out.println("input rentMoney:");
				int rentMoney = in.nextInt();
				System.out.println("input goodsCapacity:");
				int goodsCapacity = in.nextInt();
				cars[carNum++] = new TruckCar(name, rentMoney, goodsCapacity);
			}
			else if (num == 1) {
				System.out.println("input name:");
				String name = in.next();
				System.out.println("input rentMoney:");
				int rentMoney = in.nextInt();
				System.out.println("input peopleCapacity:");
				int peopleCapacity = in.nextInt();
				cars[carNum++] = new SmartCar(name, rentMoney, peopleCapacity);
			}
			else if (num == 2) {
				System.out.println("input name:");
				String name = in.next();
				System.out.println("input rentMoney:");
				int rentMoney = in.nextInt();
				System.out.println("input goodsCapacity:");
				int goodsCapacity = in.nextInt();
				System.out.println("input peopleCapacity:");
				int peopleCapacity = in.nextInt();
				cars[carNum++] = new SuperCar(name, rentMoney, peopleCapacity, goodsCapacity);
			}
			else{
				System.out.println("illage input! try again");
			}
		}

		System.out.println("ok...we have created " + carNum + " cars");
	}

	public Car[] getCars()
	{
		return cars;
	}

	public void showCars()
	{
		if (carNum == 0) {
			System.out.println("there is no fucking cars...");
			return;
		}
		System.out.println("num \tname\tmenoy\t\tcapacity");
		for (int i = 0; i < carNum; ++i) {
			System.out.println(i + "\t" + cars[i]);
		}
	}

	public static void main(String[] args) {
		CarFactory cf = new CarFactory(10);
		cf.createCars();
		cf.showCars();
		Car[] cars = cf.getCars();
	}
}