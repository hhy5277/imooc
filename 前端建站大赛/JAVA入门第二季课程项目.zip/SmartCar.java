package com.imooc.project;

public class SmartCar extends Car
{
	private int peopleCapacity;

	public SmartCar(String name, int rentMenoy, int capacity)
	{
		this.name = name;
		this.rentMenoy = rentMenoy;
		this.peopleCapacity = capacity;
		this.type = CarType.SMARTCAR;
	}

	public String toString()
	{
		return name + "\t" + rentMenoy + "RMB/day\t" + peopleCapacity + " person";
	}

	public int getPeopleCapacity()
	{
		return this.peopleCapacity;
	}

	public void setPeopleCapacity(int peopleCapacity)
	{
		this.peopleCapacity = peopleCapacity;
	}

	public static void main(String[] args) {
		SmartCar sc = new SmartCar("audi", 100, 1000);
		System.out.println(sc.type);
		System.out.println(sc);
	}
}