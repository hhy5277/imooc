package com.imooc.project;

enum CarType{TRUCKCAR, SMARTCAR, SUPERCAR}

abstract class Car
{
	protected String name;
	protected int rentMenoy;
	protected CarType type;

	public abstract String toString();

	public String getName()
	{
		return this.name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public int getRentMenoy()
	{
		return this.rentMenoy;
	}
	public void setRentMenoy(int menoy)
	{
		this.rentMenoy = menoy;
	}

	public CarType getCarType()
	{
		return this.type;
	}
}
