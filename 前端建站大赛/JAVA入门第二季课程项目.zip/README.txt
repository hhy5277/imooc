<p>答答租车系统</p><p><br/></p><p>实现思路</p><p>1、虚拟基类Car，派生出三类车，第一类：客车SmartCar、第二类：货车<span style="line-height: 24.64px;">TruckCar</span><span style="line-height: 1.76em;">，第三类：既可以载货也可以载人SuperCar。</span></p><p>2、写了一个CarFactory，通过输入车的信息，生成一个包含这些车的数组</p><p>3、实现了租车主逻辑类：RentSystem类，用于与用户交互</p><p><br/></p><p>按老师提示的思路，自己写的，实现了所有功能。</p><p><br/></p>

