package com.imooc.project;

public class SuperCar extends Car
{
	private int peopleCapacity;
	private int goodsCapacity;

	public SuperCar(String name, int rentMenoy, int pCapacity, int gCapacity)
	{
		this.name = name;
		this.rentMenoy = rentMenoy;
		this.peopleCapacity = pCapacity;
		this.goodsCapacity = gCapacity;
		this.type = CarType.SUPERCAR;
	}

	public String toString()
	{
		return name + "\t" + rentMenoy + "RMB/day\t" + goodsCapacity + " kg and "+ peopleCapacity + " person";
	}

	public int getGoodsCapacity()
	{
		return this.goodsCapacity;
	}

	public void setGoodsCapacity(int goodsCapacity)
	{
		this.goodsCapacity = goodsCapacity;
	}

	public int getPeopleCapacity()
	{
		return this.peopleCapacity;
	}

	public void setPeopleCapacity(int peopleCapacity)
	{
		this.peopleCapacity = peopleCapacity;
	}

	public static void main(String[] args) {
		SuperCar sc = new SuperCar("audi", 100, 1000, 20);
		System.out.println(sc.type);
		System.out.println(sc);
	}
}