package com.imooc.project;

public class TruckCar extends Car
{
	private int goodsCapacity;

	public TruckCar(String name, int rentMenoy, int capacity)
	{
		this.name = name;
		this.rentMenoy = rentMenoy;
		this.goodsCapacity = capacity;
		this.type = CarType.TRUCKCAR;
	}

	public String toString()
	{
		return name + "\t" + rentMenoy + "RMB/day\t" + goodsCapacity + " kg";
	}

	public int getGoodsCapacity()
	{
		return this.goodsCapacity;
	}

	public void setGoodsCapacity(int goodsCapacity)
	{
		this.goodsCapacity = goodsCapacity;
	}

	public static void main(String[] args) {
		TruckCar tc = new TruckCar("audi", 100, 1000);
		System.out.println(tc.getRentMenoy());
		System.out.println(tc);
	}
}