package com.imooc.project;

import java.util.Scanner;

public class RentSystem
{
	private static int MAXCARS = 10;
	private static int MAXDAYS = 30;
	private Car[] rentedCars;
	private int rentNum;
	private int rentDays;

	public RentSystem()
	{
		rentedCars = new Car[MAXCARS];
		rentNum = 0;
		rentDays = 0;
	}

	public void showCars(Car[] cars, int carNum)
	{
		System.out.println("num \tname\tmenoy\t\tcapacity");
		for (int i = 0; i < carNum; ++i) {
			System.out.println(i + "\t" + cars[i]);
		}
	}

	public void rentCar(Car[] cars)
	{
		if(cars.length == 0) 
		{
			System.out.println("sorry there is no car for rent!");
			return;
		}

		// ask if really want to rent car
		Scanner sc = new Scanner(System.in);
		System.out.println("do you really want to rent cars?(yes to continue!)");
		String answer = sc.next().toUpperCase();
		
		if (!(answer.equals("Y") || answer.equals("YES"))) 
		{
			return;
		}

		// show the available cars
		System.out.println("The available cars:");
		showCars(cars, cars.length);

		// input the num that want to rent
		System.out.println("How many cars do you want to rent? (1 ~ " + (MAXCARS - 1) + ")");
		int num = sc.nextInt();
		while(num <= 0 || num >= MAXCARS)
		{
			System.out.println("we cann't rent " + num + " cars for you, try again( 1 ~ " + (MAXCARS - 1)  + " ) !");
			num = sc.nextInt();
		}  // och, you not really want to rent cars!


		for (int i = 0; i < num; ++i)
		{
			System.out.println("input the "+ (i+1) + " car's number:");
			int n = sc.nextInt();
			if (n < 0 || n >= cars.length) {
				System.out.println("illegal num, pealse try again.");
				i--;
				continue;
			}

			rentedCars[rentNum++] = cars[n];
		} 

		// input rent days
		System.out.println("How many days to rent?");
		rentDays = sc.nextInt();
		while(rentDays <= 0 || rentDays >= MAXDAYS)
		{
			System.out.println("we cann't rent " + num + " cars for you, try again( 1 ~ " + (MAXDAYS - 1)  + " ) !");
			rentDays = sc.nextInt();
		} 

		System.out.println("This is you have choosed cars:");
		showCars(rentedCars, rentNum);

		// generate the bills
		int goodsCarNum = 0;
		Car[] goodsCar = new Car[MAXCARS];

		int peopleCarNum = 0;
		Car[] peopleCar = new Car[MAXCARS];

		int rentCoseAll = 0;
		int totalPeople = 0;
		int totalGoods = 0;
		for (int i = 0; i < num; ++i) {
			CarType t = rentedCars[i].getCarType();
			if (t == CarType.TRUCKCAR) {
				TruckCar tcar = (TruckCar)rentedCars[i];
				goodsCar[goodsCarNum++] = rentedCars[i];
				totalGoods += tcar.getGoodsCapacity();
			}
			else if (t == CarType.SMARTCAR) {
				SmartCar scar = (SmartCar)rentedCars[i];
				peopleCar[peopleCarNum++] = rentedCars[i];
				totalPeople += scar.getPeopleCapacity();
			}
			else if (t == CarType.SUPERCAR) {
				SuperCar spcar = (SuperCar)rentedCars[i];
				goodsCar[goodsCarNum++] = rentedCars[i];
				peopleCar[peopleCarNum++] = rentedCars[i];
				totalPeople += spcar.getPeopleCapacity();
				totalGoods += spcar.getGoodsCapacity();
			}

			rentCoseAll += rentedCars[i].getRentMenoy();
		}

		// output bills
		System.out.println("\nThe goods cars:");
		System.out.print("\t");
		for (int i = 0; i < goodsCarNum; ++i) {
			System.out.print(goodsCar[i].getName() + "\t");
		}
		System.out.print("totalGoods: " + totalGoods + " kg\n");

		System.out.println("\nThe people cars:");
		System.out.print("\t");
		for (int i = 0; i < peopleCarNum; ++i) {
			System.out.print(peopleCar[i].getName() + "\t");
		}
		System.out.print("totalPersons: " + totalPeople + " person\n");

		System.out.println("\nTotal Rent money : " + rentCoseAll*rentDays + " RMB");
	}	


	public Car[] getCars()
	{
		CarFactory cf = new CarFactory(5);
		cf.createCars();
		return cf.getCars();
	} 

	public static void main(String[] args) {
		RentSystem rsys = new RentSystem();
		Car[] cars = rsys.getCars();
		rsys.rentCar(cars);
	}
}