<?php
require_once('../config/connect.php');
//把传递过来的信息入库
//print_r ($_POST);
if (!(isset($_POST['title'])&&(!empty($_POST['title'])))){
	echo "<script>alert('标题不能为空');window.location.href='article.add.php'</script>";
}

$title=$_POST['title'];
$author=$_POST['author'];
$description=$_POST['description'];
$content=$_POST['content'];
$dateline= time();
$insertsql="insert into article(title,author,description,content,dateline) values('$title','$author','$description','$content',$dateline)";
//var_dump($insertsql);die;  
$con = mysql_query($insertsql);
if($con){
	echo "<script>alert('文章发布成功');window.location.href='article.add.php'</script>";
}else {
	echo "<script>alert('文章发布失败');window.location.href='article.add.php'</script>";
}
