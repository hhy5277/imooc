<?php
require_once('../config/connect.php');
$id=$_GET['id'];
$deletesql = "delete from article where id=$id";

//var_dump($deletesql);die;
$con = mysql_query($deletesql);
if ($con) {
	echo "<script> alert('文章删除成功！');window.location.href='article.modify.php'</script>";
}else{
	echo "<script> alert('文章删除失败，请重试！');window.location.href='article.modify.php'</script>";
}