<?php
require_once('../config/connect.php');

$id = $_POST['id'];//通过隐藏域传递过来的id
$title=$_POST['title'];
$author=$_POST['author'];
$description=$_POST['description'];
$content=$_POST['content'];
$dateline=time();

$updatasql="update article set title='$title',author='$author',description='$description',
content='$content',dateline=$dateline where id=$id";

$con = mysql_query($updatasql);
if ($con) {
	echo "<script> alert('文章更改成功！');window.location.href='article.modify.php'</script>";
}else{
	echo "<script> alert('文章更改失败，请重试！');window.location.href='article.modify.php'</script>";
}