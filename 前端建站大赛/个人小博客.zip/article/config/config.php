<?php
header("Content-type:text/html;charset=utf-8");
define('HOST','localhost');
define('USERNAME', 'root');
define('PASSWORD','');
?>