<p>使用该程序需要先安装mysql , 并创建对应数据库，表等（名称在代码里有）</p><p>注意：不能传输空的文件。会报异常！</p><ol class=" list-paddingleft-2" style="list-style-type: decimal;"><li><p>entity包下是实体类（用户类，文件类，封装的通信对象类）<br/></p></li><li><p>service包下是业务类代码</p></li><li><p>Util 包下是数据库和文件工具类<br/></p></li></ol>

