package entity;

import java.io.Serializable;

public class MyFile implements Serializable{
	
	private static final long serialVersionUID = 3L;
	private	String fname;
	private byte[] fcontent;
	
	public MyFile() {
		super();
	}
	public MyFile(String fname, byte[] fcontent) {
		super();
		this.fname = fname;
		this.fcontent = fcontent;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public byte[] getFcontent() {
		return fcontent;
	}
	public void setFcontent(byte[] fcontent) {
		this.fcontent = fcontent;
	}
	
}
