package service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * 文件的存储 
 * 内容存到系统 路径存到数据库 
 * 路径为： 本工程目录demo/用户名/文件名
 * @author SEAN
 *
 */
public class FlieService {
	
	public void save(byte[] content,String path,String fname) {
		
		try {
			
			File file1= new File(path);
			if(!file1.exists())
				file1.mkdirs();
			BufferedOutputStream bout = 
					new BufferedOutputStream(new FileOutputStream(new File(path,fname)));
			bout.write(content);			
			bout.flush();
			bout.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
