package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Util.DBUtil;
import entity.User;

/**
 * 用户的业务处理
 * 登录 注册  文件路径存储 需要数据库有 user filepath 两张表
 * @author SEAN 
 *
 */
public class UserService {

	Connection conn;
	PreparedStatement ptmt;
	ResultSet rs; 
	/**
	 * 用户登录
	 * @param user
	 * @return 和数据库匹配成功返回true
	 */
	public boolean login(User user){
		String sql = "select * from user where username=? and password=?";
		// 获取数据库连接
		conn = DBUtil.getConnection();
		try {
			ptmt = conn.prepareStatement(sql);
			ptmt.setString(1, user.getUsername());
			ptmt.setString(2, user.getPassword());
			rs = ptmt.executeQuery();
			if(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.closeAll(rs,ptmt, conn);
		}		
		return false;
	}	
	/**
	 * 注册用户
	 * @param user 
	 */
	public void register(User user)
	{
		String sql = "insert into user(username,password) values(?,?)";
		conn = DBUtil.getConnection();
		try {
		ptmt = conn.prepareStatement(sql);
		ptmt.setString(1, user.getUsername());
		ptmt.setString(2, user.getPassword());
		ptmt.execute();		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 保存文件的路径
	 * @param username 上传该文件的的用户
	 * @param path	文件存储的路径
	 */
	public void saveFilepath(String username,String path){
		String sql = "insert into filepath (filepath,username) values(?,?)";
		conn = DBUtil.getConnection();
		try {
			ptmt = conn.prepareStatement(sql);
			ptmt.setString(1, path);
			ptmt.setString(2, username);
			// 上传相同文件 主键会相同 报 MySQLIntegrityConstraintViolationException 异常
			ptmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
