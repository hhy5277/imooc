
public class Clientstart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Myclient cMyclient = new Myclient();
		cMyclient.showmenu();
	}

}
