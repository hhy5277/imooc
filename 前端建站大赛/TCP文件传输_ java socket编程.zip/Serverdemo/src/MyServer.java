
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import service.FlieService;
import service.UserService;
import entity.MyFile;
import entity.MyMessage;
import entity.User;



public class MyServer implements Runnable {

	public Socket doorsSocket = null;
	public UserService us;
	public FlieService fs;
	public String cmd;
	public MyMessage mss;
	public User curUser;
	private static String FilePath = "demo/";
	public ObjectOutputStream oos;
	public ObjectInputStream oin;
	public MyServer(Socket doorSocket){
		this.doorsSocket = doorSocket;
	}
	
	@Override
	public void run() {		
		try {
			System.out.println("欢迎");
			oin = new ObjectInputStream(doorsSocket.getInputStream());
			oos= new ObjectOutputStream(doorsSocket.getOutputStream());
			us = new UserService();
			fs = new FlieService();
			
			while(true){// 循环等待读取 信息对象
				mss = (MyMessage) oin.readObject();
				cmd = mss.getCmd();
				if(cmd.equals("login")){					
					curUser = (User) mss.getData();
					boolean flag = us.login(curUser);
					if(flag){
						MyMessage	rem = new MyMessage();
						rem.setResult("登录成功！");
						oos.flush();
						oos.writeObject(rem);
						oos.flush();
					}else {
						MyMessage rem = new MyMessage();
						rem.setResult("用户名或者密码不正确，请重新登录！");
						oos.flush();
						oos.writeObject(rem);
						oos.flush();
					}				
				}
				if(cmd.equals("register")){					
					User user = (User) mss.getData();
					us.register(user);
					MyMessage	rem = new MyMessage();
					rem.setResult("注册成功！");	
					oos.flush();
					oos.writeObject(rem);
					oos.flush();
				}
				if(cmd.equals("upload")){	
					String path = FilePath +curUser.getUsername();
					MyFile mf = (MyFile) mss.getData();					
					fs.save(mf.getFcontent(),path,mf.getFname());
					us.saveFilepath(curUser.getUsername(),path+"/"+mf.getFname());					
					MyMessage	rem = new MyMessage();
					rem.setResult("存储成功！");
					oos.flush();
					oos.writeObject(rem);
					oos.flush();
				}	
				if(cmd.equals("exit")){
					break;}				
			}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(oos!=null)
					oos.close();
				if(oin!=null)
					oin.close();
				if(doorsSocket!=null)
					doorsSocket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
