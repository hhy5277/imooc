
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import entity.MyFile;
import entity.MyMessage;
import entity.User;


public class Myclient {

	int choice;
	BufferedReader br;
	Socket clientSocket	;	  
	ObjectOutputStream oos;
	ObjectInputStream  ins;

	public void showmenu(){					
		try {	//建立连接	
				clientSocket = new Socket("localhost",6789);
				oos = new ObjectOutputStream(clientSocket.getOutputStream());
				ins = new ObjectInputStream(clientSocket.getInputStream());
				//控制台输入
				br = new BufferedReader(new InputStreamReader(System.in));
				//循环
				while(true){
					//显示界面 show UI 
					initview();
					choice = Integer.parseInt(br.readLine());
					if(1==choice)
						// 登录
						login();
					else if (2==choice) {
						// 注册
						register();
					}
					else if (3==choice) {
						// 退出
						goout();
						break;
					}											
				}			
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{				
					try {
						if(oos!=null)
							oos.close();
						if(ins!=null)
							ins.close();
						if(clientSocket!=null)
							clientSocket.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
			}
		
	}
	
	public void initview(){
		System.out.println("** 欢迎使用 SEAN 文件云存储服务器 **");
		System.out.println(" 1.登录  2.注册 3.退出 ");
	}
	
	public void login() throws IOException	{
		User curUser = new User();
		System.out.print("输入用户名:");
		curUser.setUsername(br.readLine());
		System.out.print("输入密码：");
		curUser.setPassword(br.readLine());	
		
		MyMessage mss = new MyMessage();
		mss.setCmd("login");
		mss.setData(curUser);			
		sendmessage(mss);
		String re = getmessage().getResult();
		System.out.println(re);
		try {
			if(re.equals("登录成功！"))
			upload();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void register() throws IOException{
				
			System.out.print("输入用户名:");
			String name = br.readLine();
			System.out.print("输入密码：");
			String password = br.readLine();
			System.out.print("再输入密码");
			String password2 = br.readLine();
			if(!password.equals(password2)){
				System.out.println("密码不一致请重输");
				System.out.println("#########################");
				return;
			}
			User newUser = new User(name,password);
			
			MyMessage mss = new MyMessage();
			mss.setCmd("register");
			mss.setData(newUser);
			sendmessage(mss);
			System.out.println(getmessage().getResult());
			
	}
	
	public void upload() throws IOException{
		
		System.out.println("请输入上传文件的路径");
		String path = br.readLine();
		System.out.println("请输入文件名");
		String fname = br.readLine();		
		File src = new File(path+"\\"+fname);
		if (!src.exists()) {
			System.out.println("文件："+src+"不存在");
		}
		if (!src.isFile()) {
			System.out.println(src+"不是文件");			
		}
	
		FileInputStream fis = new FileInputStream(src);
		byte [] buf = new byte[fis.available()];
		int b;
		//读取空文件会死循环 b = 0
		while ((b = fis.read(buf)) != -1) {
			MyFile mf = new MyFile();
			mf.setFname(fname);
			mf.setFcontent(buf);
			
			MyMessage m = new MyMessage();
			m.setCmd("upload");
			System.out.println(m.getCmd());
			m.setData(mf);
			sendmessage(m);
		}
		System.out.println(getmessage().getResult());
		
	}
	
	public void goout(){
		MyMessage mss = new MyMessage();
		mss.setCmd("exit");
		sendmessage(mss);
	}
	// 发送信息
	public void sendmessage(MyMessage mss){
		try {
			oos.flush();
			oos.writeObject(mss);
			oos.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	// 接受信息
	public MyMessage getmessage(){
		MyMessage mss = null;
		try {
			mss = (MyMessage) ins.readObject();	
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mss;	
	}

}
