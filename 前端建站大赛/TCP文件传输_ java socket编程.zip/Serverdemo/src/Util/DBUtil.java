package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 数据库的操作  建立连接 关闭连接 增删改查
 * @author SEAN
 *
 */
public class DBUtil {
	
	/**
	 * @return Connection 数据库的连接
	 */
	public static Connection getConnection() {		
		String driverClassname = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/userinfo?characterEncoding=utf8";
		String username ="root";
		String password = "root";	
		java.sql.Connection	connection = null;
		
		try {//1.加载驱动 load driver
			Class.forName(driverClassname);
			//2.get the database connection		 
			connection	= DriverManager.getConnection(url,username,password);	
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//3.返回连接
		return connection;			
	}

	/**
	 * 
	 * @param rs  返回集合
	 * @param stmt SQL语句	
	 * @param conn 连接
	 */
	public static void closeAll(ResultSet rs,Statement stmt,Connection conn){		
		try {
			if(rs!= null)			
				rs.close();			
			if(stmt!= null)
				stmt.close();
			if(conn !=null)
				conn.close();} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
