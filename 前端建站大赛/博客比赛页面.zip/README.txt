<p>这是我通过几天时间完成的的一个前端博客demo。想到在如此高端大型的网站上参加比赛，心情还是无比激动的。fighting！fighting! fighting!</p><p>附上网址：http://newblog.supercjh.com/</p>

