(function($){
	var Loding = function(obj){
		/**
		 * 默认配置结构体
		 * text 等待文字信息
		 * active 文字后动态内容
		 * start 初始化动态内容长度
		 * time 动态时间长度
		 * length 动态内容最长长度
		 */
		this.defalutConfig = {
			'text' : '等待加载',
			'active' : '·',
			'length' : 3,
			'start' : 1,
			'time' : 1000
		}
		if(obj&&typeof(obj)=='object'){
			$.extend(this.defalutConfig,obj);
		}
		this.parentNode = $('body');
		this.Node = null;
		this.Contener = null;
		this.render();
	}

	Loding.prototype = {
		showloading : function(){
			this.Node.show();
		},
		/**
		 * 初始化函数构造等待页面结构并添加到body（可做修改this.parentNode对应）元素中。	
		 * @return 返回undefined，无返回值。
		 */
		render : function(){
			this.Node = $('<div id="cover">').css({
				'position': 'fixed',
				'height': '100%',
				'background-color': 'rgba(0,0,0,.5)',
				'width': '100%',
				'top': 0,
				'z-index': 99999,
				'display': 'none'
			});
			this.Node.appendTo(this.parentNode);
			this.Contener = $('<div id="contener">').css({
				'position': 'absolute',
				'width': '180px',
				'height': '120px',
				'top': '50%',
				'left': '50%',
				'margin-left': '-90px',
				'margin-top': '-60px',
				'background-color': '#fff',
				'border-radius': '3px',
				'box-shadow': '0 0 7px #000',
				'line-height': '120px',
				'text-align': 'center',
				'color': '#f60',
				'overflow' : 'hidden'
			});
			this.Contener.appendTo(this.Node);
			this.active();
		},
		/**
		 * 隐藏等待页面
		 * @return 返回undefined，无返回值
		 */
		closeloading : function(){
			this.Node.hide();
		},
		/**
		 * 动态等待框中的文字
		 * @return 返回undefined，无返回值
		 */
		active : function(){
			var self = this;
			var nowText = this.defalutConfig.text;
			for(i=0;i<this.defalutConfig.start;i++){
				nowText += this.defalutConfig.active;
			}
			$('#contener').text(nowText);
			this.defalutConfig.start++;
			if(this.defalutConfig.start>this.defalutConfig.length){
				this.defalutConfig.start =1;
			}
			window.setTimeout(function(){
				self.active();
			},this.defalutConfig.time)
		},
		/**
		 * 更改配置
		 * @param obj 传入的配置结构体
		 * @return 返回undefined，无返回值
		 */
		config : function(obj){
			if(obj&&typeof(obj)=='object'){
				$.extend(this.defalutConfig,obj);
			}
		},
		/**
		 * 移除等待页面
		 * @return 返回undefined，无返回值
		 */
		destroy : function(){
			this.Node.remove();
		}
 	}

 	window['Loding'] = Loding;

})(jQuery);