<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>跟随鼠标移动的DIV</title>
<style type="text/css">
body{
    background-image:url(kong.jpg);
	background-size:100% 768px;
}
 .tip{background-image:url(1.gif);width:240px; height:180px; position:absolute}
</style>
<script type="text/javascript">
var flag = true;//#######判断--鼠标再次移入界面，DIV是否再次展现########
//获取鼠标的坐标
function getMouseXY(e){
	   var posx=0,posy=0;//鼠标的坐标的初始位置
	   if(e==null)    e=window.event;//给e一个“事件对象的状态”
	   
	   if(e.pageX || e.pageY){//参照浏览器内容区域的左上角，但它不会随着滚动条而变动
			  posx=e.pageX;
			  posy=e.pageY;
	   }else if(e.clientX || e.clientY){//参照浏览器内容区域的左上角，该参照点会随之滚动条的移动而移动
			  if(document.documentElement.scrollTop){//获取当前页面的滚动条纵坐标位置
				posx=e.clientX+document.documentElement.scrollLeft;
				posy=e.clientY+document.documentElement.scrollTop;
			   }else{
				posx=e.clientX+document.body.scrollLeft;
				posy=e.clientY+document.body.scrollTop;
			   }
	   }
	   
	   return {
			  X : posx,
			  Y : posy
	   }
}
//创建一个DIV
function getDiv(){
       return document.createElement("div");
}
//获取标签的id
function g(id){return document.getElementById(id);}
//展现出DIV
function showTip(){
	   if(!flag) return;
	   var domE = g("tip");
	   if(!domE){
			domE = getDiv();
			domE.setAttribute("id","tip");
			document.body.appendChild(domE);
			domE.className = "tip";
	   }
	   var m = getMouseXY();
	   //定义DIV消失的位置
	   with(domE.style){
			 top = (m.Y+10)+"px";
			 left = (m.X)+"px";
	   }
}
//页面加载时，调用的函数
window.onload = function(){
	 //鼠标移入界面内，DIV展现出来
     document.documentElement.onmousemove = function(){showTip();}
	 //鼠标移出界面，DIV消失
     document.documentElement.onmouseout = function(){
			flag = true;
			if(g("tip"))   document.body.removeChild(g("tip"));
     }
	 //单击鼠标，DIV消失
     document.documentElement.onclick = function(){
			flag = false;
			if(g("tip"))   g("tip").style.display = "none";
     }
}
</script>
</head>
<body>
</body>
</html>

  

