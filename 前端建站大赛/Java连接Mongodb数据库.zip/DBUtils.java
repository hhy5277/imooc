package utils;

import java.net.UnknownHostException;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;

public class DBUtils {

	private static final String host = "127.0.0.1"; 
	private static final String dbName = "ssinfo"; 
	private static final int port = 27017; 
	private static Mongo mongo; 
	private static DB db; 

	public static DBCollection getCollection(String collectionName) {
		try {
			mongo = new Mongo(host, port); 
			db = mongo.getDB(dbName); 
			// db.authenticate(username, passwd);
		} catch (UnknownHostException e) {
			e.printStackTrace(); 
		} catch (MongoException e) {
			e.printStackTrace(); 
		}
		DBCollection collection = db.getCollection(collectionName); 
		return collection; 
	}

	public static void colseCon() {
		if(mongo != null){
			mongo.close(); 
		}
		if(db != null){
			db = null; 
		}
	}
}

