
$(document).ready(function(){

//签到时间
var myDate = new Date();       
var yue=myDate.getMonth();       //获取当前月份(0-11,0代表1月)
yue++;
var day=myDate.getDate();        //获取当前日(1-31)
$("#yue").html(yue);
$("#day").html(day);
$("#yue1").html(yue);           //试玩报告
$("#day1").html(day);
var today=myDate.getDay();    
var xingqi=new Array('周日','周一','周二','周三','周四','周五','周六');
$("#xingqi").html(xingqi[today]);

//我的积分
$(".yhzx_r .wdjf .wdjf_title span").click(function(){
    var wdjf_title=$(this).index();
    $(this).addClass("xz");
    $(this).siblings().removeClass("xz");
    $(".wdjf li").eq(wdjf_title).show();
    $(".wdjf li").eq(wdjf_title).siblings().hide();
});

//人数试玩 ，人数最多
$(".yysw_title li").mouseover(function(){
     var rmsw_index=$(this).index();
    $(this).addClass("hongzi");
    $(this).siblings().removeClass("hongzi"); 
    $(".yysw_yx ul").eq(rmsw_index).show(); 
    $(".yysw_yx ul").eq(rmsw_index).siblings().hide(); 
    });


//游戏试玩
$(".yxsw_title>span").click(function(){
    var yxsw_index=$(this).index()-1;
    $(this).addClass("liebiao_xz");
    $(this).siblings().removeClass("liebiao_xz");
    $(".yxsw_box>ul>li").eq(yxsw_index).show();
    $(".yxsw_box>ul>li").eq(yxsw_index).siblings().hide();
});

//悬浮栏
$(".xfl_ty p").click(function(){    
    $("html,body").animate({scrollTop:0},400);
});

//新闻列表
var xw_index=$(".xwlb_nr>ul>li").size();
xw_index=parseInt(xw_index/5);
for(var i=1;i<=xw_index;i++){
    var xwlb_w=i*5-1;
    $(".xwlb_nr li").eq(xwlb_w).css("border-bottom","1px dashed #ccc")
};

 //晒单详情
$(".sdwz_hd li").click(function(){
    var sdwz_index=$(this).index();
    $(this).find("img").addClass("hg_img");
    $(this).find("span").show();
    $(this).siblings().find("img").removeClass("hg_img");
    $(this).siblings().find("span").hide();
    var sdwz_margin=-(sdwz_index*600);
    $(".sdwz_bd ul").animate({marginLeft:sdwz_margin+"px"},500);
});

//晒单中心
$(".sdlb_xuanzhe span").click(function(){
    var sdzx_index=$(this).index();
    $(this).addClass("sdlb_xz");
    $(this).siblings().removeClass("sdlb_xz");
    $(".sdlb_nr>ul>li").eq(sdzx_index).show();
    $(".sdlb_nr>ul>li").eq(sdzx_index).siblings().hide();
});

 //添加想要的产品
$(".tjjp").click(function(){
    $(".want_jp").show();
    $(".mengban").show();
});
$(".want_jp .qx").click(function(){
    $(".want_jp").hide();
    $(".mengban").hide();
});

//产品详情页
$(".xxnr .liebiao span").click(function(){
    var liebiao_index=$(this).index();
    $(this).addClass("liebiao_xz");
    $(this).siblings().removeClass("liebiao_xz");
    $(".xxnr ul li").eq(liebiao_index).show();
    $(".xxnr>ul li").eq(liebiao_index).siblings().hide();
});

//回复框显示隐藏
$(".pl_hf #hf").click(function(){
    $(this).parent().parent().find(".pl_plk").toggle();
});

//帮助中心
$(".bzxx_l dd a").click(function(){
    var bzzxindex=$(this).index();
    $(this).attr('id','bzxx_l_click');
    $(this).siblings().removeAttr('id','bzxx_l_click');
    $(".bzxx_r ul li").eq(bzzxindex).show();
    $(".bzxx_r ul li").eq(bzzxindex).siblings().hide();
    $(".zhejiao").show();
});

//热门活动banner
$(".rmhd_nr_l").click(function(){
    var rmhd_l=$(".rmhd_nr .rmhd_nr_xz .xz_red").index();
    if(rmhd_l==0){
        rmhd_l=2;
        $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd_l).addClass("xz_red");
        $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd_l).siblings().removeClass("xz_red");
        $(".rmhd_nr ul li").eq(rmhd_l).show();
        $(".rmhd_nr ul li").eq(rmhd_l).siblings().hide();
    }
    else{
        rmhd_l--;
            $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd_l).addClass("xz_red");
            $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd_l).siblings().removeClass("xz_red");
            $(".rmhd_nr ul li").eq(rmhd_l).show();
            $(".rmhd_nr ul li").eq(rmhd_l).siblings().hide();
    }
});
//注册页面表单验证、
    //用户名验证
$("#name").blur(function(){
    var value=$("#name").val();
    var re=/\W/g;
    var re2=/[^a-zA-Z]/g;
    var str=value.substr(0,1);
    //判断用户名是否为空！
    if(value.length==""){
        $("#name_ts").html("<a class='red'>请输入帐号名!</a>");
    }
    //判断第一个字符是否为字母
    else if(re2.test(str)){
        $("#name_ts").html("<a class='red'>请输入字母开头的账户名！</a>");
    }
    //用正则表达式检测账户名是否为数字下划线或字母！
    else if(re.test(value)){
       $("#name_ts").html("<a class='red'>请输入字母数字或下划线做为用户名!</a>");
    }
    //判断字符长度!
    else if(value.length<6 || value.length>20){
        $("#name_ts").html("<a class='red'>请输入6-20个字符的字母下划线或数字！</a>");
    }
    //ok
    else{
        $("#name_ts").html("ok!");
    }
});
    //密码验证
    $("#password").blur(function(){
        var re=/[^a-zA-Z0-9]/g;
        var value=$("#password").val();
        var str=value.substr(0,1);
        //判断用户名是否为空！
        if(value.length==""){
            $("#password_ts").html("<a class='red'>请输入密码!</a>");
        }
        //判断密码是否为数字和字母！
        else if(re.test(value)){
            $("#password_ts").html("<a class='red'>请输入字母数字做为密码!</a>");
        }
        //判断密码长度
        else if(value.length<6 || value.length>12){
            $("#password_ts").html("<a class='red'>请输入6-20个字符做为密码!</a>");
        }
        //ok！
        else{
            $("#password_ts").html("ok!");
        }
    });
    //确认密码验证
    $("#password2").blur(function(){
        var value=$("#password2").val();
        if(value != $("#password").val()){
            $("#password2_ts").html("<a class='red'>两次输入密码不相同！</a>");
        }else{
            $("#password2_ts").html("ok!");
        }
    });
});
//加入收藏
function AddFavorite(sURL, sTitle) {
    sURL = encodeURI(sURL); 
    try{   
        window.external.addFavorite(sURL, sTitle);   
    }catch(e) {   
        try{   
            window.sidebar.addPanel(sTitle, sURL, "");   
            }catch (e) {   
                alert("加入收藏失败，请使用Ctrl+D进行添加,或手动在浏览器里进行设置.");
            }   
        }
    }

//jq插件内容
$(document).ready(function(){
    jQuery(".djdt").slide({mainCell:".djdt_ul ul",autoPlay:true,effect:"leftMarquee",vis:3,interTime:50});//滚动的兑奖公告
    jQuery(".wjsj_banner").slide({mainCell:".bd ul",effect:"left",autoPlay:true});//玩家晒单
    jQuery(".yxsw_banner").slide({mainCell:".bd ul",effect:"left",autoPlay:true}); //游戏试玩
    jQuery(".yx_banner").slide({mainCell:".bd ul",effect:"left",autoPlay:true}); //游戏
});
//index_页游试玩-热门活动 banner 
function yysw_banner(){
    var yysw=$(".yysw_banner .banner_xz .yellow").index();
    if(yysw==2){
        yysw=0;
            $(".yysw_banner .banner_xz li").eq(yysw).addClass("yellow");
            $(".yysw_banner .banner_xz li").eq(yysw).siblings().removeClass("yellow");
            $(".yysw_banner .banner_tp li").eq(yysw).show();
            $(".yysw_banner .banner_tp li").eq(yysw).siblings().hide();
    }
    else{
        yysw++;
            $(".yysw_banner .banner_xz li").eq(yysw).addClass("yellow");
            $(".yysw_banner .banner_xz li").eq(yysw).siblings().removeClass("yellow");
            $(".yysw_banner .banner_tp li").eq(yysw).show();
            $(".yysw_banner .banner_tp li").eq(yysw).siblings().hide();
    }
};
$(document).ready(function(){
    $(".yysw_banner .banner_xz li").mouseover(
        function(){
            var yysw_index=$(this).index();
            $(this).addClass("yellow");
            $(this).siblings().removeClass("yellow");
            $(".yysw_banner .banner_tp li").eq(yysw_index).show();
            $(".yysw_banner .banner_tp li").eq(yysw_index).siblings().hide();   
    });
    var yysw_dsq=setInterval(yysw_banner,3000);
    $(".yysw_banner").hover(
        function(){
            clearInterval(yysw_dsq);
        },
        function(){
         yysw_dsq=setInterval(yysw_banner,3000);
        });
});
$(document).ready(function(){
    $(".rmhd_nr_r").click(function(){
        var rmhd_r=$(".rmhd_nr .rmhd_nr_xz .xz_red").index();
    if(rmhd_r==2){
        rmhd_r=0;
            $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd_r).addClass("xz_red");
            $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd_r).siblings().removeClass("xz_red");
            $(".rmhd_nr ul li").eq(rmhd_r).show();
            $(".rmhd_nr ul li").eq(rmhd_r).siblings().hide();
    }
    else{
        rmhd_r++;
            $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd_r).addClass("xz_red");
            $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd_r).siblings().removeClass("xz_red");
            $(".rmhd_nr ul li").eq(rmhd_r).show();
            $(".rmhd_nr ul li").eq(rmhd_r).siblings().hide();
    }
    });
});
function rmhd_banner(){
    var rmhd=$(".rmhd_nr .rmhd_nr_xz .xz_red").index();
    if(rmhd==2){
        rmhd=0;
            $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd).addClass("xz_red");
            $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd).siblings().removeClass("xz_red");
            $(".rmhd_nr ul li").eq(rmhd).show();
            $(".rmhd_nr ul li").eq(rmhd).siblings().hide();
    }
    else{
        rmhd++;
            $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd).addClass("xz_red");
            $(".rmhd_nr .rmhd_nr_xz span").eq(rmhd).siblings().removeClass("xz_red");
            $(".rmhd_nr ul li").eq(rmhd).show();
            $(".rmhd_nr ul li").eq(rmhd).siblings().hide();
    }
}
$(document).ready(function(){
    $("..rmhd_nr .rmhd_nr_xz span").mouseover(
        function(){
            var rmhd_index=$(this).index();
            $(this).addClass("xz_red");
            $(this).siblings().removeClass("xz_red");
            $(".rmhd_nr ul li").eq(rmhd_index).show();
            $(".rmhd_nr ul li").eq(rmhd_index).siblings().hide();
        });
var rmhd_dsq=setInterval(rmhd_banner,3000);
    $(".rmhd_nr").hover(
        function(){
            clearInterval(rmhd_dsq);
        },
        function(){
          rmhd_dsq=setInterval(rmhd_banner,3000);
        });
});
//index_页游试玩-热门活动 banner end


//登陆框
function denglu(){
    $(".dlk").show();
    $(".mengban").show();
    $(".dlk .dlk_gb").click(function(){
        $(".dlk").hide();
        $(".mengban").hide();
    });
};

//登陆框
function qiandao(){
    $(".qdk").show();
    $(".mengban").show();
    $(".qdk .dlk_gb").click(function(){
        $(".qdk").hide();
        $(".mengban").hide();
    });
};











