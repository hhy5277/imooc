import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class PlayGame {
	 static List<Poker> pokers = new ArrayList<Poker>();
	 static List<Player> players = new ArrayList<Player>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PlayGame pg = new PlayGame();
		pg.createpokers();
		pg.createPlayer();
		System.out.println("-------��ʼ����-------");
		pg.deal(players.get(0));
		pg.deal(players.get(1));
		pg.deal(players.get(0));
		pg.deal(players.get(1));
		System.out.println("-----���ƽ���-------");
		System.out.println("---------��ʼ��Ϸ-----------");
		Poker pk1;
		pk1 = pg.compareoneplayer(players.get(0));
		Poker pk2;
		pk2 = pg.compareoneplayer(players.get(1));
		
		if(pg.comparepoker(pk1, pk2)==0)
		{
			System.out.println("-------���"+players.get(0).getName() +"ʤ-------");
		}
		else
		{
			System.out.println("-------���"+players.get(1).getName() +"ʤ-------");
		}
		
		System.out.println("��Ҹ��Ե�����Ϊ��");
		System.out.println(players.get(0).getName()+":"+"["+players.get(0).getPoker().get(0).getColor()+players.get(1).getPoker().get(0).getNumber()+
				","+players.get(0).getPoker().get(1).getColor()+players.get(0).getPoker().get(1).getNumber()+"]");
		System.out.println(players.get(1).getName()+":"+"["+players.get(1).getPoker().get(0).getColor()+players.get(1).getPoker().get(0).getNumber()+
				","+players.get(1).getPoker().get(1).getColor()+players.get(1).getPoker().get(1).getNumber()+"]");
		
	}
	
	public void createpokers()
	{
		String colors[] = {"��Ƭ","÷��","����","����"};
		String numbers[] = {"2","3","4","5","6","7","8","9","10","J","Q","K","A"};
		System.out.println("-------�����˿���-----------");
		for(int i=0;i<colors.length;i++)
		{
			for(int j=0;j<numbers.length;j++)
			{
				pokers.add(new Poker(colors[i],i+1,numbers[j],j+1));
			}
		}
		for (Poker p : pokers) {
			System.out.print(p.getColor()+p.getNumber()+",");
		}
		System.out.println();
		System.out.println("------------�����˿��Ƴɹ���--------------");
		
	}
	
	public void createPlayer(){
			for(int i=0;i<2;i++)
			{
				int id;
				String name;
				System.out.println("���������"+(i+1)+"��id: ");
				id = TextIO.getInt();
				System.out.println("������������");
				name = TextIO.getWord();
				players.add(new Player(id,name));
			}
			System.out.println("��ӭ��ң�" + players.get(0).getName());
			System.out.println("��ӭ��ң�" + players.get(1).getName());
		}
	public void deal(Player p){
		Random r = new Random();
		int k = r.nextInt(51);
		while(pokers.get(k).isUsed())
		{
			k = r.nextInt(51);
		}
		Poker poker1 = pokers.get(k);
		pokers.get(k).setUsed(true);
		p.getPoker().add(poker1);
		System.out.println("--���"+p.getName()+"����--");
	}
	
	public Poker compareoneplayer(Player p){
		int id = comparepoker(p.getPoker().get(0),p.getPoker().get(1));
		System.out.println("���"+p.getName()+"���������ǣ�"+p.getPoker().get(id).getColor()+p.getPoker().get(id).getNumber());
		return p.getPoker().get(id);
	}
	public int comparepoker(Poker p1,Poker p2)
	{
		int id = 0;
		if(p1.getNumberid()>p2.getNumberid())
		{
			id = 0;
		}
		else if(p1.getNumberid()<p2.getNumberid())
		{
			id = 1;
		}
		else
		{
			if(p1.getColorid()>p2.getColorid())
			{
				id = 0;
				
			}
			else
			{
				id=1;
			}
			
		}
		return id;
	}

}
