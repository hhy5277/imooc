
public class Poker {
	private String color;
	private int colorid;
	private String number;
	private int numberid;
	private boolean used;
	public Poker(String color, int colorid, String number, int numberid) {
		this.color = color;
		this.colorid = colorid;
		this.number = number;
		this.numberid = numberid;
		this.used = false;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getColorid() {
		return colorid;
	}
	public void setColorid(int colorid) {
		this.colorid = colorid;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public int getNumberid() {
		return numberid;
	}
	public void setNumberid(int numberid) {
		this.numberid = numberid;
	}
	public boolean isUsed() {
		return used;
	}
	public void setUsed(boolean used) {
		this.used = used;
	}
	
}
