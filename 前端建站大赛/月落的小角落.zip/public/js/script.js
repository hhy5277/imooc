/**
 * Created by misicdemone on 16/3/16.
 */

var btn = document.querySelector(".btn"),
    line_left = document.querySelector(".line-left"),
    line_right = document.querySelector(".line-right"),
    line_top = document.querySelector(".line-top"),
    line_bottom = document.querySelector(".line-bottom"),
    bg = document.querySelector(".bg"),
    cover = document.querySelector(".cover"),
    logo = document.querySelector("#logo"),
    menu = document.querySelector(".menu"),
    article_list = document.querySelector("#article-list"),
    _menu = {};

addLoadEvent(start_transition);


function start_transition(){
    bg.style.opacity = "1";
    if(location.hash == ''){
        location.hash='#/home';
    }
}

function home_animation(){
    cover.style.display = "block";
    var logo = new Vivus('logo', {
        type: 'delayed',
        duration: 1000,
        pathTimingFunction: Vivus.EASE
    });

    (function lineAnimation(){

        setTimeout(function(){
            line_left.style.height = "50px";
            line_right.style.height = "50px";
            line_top.style.width = "152px";
            line_bottom.style.width = "152px";
            line_left.style.marginTop = "51px";
            line_right.style.marginTop = "51px";
            line_top.style.marginLeft = "-76px";
            line_bottom.style.marginLeft = "-76px";
            btn.style.opacity = "1";
        }, 1500)
    })();

    btn.addEventListener("click",function(){
        logo.play(-3);
        line_left.style.height = "0";
        line_right.style.height = "0";
        line_top.style.width = "0";
        line_bottom.style.width = "0";
        line_left.style.marginTop = "153px";
        line_right.style.marginTop = "-51px";
        line_top.style.marginLeft = "-150px";
        line_bottom.style.marginLeft = "300px";
        btn.style.opacity = "0";
        setTimeout(function(){
            cover.style.display = "none";
        },1001)
    });

}
_menu.in = function(ele){
    ele.style.display = "block";
    setTimeout(function(){
        ele.style.opacity = "1";
    },11)
};
_menu.out = function(ele){
    ele.style.opacity = "0";
    setTimeout(function(){
        ele.style.display = "none";
    },1001)
};

function addLoadEvent(func)
{
    var oldonload=window.onload;
    if(typeof window.onload != 'function')
    {
        window.onload=func;
    }
    else
    {
        window.onload=function()
        {
            oldonload();
            func();
        }
    }
}
function preLoadImg(url) {
    var img = new Image();
    img.src = url;
    console.log(url);
}