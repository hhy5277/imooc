/**
 * Created by misicdemone on 16/3/26.
 */

var content_menu = document.querySelector("#content-menu"),
    content_ctn = document.querySelector("#content"),
    main_body = document.querySelector("#main");

(function(){
    var articles_bhv = function () {
        content_menu.style.width = "30vw";
        var len = essayList.length;
        content_menu.innerHTML = essay;
        loadEssay(essayList[len-1].url);
        _menu.out(menu);
        _menu.out(article_list);
        main_body.style.opacity = "1";
    };
    var home_bhv = function () {
        logo.style.display = "block";
        home_animation();
    };
    var showMenu = function () {
        _menu.out(article_list);
        _menu.in(menu);
    };
    var showList = function () {
        console.log(article_list);
        article_list.innerHTML = essay;
        _menu.in(article_list);
    };
    var life_bhv = function () {
        content_menu.style.width = "0";
        content_ctn.innerHTML = life;
        _menu.out(menu);
        _menu.out(article_list);
        main_body.style.opacity = "1";
    };
    var myself_bhv = function () {
        content_menu.style.width = "0";
        content_ctn.innerHTML = about;
        _menu.out(menu);
        _menu.out(article_list);
        main_body.style.opacity = "1";
    };
    var thoughts_bhv = function () {
        content_menu.style.width = "0";
        content_ctn.innerHTML = note;
        _menu.out(menu);
        _menu.out(article_list);
        main_body.style.opacity = "1";
    };
    var viewArticle = function (articleId) {
        content_menu.innerHTML = essay;
        console.log(articleId);
        loadEssay(essayList[articleId].url);
        _menu.out(menu);
        _menu.out(article_list);
        main_body.style.opacity = "1";
    };


    var routes = {
        '/home': home_bhv,
        '/articles': articles_bhv,
        '/menu': showMenu,
        '/list': showList,
        '/life': life_bhv,
        '/myself': myself_bhv,
        '/thoughts': thoughts_bhv,
        '/articles/view/:articleId': viewArticle
    };

    var router = Router(routes);

    router.init();
})();


function loadEssay(url) {
    var content = document.querySelector("#content");
    var converter = new showdown.Converter(),
        text = "";

    (function ajax() {
        var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        xhr.open("GET", url, false);
        xhr.send();
        text = xhr.responseText;
    })();

    var essay_content = converter.makeHtml(text);
    var essay_html = '<a class="back-btn-mobile" href="#/list"><h2 class="page-name">Menu</h2></a>'+
        '<div id="essay-container">' + essay_content + '</div>';

    content.innerHTML = essay_html;
}