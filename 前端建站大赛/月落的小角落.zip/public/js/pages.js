/**
 * Created by misicdemone on 16/3/26.
 */

var essayList = '', lifeList = '', noteList = '';

(function ajaxEssay() {
    var url = '../public/js/essaylist.json';
    var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
    xhr.open("GET", url, false);
    xhr.send();
    essayList = xhr.responseText;
})();
(function ajaxLife() {
    var url = '../public/js/lifelist.json';
    var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
    xhr.open("GET", url, false);
    xhr.send();
    lifeList = xhr.responseText;
})();
(function ajaxLife() {
    var url = '../public/js/thoughtlist.json';
    var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
    xhr.open("GET", url, false);
    xhr.send();
    noteList = xhr.responseText;
})();

essayList = JSON.parse(essayList);
lifeList = JSON.parse(lifeList);
noteList = JSON.parse(noteList);

for (var p = noteList.length - 1; p >= 0; p--) {
    (function(p) {
        preLoadImg(noteList[p].src);
    })(p);
}

var essay_temp = '';
for (var i = essayList.length - 1; i >= 0; i--) {
    (function(i) {
        essay_temp += '<a href="#/articles/view/' + essayList[i].id + '"><li>' + essayList[i].title + '</li></a>'
    })(i);
}

var essay = '<a href="#/menu"><h2 class="page-name"><span class="arrow">&#10132;</span>文章</h2></a>'+
    '<hr class="line"/>'+
    '<ul class="list">'+
    essay_temp +
    '</ul>';

var note_temp = '';
for (var p = noteList.length - 1; p >= 0; p--) {
    (function(p) {
        note_temp += '<div class="note-list">' +
            '<div class="note-img">' +
            '<img src="' + noteList[p].src + '" title="' + noteList[p].describe + '"/>' +
            '</div>' +
            '<div class="note-words">' +
            '<p>' + noteList[p].main + '</p>' +
            '</div>' +
            '</div>';
    })(p);
}
var note = '<div class="page-content">' +
    '<div class="page-thoughts">'+
    '<a class="menu-btn" href="#/menu"><h2 class="page-name"><span class="arrow">&#10132;</span>念想</h2></a>'+
    note_temp +
    '</div>'+
    '</div>';



var life_temp = '';
for (var m = lifeList.length - 1; m >= 0; m--) {
    (function(m) {
        life_temp += '<li>' +
            '<div class="time-line-box">' +
            '<span class="time-line-time">'+ lifeList[m].time +'</span>' +
            '<p>'+ lifeList[m].main +'</p>' +
            '</div>' +
            '</li>';
    })(m);
}

var life = '<div class="page-content">' +
    '<div class="time-line">' +
    '<a href="#/menu"><h2 class="page-name"><span class="arrow">&#10132;</span>生活</h2></a>'+
    '<ul class="time-line-list">' + life_temp + '</ul>' +
    '</div>' +
    '</div>';

var about = '<div class="page-content">' +
    '<div class="about">' +
    '<a href="#/menu"><h2 class="page-name"><span class="arrow">&#10132;</span>自己</h2></a>'+
    '<a href="http://weibo.com/5329878019/"><h1>@月落音阑</h1></a>' +
    '<p><a href="http://github.com/InfiniteSword"><i class="icon iconfont">&#xe9fa;</i>: InfiniteSword </a></p>' +
    '<p><a href="mailto:m18883993593@163.com"><i class="icon iconfont">&#xe628;</i>: m18883993593@163.com </a></p>' +
    '<p><span><i class="icon iconfont">&#xe65b;</i>: 424532913</span></p>' +
    '<hr/>' +
    '<p>现在于重庆邮电大学计算机科学与技术学院接受本科教育，感谢红岩网校工作站的学长学姐带我第一次接触到前端并让我得以入门。</p>' +
    '<p>二次元爱好者，欢迎同好勾搭~ o(*￣▽￣*)ブ</p>' +
    '<p>CP：<a href="http://weibo.com/u/5810067056">@景柚大人</a>，是时候秀一波了√</p>' +
    '<p><small>【若本站有内容冒犯了你，请联系我】</small></p>' +
    '</div>' +
    '</div>';



