<p>用作个人博客，包含响应式内容，主要用到js路由，ajax以及css动画，用到的框架包括vivus.js(用作svg动画)，showdown.js(用作markdown文件转html)，director.js(用作js路由)。</p><p>时间略紧，于是没有作浏览器兼容。。</p><p><br/></p><p>预览地址：http://www.sakuramelody.com/</p>

