<ol class=" list-paddingleft-2" style="list-style-type: decimal;"><li><p>Android Studio实现</p></li><li><p>需要一个第三方类库：com.nineoldandroids:library:2.4.0</p></li><li><p>UTF-8编码格式</p></li></ol>

