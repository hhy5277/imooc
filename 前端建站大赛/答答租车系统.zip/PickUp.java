package com.java.se.rentCar;

/**
 * @author 大昆
 * 2015-6-17
 */
public class PickUp extends Car {
/**
 * 
 */
	public PickUp(String carName,int rent,int capHumans,double capGoods) {
		 this.carName = carName;
		 this.rent = rent;
		 this.capHumans = capHumans;
		 this.capGoods = capGoods;
	}
}

