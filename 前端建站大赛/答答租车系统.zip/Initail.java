package com.java.se.rentCar;

import java.util.Scanner;

/**
 * @author 大昆
 * 2015-6-17
 */
public class Initail {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Car[] cars = {new PasserCar("奥迪A4", 500, 4),new PasserCar("马自达6", 400, 4),new PickUp("皮卡雪6", 450, 4, 2),new PasserCar("金龙", 800, 20),new Truck("松花江", 400, 4),new Truck("依维柯", 1000, 20)};
		int countHumans=0;
		int countRent=0;
		double countGoods=0.0;
		StringBuffer rentP = new StringBuffer();
		StringBuffer rentG = new StringBuffer();
		System.out.println("欢迎使用达达租车系统^^");
		System.out.println("您是否要租车？1是0否");
		
		Scanner input = new Scanner(System.in);
		int flag = input.nextInt();
		if(flag==0) {
			System.out.println("您取消了操作，欢迎下次使用系统");
		}else{
			System.out.println("您可租车的类型及其价目表：");
			System.out.println("序号\t汽车名称\t租金\t容量");
			for(int i=0;i<cars.length;i++){
				//序号生成
				System.out.print((i+1)+"\t");
				if(cars[i] instanceof PasserCar){
					System.out.println(cars[i].carName+"\t"+cars[i].rent+"元/天\t"+cars[i].capHumans+"人");
				} else if(cars[i] instanceof PickUp){
					System.out.println(cars[i].carName+"\t"+cars[i].rent+"元/天\t"+cars[i].capHumans+"人,"+cars[i].capGoods+"吨");
				}else if(cars[i] instanceof Truck){
					System.out.println(cars[i].carName+"\t"+cars[i].rent+"元/天\t"+cars[i].capGoods+"吨");
				}
				
			}
			
			System.out.println("请输入您要租车的数量：");
			int nums = input.nextInt();
			for(int i=0;i<nums;i++){
				System.out.println("请输入您要租用的车辆序号：");
				int x = input.nextInt();
				if(x>0&&x<=cars.length){
					if(cars[x-1] instanceof PasserCar){
						countHumans += cars[x-1].capHumans;
						countRent += cars[x-1].rent;
						rentP.append(cars[x-1].carName+"\t");
					}else if(cars[x-1] instanceof PickUp){
						countHumans += cars[x-1].capHumans;
						countRent += cars[x-1].rent;
						countGoods += cars[x-1].capGoods;
						rentP.append(cars[x-1].carName+"\t");
						rentG.append(cars[x-1].carName+"\t");
					}else if(cars[x-1] instanceof Truck){
						countRent += cars[x-1].rent;
						countGoods += cars[x-1].capGoods;
						rentG.append(cars[x-1].carName+"\t");
					}
					
				}else{
					System.out.println("您输入的车辆序号有误！请重新操作");
				}
			}
			System.out.println("请输入您要租用的天数：");
			int rentDays = input.nextInt();
			countHumans *=rentDays;
			countGoods *= rentDays;
			countRent *= rentDays;
			System.out.println("您的账单为：");
			System.out.println("**可载人的车有");
			System.out.println(rentP+"共载人："+countHumans+"人");
			System.out.println("**可载货的车有");
			System.out.println(rentG+"共载货："+countGoods+"吨");
			System.out.println("***租车总价格："+countRent+"元");
		}
	}

}

