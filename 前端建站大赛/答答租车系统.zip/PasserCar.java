package com.java.se.rentCar;

/**
 * @author 大昆
 * 2015-6-17
 */
public class PasserCar extends Car {


public PasserCar(String carName,int rent,int capHumans){
	 this.carName = carName;
	 this.rent = rent;
	 this.capHumans = capHumans;
 }
	
}

