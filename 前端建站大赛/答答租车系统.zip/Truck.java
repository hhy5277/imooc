package com.java.se.rentCar;

/**
 * @author 大昆
 * 2015-6-17
 */
public class Truck extends Car {

	Truck(String carName,int rent,int capGoods){
		this.carName = carName;
		 this.rent = rent;
		 this.capGoods = capGoods;
	};
}

