package com.java.se.rentCar;

/**
 * @author 大昆
 * 2015-6-17
 */
public abstract class Car {

	protected String carName; //汽车名称
	protected int rent; //每日租金
	protected int capHumans; //容量人
	protected double capGoods; //容量货

}

