window.onload=function(){
	var oli=document.getElementsByTagName("li");
	var act=document.getElementById("act");
	var i=0;
	var arr=['去爬山','去钓鱼','去购物','去商场','去工作','去打球','去看朋友','去上课','去找人','去上网','去取钱','去打电话'];	
	for(i=0;i<oli.length;i++)//每月活动，对li进行遍历操作
	{	
		oli[i].index=i;//将i的值赋给oli的索引，即下标	
		oli[i].onmouseover=function()//鼠标滑过li，触发事件
		{	
			act.innerHTML =(this.index+1)+'月活动<br>'+arr[this.index]+'';//act中的内容	
		};
	}
}
/*思想：
*通过li的数组和arr的数组进行匹配，也就是下标相等
*此时在act中输出arr数组的值
*这样就实现了下面内容随li的变化效果
*/