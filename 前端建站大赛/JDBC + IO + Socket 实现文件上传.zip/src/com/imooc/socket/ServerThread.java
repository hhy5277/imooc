package com.imooc.socket;

import java.io.*;
import java.net.*;
import com.imooc.controller.*;
import com.imooc.entity.*;
import com.imooc.entity.File;
import com.imooc.util.CommandTransfer;

public class ServerThread implements Runnable {

	private Socket socket = null;
	private ObjectInputStream ois = null;// 对象输入流
	private ObjectOutputStream oos = null;// 对象输出流
	private UserService us = new UserService();
	private FileService fs = new FileService();

	private static final String SIGNUP = "signup";
	private static final String LOGIN = "login";
	private static final String UPLOADFILE = "uploadfile";

	// 初始化socket
	public ServerThread(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			//
			ois = new ObjectInputStream(socket.getInputStream());
			oos = new ObjectOutputStream(socket.getOutputStream());
			// 读取客户端发送的数据
			CommandTransfer transfer = (CommandTransfer) ois.readObject();

			transfer = execute(transfer);// 执行客户端发送到服务器的指令操作
			oos.writeObject(transfer);// 响应客户端
			oos.flush();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	private CommandTransfer execute(CommandTransfer transfer) {
		String cmd = transfer.getCmd();
		if (SIGNUP.equalsIgnoreCase(cmd)) {// 注册
			// 获取用户对象
			User u = (User) transfer.getData();
			// 注册用户----向数据库中添加用户
			transfer.setFlag(us.register(u));
		} else if (LOGIN.equalsIgnoreCase(cmd)) {// 登录
			// 获取用户对象
			User u = (User) transfer.getData();
			// 登录----用户名与密码是否与数据库中的数据匹配
			transfer.setFlag(us.login(u));
		} else if (UPLOADFILE.equalsIgnoreCase(cmd)) {// 上传文件
			// 获取文件对象
			File file = ( File )transfer.getData();
			// 上传文件
			transfer.setFlag( fs.uploadFile(file));
		}
		return transfer;
	}

}
