package com.imooc.socket;

import java.util.*;
import com.imooc.entity.File;
import com.imooc.entity.User;
import com.imooc.util.CommandTransfer;
import java.io.*;
import java.net.*;

public class SocketClient {

	private Scanner input ;
	private Socket socket = null;// 客户端Socket
	private static final String ADDRESS = "127.0.0.1";
	private static final int PORT = 8888;

	private static final String MAIN_MENU = "Welcome to imooc file uploader ^_^,\n" + "please choose:\n"
			+ "  1.sign up\n" + "  2.log in\n" + "  3.upload file\n" + "  4.exit";
	private static final String SIGNUP = "signup";
	private static final String LOGIN = "login";
	private static final String UPLOADFILE = "uploadfile";

	public void showMainMenu() {
		this.showHomePage();
		input = new Scanner(System.in);
		while( input.hasNext() ) {
			int choice = input.nextInt();
			switch (choice) {
			case 1:
				showSignUp();
				break;
			case 2:
				showLogIn();
				break;
			case 3:
				showUploadFile();
				break;
			case 4:
				System.out.println(" Bye~");
				System.exit(0);
				break;
			default:
				System.out.println("input error~~~");
				showHomePage();
			}
		}
	}

	private void showUploadFile() {
		File file = new File();
		System.out.println("please input the path of your file:");
		String url = input.next();
		java.io.File fileInfo = new java.io.File( url );
		if( fileInfo.exists() && fileInfo.isFile() ) {
			file.setFname( fileInfo.getName() );
			CommandTransfer transfer = new CommandTransfer();
			transfer.setCmd(UPLOADFILE);
			try {
				FileInputStream fis = new FileInputStream(fileInfo);
				byte[] fcontent = new byte[ fis.available() ];
				fis.read(fcontent);
				file.setFcontent(fcontent);
				transfer.setData(file);
				// 请求连接服务器
				socket = new Socket(ADDRESS, PORT);
				sendData(transfer);
				transfer = getData();
				if( transfer.isFlag() ) {
					System.out.println("uploaded successfully~");
				}else{
					System.out.println("sorry,upload failed~");
				}
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{
			System.out.println("sorry,file does not exist~");
		}
		
	}

	private void showLogIn() {
		User u = new User();
		CommandTransfer transfer = new CommandTransfer();
		
		System.out.println("please input your name:");
		u.setUsername( input.next() );
		System.out.println("please input your password:");
		u.setPassword( input.next() );
		
		transfer.setCmd( LOGIN );
		transfer.setData(u);
		try {
			// 请求连接服务器
			socket = new Socket(ADDRESS, PORT);
		} catch (IOException e) {
			e.printStackTrace();
		}
		sendData(transfer);
		transfer = getData();
		if( transfer.isFlag() ){//登录成功
			System.out.println("congratulations～"+u.getUsername()
										+ ",log in successfully~");
		}else {
			System.out.println("sorry,failed~");
			showHomePage();
		}
		
	}

	private void showSignUp() {
		User u = new User();
		System.out.println("please input your name:");
		u.setUsername(input.next());
		System.out.println("please input your password:");
		u.setPassword(input.next());
		System.out.println("please confirm your password:");
		String confirm = input.next();
		if (!confirm.equals(u.getPassword())) {
			System.out.println("your password is not the same~");
			showHomePage();
		} else {
			try {
				// 请求连接服务器
				socket = new Socket(ADDRESS, PORT);
			} catch (IOException e) {
				e.printStackTrace();
			}
			CommandTransfer transfer = new CommandTransfer();
			transfer.setCmd(SIGNUP);
			transfer.setData(u);
			sendData( transfer );// 向服务器发送数据
			transfer = getData();// 从服务器接收数据
			if( transfer.isFlag() ) {//注册成功
				System.out.println("congratulations～"+u.getUsername()
								+ ",sign up successfully~");// 显示返回的结果
			}else {
				System.out.println( "sorry,sign up failed~" );// 显示返回的结果
				showHomePage();
			}
			
		}
	}

	// 向服务器端发送数据
	private void sendData(CommandTransfer transfer) {
		try {
			
			ObjectOutputStream oos = new ObjectOutputStream( socket.getOutputStream());
			oos.writeObject(transfer);
			oos.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// 从服务器接收数据
	private CommandTransfer getData( ) {
		try {
			ObjectInputStream ois = new ObjectInputStream( socket.getInputStream());
			return (CommandTransfer) ois.readObject();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}

	private void showHomePage() {
		System.out.println(MAIN_MENU);
	}
}
