package com.imooc.socket;


/**
 * 启动客户端
 * @author liqian
 *
 */
public class StartClient {

	public static void main(String[] args) {
		SocketClient client = new SocketClient();
		// 显示主菜单
		client.showMainMenu();
	}
	
}
