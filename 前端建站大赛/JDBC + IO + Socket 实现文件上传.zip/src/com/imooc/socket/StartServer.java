package com.imooc.socket;

import java.io.IOException;
import java.net.*;

public class StartServer {

	private static final int PORT = 8888;
	
	public static void main(String[] args) {
		try {
			// 创建服务器Socket，绑定指定端口
			ServerSocket serverSocket = new ServerSocket(PORT);
			Socket socket = null;
			System.out.println("*****server start****");
			// 服务器循环监听客户端的连接请求
			while( true ) {
				// 开始监听
				socket = serverSocket.accept();
				// 启动线程
				ServerThread serverThread = new ServerThread( socket );
				Thread thread = new Thread(serverThread);
				thread.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
