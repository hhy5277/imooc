package com.imooc.model;

import java.sql.*;
import java.io.*;
import java.util.*;
import com.imooc.entity.File;
import com.imooc.util.Database;

/**
 * public method
 *   addFile( 
 *
 */
public class FileModel {
	
	public boolean addFile( File file ) {
		
		String sql = "insert into tb_file (fname,fcontent) "
				+ "values(?,?);";
		
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(file.getFcontent());
			
			PreparedStatement ptmt = Database.getConnection().prepareStatement(sql);
			ptmt.setString(1, file.getFname());
			ptmt.setBinaryStream(2, bis, bis.available() );
			
			ptmt.execute();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	public List<File> query( ) {
		String sql = "select * from tb_file;";
		
		try {
			Statement stmt = Database.getConnection().createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			List<File> list = new ArrayList<File>();
			
			while( rs.next() ) {
				File file = new File();
				file.setFname( rs.getString("fname"));
				file.setFcontent( rs.getBytes("fcontent"));
				list.add(file);
			}
			
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
			
	}
	
}
