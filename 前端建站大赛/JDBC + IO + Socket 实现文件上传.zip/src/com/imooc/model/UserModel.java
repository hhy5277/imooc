package com.imooc.model;

import java.sql.*;
import com.imooc.entity.User;
import com.imooc.util.Database;

/**
 * public method 
 *   addUser( User);//添加用户 query(String);//查询某个用户
 *   isExists(String);//查询某个用户是否存在
 */
public class UserModel {
	
	/**
	 * 向数据库中添加用户
	 * @param u 用户对象
	 * @return 是否添加成功
	 * @throws SQLException
	 */
	public boolean addUser(User u)  {
		String sql = "insert into tb_user (username,password) " + "  values(?,?);";
		try {
			PreparedStatement ptmt = Database.getConnection().prepareStatement(sql);

			ptmt.setString(1, u.getUsername());
			ptmt.setString(2, u.getPassword());

			ptmt.execute();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean isExists( String username ) {
		String sql = "select uid from tb_user where username = ?;";
		try {
			PreparedStatement ptmt = Database.getConnection().prepareStatement(sql);
			
			ptmt.setString(1, username);
			
			ResultSet rs = ptmt.executeQuery();
			if( rs == null || !rs.next() ) {//结果集中没有元素时
				return false;
			}else {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return true;
		}	
	}
	
	public String query( String username ) {
		String pwd = null;
		String sql = " select password from tb_user where username=?;";
		try {
			
			PreparedStatement ptmt = Database.getConnection().prepareStatement(sql);
			ptmt.setString(1, username);
			ResultSet rs = ptmt.executeQuery();
			while( rs.next() ) {
				pwd = rs.getString("password");
			}
			return pwd;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
}
