package com.imooc.util;

import java.sql.*;
/**
 * 鏁版嵁搴撳伐鍏风被
 * @author liqian
 *1.鑾峰彇鏁版嵁搴撶殑杩炴帴
 */
public class Database {
	
	private static Connection conn = null;
	
	public static Connection getConnection( ) {
		try {
			//鍔犺浇鏁版嵁搴撶殑椹卞姩
			Class.forName("com.mysql.jdbc.Driver");
			//鑾峰緱鏁版嵁搴撶殑杩炴帴
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/imooc", "root", "root");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
		
	}
}
