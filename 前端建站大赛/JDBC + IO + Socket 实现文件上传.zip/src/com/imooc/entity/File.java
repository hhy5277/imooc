package com.imooc.entity;

import java.io.Serializable;

/**
 * 文件类
 * @author liqian
 *域：1.文件ID 2.文件名 3.文件本身
 */
public class File implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int fid;
	private String fname;
	private byte[] fcontent;
	
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public byte[] getFcontent() {
		return fcontent;
	}
	public void setFcontent(byte[] fcontent) {
		this.fcontent = fcontent;
	}
	
	
}
