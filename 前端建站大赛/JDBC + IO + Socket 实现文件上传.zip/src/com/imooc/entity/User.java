package com.imooc.entity;

import java.io.Serializable;

/**
 * 用户类
 * @author liqian
 * 域：1.用户的ID，2.用户名 3.用户的密码
 */
public class User implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int uid;
	private String username;
	private String password;
	
	
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String uname) {
		this.username = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
