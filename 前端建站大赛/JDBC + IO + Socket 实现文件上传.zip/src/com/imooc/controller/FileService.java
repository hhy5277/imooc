package com.imooc.controller;

import com.imooc.entity.*;
import com.imooc.model.FileModel;

/**
 * 文件服务
 * 
 * @author liqian public method： 1.uploadFile(File) 上传文件
 */
public class FileService {

	/**
	 * 上传文件
	 * 
	 * @param file
	 *            文件对象
	 * @return 文件是否上传成功
	 */

	public boolean uploadFile(File file) {
		
		FileModel fileModel = new FileModel();
		return fileModel.addFile(file);

	}

}
