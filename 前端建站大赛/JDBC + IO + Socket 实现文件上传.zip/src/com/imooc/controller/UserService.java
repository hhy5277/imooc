package com.imooc.controller;

import com.imooc.entity.User;
import com.imooc.model.UserModel;

/**
 * 用户服务
 * @author liqian
 *1.register(User) 向数据库中添加用户（用户注册）
 */
public class UserService {
	
	public boolean isExist( String username ) {
		return new UserModel().isExists(username);
	}
	
	
	/**
	 * 向模型层传递用户的数据，
	 * @param u 用户对象
	 * @return 是否添加成功
	 */
	public boolean register( User u ) {
		UserModel userModel = new UserModel();
		if( userModel.isExists( u.getUsername() ) ) {//该用户存在
			return false;
		}else {
			return userModel.addUser(u);	
		}
	}
	
	/**
	 * 用户登陆
	 * @param u 用户对象
	 * @return 是否登陆成功
	 */
	public boolean login( User u ) {
		UserModel userModel = new UserModel();
		
		if( !userModel.isExists(u.getUsername()) ) {//用户不存在，无法登陆
			return false;
		}else {//用户存在时查看密码是否匹配
			String pwd = userModel.query(u.getUsername());
			if( u.getPassword().equals(pwd)) {//密码匹配时
				return true;
			}else{//密码不匹配时
				return false;
			}
		}
	}
	
}
