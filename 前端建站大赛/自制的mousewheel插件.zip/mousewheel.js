

    var mousewheel={

		isFireFox:function(){

			return navigator.userAgent.toLowerCase().indexOf('firefox')!=-1;

		},

		getFFWheelData:function(e){

			return e.detail;

		},

		getFFElseWheelData:function(e){

			return e.wheelDelta;

		},

		wheel:function(obj,fn){

			if(this.isFireFox()){

				return obj.addEventListener('DOMMouseScroll',fn,false);

			}else{

				return obj.onmousewheel=fn;

			}

		},

		start:function(o){

			var self=this;

			var obj=o.obj||document;

			var onwheelup=o.onwheelup;

			var onwheeldown=o.onwheeldown;

			this.wheel(obj,function(e){

				var e=window.event||e;

				var FFwheelData=self.getFFWheelData(e);

				var notFFwheelData=self.getFFElseWheelData(e);

				(FFwheelData==3||notFFwheelData==120)&&onwheelup&&onwheelup();

				(FFwheelData==-3||notFFwheelData==-120)&&onwheeldown&&onwheeldown();

				e.preventDefault()?e.preventDefault():e.returnValue=false;

			})

		}

	}

	window.onload=mousewheel.start({

		onwheelup:function(){

			alert('up wheel')

		},

		onwheeldown:function(){

			alert('down wheel');

		}

	});



