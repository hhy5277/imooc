<?php require_once('Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_web_shop2 = 9;
$pageNum_web_shop2 = 0;
if (isset($_GET['pageNum_web_shop2'])) {
  $pageNum_web_shop2 = $_GET['pageNum_web_shop2'];
}
$startRow_web_shop2 = $pageNum_web_shop2 * $maxRows_web_shop2;

$colname_web_shop2 = "-1";
if (isset($_GET['shop_id'])) {
  $colname_web_shop2 = $_GET['shop_id'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_shop2 = sprintf("SELECT shop1.shop_id,shop1.shop_name,shop2.p_id, shop2.p_name,shop2.p_price, shop2.p_open, shop2.p_pic FROM shop1 Left Join shop2 ON shop1.shop_id = shop2.shop_id WHERE shop2.shop_id = %s AND shop2.p_open = 'Y' ORDER BY shop2.p_id DESC", GetSQLValueString($colname_web_shop2, "int"));
$query_limit_web_shop2 = sprintf("%s LIMIT %d, %d", $query_web_shop2, $startRow_web_shop2, $maxRows_web_shop2);
$web_shop2 = mysql_query($query_limit_web_shop2, $conn_web) or die(mysql_error());
$row_web_shop2 = mysql_fetch_assoc($web_shop2);

if (isset($_GET['totalRows_web_shop2'])) {
  $totalRows_web_shop2 = $_GET['totalRows_web_shop2'];
} else {
  $all_web_shop2 = mysql_query($query_web_shop2);
  $totalRows_web_shop2 = mysql_num_rows($all_web_shop2);
}
$totalPages_web_shop2 = ceil($totalRows_web_shop2/$maxRows_web_shop2)-1;

mysql_select_db($database_conn_web, $conn_web);
$query_web_shop1 = "SELECT * FROM shop1 ORDER BY shop_id ASC";
$web_shop1 = mysql_query($query_web_shop1, $conn_web) or die(mysql_error());
$row_web_shop1 = mysql_fetch_assoc($web_shop1);
$totalRows_web_shop1 = mysql_num_rows($web_shop1);

$queryString_web_shop2 = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_web_shop2") == false && 
        stristr($param, "totalRows_web_shop2") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_web_shop2 = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_web_shop2 = sprintf("&totalRows_web_shop2=%d%s", $totalRows_web_shop2, $queryString_web_shop2);
?>
<?php session_start();?>
<!doctype html>
<!--[if lt IE 7]> <html class="ie6 oldie"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 oldie"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 oldie"> <![endif]-->
<!--[if gt IE 8]><!-->
<html>
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——分享创意</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/pagestyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
  <?php include("meau.php"); ?> 
  <div class="container">
    <nav class="navbar navbar-default" role="navigation">
      <div class="navbar-header"> <a class="navbar-brand" href="shop.php"><strong>奇创网商城</strong></a> </div>
      <div>
        <ul class="nav navbar-nav">
          <li class="dropdown"> <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown"> 分类 <b class="caret"></b> </a>
            <ul class="dropdown-menu">
              <li><a href="shop.php">所有</a></li>
              <?php do { ?>
                <li class="divider"></li>
                <li><a href="products.php?shop_id=<?php echo $row_web_shop1['shop_id']; ?>"><?php echo $row_web_shop1['shop_name']; ?></a></li>
                <?php } while ($row_web_shop1 = mysql_fetch_assoc($web_shop1)); ?>

            </ul>
          </li>
        </ul>
        <div>
          <p class="navbar-text">目前所在分类：<?php echo $row_web_shop2['shop_name']; ?></p>
        </div>
        <? if(empty($_SESSION["MM_Username"])){?>
        <div>
		<p class="navbar-text" style="font-size:1.8rem"><a href="member/index.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> 登入</a></p>
        </div>
        <? }else{?>
        <ul class="nav navbar-nav">
        	<li class="dropdown">
            <a href="javascript:();" class="dropdown-toggle" data-toggle="dropdown">
               会员中心 
               <b class="caret"></b>
            </a>
            <ul class="dropdown-menu">
               <li><a href="shopcart_myorder.php">订单记录</a></li>
               <? if($_SESSION["MM_Username"]=='admin'){?>
               <li class="divider"></li>
               <li><a href="admin/admin.php">前往后台</a></li>
        	   <? }?>
               <li class="divider"></li>
               <li><a href="logout.php">退出</a></li>
            </ul>
         </li>
        </ul>
        <? }?>
        <?php if(isset($_SESSION["cart"])){?>
        <a href="shopcart_show.php">
        <button type="button" class="btn btn-default navbar-btn"> 我的购物车 </button>
        </a>
        <?php }?>
      </div>
    </nav>
  </div>
  <!--end shoppage-->
  
  <div class="container">
      <?php if ($totalRows_web_shop2 > 0) { // Show if recordset not empty ?>
      <?php do { ?>
        <div class="col-sm-4 col-md-4 col-lg-4">
          <div class="thumbnail"> <a href="products_detial.php?p_id=<?php echo $row_web_shop2['p_id']; ?>"><img src="images/shop/<?php echo $row_web_shop2['p_pic']; ?>" width="100%" border="0" /></a> </div>
          <div class="caption">
            <h3>
              <h3><?php echo $row_web_shop2['p_name']; ?></h3>
            </h3>
            <p>价格：¥<?php echo $row_web_shop2['p_price']; ?></p>
            <p> <a href="#" class="btn btn-primary" role="button"> 购买 </a> <a href="shopcart_add.php?p_name=<?php echo urlencode($row_web_shop2['p_name']); ?>&amp;p_price=<?php echo $row_web_shop2['p_price']; ?>&amp;p_pic=<?php echo $row_web_shop2['p_pic']; ?>" class="btn btn-default"> 加入购物车 </a> </p>
          </div>
        </div>
        <?php } while ($row_web_shop2 = mysql_fetch_assoc($web_shop2)); ?>

        <table width="100%">
          <tr>
            <td align="left" valign="bottom"><table border="0">
                <tr>
                  <td><h4>
                      <?php if ($pageNum_web_shop2 > 0) { // Show if not first page ?>
                        <a href="<?php printf("%s?pageNum_web_shop2=%d%s", $currentPage, 0, $queryString_web_shop2); ?>">第一页&nbsp;/&nbsp;</a>
                        <?php } // Show if not first page ?>
                    </h4></td>
                  <td><h4>
                      <?php if ($pageNum_web_shop2 > 0) { // Show if not first page ?>
                        <a href="<?php printf("%s?pageNum_web_shop2=%d%s", $currentPage, max(0, $pageNum_web_shop2 - 1), $queryString_web_shop2); ?>">前一页&nbsp;/&nbsp;</a>
                        <?php } // Show if not first page ?>
                    </h4></td>
                  <td><h4>
                      <?php if ($pageNum_web_shop2 < $totalPages_web_shop2) { // Show if not last page ?>
                        <a href="<?php printf("%s?pageNum_web_shop2=%d%s", $currentPage, min($totalPages_web_shop2, $pageNum_web_shop2 + 1), $queryString_web_shop2); ?>">下一页&nbsp;/&nbsp;</a>
                        <?php } // Show if not last page ?>
                    </h4></td>
                  <td><h4>
                      <?php if ($pageNum_web_shop2 < $totalPages_web_shop2) { // Show if not last page ?>
                        <a href="<?php printf("%s?pageNum_web_shop2=%d%s", $currentPage, $totalPages_web_shop2, $queryString_web_shop2); ?>">最后一页</a>
                        <?php } // Show if not last page ?>
                    </h4></td>
                </tr>
              </table></td>
            <td align="right" valign="bottom"><h4>&nbsp;
                记录 <?php echo ($startRow_web_shop2 + 1) ?> 到 <?php echo min($startRow_web_shop2 + $maxRows_web_shop2, $totalRows_web_shop2) ?> (总共 <?php echo $totalRows_web_shop2 ?>笔)</h4></td>
          </tr>
        </table>

    <?php } // Show if recordset not empty ?>
    <?php if ($totalRows_web_shop2 == 0) { // Show if recordset empty ?>
      <table width="100%">
        <tr>
          <td height="80" align="center"  style="color:#F00">目前商城没有任何商品。</td>
        </tr>
      </table>
      <?php } // Show if recordset empty ?>
  </div>
  <!--end container--> 
</div>
<?php include("footer.php");?>
</div>
<!--end container-->

</body>
</html>
<?php
mysql_free_result($web_shop2);

mysql_free_result($web_shop1);
?>
