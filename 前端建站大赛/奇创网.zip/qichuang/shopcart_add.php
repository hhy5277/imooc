<?php require_once('Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO orderlist (p_name, p_price, p_pic, odlist_date, order_sid, order_group) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['p_name'], "text"),
                       GetSQLValueString($_POST['p_price'], "text"),
                       GetSQLValueString($_POST['p_pic'], "text"),
                       GetSQLValueString($_POST['odlist_date'], "date"),
                       GetSQLValueString($_POST['order_sid'], "text"),
                       GetSQLValueString($_POST['order_group'], "text"));

  mysql_select_db($database_conn_web, $conn_web);
  $Result1 = mysql_query($insertSQL, $conn_web) or die(mysql_error());

  $insertGoTo = "shopcart_show.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<?
//啟動session功能
session_start();

//如果Session變cart是空的，就註冊Session變數cart，值為1
//用在判別使用者是否已經有將任何商品加入購物車
if(empty($_SESSION["cart"])){
$_SESSION["cart"]='1';
}

//如果Session變數order_sid是空的，就註冊Session變數order_sid，取目前session的session id為值
//用在判別訂單資料
if(empty($_SESSION["order_sid"])){
$_SESSION["order_sid"]=session_id();
}

//如果Session變數order_group是空的，就註冊Session變數order_group，取目前unixtime為值
//用在判別訂單資料
if(empty($_SESSION["order_group"])){
$_SESSION["order_group"]=time(NULL);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title></title>
<script language=javascript> 
//0秒後，直接送出表單form1 
setTimeout("document.form1.submit()",0); 
</script>
</head>

<body>
<form id="form1" name="form1" method="POST" action="<?php echo $editFormAction; ?>">
  <input name="p_name" type="hidden" id="p_name" value="<?php echo urldecode($_GET['p_name']); ?>" />
  <input name="p_price" type="hidden" id="p_price" value="<?php echo $_GET['p_price']; ?>" />
  <input name="p_pic" type="hidden" id="p_pic" value="<?php echo $_GET['p_pic']; ?>" />
  <input name="odlist_date" type="hidden" id="odlist_date" value="<?php echo date("Y-m-d H:i:s")?>" />
  <input name="order_sid" type="hidden" id="order_sid" value="<?php echo session_id()?>" />
  <input name="order_group" type="hidden" id="order_group" value="<?php echo $_SESSION["order_group"]?>" />
  <input type="hidden" name="MM_insert" value="form1" />
</form>
</body>
</html>