<?php require_once('Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conn_web, $conn_web);
$query_web_shop1 = "SELECT * FROM shop1 ORDER BY shop_id ASC";
$web_shop1 = mysql_query($query_web_shop1, $conn_web) or die(mysql_error());
$row_web_shop1 = mysql_fetch_assoc($web_shop1);
$totalRows_web_shop1 = mysql_num_rows($web_shop1);
?>

<div class="container">
    <nav class="navbar navbar-default" role="navigation">
      <div class="navbar-header"> <a class="navbar-brand" href="shop.php"><strong>奇创网商城</strong></a> </div>
      <div>
        <ul class="nav navbar-nav">
          <li class="dropdown"> <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown"> 分类 <b class="caret"></b> </a>
            <ul class="dropdown-menu">
              <li><a href="shop.php">所有</a></li>
              <?php do { ?>
                <li class="divider"></li>
                <li><a href="products.php?shop_id=<?php echo $row_web_shop1['shop_id']; ?>"><?php echo $row_web_shop1['shop_name']; ?></a></li>
                <?php } while ($row_web_shop1 = mysql_fetch_assoc($web_shop1)); ?>
                
            </ul>
          </li>
        </ul>
	
        <?php if(empty($_SESSION["MM_Username"])){?>
        <div>
		<p class="navbar-text" style="font-size:1.8rem"><a href="member/index.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> 登入</a></p>
        </div>
        <? }else{?>
        <ul class="nav navbar-nav">
        	<li class="dropdown">
            <a href="javascript:();" class="dropdown-toggle" data-toggle="dropdown">
               会员中心 
               <b class="caret"></b>
            </a>
            <ul class="dropdown-menu">
               <li><a href="shopcart_myorder.php">订单记录</a></li>
               <?php if($_SESSION["MM_Username"]=='admin'){?>
               <li class="divider"></li>
               <li><a href="admin/admin.php">前往后台</a></li>
        	   <? }?>
               <li class="divider"></li>
               <li><a href="logout.php">退出</a></li>
            </ul>
         </li>
        </ul>
        <? }?>
<!--        <form class="navbar-form navbar-right" role="search" action="">
          <div class="form-group">
            <input name="keyword" type="text" class="form-control" placeholder="Search" disabled>
          </div>

          <button type="submit" class="btn btn-default">搜索</button>
        </form>
-->
        <?php if(isset($_SESSION["cart"])){?>
        <a href="shopcart_show.php">
        <button type="button" class="btn btn-default navbar-btn"> 我的购物车 </button>
        </a>
        <?php }?>
      </div>
    </nav>
</div>
<?php
mysql_free_result($web_shop1);
?>
