<?php require_once('Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conn_web, $conn_web);
$query_web_shop2 = "SELECT * FROM shop2 WHERE p_open = 'Y' ORDER BY p_id DESC";
$web_shop2 = mysql_query($query_web_shop2, $conn_web) or die(mysql_error());
$row_web_shop2 = mysql_fetch_assoc($web_shop2);
$totalRows_web_shop2 = mysql_num_rows($web_shop2);

$colname_web_search = "-1";
if (isset($_GET['keyword'])) {
  $colname_web_search = $_GET['keyword'];
}
$colname2_web_search = "-1";
if (isset($_GET['keyword'])) {
  $colname2_web_search = $_GET['keyword'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_search = sprintf("SELECT p_id, p_name, p_price, p_pic, p_content FROM shop2 WHERE ( p_name LIKE %s OR p_content LIKE %s ) AND p_open = 'Y' ORDER BY p_id ASC", GetSQLValueString("%" . $colname_web_search . "%", "text"),GetSQLValueString("%" . $colname2_web_search . "%", "text"));
$web_search = mysql_query($query_web_search, $conn_web) or die(mysql_error());
$row_web_search = mysql_fetch_assoc($web_search);
$totalRows_web_search = mysql_num_rows($web_search);
?>
<? session_start();?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——分享创意</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/pagestyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>

<body>
  <?php include("meau.php"); ?>
  
  <?php include("shopmeau.php"); ?>

  <div class="container">
  	<div class="panel panel-default">
    <div class="panel-body">
    	<span>搜索的关键字为：<em><?php echo $_GET['keyword']; ?></em></span>
        <span>搜索结果：相关商品总共<em><?php echo $totalRows_web_search ?></em>笔</span>
    </div>
    </div>
    
    <div class="row">
          <div class="col-sm-4 col-md-4 col-lg-4">
            <div class="thumbnail"> <a href="products_detial.php?p_id=<?php echo $row_web_shop2['p_id']; ?>"><img src="images/shop/<?php echo $row_web_search['p_pic']; ?>" width="100%" height="auto" border="0" /></a></div>
            <div class="caption">
              <h3><a href="products_detial.php?p_id=<?php echo $row_web_search['p_id']; ?>"><?php echo $row_web_search['p_name']; ?></a></h3>
              <p><h4 style="color:#FFF">价格：¥<?php echo $row_web_search['p_price']; ?> </h4></p>
              <p> <a href="shopcart_add.php?p_name=<?php echo urlencode($row_web_search['p_name']); ?>&amp;p_price=<?php echo $row_web_search['p_price']; ?>&amp;p_pic=<?php echo $row_web_search['p_pic']; ?>" class="btn btn-primary" role="button"> 购买 </a> <a href="shopcart_add.php?p_name=<?php echo urlencode($row_web_search['p_name']); ?>&amp;p_price=<?php echo $row_web_search['p_price']; ?>&amp;p_pic=<?php echo $row_web_search['p_pic']; ?>" class="btn btn-default"> 加入购物车 </a></p>
            </div>
          </div>
    </div>
    <!--end row-->
</div>
<?php include("footer.php");?>
</body>
</html>
<?php
mysql_free_result($web_shop2);

mysql_free_result($web_search);
?>
