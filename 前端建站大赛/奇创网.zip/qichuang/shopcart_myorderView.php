<?php require_once('Connections/conn_web.php'); ?>
<?php $order_total='0';?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "order")) {
  $updateSQL = sprintf("UPDATE orders SET order_payok=%s, order_paynumber=%s WHERE order_id=%s",
                       GetSQLValueString($_POST['order_payok'], "text"),
                       GetSQLValueString($_POST['order_paynumber'], "text"),
                       GetSQLValueString($_POST['order_id'], "int"));

  mysql_select_db($database_conn_web, $conn_web);
  $Result1 = mysql_query($updateSQL, $conn_web) or die(mysql_error());

  $updateGoTo = "shopcart_myorder.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_web_orders = "-1";
if (isset($_GET['order_id'])) {
  $colname_web_orders = $_GET['order_id'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_orders = sprintf("SELECT * FROM orders WHERE order_id = %s", GetSQLValueString($colname_web_orders, "int"));
$web_orders = mysql_query($query_web_orders, $conn_web) or die(mysql_error());
$row_web_orders = mysql_fetch_assoc($web_orders);
$totalRows_web_orders = mysql_num_rows($web_orders);

$colname_web_orderList = "-1";
if (isset($_GET['order_sid'])) {
  $colname_web_orderList = $_GET['order_sid'];
}
$colname2_web_orderList = "-1";
if (isset($_GET['order_group'])) {
  $colname2_web_orderList = $_GET['order_group'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_orderList = sprintf("SELECT * FROM orderlist WHERE order_sid = %s AND order_group = %s ORDER BY odlist_id ASC", GetSQLValueString($colname_web_orderList, "text"),GetSQLValueString($colname2_web_orderList, "text"));
$web_orderList = mysql_query($query_web_orderList, $conn_web) or die(mysql_error());
$row_web_orderList = mysql_fetch_assoc($web_orderList);
$totalRows_web_orderList = mysql_num_rows($web_orderList);
?>
<?php session_start();?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——分享创意</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/pagestyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>

<body>
<div class="container">
  <?php include("meau.php"); ?>
</div>
  <?php include("shopmeau.php"); ?>
<div id="main" class="container">
  <div>
    <?php if($_SESSION['MM_Username'] == $row_web_orders['order_username'] ){?>
    <form action="<?php echo $editFormAction; ?>" method="POST" name="order" id="order">
      <h3 class="text-center">订单细节</h3>
      <table width="100%" border="1" cellspacing="0" cellpadding="0" background="images/back11_2.gif">
        <tr>
          <td align="left" valign="middle" background="images/board04.gif"><span class="font_black">亲爱的客戶 (<span class="font_red"><?php echo $row_web_orders['order_username']; ?> </span>)   
            您好，这是你的订单资料：</span></td>
        </tr>
      </table>
      <table width="100%" class="table table-bordered"  cellspacing="0" cellpadding="5">
        <tr>
          <td width="30%" align="right" class="board_add"><span class="font_black">收件者姓名：</span></td>
          <td width="442" align="left" class="board_add"><?php echo $row_web_orders['order_name2']; ?></td>
        </tr>
        <tr>
          <td align="right" class="board_add"><span class="font_black">联系电话：</span></td>
          <td align="left" class="board_add"><?php echo $row_web_orders['order_phone']; ?></td>
        </tr>
        <tr>
          <td align="right" class="board_add"><span class="font_black">收件者地址：</span></td>
          <td align="left" class="board_add"><?php echo $row_web_orders['order_cusadr']; ?></td>
        </tr>
        <tr>
          <td align="right" class="board_add"><span class="font_black">付款方式：</span></td>
          <td align="left" class="board_add"><?php echo $row_web_orders['order_paytype']; ?></td>
        </tr>
        <tr>
          <td align="right" class="board_add"><span class="font_black">完成付款：</span></td>
          <td align="left" class="board_add"><input <?php if (!(strcmp($row_web_orders['order_payok'],"y"))) {echo "checked=\"checked\"";} ?> name="order_payok" type="radio" id="radio" value="y" checked="checked" />
            已完成付款
            <label>
              <input <?php if (!(strcmp($row_web_orders['order_payok'],"n"))) {echo "checked=\"checked\"";} ?> type="radio" name="order_payok" id="radio2" value="n" />
              未完成付款</label></td>
        </tr>
        <!--
      <tr>
        <td align="right" class="board_add"><span class="font_black">匯款帳號末5碼：</span></td>
        <td align="left" class="board_add"><label>
          <input name="order_paynumber" type="text" id="order_paynumber" value="<?php echo $row_web_orders['order_paynumber']; ?>" size="10" />
          </label><span class="font_black">**匯款完成，請留下匯款帳號末5碼</span></td>
      </tr>-->
      </table>
      <div align="center"> <br />
        <label>
          <input type="submit" name="button3" class="btn btn-default" value="修改付款状态" />
        </label>
        <input type="button" name="submit" value="回上一页" class="btn btn-default" onClick="window.history.back()";>
        <input name="order_id" type="hidden" id="order_id" value="<?php echo $row_web_orders['order_id']; ?>" />
        <br />
      </div>
      <table width="100%" class="table table-bordered table-striped"  cellspacing="0" cellpadding="5">
        <caption class="text-center">
        <h4>订单资料:</h4>
        </caption>
        <thead>
        <tr class="font_black">
          <th width="10%" align="center" class="board_add3"><span class="font_black">商品图</span></th>
          <th width="25%" align="left" class="board_add3"><span class="font_black">商品名称</span></th>
          <th width="10%" align="center" valign="middle" class="board_add3"><span class="font_black">单价</span></th>
          <th width="10%" align="center" class="board_add3"><span class="font_black">订购数量</span></th>
        </tr>
       </thead>
       <tbody>
        <?php do { ?>
          <tr>
            <td align="center" class="board_add3"><img src="images/shop/thum/<?php echo $row_web_orderList['p_pic']; ?>" width="100%" /></td>
            <td height="30" align="left" class="board_add3"><span class="font_black">&nbsp;<?php echo $row_web_orderList['p_name']; ?></span></td>
            <td align="center" valign="middle" class="board_add3"><span class="font_black">&nbsp;<?php echo $row_web_orderList['p_price']; ?></span>
              <? $order_total=$order_total+$row_web_orderList['p_price']*$row_web_orderList['odlist_qty']?></td>
            <td align="center" class="board_add3"><?php echo $row_web_orderList['odlist_qty']; ?></td>
          </tr>
          <?php } while ($row_web_orderList = mysql_fetch_assoc($web_orderList)); ?>
         </tbody>
      </table>
      <table width="100%" class="table table-bordered"  cellspacing="0" cellpadding="5">
        <tr>
          <td height="20" align="right" class="board_add3"><span class="font_black">小计：<?php echo $order_total?></span></td>
        </tr>
        <tr>
          <td height="20" align="right" class="board_add3"><span class="font_black">运费：20元</span></td>
        </tr>
        <tr>
          <td height="20" align="right" class="board_add3"><span class="font_red">总计：<?php echo $order_total+20?></span></td>
        </tr>
      </table>
      <input type="hidden" name="MM_update" value="order" />
    </form>
    <?php }else{?>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="80" align="center" style="color:#F00">这不是属于你的订单资料!!</td>
      </tr>
    </table>
    <?php }?>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($web_orders);

mysql_free_result($web_orderList);
?>
