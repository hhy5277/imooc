<?php require_once('Connections/conn_web.php'); ?>
<?php 
// 建立cookie
if (!isset($_POST['username'])) {
	setcookie("username", "");
}
?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['username']) && isset($_POST['password'])) {
  // 圖形驗證
  require_once('recaptcha/recaptchalib.php');
  $privatekey = "6Le4pwYTAAAAAJBy??tfiFSrJW3scMfjIrq1X8AFir";
  $resp = recaptcha_check_answer ($privatekey,
                                $_SERVER["REMOTE_ADDR"],
                                $_POST["recaptcha_challenge_field"],
                                $_POST["recaptcha_response_field"]);
								  
  if (!$resp->is_valid) {
	echo '<script>
	        alert("验证码错误，请重新输入!");
			document.getElementById("password").value = "";	
			document.getElementById("password").focus();	
		  </script>'; 		  
  } else {    
  $loginUsername=$_POST['username'];
  $password=$_POST['password'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "index.php";
  $MM_redirectLoginFailed = "signin.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_conn_web, $conn_web);
  
  $LoginRS__query=sprintf("SELECT username, password FROM member WHERE username=%s AND password=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $connection1) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
	setcookie("username", "", time()-3600);
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
		echo '<script>
				alert("您不是会员,请注册!");
				document.getElementById("username").value = "";	
				document.getElementById("username").focus();
				location.href = "signin.php";
			  </script>'; 	
		  
	  }
    //header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>用户登录</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">

<link rel="stylesheet" href="css/bootstrap.min.css">
<script type="text/javascript">
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
</script>
<style>
#signmain{
	margin-top:100px;
	}
#sign1{
	margin:0 auto;
	}
</style>
</head>

<body>
<div class="container text-center" id="signmain">
<form action="<?php echo $loginFormAction; ?>" method="POST" id="form1" 
  onSubmit="return CheckFields();">
  <table width="50%" border="1" id="sign1">
    <tr align="center">
      <td height="50" colspan="2" valign="middle">
        <h3><span class="glyphicon glyphicon-user" aria-hidden="true"></span>登入</h3>
      </td>
    <tr>
      <td align="right">账号：</td>
      <td align="left">
        <input name="username" id="username" type="text" maxlength="10" value="<?php if (isset($_COOKIE['username'])) { echo $_COOKIE['username']; } ?>">                     
      </td>
    </tr>
    <tr>
      <td align="right">密码：</td>
      <td align="left">
      <input name="password" id="password" type="password" maxlength="12">  
       </td>
    </tr>
    <tr>
      <td colspan="2">
		<script type="text/javascript">
          var RecaptchaOptions = {
            theme : 'clean'
          };
        </script>   
        <?php
		  require_once('recaptcha/recaptchalib.php');			
		  $publickey = "6Le4pwYTAAAAAGxu0zdTXVK0IYHxPCcnraPh86fV"; // you got this from the signup page
		  echo recaptcha_get_html($publickey);
        ?>
      </td>
    </tr>
    <tr>
      <td colspan="2" align="center" valign="middle">
        <input type="submit" value="登入">
      </td>
    </tr>
    <tr>
      <td colspan="2">
        <a href="member_new.php">加入會員</a>
        <a href="exec_help.php">忘記密碼</a>
		<?php
          // 已經登入
          if (isset($_SESSION['MM_Username'])) {
        ?>    
            <a href="member_info.php">基本資料</a>
            <a href="<?php echo $logoutAction ?>" class="class7">登出</a>
        <?php
          }
        ?>
      </td>
    </tr>
  </table>  
</form>    
</div>
<script>
  document.getElementById("username").focus();
</script>  
</body>
</html>
