<?php require_once('Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_web_myOrder = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_web_myOrder = $_SESSION['MM_Username'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_myOrder = sprintf("SELECT * FROM orders WHERE order_username = %s ORDER BY order_id DESC", GetSQLValueString($colname_web_myOrder, "text"));
$web_myOrder = mysql_query($query_web_myOrder, $conn_web) or die(mysql_error());
$row_web_myOrder = mysql_fetch_assoc($web_myOrder);
$totalRows_web_myOrder = mysql_num_rows($web_myOrder);
?>
<?php session_start();?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />

<title>奇创网——分享创意</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">

<link href="css/pagestyle.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>

<body>
<div class="container">
  <?php include("meau.php"); ?>
</div>
  <?php include("shopmeau.php"); ?>
<div id="main" class="container">
  <div id="main3">
  	<h3 class="text-center">会员订单记录</h3>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%" align="left" valign="middle" >&nbsp; <span class="font_black">亲爱的客戶<span class="font_red"><?php echo $_SESSION['MM_Username']; ?> </span>您好，这是你的订单记录。</span></td>
      </tr>
    </table>
    <?php if ($totalRows_web_myOrder > 0) { // Show if recordset not empty ?>
      <table width="100%" class="table table-bordered table-striped"  cellspacing="0" cellpadding="0">
      <thead>
        <tr>
          <th width="20%" height="30" align="center" class="board_add"><span class="font_black">订单编号</span></th>
          <th width="25%" align="center" class="board_add"><span class="font_black">订购日期</span></th>
          <th width="10%" align="center" class="board_add">操作</th>
        </tr>
       </thead>
       <tbody>
        <?php do { ?>
          <tr>
            <td height="30" align="center" class="board_add"><?php echo $row_web_myOrder['order_id']; ?></td>
            <td align="left" class="board_add"><?php echo $row_web_myOrder['order_date']; ?></td>
            <td align="center" class="board_add"><a href="shopcart_myorderView.php?order_id=<?php echo $row_web_myOrder['order_id']; ?>&amp;order_sid=<?php echo $row_web_myOrder['order_sid']; ?>&amp;order_group=<?php echo $row_web_myOrder['order_group']; ?>" class="btn btn-info">检视</a></td>
          </tr>
          <?php } while ($row_web_myOrder = mysql_fetch_assoc($web_myOrder)); ?>
          </tbody>
      </table>
      <?php } // Show if recordset not empty ?>
    <?php if ($totalRows_web_myOrder == 0) { // Show if recordset empty ?>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="80" align="center" style="color:#F00">目前沒有购物记录!</td>
      </tr>
      <tr>
     <td height="80" align="center"><a href="shop.php" class="btn btn-default">返回商城</a></td>
     </tr>
  </table>
  <?php } // Show if recordset empty ?>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($web_myOrder);
?>
