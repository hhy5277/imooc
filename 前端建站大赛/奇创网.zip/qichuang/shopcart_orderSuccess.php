<?php require_once('Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_web_orders = "-1";
if (isset($_SESSION['order_sid'])) {
  $colname_web_orders = $_SESSION['order_sid'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_orders = sprintf("SELECT * FROM orders WHERE order_sid = %s ORDER BY order_id DESC", GetSQLValueString($colname_web_orders, "text"));
$web_orders = mysql_query($query_web_orders, $conn_web) or die(mysql_error());
$row_web_orders = mysql_fetch_assoc($web_orders);
$totalRows_web_orders = mysql_num_rows($web_orders);
?>
<? 
session_start();
//將session變數cart,取消登記,網頁左方的觀看購物車按鈕會取消顯示
session_unregister("cart");
//將session變數order_group,取消登記,下次商品新加入購物車時會再登記，訂單才不會產生錯誤
session_unregister("order_group");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——分享创意</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/pagestyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>

<body>
  <?php include("meau.php"); ?>
  
  <?php include("shopmeau.php"); ?>
<div id="main" class="container">
  <div>
    <form name="form1" method="shopcart" action="">
      <h3 class="text-center">订单完成</h3>
      <table width="100%" class="table table-bordered"  cellspacing="0" cellpadding="0">
        <caption class="text-center">
        <h4>订单资料:</h4>
        </caption>
        <tr>
          <td align="center" valign="middle"><table width="70%" class="table table-bordered"  cellspacing="0" cellpadding="5">
              <tr>
                <td align="left" class="board_add"><span class="font_black">订单编号：</span><?php echo $row_web_orders['order_id']; ?></td>
              </tr>
              <tr>
                <td align="left" class="board_add"><span class="font_black">订购者：<?php echo $row_web_orders['order_name1']; ?></span></td>
              </tr>
              <tr>
                <td align="left" class="board_add"><span class="font_black">收件者：<?php echo $row_web_orders['order_name2']; ?></span></td>
              </tr>
              <tr>
                <td align="left" class="board_add"><span class="font_black">联系电话：<?php echo $row_web_orders['order_phone']; ?></span></td>
              </tr>
              <tr>
                <td align="left" class="board_add"><span class="font_black">收件者地址：<?php echo $row_web_orders['order_cusadr']; ?></span></td>
              </tr>
              <tr>
                <td align="left" class="board_add"><span class="font_black">付款方式：<?php echo $row_web_orders['order_paytype']; ?></span></td>
              </tr>
              <tr>
                <td align="left" class="board_add"><span class="font_black">订单总金额：<?php echo $row_web_orders['order_total']; ?></span></td>
              </tr>
            </table>
            <p>&nbsp;</p>
            <p>
              <input name="button" type="button" class="btn btn-default" onclick="window.location='shop.php'" value="回首页">
            </p></td>
        </tr>
      </table>
    </form>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($web_orders);
?>
