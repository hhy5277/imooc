<?php require_once('Connections/conn_web.php'); ?>
<? $order_total='0';?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "order")) {
  $insertSQL = sprintf("INSERT INTO orders (order_username, order_name1, order_name2, order_phone, order_cusadr, order_paytype, order_total, order_sid, order_group, order_date) VALUES ( %s,%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['order_username'], "text"),
                       GetSQLValueString($_POST['order_name1'], "text"),
                       GetSQLValueString($_POST['order_name2'], "text"),
                       GetSQLValueString($_POST['order_phone'], "text"),
                       GetSQLValueString($_POST['order_cusadr'], "text"),
					   GetSQLValueString($_POST['order_paytype'], "text"),
                       GetSQLValueString($_POST['order_total'], "text"),
                       GetSQLValueString($_POST['order_sid'], "text"),
                       GetSQLValueString($_POST['order_group'], "text"),
                       GetSQLValueString($_POST['order_date'], "date"));

  mysql_select_db($database_conn_web, $conn_web);
  $Result1 = mysql_query($insertSQL, $conn_web) or die(mysql_error());

  $insertGoTo = "shopcart_orderSuccess.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  //自訂變數$order_sid取得Session變數order_sid值
  $order_sid=$_SESSION["order_sid"];
  //自訂變數$order_group取得Session變數order_group值
  $order_group=$_SESSION["order_group"];
  /* 指定將orderlist資料表中order_sid與order_group欄位值符合上述session值的，將odlist_ok欄位值修改為y的SQL語法 */
  $updateSQL = "UPDATE orderlist SET odlist_ok='y' WHERE order_sid='$order_sid' and order_group='$order_group'";
  /* 執行更新動作 */
  mysql_select_db($database_conn_web, $conn_web);
  $Result = mysql_query($updateSQL, $conn_web) or die(mysql_error());

  header(sprintf("Location: %s", $insertGoTo));
}

$colname_web_member = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_web_member = $_SESSION['MM_Username'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_member = sprintf("SELECT * FROM member_md5 WHERE username = %s", GetSQLValueString($colname_web_member, "text"));
$web_member = mysql_query($query_web_member, $conn_web) or die(mysql_error());
$row_web_member = mysql_fetch_assoc($web_member);

$colname_web_orderList = "-1";
if (isset($_SESSION['order_sid'])) {
  $colname_web_orderList = $_SESSION['order_sid'];
}
$colname2_web_orderList = "-1";
if (isset($_SESSION['order_group'])) {
  $colname2_web_orderList = $_SESSION['order_group'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_orderList = sprintf("SELECT * FROM orderlist WHERE order_sid = %s AND order_group = %s ORDER BY odlist_id ASC", GetSQLValueString($colname_web_orderList, "text"),GetSQLValueString($colname2_web_orderList, "text"));
$web_orderList = mysql_query($query_web_orderList, $conn_web) or die(mysql_error());
$row_web_orderList = mysql_fetch_assoc($web_orderList);
$totalRows_web_orderList = mysql_num_rows($web_orderList);

$colname_web_member = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_web_member = $_SESSION['MM_Username'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_member = sprintf("SELECT * FROM member_md5 WHERE username = %s", GetSQLValueString($colname_web_member, "text"));
$web_member = mysql_query($query_web_member, $conn_web) or die(mysql_error());
$row_web_member = mysql_fetch_assoc($web_member);
$totalRows_web_member = mysql_num_rows($web_member);

mysql_select_db($database_conn_web, $conn_web);
$query_web_shop = "SELECT * FROM shop1";
$web_shop = mysql_query($query_web_shop, $conn_web) or die(mysql_error());
$row_web_shop = mysql_fetch_assoc($web_shop);
$totalRows_web_shop = mysql_num_rows($web_shop);
?>
<?php session_start();?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />

<title>奇创网——分享创意</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">

<link href="css/pagestyle.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>

<body>
<div class="container">
  <?php include("meau.php"); ?>
</div>
  <div class="container">
    <nav class="navbar navbar-default" role="navigation">
      <div class="navbar-header"> <a class="navbar-brand" href="shop.php"><strong>奇创网商城</strong></a> </div>
      <div>
        <ul class="nav navbar-nav">
          <li class="dropdown"> <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown"> 分类 <b class="caret"></b> </a>
            <ul class="dropdown-menu">
              <li><a href="shop.php">所有</a></li>
              <?php do { ?>
                <li class="divider"></li>
                <li><a href="products.php?shop_id=<?php echo $row_web_shop1['shop_id']; ?>"><?php echo $row_web_shop1['shop_name']; ?></a></li>
                <?php } while ($row_web_shop = mysql_fetch_assoc($web_shop)); ?>
            </ul>
          </li>
        </ul>
        <? if(empty($_SESSION["MM_Username"])){?>
        <div>
		<p class="navbar-text" style="font-size:1.8rem"><a href="member/index.php"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> 登入</a></p>
        </div>
        <? }else{?>
        <ul class="nav navbar-nav">
        	<li class="dropdown">
            <a href="javascript:();" class="dropdown-toggle" data-toggle="dropdown">
               会员中心 
               <b class="caret"></b>
            </a>
            <ul class="dropdown-menu">
               <li><a href="shopcart_myorder.php">订单记录</a></li>
               <? if($_SESSION["MM_Username"]=='admin'){?>
               <li class="divider"></li>
               <li><a href="admin/admin.php">前往后台</a></li>
        	   <? }?>
               <li class="divider"></li>
               <li><a href="logout.php">退出</a></li>
            </ul>
         </li>
        </ul>
        <? }?>
        <form class="navbar-form navbar-right" role="search" action="">
          <div class="form-group">
            <input type="text" class="form-control" placeholder="Search">
          </div>
          <button type="submit" class="btn btn-default">搜索</button>
        </form>
        <?php if(isset($_SESSION["cart"])){?>
        <a href="shopcart_show.php">
        <button type="button" class="btn btn-default navbar-btn"> 我的购物车 </button>
        </a>
        <?php }?>
      </div>
    </nav>
  </div>
  
<div id="main" class="container">
  <div>
    <?php if(isset($_SESSION["MM_Username"])){//如果驗證到會員登入的Session變數MM_Username，顯示本區塊?>
    <form action="<?php echo $editFormAction; ?>" method="POST" name="order" id="order" onsubmit="YY_checkform('order','order_name2','#q','0','请输入收件者姓名','order_phone','#q','0',请输入收件者电话','order_cusadr','#q','0','请输入收件者地址');return document.MM_returnValue">
    <table width="100%" class="table table-bordered" cellspacing="0" cellpadding="0">
      <tr>
      <td>
      <h3 class="text-center">订购资料</h3>
      </td>
      </tr>
      <tr>
        <td width="100%" align="center" valign="middle" ><span class="font_black">亲爱的会员 (<?php echo $_SESSION['MM_Username']; ?>)
<input name="order_username" type="hidden" id="order_username" value="<?php echo $row_web_member['username']; ?>" />
<input name="order_name1" type="hidden" id="order_name1" value="<?php echo $row_web_member['name']; ?>" />
          您好请确认你的资料和订购清单：</span></td>
      </tr>
    </table>
    <table width="100%" class="table table-bordered"  align="center" cellpadding="5" cellspacing="0">
      <tr>
        <td width="20%" align="center" class="board_add"><span class="font_black">收件者姓名：</span></td>
        <td width="448" class="board_add">
        <label>
          <input name="order_name2" type="text" id="order_name2" value="<?php echo $row_web_member['name']; ?>" /> 
          </label>          
          <span class="font_red">*</span></td>
      </tr>
      <tr>
        <td align="center" class="board_add"><span class="font_black">联系电话：</span></td>
        <td class="board_add"><label>
          <input name="order_phone" type="text" id="order_phone" value="<?php echo $row_web_member['phone']; ?>" />
          <input name="email" type="hidden" id="email" value="<?php echo $row_web_member['email']; ?>" />
        </label><span class="font_red">*</span></td>
      </tr>
      <tr>
        <td align="center" class="board_add"><span class="font_black">收件者地址：</span></td>
        <td class="board_add"><label>
          <input name="order_cusadr" type="text" id="order_cusadr" value="<?php echo $row_web_member['address']; ?>" size="100%" />
        </label><span class="font_red">*</span></td>
      </tr>
      <tr>
        <td align="center" class="board_add"><span class="font_black">付款方式：</span></td>
        <td class="board_add">
          <span class="font_black">
          <label>
          <input type="radio" name="order_paytype" id="radio3" value="货到付款" checked="checked" />
          货到付款
          <input type="radio" name="order_paytype" id="radio3" value="支付宝付款" />
          支付宝付款</label></span></td>
      </tr>
    </table>
    <br />
    <h3 class="text-center">订购清单</h3>
    <table width="100%" class="table table-bordered table-striped"  cellspacing="0" cellpadding="5">
    <thead>
      <tr class="font_black">
        <th width="10%" align="center" class="board_add3"><span class="font_black">商品图</span></th>
        <th width="20%" align="left" class="board_add3"><span class="font_black">商品名称</span></th>
        <th width="10%" align="center" valign="middle" class="board_add3"><span class="font_black">单价</span></th>
        <th width="10%" align="center" class="board_add3"><span class="font_black">订购数量</span></th>
        </tr>
      </thead>
      <?php do { ?>
        <tr>
          <td align="center" class="board_add3"><img src="images/shop/<?php echo $row_web_orderList['p_pic']; ?>" width="100%" /></td>
          <td align="left" class="board_add3"><span class="font_black">&nbsp;<?php echo $row_web_orderList['p_name']; ?></span></td>
          <td align="center" valign="middle" class="board_add3"><span class="font_black">&nbsp;<?php echo $row_web_orderList['p_price']; ?></span><? $order_total=$order_total+$row_web_orderList['p_price']*$row_web_orderList['odlist_qty']?></td>
          <td align="center" class="board_add3"><?php echo $row_web_orderList['odlist_qty']; ?></td>
        </tr>
        <?php } while ($row_web_orderList = mysql_fetch_assoc($web_orderList)); ?>
    </table>
    <table width="100%" class="table table-bordered"  cellspacing="0" cellpadding="5">
      <tr>
        <td height="20" align="right" class="board_add3"><span class="font_black">小计：<?php echo $order_total;?></span></td>
      </tr>
      <tr>
        <td height="20" align="right" class="board_add3"><span class="font_black">运费：20元</span></td>
      </tr>
      <tr>
        <td height="20" align="right" class="board_add3"><span class="font_red">
          总计：<?php echo $order_total+20;?></span></td>
      </tr>
    </table>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="70" align="center" valign="middle">
           <input name="button" type="submit" class="btn btn-default" value="确认并结账">
           <input name="button2" type="button" class="btn btn-default" onclick="window.location='shop.php'" value="继续购物">
           <input type="hidden" name="order_total" id="order_total" value="<?php echo $order_total+100?>" />
           <input name="order_sid" type="hidden" id="order_sid" value="<?php echo $_SESSION['order_sid']; ?>" />
           <input name="order_group" type="hidden" id="order_group" value="<?php echo $_SESSION['order_group']; ?>" />
          <input name="order_date" type="hidden" id="order_date" value="<?php echo date("Y-m-d H:i:s")?>" /></td>
      </tr>
    </table>
    <input type="hidden" name="MM_insert" value="order" />
    </form>
    <?php }else{ //否則顯示另一個區塊?>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="80" align="center" style="color:#F00; font-size:2.5rem;padding-top:100px">结账前请先登录会员!!</td>
      </tr>
      <tr>
        <td height="80" align="center"><a href="member/index.php" class="btn btn-default">前往会员中心</a></td>
      </tr>
    </table>
    <?php }?>
  </div>
</div>

</body>
</html>
<?php
mysql_free_result($web_orderList);

mysql_free_result($web_member);

mysql_free_result($web_shop);
?>
