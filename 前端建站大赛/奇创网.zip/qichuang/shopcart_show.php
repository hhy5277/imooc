<?php require_once('Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  //計算更新的資料筆數
  $countNum=count($_POST["odlist_id"]);
  //利用迴圈更新資料
  for($i=0;$i<$countNum;$i++){
	//自訂變數接收上一頁傳來的欄位之陣列值
    $odlist_id=$_POST["odlist_id"][$i];
    $odlist_qty=$_POST["odlist_qty"][$i];
  $updateSQL = sprintf("UPDATE orderlist SET odlist_qty=%s WHERE odlist_id=%s",
                       GetSQLValueString($odlist_qty, "text"),
                       GetSQLValueString($odlist_id, "int"));

  mysql_select_db($database_conn_web, $conn_web);
  $Result1 = mysql_query($updateSQL, $conn_web) or die(mysql_error());
  }
  $updateGoTo = "shopcart_show.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_web_orderList = "-1";
if (isset($_SESSION['order_sid'])) {
  $colname_web_orderList = $_SESSION['order_sid'];
}
$colname2_web_orderList = "-1";
if (isset($_SESSION['order_group'])) {
  $colname2_web_orderList = $_SESSION['order_group'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_orderList = sprintf("SELECT * FROM orderlist WHERE order_sid = %s AND order_group = %s ORDER BY odlist_id ASC", GetSQLValueString($colname_web_orderList, "text"),GetSQLValueString($colname2_web_orderList, "text"));
$web_orderList = mysql_query($query_web_orderList, $conn_web) or die(mysql_error());
$row_web_orderList = mysql_fetch_assoc($web_orderList);
$totalRows_web_orderList = mysql_num_rows($web_orderList);
?>
<? session_start();?>
<? $order_total='0';?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——分享创意</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/pagestyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>

<body>
<div class="container">
  <?php include("meau.php"); ?>
</div>
  <?php include("shopmeau.php"); ?>
<div id="main" class="container">
  <div>
    <form name="form1" method="POST" action="<?php echo $editFormAction; ?>">
      <h3 class="text-center">购物车清单</h3>
      <?php if ($totalRows_web_orderList > 0) { // Show if recordset not empty ?>
        <table width="100%" class="table table-bordered table-striped"  cellspacing="0" cellpadding="5">
          <thead>
            <tr>
              <th width="10%" align="center" valign="middle" >商品图</th>
              <th width="20%" align="center" valign="middle" >商品名称</th>
              <th width="10%" align="center" valign="middle" >单价</th>
              <th width="10%" align="center" valign="middle" >订购数量</th>
              <th width="10%" align="center" valign="middle" >操作</th>
            </tr>
          </thead>
          <tbody>
            <?php do { ?>
              <tr>
                <td align="center" ><img src="images/shop/<?php echo $row_web_orderList['p_pic']; ?>" width="100%" /></td>
                <td align="center" valign="middle"><?php echo $row_web_orderList['p_name']; ?></td>
                <td align="center" valign="middle"><?php echo $row_web_orderList['p_price']; ?></span></td>
                <td align="center" valign="middle" ><label>
                    <input name="odlist_qty[]" type="text" id="odlist_qty[]" value="<?php echo $row_web_orderList['odlist_qty']; ?>" size="3" maxlength="3" />
                    <input name="odlist_id[]" type="hidden" id="odlist_id[]" value="<?php echo $row_web_orderList['odlist_id']; ?>" />
                    <input name="order_total" type="hidden" id="order_total" value="<?php $order_total=$order_total+$row_web_orderList['p_price']*$row_web_orderList['odlist_qty']?>" />
                  </label></td>
                <td align="center" valign="middle" ><a href="shopcart_del2.php?delSure=1&amp;odlist_id=<?php echo $row_web_orderList['odlist_id']; ?>" class="btn btn-danger">取消</a></td>
              </tr>
              <?php } while ($row_web_orderList = mysql_fetch_assoc($web_orderList)); ?>
          </tbody>
        </table>
        <table width="100%" border="0" cellspacing="0" cellpadding="5">
          <tr>
            <td height="50" align="right" >小计：<?php echo $order_total ;?></td>
          </tr>
          <tr>
            <td height="50" align="right" >运费：20元</td>
          </tr>
          <tr>
            <td height="50" align="right" >总计：<?php echo $order_total+20 ;?></td>
          </tr>
        </table>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="70" align="center" valign="middle"><input name="button" type="button" class="btn btn-default" onclick="window.location='shop.php'" value="继续购物">
              <input name="button2" type="submit" class="btn btn-default" value="更新购物车">
              <input name="button3" type="button" class="btn btn-danger" onclick="window.location='shopcart_del.php'" value="清空购物车">
              <input name="button4" type="button" class="btn btn-success" onclick="window.location='shopcart_checkout.php'" value="立即结账"></td>
          </tr>
        </table>
        <?php } // Show if recordset not empty ?>
      <input type="hidden" name="MM_update" value="form1" />
    </form>
    <?php if ($totalRows_web_orderList == 0) { // Show if recordset empty ?>
      <table width="100%" border="0" cellspacing="0" cellpadding="0" style="color:#F00">
        <tr>
          <td height="80" align="center" valign="middle"><h4>你的购物车还没有商品，请前往商城添加商品!</h4></td>
        </tr>
        <tr>
          <td height="80" align="center"><input name="button" type="button" class="btn btn-info" onclick="window.location='shop.php'" value="前往商城"></td>
        </tr>
      </table>
      <?php } // Show if recordset empty ?>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($web_orderList);
?>
