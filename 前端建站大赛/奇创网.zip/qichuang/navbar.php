<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——分享创意</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>
<!--a-->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-55122725-1', 'auto');
  ga('send', 'pageview');
</script>
<script type="text/javascript">
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
</script>

<!--end Google analysis-->
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>

<body>
<div class="container">
  <nav class="navbar navbar-default" role="navigation">
  	<div class="navbar-header navbar-text">
      <img src="images/main/logo.png" height="50px" alt="logo">
   </div>
    <div class="pull-left">
      <ul class="nav nav-pills navbar-text" style="font-size:2.2rem">
        <li class="active"><a href="index.php"> &nbsp; 首页 &nbsp; </a></li>
        <li><a href="cy.html">&nbsp; 创意 &nbsp; </a></li>
        <li><a href="sj.html">&nbsp; 设计 &nbsp; </a></li>
        <li><a href="video.html">&nbsp; 视频 &nbsp; </a></li>
        <li><a href="shop.php">&nbsp; 产品 &nbsp; </a></li>
        <li><a href="other.html">&nbsp; 其他 &nbsp; </a></li>
      </ul>
    </div>
  </nav>
  
</div>
</body>
</html>