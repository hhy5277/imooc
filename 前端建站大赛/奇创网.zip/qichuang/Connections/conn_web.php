<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_conn_web = "qdm177116650.my3w.com";
$database_conn_web = "qdm177116650_db";
$username_conn_web = "qdm177116650";
$password_conn_web = "lilong5431580";
$conn_web = mysql_pconnect($hostname_conn_web, $username_conn_web, $password_conn_web) or trigger_error(mysql_error(),E_USER_ERROR); 
mysql_query("SET NAMES utf8");

session_start();
if(isset($_POST['uCheck']) and isset($_POST['pCheck'])) {
	if(isset($_POST['remember'])) {
		
		setcookie("rmUsername",$_POST['uCheck'],time()+3600*24*30);
		
		setcookie("rmPassword",$_POST['pCheck'],time()+3600*24*30);
	}else{
		setcookie("rmUsername",'', time()); 
		setcookie("rmPassword",'', time());
	}
}
?>