<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>::德瑞購物廣場::</title>
<link href="CSS/main.css" rel="stylesheet">
</head>
<body>
<div class="class1">
  歡迎光臨 德瑞購物廣場
</div>
<div class="class2">
  <input type="button" value="返回會員中心" class="class3" 
    onclick="document.location='index_md5.php'; return false;">
</div>
</body>
</html>