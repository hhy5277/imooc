<?php session_start();?>
<?php require_once('../Connections/conn_web.php'); ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>加入会员成功</title>
<link rel="stylesheet" href="../css/bootstrap.min.css">
</head>

<body>
<div>
<p class="text-center" style="font-size:2.5rem; color:#FFF; margin-bottom:50px">恭喜！你已成功加入会员！</p>
<p class="text-center"><a href="index.php" class="btn btn-default">前往登入</a></p>
</div>
</body>
</html>