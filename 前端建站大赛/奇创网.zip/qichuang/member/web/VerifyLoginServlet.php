<?php 

// error_reporting(0);
require_once dirname(dirname(__FILE__)) . '/lib/class.geetestlib.php';
session_start();
$GtSdk = new GeetestLib();
if ($_SESSION['gtserver'] == 1) {
    $result = $GtSdk->validate($_POST['geetest_challenge'], $_POST['geetest_validate'], $_POST['geetest_seccode']);
    if ($result == TRUE) {
        header('location:../../shop.php');	
    } else if ($result == FALSE) {
        header('location:../index.php');
    } else {
        echo 'FORBIDDEN';
    }
}else{
    if ($GtSdk->get_answer($_POST['geetest_validate'])) {
		header('location:../../shop.php');
    }else{
        header('location:../index.php');
    }
}

?>


