<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>忘记密码</title>
<link rel="stylesheet" href="../css/bootstrap.min.css">
<script src="SpryAssets/SpryData.js"></script>
<script src="JavaScript/exec_help.js"></script>
<script type="text/javascript">
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
</script>
</head>
<body>
<form action="index.php" method="post" id="form1" 
  onkeydown="if(event.keyCode==13) return false;" onSubmit="return CheckFields();">
  <table border="1" style="margin-left: auto;margin-right: auto;margin-top:100px">
    <tr>
      <td class="class2">
        请输入你的账号，我们会将密码寄送至您的邮箱。
      </td>
    </tr>
    <tr>
      <td class="class2">
      <label>
        账号：
      </label>
        <input name="username" id="username" type="text" size="30" maxlength="10">
      </td>
    </tr>
    <tr>
      <td class="class3">
        <input type="submit" value="确认" class="btn btn-default">
        <input type="button" class="btn btn-default" onClick="MM_goToURL('parent','index.php');return document.MM_returnValue" value="取消">
      </td>
    </tr>
  </table>
</form>
</body>
</html>
<script>
  document.getElementById("username").focus();
</script>