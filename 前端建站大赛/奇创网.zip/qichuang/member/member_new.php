<?php require_once('../Connections/conn_web.php'); ?>
<?php 
// 建立cookie, 用来记住使用者填入的资料
if (!isset($_POST['username'])) {
  setcookie("username", "");
}
if (!isset($_POST['name'])) {
  setcookie("name", "");
}
if (!isset($_POST['year'])) {
  setcookie("year", "");
}
if (!isset($_POST['month'])) {
  setcookie("month", "");
}
if (!isset($_POST['day'])) {
  setcookie("day", "");
}
if (!isset($_POST['name'])) {
  setcookie("name", "");
}
if (!isset($_POST['email'])) {
  setcookie("email", "");
}
if (!isset($_POST['phone'])) {
  setcookie("phone", "");
}
if (!isset($_POST['address'])) {
  setcookie("address", "");
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO member_md5 (username, password, name, sex, birthday, email, phone, address, userlevel) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString(md5($_POST['password']), "text"),
                       GetSQLValueString($_POST['name'], "text"),
                       GetSQLValueString($_POST['sex'], "text"),
                       GetSQLValueString($_POST['birthday'], "date"),
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['phone'], "text"),
                       GetSQLValueString($_POST['address'], "text"),
                       GetSQLValueString($_POST['userlevel'], "int"));

  mysql_select_db($database_conn_web, $conn_web);
  $Result1 = mysql_query($insertSQL, $conn_web) or die(mysql_error());

  $insertGoTo = "index.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>注册会员</title>
<link rel="stylesheet" href="../css/bootstrap.min.css">
<script src="SpryAssets/SpryData.js"></script>
<script src="JavaScript/member_new.js"></script>
<script type="text/javascript">
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
</script>
<style>
.side {
	width: 80%;
	margin: 20px auto;
	}
.form-group {
	margin-top: 10px;
	margin-left: 10px;
	}
.form-group a {
	margin-left:50px;
	}
#username,
#password,
#name,
#email,
#phone,
#address {
	width: 300px;
	height: 40px;
	}
#year { height: 40px; }
</style>

</head>
<body>
<div class="panel panel-default side">
<div class="panel panel-heading text-center" style="font-size:2.5rem; color:#F00">
  <strong>注册会员</strong>
</div>
<div class="panel panel-body">
<form action="<?php echo $editFormAction; ?>" name="form1" method="POST" 
  id="form1" onkeydown="if(event.keyCode==13) return false;" 
  onsubmit="return CheckFields();"> 
  <div class="form-group">
    <label for="username">账号：</label>
    <input name="username" id="username" type="text" size="20" maxlength="10" placeholder="请输入账号">
      （3~12个字符，请勿使用中文）
  </div>
  <div class="form-group">
    <label for="password">密码：</label>
    <input name="password" id="password" type="password" size="20" maxlength="12" placeholder="请输入密码">
         （6~12个字符，请勿使用中文）
  </div>
  <div class="form-group">
    <label for="name">姓名：</label>
    <input name="name" id="name" type="text" size="20" maxlength="20" placeholder="请输入姓名">
  </div>
  <div class="form-group">
    <label>性別：</label>
    <input name="sex" type="radio" value="男" checked="checked">
         男
    <input name="sex" type="radio" value="女">
         女
  </div>
  <div class="form-group">
    <label for="email">邮箱：</label>
    <input name="email" id="email" type="text" size="40" maxlength="40" placeholder="请输入邮箱">
  </div>
  <div class="form-group">
    <label for="year">出生日期：</label>
    <input name="year" id="year" type="text" size="6" maxlength="4">
         &nbsp;年&nbsp;
       <!-- 在选單中填入[出生日期]的[月]栏位值 -->
       <select name="month" id="month">
       <?php
         for ($i = 1; $i <= 12; $i++)
         {
         ?>
           <option value="<?php echo $i ?>" 
           <?php 
             if (!empty($_COOKIE['month']))
             {
               if ($i == $_COOKIE['month']) {
                 echo "selected=\"selected\"";
               }
             } 
           ?>>
             &nbsp;&nbsp;<?php echo $i ?>&nbsp; 
           </option>         
         <?php
         }
         ?>
       </select>
       &nbsp;月&nbsp;&nbsp;
       <select name="day" id="day">                   
       <!-- 在选單中填入[出生日期]的[日]栏位值 -->
       <?php
         for ($i = 1; $i <= 31; $i++)
         {
         ?>
           <option value="<?php echo $i ?>" 
           <?php 
             if (!empty($_COOKIE['day']))
             {
               if ($i == $_COOKIE['day']) {
                 echo "selected=\"selected\"";
               }
             }
             ?>>
             &nbsp;&nbsp;<?php echo $i ?>&nbsp;&nbsp; 
           </option>         
         <?php
         }
         ?>
       </select>
       &nbsp;日
  </div>
  <div class="form-group">
    <label for="phone">联系电话：</label>
    <input name="phone" id="phone" type="text" size="20" maxlength="15" placeholder="请输入电话">
  </div>
  <div class="form-group">
    <label for="address">收件地址：</label>
    <input name="address" id="address" type="text" size="60" maxlength="120" placeholder="请输入地址">
  </div>
  <div class="form-group">
  <input class="btn btn-success btn-lg" type="submit" value="确定" >
  <input class="btn btn-default btn-lg" type="button"  onClick="MM_goToURL('parent','index.php');return document.MM_returnValue" 
    value="取消">
  </div>
  <input name="userlevel" id="userlevel" type="hidden" value="0">
  <input name="birthday" id="birthday" type="hidden">
  <input type="hidden" name="MM_insert" value="form1" id="MM_insert" >
</form>
</div>
</div>

</body>
</html>
<script>
  document.getElementById("username").focus();
</script>