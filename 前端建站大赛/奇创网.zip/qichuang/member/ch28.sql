-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- 主機: localhost
-- 建立日期: Apr 13, 2013, 05:03 �W��
-- 伺服器版本: 5.5.8
-- PHP 版本: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 資料庫: `ch28`
--

-- --------------------------------------------------------

--
-- 資料表格式： `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `sex` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `birthday` date NOT NULL,
  `email` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `userlevel` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=85 ;

--
-- 列出以下資料庫的數據： `member`
--

INSERT INTO `member` (`id`, `username`, `password`, `name`, `sex`, `birthday`, `email`, `phone`, `address`, `userlevel`) VALUES
(1, 'daniel', '123456', '管理員', '男', '1999-01-01', 'daniel@derek.com', '02-11112222', '德瑞工作室', 99),
(2, 'andy', 'a123456', '李大華', '男', '1997-03-07', 'andy@example.com', '02-12345678', '台北市忠孝東路100號', 0),
(3, 'bob', 'b123456', '陳小明', '男', '1997-02-01', 'bob@example.com', '02-23456789', '台北市信義路23號', 0),
(4, 'cindy', 'c123456', '劉小珍', '女', '1997-08-03', 'cindy@example.com', '02-34567890', '台北市仁愛路332號', 0),
(5, 'mary', 'm123456', '廖小敏', '女', '1997-10-21', 'mary@example.com', '02-45678901', '台北市和平路194號', 0),
(6, 'david', 'd123456', '吳大龍', '男', '1997-05-17', 'david@example.com', '02-56789012', '台北市萬華路90號', 0),
(7, 'jane', 'j123456', '辛小君', '女', '1997-06-22', 'jane@example.com', '02-67890123', '台北市辛亥路4號', 0),
(8, 'kim', 'k123456', '趙大志', '男', '1997-09-13', 'kim@example.com', '02-78901234', '台北市基隆路211號', 0),
(9, 'sam', 's123456', '賴大平', '男', '1997-04-30', 'sam@example.com', '02-89012345', '台北市松平路112號', 0);

-- --------------------------------------------------------

--
-- 資料表格式： `member_md5`
--

CREATE TABLE IF NOT EXISTS `member_md5` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `sex` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `birthday` date NOT NULL,
  `email` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `userlevel` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- 列出以下資料庫的數據： `member_md5`
--

INSERT INTO `member_md5` (`id`, `username`, `password`, `name`, `sex`, `birthday`, `email`, `phone`, `address`, `userlevel`) VALUES
(1, '210dc1fd8cb4e4e43cb4961b28fac275', '59f2443a4317918ce29ad28a14e1bdb7', '方小萍', '女', '1997-05-30', 'tiffany@example.com', '02-90123456', '台北市重慶東路233號', 0);
