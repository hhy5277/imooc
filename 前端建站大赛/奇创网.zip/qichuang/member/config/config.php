<?php 
/**
*  Geetest配置文件
* @author Tanxu
*/
define("CAPTCHA_ID", "ee776f862211d8398c07ab625679704d");
define("PRIVATE_KEY", "1398182be206b0c4ea3a7c6c7313aa19");

 ?>