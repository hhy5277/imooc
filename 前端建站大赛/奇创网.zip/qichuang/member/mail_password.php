<?php require_once('Connections/connection1.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_rs1 = "-1";
if (isset($_GET['username'])) {
  $colname_rs1 = $_GET['username'];
}
mysql_select_db($database_connection1, $connection1);
$query_rs1 = sprintf("SELECT username, password, email FROM member WHERE username = %s", GetSQLValueString($colname_rs1, "text"));
$rs1 = mysql_query($query_rs1, $connection1) or die(mysql_error());
$row_rs1 = mysql_fetch_assoc($rs1);
$totalRows_rs1 = mysql_num_rows($rs1);

// 指定帳號的資料筆數
if ($totalRows_rs1 > 0)
{	
	// 收信人
	$to = $row_rs1['email'];
	// 主旨
	$subject = iconv("utf-8", "big5", "奇创网 - 會員密碼回函");
	// 信件的內容
	$body = "歡迎您加入奇创网會員。<br>";
	$body .= "您個人的會員密碼為　" . $row_rs1['password'] . " 。";	
	$body = iconv("utf-8", "big5", $body);
	// 信件的表頭
	$header = "Content-type: text/html; chars1et=utf-8\r\n" . "From: 986069558@qq.com";	
	// 寄信
	mail($to, $subject, $body, $header);
}
// 傳回指定帳號的資料筆數
echo $totalRows_rs1;
mysql_free_result($rs1);
?>
