<?php require_once('Connections/connection1.php'); ?>
<?php 
if (!isset($_SESSION)) {
  session_start();
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_rs1 = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_rs1 = $_SESSION['MM_Username'];
}
mysql_select_db($database_connection1, $connection1);
$query_rs1 = sprintf("SELECT * FROM member WHERE username = %s", GetSQLValueString($colname_rs1, "text"));
$rs1 = mysql_query($query_rs1, $connection1) or die(mysql_error());
$row_rs1 = mysql_fetch_assoc($rs1);
$totalRows_rs1 = mysql_num_rows($rs1);
?>
<?php
$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE member SET username=%s, password=%s, name=%s, sex=%s, birthday=%s, email=%s, phone=%s, address=%s, userlevel=%s WHERE id=%s",
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['password'], "text"),
                       GetSQLValueString($_POST['name'], "text"),
                       GetSQLValueString($_POST['sex'], "text"),
                       GetSQLValueString($_POST['birthday'], "date"),
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['phone'], "text"),
                       GetSQLValueString($_POST['address'], "text"),
                       GetSQLValueString($_POST['userlevel'], "int"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_connection1, $connection1);
  $Result1 = mysql_query($updateSQL, $connection1) or die(mysql_error());

  $updateGoTo = "index.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  
  // 更改帳號?
  $_SESSION['MM_Username'] = $_POST['username'];
	
  header(sprintf("Location: %s", $updateGoTo));
}
?>
<?php 
// 取得這筆紀錄的 birthday 欄位值
$date = getdate(strtotime($row_rs1['birthday']));
// 設定 [年],[月],[日] 欄位
$year = $date['year'];
$month = $date['mon'];
$day = $date['mday'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>會員基本資料</title>
<link href="CSS/member_info.css" rel="stylesheet">
<script src="SpryAssets/SpryData.js"></script>
<script src="JavaScript/member_info.js"></script>
<script type="text/javascript">
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
</script>
</head>
<body>
<!--<form name="form1" method="POST" id="form1" 
  onkeydown="if(event.keyCode==13) return false;" onsubmit="return CheckFields();"> -->
<form action="<?php echo $editFormAction; ?>" name="form1" method="POST" id="form1" onsubmit="return CheckFields();"> 
  <table class="class1">
    <tr>
      <td colspan="2" class="class2">
        <span class="class3">
          會員基本資料        
        </span>          
      </td>
    </tr>
    <tr>
      <td class="class4">帳號</td>
      <td class="class5">
        <input name="username" type="text" id="username" size="20" maxlength="10"
          value="<?php echo $row_rs1['username']; ?>">
        （3~12個字元，請勿使用中文）                 
    <tr>
      <td class="class4">密碼</td>
      <td class="class5">
      <input name="password" type="password" id="password" size="20" maxlength="12"
        value="<?php echo $row_rs1['password']; ?>">
        （6~12個字元，請勿使用文）
     </td>
    </tr>
    <tr>
      <td class="class4">姓名</td>
      <td class="class5">
        <input name="name" type="text" id="name" size="20" maxlength="40" 
          value="<?php echo $row_rs1['name']; ?>">
      </td>
    </tr>
    <tr>
      <td class="class4">性別</td>
      <td class="class5">
        <input name="sex" type="radio" value="男" 
        <?php if (!(strcmp($row_rs1['sex'],'男'))) {echo "checked=\"checked\"";} ?>>
          男
        <input name="sex" type="radio" value="女" 
        <?php if (!(strcmp($row_rs1['sex'],'女'))) {echo "checked=\"checked\"";} ?>>
  	      女
        </td>
      </td>
    </tr>
    <tr>
      <td class="class4">電子信箱</td>
      <td class="class5">
        <input name="email" type="text" id="email" size="40" maxlength="40" 
          value="<?php echo $row_rs1['email']; ?>">
      </td>
    </tr>
    <tr>
      <td class="class4">出生日期</td>
      <td class="class5">
        <input name="year" id="year" type="text" class="class13" 
         size="6" maxlength="4" value="<?php echo $date['year']; ?>">
         &nbsp;年&nbsp;
        <select name="month" id="month" value="<?php echo $date['mon']; ?>">
        <?php
         for ($i = 1; $i <= 12; $i++)
         {
        ?>
          <option value="<?php echo $i ?>"
           <?php if ($i == $month){ echo "selected=\"selected\"";} ?>>
           &nbsp;&nbsp;<?php echo $i ?>&nbsp; 
          </option>         
        <?php
         }
        ?>
        </select>
        &nbsp;月&nbsp;&nbsp;
        <select name="day" id="day" value="<?php echo $date['mday']; ?>"> 
        <?php
		   for ($i = 1; $i <= 31; $i++)
		   {
		 ?>
			 <option value="<?php echo $i ?>" 
			 <?php if ($i == $day){ echo "selected=\"selected\"";} ?>>
			   &nbsp;&nbsp;<?php echo $i ?>&nbsp;&nbsp;
			 </option>
		 <?php
		   }
		 ?>
		 </select>
		 &nbsp;日&nbsp;&nbsp;
      </td>
    </tr>
    <tr>
      <td class="class4">連絡電話</td>
      <td class="class5">
        <input name="phone" type="text" id="phone" size="20" maxlength="15" 
          value="<?php echo $row_rs1['phone']; ?>">
      </td>
    </tr>
    <tr>
      <td class="class4">收件地址</td>
      <td class="class5">
        <input name="address" type="text" id="address" size="60" maxlength="120" 
          value="<?php echo $row_rs1['address']; ?>">
      </td>
    </tr>
    <tr>
     <td colspan="2" class="class2">
       <input type="submit" value="確定">
       <input type="button" class="class6" onClick="MM_goToURL('parent','index.php');return document.MM_returnValue" value="取消">
     </td>
    </tr>
  </table>
  <input name="userlevel" id="userlevel" type="hidden" 
    value="<?php echo $row_rs1['userlevel']; ?>">
  <input name="birthday" id="birthday" type="hidden" 
    value="<?php echo $row_rs1['birthday']; ?>">
  <input name="id" id="id" type="hidden" value="<?php echo $row_rs1['id']; ?>">        
  <input name="old_username" id="old_username" type="hidden" 
    value="<?php echo $row_rs1['username']; ?>">
  <input type="hidden" name="MM_update" id="MM_update" value="form1">
</form>
</body>
</body>
</html>
<?php
mysql_free_result($rs1);
?>
