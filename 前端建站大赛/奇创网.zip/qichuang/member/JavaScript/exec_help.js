var return_value = false;

// 檢查欄位
function CheckFields()
{
	// 檢查『帳號』欄位
	var fieldvalue = document.getElementById("username").value;
	if (fieldvalue == "") {
		alert("账号不可以是空白!");
		document.getElementById("username").focus();
		return false;
	}
	
	// 寄出電子郵件
	SendMail(document.getElementById("username").value);
	document.getElementById("username").value = "";
	document.getElementById("username").focus();
	
	return return_value;
}
// 寄出電子郵件
function SendMail(username)
{
	var objUserData = new Object;
	objUserData.username = username;
	// 呼叫伺服端的mail_password.php, 在網址後加上使用者輸入的帳號
	var req = Spry.Utils.loadURL("GET","mail_password.php?username="+username, false, 
	  myCallBack, {userData: objUserData});
}
// 在收到伺服器的反應後，這個callback函數就會被觸發
function myCallBack(req) 
{
	// 查詢結果的記錄筆數 
	var count = req.xhRequest.responseText;
	if (count > 0)	{
		alert(req.userData.username + "\r\n您的密码已经寄送到您的邮箱，请查收！"); 
		// 返回前一頁
		return_value = true;
	} else {
		alert("您输入的账号 " + req.userData.username + " 不存在"); 
	}
}