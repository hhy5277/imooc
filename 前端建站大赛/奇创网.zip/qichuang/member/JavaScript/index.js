// 檢查欄位
function CheckFields()
{
	// 保留輸入值
	document.cookie = "username=" + document.getElementById("username").value + ";";
	
	// 檢查『帳號』欄位
	var fieldvalue = document.getElementById("username").value;	
	if (fieldvalue == "") {
		alert("账号不可以是空白!");
		document.getElementById("username").focus();
		return false;
	}
	else if (fieldvalue.length < 3 || fieldvalue.length > 12) {
		alert("账号长度必须是3~12个字元!");
		document.getElementById("username").focus();
		return false;
	}
	else if (fieldvalue.search(/[\u4E00-\u9FA5]/g) != -1) {
		alert("账号不可以是中文!");
		document.getElementById("username").focus();
		return false;
	}
		
	// 檢查『密碼』欄位
	fieldvalue = document.getElementById("password").value;
	if (fieldvalue == "") {
		alert("密码不可以是空白!");
		document.getElementById("password").value = "";	
		document.getElementById("password").focus();
		return false;
	}
	else if (fieldvalue.length < 5 || fieldvalue.length > 12) {
		alert("密码的长度必须是5~12个字元!");
		document.getElementById("password").value = "";	
		document.getElementById("password").focus();
		return false;
	}
	else if (fieldvalue.search(/[\W]/g) != -1) {
		alert("密码必须是英文字与数字!");
		document.getElementById("password").value = "";	
		document.getElementById("password").focus();
		return false;
	}
	
	// 檢查『驗證碼』欄位
	fieldvalue = document.getElementById("recaptcha_response_field").value;
	if (fieldvalue == "") {
		alert("验证码不可以是空白!");
		document.getElementById("password").value = "";
		document.getElementById("password").focus();
		return false;
	}
	
	return true;
}