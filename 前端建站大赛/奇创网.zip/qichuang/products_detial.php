<?php require_once('Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_web_shop2 = "-1";
if (isset($_GET['p_id'])) {
  $colname_web_shop2 = $_GET['p_id'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_shop2 = sprintf("SELECT shop1.shop_id, shop1.shop_name, shop2.p_id, shop2.p_name, shop2.p_price, shop2.p_open, shop2.p_pic, shop2.p_content FROM shop1 left join shop2 on shop1.shop_id=shop2.shop_id WHERE shop2.p_id = %s", GetSQLValueString($colname_web_shop2, "int"));
$web_shop2 = mysql_query($query_web_shop2, $conn_web) or die(mysql_error());
$row_web_shop2 = mysql_fetch_assoc($web_shop2);
$totalRows_web_shop2 = mysql_num_rows($web_shop2);
?>
<? session_start();?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——分享创意</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/pagestyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>
<script>
$(function(){
	$(windows).scroll(function(){
		if($(windows).scrollTop()>100){
			$("#gotop").fadeIn();
		}
		else
			$("#gotop").fadeOut();
	});
	$("#gotop").click(function(){
		$('body,html').animate({scrollTop:0},500);
		return false;
	});
})
</script>
<style>
#totop{
	background:url("../images/main/gotop.png") no-repeat;
	bottom: 20px;
    cursor: pointer;
    display: none;
    height: 70px;
    position: fixed;
    right: 20px;
    text-indent: -9999px;
    width: 70px;
    z-index: 100;
	}
</style>

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>

<body>
<div class="container">
  <?php include("meau.php"); ?>
</div>

  <?php include("shopmeau.php"); ?>

<div class="container">
<div id="main3" class="panel panel-default">
<div class="panel-body">
  <table width="100%" class="table table-bordered" cellspacing="0" cellpadding="0">
    <tr>
      <td height="25" valign="middle"><h4>&nbsp;<a href="shop.php">商城</a> &gt; <a href="product.php?shop_id=<?php echo $row_web_shop2['shop_id']; ?>"><?php echo $row_web_shop2['shop_name']; ?></a> &gt; <?php echo $row_web_shop2['p_name']; ?></h4></td>
    </tr>
  </table>
  <table width="100%" class="table table-bordered" cellspacing="0" cellpadding="0">
    <tr>
      <td width="40%" align="center" valign="top"><img src="images/shop/<?php echo $row_web_shop2['p_pic']; ?>" width="70%" height="auto" /></td>
      <td width="30%" align="left" valign="middle"><h3><?php echo $row_web_shop2['p_name']; ?></h3>
        <p>价格：¥<?php echo $row_web_shop2['p_price']; ?></p>
        <p><a href="shopcart_add.php?p_name=<?php echo urlencode($row_web_shop2['p_name']); ?>&amp;p_price=<?php echo $row_web_shop2['p_price']; ?>&amp;p_pic=<?php echo $row_web_shop2['p_pic']; ?>" class="btn btn-default" role="button">加入购物车</a></p></td>
    </tr>
  </table>
  <table width="100%" class="table table-bordered" cellspacing="0" cellpadding="0">
    <tr>
      <td align="left"><h3>商品简介：</h3></td>
    </tr>
    <tr>
      <td align="left" valign="top" style="width:100%"><?php echo $row_web_shop2['p_content']; ?><br />
        <br /></td>
    </tr>
  </table>
 </div>
</div>
</div>
<div id="totop">
<a id="gotop" href="javascript:void" title="回到顶部"></a>

</div>
</body>
</html>
<?php
mysql_free_result($web_shop2);
?>