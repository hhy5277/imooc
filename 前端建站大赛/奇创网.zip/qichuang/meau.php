     <nav id="meau"> 
        <li><img src="images/main/logo60x60.png" alt="logo"></li>
     	<li><a href="index.html">首页</a></li> 
        <li><a href="cy.html">创意</a></li> 
        <li><a href="sj.html">设计</a></li> 
        <li><a href="video.html">视频</a></li> 
        <li><a href="shop.php">商城</a></li>  
     </nav>
