<?php require_once('../Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form3")) {
  $updateSQL = sprintf("UPDATE member_md5 SET username=%s, password=%s, name=%s, sex=%s, birthday=%s, email=%s, phone=%s, address=%s, userlevel=%s WHERE id=%s",
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['password'], "text"),
                       GetSQLValueString($_POST['uname'], "text"),
                       GetSQLValueString($_POST['sex'], "text"),
                       GetSQLValueString($_POST['birthday'], "date"),
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['phone'], "text"),
                       GetSQLValueString($_POST['cusadr'], "text"),
                       GetSQLValueString($_POST['level'], "text"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_conn_web, $conn_web);
  $Result1 = mysql_query($updateSQL, $conn_web) or die(mysql_error());

  $updateGoTo = "admin_member.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

//自訂變數$password記錄隱藏欄位傳送過來的已加密舊密碼
$password=$_POST["password"];
//如果新密碼passwordNew輸入欄位不是空的
if($_POST["passwordNew"]!=""){
	     //自訂變數$password就變更，改為記錄md5加密的passwordNew
	     $password=md5($_POST["passwordNew"]);
	}

$colname_web_member = "-1";
if (isset($_GET['id'])) {
  $colname_web_member = $_GET['id'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_member = sprintf("SELECT * FROM member_md5 WHERE id = %s", GetSQLValueString($colname_web_member, "int"));
$web_member = mysql_query($query_web_member, $conn_web) or die(mysql_error());
$row_web_member = mysql_fetch_assoc($web_member);
$totalRows_web_member = mysql_num_rows($web_member);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——后台管理</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="../images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/pagestyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
</head>

<body>
<?php include("adminheader.php"); ?>
<div class="container">
  <form action="<?php echo $editFormAction; ?>" id="form3" name="form3" method="POST">
    <h4>Hello!管理员。您正在编辑会员<em class="text-danger"><?php echo $row_web_member['username']; ?></em>的资料</h4>
    <table width="100%" class="table table-bordered" cellspacing="0" cellpadding="2">
      <tr>
        <td height="30" align="right">账号：</td>
        <td align="left" class="board_add"><label>
            <input name="username" type="text" id="username" value="<?php echo $row_web_member['username']; ?>" />
          </label></td>
      </tr>
      <tr>
        <td width="82" height="30" align="right" class="board_add">姓名：</td>
        <td width="458" align="left" class="board_add"><label>
            <input name="uname" type="text" id="uname" value="<?php echo $row_web_member['name']; ?>" />
          </label></td>
      </tr>
      <tr>
        <td height="30" align="right">等级：</td>
        <td align="left"><label>
            <select name="level" id="level">
              <option value="admin" <?php if (!(strcmp("admin", $row_web_member['userlevel']))) {echo "selected=\"selected\"";} ?>>管理员</option>
              <option value="member" <?php if (!(strcmp("member", $row_web_member['userlevel']))) {echo "selected=\"selected\"";} ?>>一般会员</option>
            </select>
          </label></td>
      </tr>
      <tr>
        <td height="30" align="right" class="board_add">更改密码：</td>
        <td align="left" class="board_add"><label>
            <input name="passwordNew" type="password" id="passwordNew" size="15" />
          </label>
          <span class="text-danger">*如需更改才输入!
          <input name="password" type="hidden" id="password" value="<?php echo $row_web_member['password']; ?>" />
          </span></td>
      </tr>
      <tr>
        <td height="15" align="right" class="board_add">E-mail：</td>
        <td align="left" class="board_add"><label>
            <input name="email" type="text" id="email" value="<?php echo $row_web_member['email']; ?>" size="35" />
          </label></td>
      </tr>
      <tr>
        <td height="30" align="right" class="board_add">性別：</td>
        <td align="left" class="board_add"><label>
            <input <?php if (!(strcmp($row_web_member['sex'],"man"))) {echo "checked=\"checked\"";} ?> name="sex" type="radio" id="radio" value="man" checked="checked" />
            男
            <input <?php if (!(strcmp($row_web_member['sex'],"woman"))) {echo "checked=\"checked\"";} ?> type="radio" name="sex" id="radio2" value="woman" />
            女</label></td>
      </tr>
      <tr>
        <td height="30" align="right" class="board_add">生日：</td>
        <td align="left" class="board_add"><label>
            <input name="birthday" type="date" id="birthday" value="<?php echo $row_web_member['birthday']; ?>" />
            格式为：YYYY-MM-DD</label></td>
      </tr>
      <tr>
        <td height="30" align="right" class="board_add">电话：</td>
        <td align="left" class="board_add"><label>
            <input name="phone" type="text" id="phone" value="<?php echo $row_web_member['phone']; ?>" />
          </label></td>
      </tr>
      <tr>
        <td height="30" align="right" class="board_add">收件地址：</td>
        <td align="left" class="board_add"><span class="bs">
          <input name="cusadr" type="text" id="cusadr" value="<?php echo $row_web_member['address']; ?>" size="60" />
          </span></td>
      </tr>
      <tr>
        <td height="40" colspan="2" align="center"><label>
            <input type="submit" name="button" id="button" class="btn btn-success" value="确定更改" />
            <input type="button" name="submit" class="btn btn-default" value="回上一页" onClick='window.history.back();'>
            <input name="id" type="hidden" id="id" value="<?php echo $row_web_member['id']; ?>" />
          </label></td>
      </tr>
    </table>
    <input type="hidden" name="MM_update" value="form3">
  </form>
</div>
</body>
</html>
<?php
mysql_free_result($web_member);
?>
