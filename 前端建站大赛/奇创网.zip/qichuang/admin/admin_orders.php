<?php
#	BuildNav for Dreamweaver MX v0.2
#              10-02-2002
#	Alessandro Crugnola [TMM]
#	sephiroth: alessandro@sephiroth.it
#	http://www.sephiroth.it
#	
#	Function for navigation build ::
function buildNavigation($pageNum_Recordset1,$totalPages_Recordset1,$prev_Recordset1,$next_Recordset1,$separator=" | ",$max_links=10, $show_page=true)
{
                GLOBAL $maxRows_web_orders,$totalRows_web_orders;
	$pagesArray = ""; $firstArray = ""; $lastArray = "";
	if($max_links<2)$max_links=2;
	if($pageNum_Recordset1<=$totalPages_Recordset1 && $pageNum_Recordset1>=0)
	{
		if ($pageNum_Recordset1 > ceil($max_links/2))
		{
			$fgp = $pageNum_Recordset1 - ceil($max_links/2) > 0 ? $pageNum_Recordset1 - ceil($max_links/2) : 1;
			$egp = $pageNum_Recordset1 + ceil($max_links/2);
			if ($egp >= $totalPages_Recordset1)
			{
				$egp = $totalPages_Recordset1+1;
				$fgp = $totalPages_Recordset1 - ($max_links-1) > 0 ? $totalPages_Recordset1  - ($max_links-1) : 1;
			}
		}
		else {
			$fgp = 0;
			$egp = $totalPages_Recordset1 >= $max_links ? $max_links : $totalPages_Recordset1+1;
		}
		if($totalPages_Recordset1 >= 1) {
			#	------------------------
			#	Searching for $_GET vars
			#	------------------------
			$_get_vars = '';			
			if(!empty($_GET) || !empty($HTTP_GET_VARS)){
				$_GET = empty($_GET) ? $HTTP_GET_VARS : $_GET;
				foreach ($_GET as $_get_name => $_get_value) {
					if ($_get_name != "pageNum_web_orders") {
						$_get_vars .= "&$_get_name=$_get_value";
					}
				}
			}
			$successivo = $pageNum_Recordset1+1;
			$precedente = $pageNum_Recordset1-1;
			$firstArray = ($pageNum_Recordset1 > 0) ? "<a href=\"$_SERVER[PHP_SELF]?pageNum_web_orders=$precedente$_get_vars\">$prev_Recordset1</a>" :  "$prev_Recordset1";
			# ----------------------
			# page numbers
			# ----------------------
			for($a = $fgp+1; $a <= $egp; $a++){
				$theNext = $a-1;
				if($show_page)
				{
					$textLink = $a;
				} else {
					$min_l = (($a-1)*$maxRows_web_orders) + 1;
					$max_l = ($a*$maxRows_web_orders >= $totalRows_web_orders) ? $totalRows_web_orders : ($a*$maxRows_web_orders);
					$textLink = "$min_l - $max_l";
				}
				$_ss_k = floor($theNext/26);
				if ($theNext != $pageNum_Recordset1)
				{
					$pagesArray .= "<a href=\"$_SERVER[PHP_SELF]?pageNum_web_orders=$theNext$_get_vars\">";
					$pagesArray .= "$textLink</a>" . ($theNext < $egp-1 ? $separator : "");
				} else {
					$pagesArray .= "$textLink"  . ($theNext < $egp-1 ? $separator : "");
				}
			}
			$theNext = $pageNum_Recordset1+1;
			$offset_end = $totalPages_Recordset1;
			$lastArray = ($pageNum_Recordset1 < $totalPages_Recordset1) ? "<a href=\"$_SERVER[PHP_SELF]?pageNum_web_orders=$successivo$_get_vars\">$next_Recordset1</a>" : "$next_Recordset1";
		}
	}
	return array($firstArray,$pagesArray,$lastArray);
}
?>
<?php require_once('../Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_web_orders = 10;
$pageNum_web_orders = 0;
if (isset($_GET['pageNum_web_orders'])) {
  $pageNum_web_orders = $_GET['pageNum_web_orders'];

}
$startRow_web_orders = $pageNum_web_orders * $maxRows_web_orders;

$maxRows_web_orders = 10;
$pageNum_web_orders = 0;
if (isset($_GET['pageNum_web_orders'])) {
  $pageNum_web_orders = $_GET['pageNum_web_orders'];
}
$startRow_web_orders = $pageNum_web_orders * $maxRows_web_orders;

mysql_select_db($database_conn_web, $conn_web);
$query_web_orders = "SELECT * FROM orders ORDER BY order_id DESC";
$query_limit_web_orders = sprintf("%s LIMIT %d, %d", $query_web_orders, $startRow_web_orders, $maxRows_web_orders);
$web_orders = mysql_query($query_limit_web_orders, $conn_web) or die(mysql_error());
$row_web_orders = mysql_fetch_assoc($web_orders);

if (isset($_GET['totalRows_web_orders'])) {
  $totalRows_web_orders = $_GET['totalRows_web_orders'];
} else {
  $all_web_orders = mysql_query($query_web_orders);
  $totalRows_web_orders = mysql_num_rows($all_web_orders);
}
$totalPages_web_orders = ceil($totalRows_web_orders/$maxRows_web_orders)-1;

$queryString_web_orders = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_web_orders") == false && 
        stristr($param, "totalRows_web_orders") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_web_orders = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_web_orders = sprintf("&totalRows_web_orders=%d%s", $totalRows_web_orders, $queryString_web_orders);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——后台管理</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/pagestyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script type="text/javascript">
<!--
function tfm_confirmLink(message) { //v1.0
	if(message == "") message = "Ok to continue?";	
	document.MM_returnValue = confirm(message);
}
//-->
</script>
</head>

<body>
<?php include("adminheader.php"); ?>
<div id="main" class="container">
  <div id="admin_main2">
  <?php if ($totalRows_web_orders > 0) { // Show if recordset not empty ?>
    <table width="100%" class="table table-bordered table-striped" cellspacing="0" cellpadding="5">
    <caption class="text-center">
    <h3>订单管理</h3>
    </caption>
    <thead>
      <tr>
        <th width="10%" align="center" class="board_add3"><span class="font_black">订单编号</span></th>
        <th width="35%" height="30" align="center" class="board_add3">会员姓名(账号)-订购日期</th>
        <th width="10%" align="center" class="board_add3"><span class="font_black">付款方式</span></th>
        <th width="10%" align="center" class="board_add3"><span class="font_black">付款状态</span></th>
        <td width="10%" align="center" class="board_add3">操作</th>
      </tr>
     </thead>
     <tbody>
      <?php do { ?>
        <tr>
          <td align="center" class="board_add3"><?php echo $row_web_orders['order_id']; ?></td>
          <td height="30" align="left" class="board_add3"><?php echo $row_web_orders['order_name1']; ?>(<?php echo $row_web_orders['order_username']; ?>)-<?php echo $row_web_orders['order_date']; ?></td>
          <td align="center" class="board_add3"><?php echo $row_web_orders['order_paytype']; ?></td>
          <td align="center" class="board_add3"><?php echo $row_web_orders['order_payok']; ?></td>
          <td align="center" class="board_add3"><a href="admin_ordersDetial.php?order_id=<?php echo $row_web_orders['order_id']; ?>&amp;order_sid=<?php echo $row_web_orders['order_sid']; ?>&amp;order_group=<?php echo $row_web_orders['order_group']; ?>" class="btn btn-default">检视</a><a href="admin_ordersDel.php?order_id=<?php echo $row_web_orders['order_id']; ?>&amp;delSure=1" onclick="tfm_confirmLink('确定删除这笔资料?');return document.MM_returnValue" class="btn btn-danger">刪除</a></td>
        </tr>
        <?php } while ($row_web_orders = mysql_fetch_assoc($web_orders)); ?>
       </tbody>
    </table>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="left" valign="bottom"><table border="0">
          <tr>
            <td><?php if ($pageNum_web_orders > 0) { // Show if not first page ?>
                <a href="<?php printf("%s?pageNum_web_orders=%d%s", $currentPage, 0, $queryString_web_orders); ?>">第一页</a>
                <?php } // Show if not first page ?></td>
            <td><?php if ($pageNum_web_orders > 0) { // Show if not first page ?>
                <a href="<?php printf("%s?pageNum_web_orders=%d%s", $currentPage, max(0, $pageNum_web_orders - 1), $queryString_web_orders); ?>">前一页</a>
                <?php } // Show if not first page ?></td>
            <td><?php if ($pageNum_web_orders < $totalPages_web_orders) { // Show if not last page ?>
                <a href="<?php printf("%s?pageNum_web_orders=%d%s", $currentPage, min($totalPages_web_orders, $pageNum_web_orders + 1), $queryString_web_orders); ?>">下一个</a>
                <?php } // Show if not last page ?></td>
            <td><?php if ($pageNum_web_orders < $totalPages_web_orders) { // Show if not last page ?>
                <a href="<?php printf("%s?pageNum_web_orders=%d%s", $currentPage, $totalPages_web_orders, $queryString_web_orders); ?>">最后一页</a>
                <?php } // Show if not last page ?></td>
          </tr>
        </table></td>
        <td align="right" valign="bottom">&nbsp;
          记录 <?php echo ($startRow_web_orders + 1) ?> 到 <?php echo min($startRow_web_orders + $maxRows_web_orders, $totalRows_web_orders) ?> 共 <?php echo $totalRows_web_orders ?></td>
      </tr>
    </table>
    <?php } // Show if recordset not empty ?>
  <?php if ($totalRows_web_orders == 0) { // Show if recordset empty ?>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="80" align="center" style="color:#F00">目前资料库中沒有任何资料!</td>
      </tr>
  </table>
  <?php } // Show if recordset empty ?>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($web_orders);
?>
