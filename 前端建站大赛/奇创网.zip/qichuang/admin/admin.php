<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "admin";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../index.html";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />

<title>奇创网——后台管理</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="../images/main/favicon.png">
<meta name="robots" content="index,follow">

<link href="css/pagestyle.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>
</head>

<body>
<?php include("adminheader.php"); ?>
<p class="text-center" style="color: #FFF; font-size:2.5rem; padding-top:80px">欢迎来到后台！！！</p>
</body>
</html>