<?php require_once('../Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO shop1 (shop_name) VALUES (%s)",
                       GetSQLValueString($_POST['shop_name'], "text"));

  mysql_select_db($database_conn_web, $conn_web);
  $Result1 = mysql_query($insertSQL, $conn_web) or die(mysql_error());

  $insertGoTo = "admin_shop1.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_conn_web, $conn_web);
$query_web_shop1 = "SELECT * FROM shop1";
$web_shop1 = mysql_query($query_web_shop1, $conn_web) or die(mysql_error());
$row_web_shop1 = mysql_fetch_assoc($web_shop1);
$totalRows_web_shop1 = mysql_num_rows($web_shop1);
$query_web_shop1 = "SELECT * FROM shop1 ORDER BY shop_id ASC";
$web_shop1 = mysql_query($query_web_shop1, $conn_web) or die(mysql_error());
$row_web_shop1 = mysql_fetch_assoc($web_shop1);
$totalRows_web_shop1 = mysql_num_rows($web_shop1);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——后台管理</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="../images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/pagestyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>
</head>

<body>
<?php include("adminheader.php"); ?>
<table width="100%">
  <caption class="text-center">
  <h3>新增商品分类</h3>
  </caption>
  <tr>
    <td height="30" align="center" class="board_add"><br />
      <br />
      <form id="form1" name="form1" method="POST" action="<?php echo $editFormAction; ?>">
        <span class="font_black">请输入新增商品分类名称：</span>
        <label>
          <input name="shop_name" type="text" id="shop_name" size="30" placeholder="输入名称" />
        </label>
        <label>
          <input type="submit" name="button" id="button" class="btn btn-default" value="新增" />
        </label>
        <input type="hidden" name="MM_insert" value="form1">
      </form>
      <br />
      <br /></td>
  </tr>
</table>
<table width="100%">
  <tr>
    <td height="80" align="center" class="font_red2"><input type="button" name="submit" class="btn btn-default" value="回上一页" onClick="window.history.back()";></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($web_shop1);
?>
