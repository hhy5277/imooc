<?php require_once('../Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_web_member = 10;
$pageNum_web_member = 0;
if (isset($_GET['pageNum_web_member'])) {
  $pageNum_web_member = $_GET['pageNum_web_member'];
}
$startRow_web_member = $pageNum_web_member * $maxRows_web_member;

mysql_select_db($database_conn_web, $conn_web);
$query_web_member = "SELECT * FROM member_md5 ORDER BY id ASC";
$query_limit_web_member = sprintf("%s LIMIT %d, %d", $query_web_member, $startRow_web_member, $maxRows_web_member);
$web_member = mysql_query($query_limit_web_member, $conn_web) or die(mysql_error());
$row_web_member = mysql_fetch_assoc($web_member);

if (isset($_GET['totalRows_web_member'])) {
  $totalRows_web_member = $_GET['totalRows_web_member'];
} else {
  $all_web_member = mysql_query($query_web_member);
  $totalRows_web_member = mysql_num_rows($all_web_member);
}
$totalPages_web_member = ceil($totalRows_web_member/$maxRows_web_member)-1;$maxRows_web_member = 10;
$pageNum_web_member = 0;
if (isset($_GET['pageNum_web_member'])) {
  $pageNum_web_member = $_GET['pageNum_web_member'];
}
$startRow_web_member = $pageNum_web_member * $maxRows_web_member;

mysql_select_db($database_conn_web, $conn_web);
$query_web_member = "SELECT * FROM member_md5 ORDER BY id ASC";
$query_limit_web_member = sprintf("%s LIMIT %d, %d", $query_web_member, $startRow_web_member, $maxRows_web_member);
$web_member = mysql_query($query_limit_web_member, $conn_web) or die(mysql_error());
$row_web_member = mysql_fetch_assoc($web_member);

if (isset($_GET['totalRows_web_member'])) {
  $totalRows_web_member = $_GET['totalRows_web_member'];
} else {
  $all_web_member = mysql_query($query_web_member);
  $totalRows_web_member = mysql_num_rows($all_web_member);
}
$totalPages_web_member = ceil($totalRows_web_member/$maxRows_web_member)-1;

$queryString_web_member = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_web_member") == false && 
        stristr($param, "totalRows_web_member") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_web_member = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_web_member = sprintf("&totalRows_web_member=%d%s", $totalRows_web_member, $queryString_web_member);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />

<title>奇创网——后台管理</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="../images/main/favicon.png">
<meta name="robots" content="index,follow">
<link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
<script type="text/javascript">
<!--
function tfm_confirmLink(message) { //v1.0
	if(message == "") message = "Ok to continue?";	
	document.MM_returnValue = confirm(message);
}
//-->
</script>
</head>

<body>
<?php include("adminheader.php"); ?>
  <div class="container">
    <h3 class="text-center">会员管理区</h3>
    <table width="100%" class="table table-bordered table-striped" cellspacing="0" cellpadding="0">
      <?php do { ?>
        <tr>
          <td width="20px" align="center" class="board_add"><?php echo $row_web_member['id']; ?></td>
          <td width="435" height="30" align="left" class="board_add">&nbsp; &nbsp;[<?php echo $row_web_member['username']; ?> ] <?php echo $row_web_member['name']; ?>&nbsp; &nbsp; - &nbsp;<?php echo $row_web_member['userlevel']; ?></td>
          <td width="100" align="center" class="board_add"><a   class="btn btn-primary" href="admin_memberUpdate.php?id=<?php echo $row_web_member['id']; ?>">编辑</a><a class="btn btn-danger" href="admin_memberDel.php?id=<?php echo $row_web_member['id']; ?>&amp;delSure=1" onclick="tfm_confirmLink('确定删除？');return document.MM_returnValue">刪除</a></td>
        </tr>
        <?php } while ($row_web_member = mysql_fetch_assoc($web_member)); ?>
    </table>
    <table width="100%" class="table table-striped" cellspacing="0" cellpadding="0">
      <tr>
        <td align="left" valign="bottom">
          <table border="0">
            <tr>
              <td><?php if ($pageNum_web_member > 0) { // Show if not first page ?>
                  <a href="<?php printf("%s?pageNum_web_member=%d%s", $currentPage, 0, $queryString_web_member); ?>">第一页</a>
                  <?php } // Show if not first page ?></td>
              <td><?php if ($pageNum_web_member > 0) { // Show if not first page ?>
                  <a href="<?php printf("%s?pageNum_web_member=%d%s", $currentPage, max(0, $pageNum_web_member - 1), $queryString_web_member); ?>">上一页</a>
                  <?php } // Show if not first page ?></td>
              <td><?php if ($pageNum_web_member < $totalPages_web_member) { // Show if not last page ?>
                  <a href="<?php printf("%s?pageNum_web_member=%d%s", $currentPage, min($totalPages_web_member, $pageNum_web_member + 1), $queryString_web_member); ?>">下一页</a>
                  <?php } // Show if not last page ?></td>
              <td><?php if ($pageNum_web_member < $totalPages_web_member) { // Show if not last page ?>
                  <a href="<?php printf("%s?pageNum_web_member=%d%s", $currentPage, $totalPages_web_member, $queryString_web_member); ?>">最后一页</a>
                  <?php } // Show if not last page ?></td>
            </tr>
        </table></td>
        <td align="right" valign="bottom">&nbsp;
记录 <?php echo ($startRow_web_member + 1) ?> 到 <?php echo min($startRow_web_member + $maxRows_web_member, $totalRows_web_member) ?> 共 <?php echo $totalRows_web_member ?></td>
      </tr>
    </table>
  </div>

</body>
</html>
<?php
mysql_free_result($web_member);
?>
