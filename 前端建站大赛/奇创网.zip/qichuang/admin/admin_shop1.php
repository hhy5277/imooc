<?php require_once('../Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conn_web, $conn_web);
$query_web_shop1 = "SELECT * FROM shop1 ORDER BY shop_id ASC";
$web_shop1 = mysql_query($query_web_shop1, $conn_web) or die(mysql_error());
$row_web_shop1 = mysql_fetch_assoc($web_shop1);
$totalRows_web_shop1 = mysql_num_rows($web_shop1);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />

<title>奇创网——后台管理</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="../images/main/favicon.png">
<meta name="robots" content="index,follow">

<link href="css/pagestyle.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>
</head>

<body>

<?php include("adminheader.php"); ?>

<div class="container">
<?php if ($totalRows_web_shop1 > 0) { // Show if recordset not empty ?>
  <div class="table-responsive">
    <table width="100%" class="table table-striped table-bordered">
      <caption class="text-center"><h3>商品分类管理</h3></caption>
      <thead>
      <tr>
        <th>商品分类ID</th>
        <th>分类名称</th>
        <th>操作</th>
      </tr>
      </thead>
      <tbody>
      <?php do { ?>
        <tr>
          <td valign="middle"><?php echo $row_web_shop1['shop_id']; ?></td>
          <td valign="middle"><?php echo $row_web_shop1['shop_name']; ?></td>
          <td valign="middle"><a href="admin_shop2.php?shop_id=<?php echo $row_web_shop1['shop_id']; ?>" class="btn btn-default">管理本分类商品</a><a href="admin_shop1Update.php?shop_id=<?php echo $row_web_shop1['shop_id']; ?>" class="btn btn-info">编辑</a><a href="admin_shop1Del.php?delSure=1&shop_id=<?php echo $row_web_shop1['shop_id']; ?>" class="btn btn-danger">删除</a></td>
        </tr>
        <?php } while ($row_web_shop1 = mysql_fetch_assoc($web_shop1)); ?>
        </tbody>
    </table>
  </div><!--end table-res-->
  <?php } // Show if recordset not empty ?>
  
    <h4 class="text-center"><a href="admin_shop1Add.php" class="btn btn-default">新增商品分类</a></h4>
    
  <?php if ($totalRows_web_shop1 == 0) { // Show if recordset empty ?>
    <table width="100%" class="text-center">
      <tr>
        <td><h3>目前资料库中没有建立商品分类</h3></td>
      </tr>
    </table>
    <?php } // Show if recordset empty ?>
</div>
</body>
</html>
<?php
mysql_free_result($web_shop1);
?>
