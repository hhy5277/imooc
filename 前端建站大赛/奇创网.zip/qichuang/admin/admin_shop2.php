<?php require_once('../Connections/conn_web.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_web_shop2 = 9;
$pageNum_web_shop2 = 0;
if (isset($_GET['pageNum_web_shop2'])) {
  $pageNum_web_shop2 = $_GET['pageNum_web_shop2'];
}
$startRow_web_shop2 = $pageNum_web_shop2 * $maxRows_web_shop2;

$colname_web_shop2 = "-1";
if (isset($_GET['shop_id'])) {
  $colname_web_shop2 = $_GET['shop_id'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_shop2 = sprintf("SELECT shop1.shop_id,shop1.shop_name,shop2.p_id, shop2.p_name, shop2.p_open, shop2.p_pic FROM shop1 Left Join shop2 ON shop1.shop_id = shop2.shop_id WHERE shop2.shop_id = %s ORDER BY shop2.p_id DESC", GetSQLValueString($colname_web_shop2, "int"));
$query_limit_web_shop2 = sprintf("%s LIMIT %d, %d", $query_web_shop2, $startRow_web_shop2, $maxRows_web_shop2);
$web_shop2 = mysql_query($query_limit_web_shop2, $conn_web) or die(mysql_error());
$row_web_shop2 = mysql_fetch_assoc($web_shop2);

if (isset($_GET['totalRows_web_shop2'])) {
  $totalRows_web_shop2 = $_GET['totalRows_web_shop2'];
} else {
  $all_web_shop2 = mysql_query($query_web_shop2);
  $totalRows_web_shop2 = mysql_num_rows($all_web_shop2);
}
$totalPages_web_shop2 = ceil($totalRows_web_shop2/$maxRows_web_shop2)-1;

$queryString_web_shop2 = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_web_shop2") == false && 
        stristr($param, "totalRows_web_shop2") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_web_shop2 = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_web_shop2 = sprintf("&totalRows_web_shop2=%d%s", $totalRows_web_shop2, $queryString_web_shop2);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——后台管理</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="../images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/pagestyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>
</head>

<body>
<?php include("adminheader.php"); ?>
<div class="container">
  <table width="100%" class="table table-bordered table-striped">
    <caption class="text-center">
    <h3><?php echo $row_web_shop2['shop_name']; ?>分类商品管理</h3>
    <p><a href="admin_shop2Add.php?shop_id=<?php echo $_GET['shop_id']; ?>" class="btn btn-default">
      新增商品
      </a></p>
    </caption>
    <?php if ($totalRows_web_shop2 > 0) { // Show if recordset not empty ?>
    <thead>
      <tr>
        <th height="30" align="center"> 商品ID </th>
        <th height="30" align="center"> 商品信息 </th>
        <th height="30" align="center"> 操作 </th>
      </tr>
    </thead>
    <tbody>
      <?php do { ?>
        <tr>
          <td height="50" align="center"><?php echo $row_web_shop2['p_id']; ?></td>
          <td height="30" align="left"><img src="../images/shop/thum/<?php echo $row_web_shop2['p_pic']; ?>" alt="" name="pic" width="57" id="pic" /><?php echo $row_web_shop2['p_name']; ?>
            
            <?php /*START_PHP_SIRFCIT*/ if ($row_web_shop2['p_open']=="Y"){ ?>
              <span class="glyphicon glyphicon-arrow-up" aria-hidden="true"></span>
              <?php } /*END_PHP_SIRFCIT*/ ?>
                  
            <?php /*START_PHP_SIRFCIT*/ if ($row_web_shop2['p_open']=="N"){ ?>
              <span class="glyphicon glyphicon-arrow-down" aria-hidden="true"></span>
              <?php } /*END_PHP_SIRFCIT*/ ?>
            </td>
          <td height="30" align="left"><a href="admin_shop2Update.php?p_id=<?php echo $row_web_shop2['p_id']; ?>" class="btn btn-default">编辑</a><a href="admin_shop2Del.php?delSure=1&p_id=<?php echo $row_web_shop2['p_id']; ?>&shop_id=<?php echo $row_web_shop2['shop_id']; ?>&p_pic=<?php echo $row_web_shop2['p_pic']; ?>" class="btn btn-danger">删除</a></td>
        </tr>
        <?php } while ($row_web_shop2 = mysql_fetch_assoc($web_shop2)); ?>
        </tbody>
      <?php } // Show if recordset not empty ?>
     
  </table>
  <?php if ($totalRows_web_shop2 > 0) { // Show if recordset not empty ?>
    <table width="100%">
      <tr>
        <td align="left" valign="bottom"><?php if ($pageNum_web_shop2 > 0) { // Show if not first page ?>
            <a href="<?php printf("%s?pageNum_web_shop2=%d%s", $currentPage, 0, $queryString_web_shop2); ?>">第一页 /</a>
            <?php } // Show if not first page ?>
          <?php if ($pageNum_web_shop2 > 0) { // Show if not first page ?>
            <a href="<?php printf("%s?pageNum_web_shop2=%d%s", $currentPage, max(0, $pageNum_web_shop2 - 1), $queryString_web_shop2); ?>">前一页 /</a>
            <?php } // Show if not first page ?>
          <?php if ($pageNum_web_shop2 < $totalPages_web_shop2) { // Show if not last page ?>
            <a href="<?php printf("%s?pageNum_web_shop2=%d%s", $currentPage, min($totalPages_web_shop2, $pageNum_web_shop2 + 1), $queryString_web_shop2); ?>">下一个 /</a>
            <?php } // Show if not last page ?>
          <?php if ($pageNum_web_shop2 < $totalPages_web_shop2) { // Show if not last page ?>
            <a href="<?php printf("%s?pageNum_web_shop2=%d%s", $currentPage, $totalPages_web_shop2, $queryString_web_shop2); ?>">最后一页</a>
            <?php } // Show if not last page ?></td>
        <td align="right" valign="bottom">
          记录 <?php echo ($startRow_web_shop2 + 1) ?> 到 <?php echo min($startRow_web_shop2 + $maxRows_web_shop2, $totalRows_web_shop2) ?> (总共 <?php echo $totalRows_web_shop2 ?>笔）</td>
      </tr>
    </table>
    <?php } // Show if recordset not empty ?>
  <?php if ($totalRows_web_shop2 == 0) { // Show if recordset empty ?>
    <table width="100%">
      <tr>
        <td height="80" align="center" class="font_red2"> 目前资料库中没有任何商品 </td>
      </tr>
    </table>
    <?php } // Show if recordset empty ?>
  <p class="text-center"><script type="text/JavaScript">
<!--
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
//-->
</script>
    <input name="Submit" type="button" class="btn btn-default" onclick="MM_goToURL('parent','admin_shop1.php');return document.MM_returnValue" value="回商品管理区" />
  </p>
</div>
</body>
</html>
<?php
mysql_free_result($web_shop2);
?>
