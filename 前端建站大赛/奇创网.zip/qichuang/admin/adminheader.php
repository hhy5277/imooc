<nav class="navbar navbar-default" role="navigation">
   <div class="text-center">
      <h3>奇创网<small>——<a href="admin.php">后台管理</a></small></h3>
   </div>
</nav>

<div class="row">

	<div class="panel panel-default">
    	<div class="panel-heading">
       		<strong>网站管理选项</strong>
        </div>
        <div class="panel-body">
          <ul class="nav nav-pills nav-justified">
          	  <li><a href="../index.html">网站首页</a></li>
              <li><a href="javascript:void">留言板管理</a></li>
              <li><a href="javascript:void">新闻/活动管理</a></li>
              <li><a href="admin_member.php">会员管理</a></li>
              <li><a href="javascript:void">讨论区管理</a></li>
              <li><a href="admin_shop1.php">商品管理</a></li>
              <li><a href="admin_orders.php">订单管理</a></li>
              <li><a href="../logout.php">退出后台</a></li>
    	  </ul>
        </div>
    </div>

</div><!--end row-->