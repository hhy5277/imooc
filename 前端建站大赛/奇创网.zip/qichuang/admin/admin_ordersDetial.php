<?php require_once('../Connections/conn_web.php'); ?>
<?php $order_total='0';?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_web_orders = "-1";
if (isset($_GET['order_id'])) {
  $colname_web_orders = $_GET['order_id'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_orders = sprintf("SELECT * FROM orders WHERE order_id = %s", GetSQLValueString($colname_web_orders, "int"));
$web_orders = mysql_query($query_web_orders, $conn_web) or die(mysql_error());
$row_web_orders = mysql_fetch_assoc($web_orders);
$totalRows_web_orders = mysql_num_rows($web_orders);

$colname_web_orderList = "-1";
if (isset($_GET['order_sid'])) {
  $colname_web_orderList = $_GET['order_sid'];
}
$colname2_web_orderList = "-1";
if (isset($_GET['order_group'])) {
  $colname2_web_orderList = $_GET['order_group'];
}
mysql_select_db($database_conn_web, $conn_web);
$query_web_orderList = sprintf("SELECT * FROM orderlist WHERE order_sid = %s AND order_group = %s ORDER BY odlist_id ASC", GetSQLValueString($colname_web_orderList, "text"),GetSQLValueString($colname2_web_orderList, "text"));
$web_orderList = mysql_query($query_web_orderList, $conn_web) or die(mysql_error());
$row_web_orderList = mysql_fetch_assoc($web_orderList);
$totalRows_web_orderList = mysql_num_rows($web_orderList);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">
<!--use IE and chrome new Version-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<!--baidu禁止转码-->
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title>奇创网——后台管理</title>
<meta name="keywords" content="分享创意、创意产品、创意家居、创意生活、新奇产品、创意发明、创意产品视频"/>
<meta name="description" content="这是一个分享创意的网站，带你了解更多新奇产品，无创意不生活."/>
<meta name="author" content="lilong, 986069558@qq.com">
<link rel="icon" type="image/png" href="images/main/favicon.png">
<meta name="robots" content="index,follow">
<link href="css/pagestyle.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
<script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js" defer></script>
<script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js" defer></script>

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="../ie6png.js" type="text/javascript"></script>
</head>

<body>
<?php include("adminheader.php"); ?>
<div id="main" class="container">
  <div id="admin_main2">
    <table width="100%" class="table table-bordered table-striped" cellspacing="0" cellpadding="5">
       <tr>
        <td width="20%" align="right" valign="middle">订单编号：</td>
        <td width="80%" align="left" valign="middle"><?php echo $row_web_orders['order_id']; ?></td>
      </tr>
      <tr>
        <td align="right" >订购者资料：</td>
        <td align="left" ><?php echo $row_web_orders['order_name1']; ?>-<?php echo $row_web_orders['order_username']; ?></td>
      </tr>
      <tr>
        <td width="93" align="right" >收件者姓名：</td>
        <td width="442" align="left" ><?php echo $row_web_orders['order_name2']; ?></td>
      </tr>
      <tr>
        <td align="right" >联系电话：</td>
        <td align="left" ><?php echo $row_web_orders['order_phone']; ?></td>
      </tr>
      <tr>
        <td align="right" >收件者地址：</td>
        <td align="left" ><?php echo $row_web_orders['order_cusadr']; ?></td>
      </tr>
      <tr>
        <td align="right" >付款方式：</td>
        <td align="left" ><?php echo $row_web_orders['order_paytype']; ?></td>
      </tr>
      <tr>
        <td align="right" >完成付款：</td>
        <td align="left" ><?php echo $row_web_orders['order_payok']; ?></td>
      </tr>
      <!--
      <tr>
        <td align="right" >匯款帳號末5碼：</td>
        <td align="left" ><?php echo $row_web_orders['order_paynumber']; ?></td>
      </tr>-->
    </table>
    <h3 class="text-center">订购清单</h3>
    <table width="100%" class="table table-bordered table-striped" cellspacing="0" cellpadding="5">
    <thead>
      <tr>
        <th width="10%" align="center" class="board_add3">商品图</th>
        <th width="20%" align="center" class="board_add3">商品名称</th>
        <th width="10%" align="center" valign="middle" class="board_add3">单价</th>
        <th width="10%" align="center" class="board_add3">订购数量</th>
      </tr>
     </thead>
     <tbody>
      <?php do { ?>
        <tr>
          <td align="center" class="board_add3"><img src="../images/shop/<?php echo $row_web_orderList['p_pic']; ?>" width="100%" /></td>
          <td height="30" align="left" class="board_add3"><span class="font_black">&nbsp;<?php echo $row_web_orderList['p_name']; ?></span></td>
          <td align="center" valign="middle" class="board_add3"><span class="font_black">&nbsp;<?php echo $row_web_orderList['p_price']; ?></span><? $order_total=$order_total+$row_web_orderList['p_price']*$row_web_orderList['odlist_qty']?></td>
          <td align="center" class="board_add3"><?php echo $row_web_orderList['odlist_qty']; ?></td>
        </tr>
        <?php } while ($row_web_orderList = mysql_fetch_assoc($web_orderList)); ?>
      </tbody>
    </table>
    <table width="100%" class="table table-bordered" cellspacing="0" cellpadding="5">
      <tr>
        <td height="50" align="right" valign="middle" class="board_add3"><span class="font_black">小计：<?php echo $order_total ;?></span></td>
      </tr>
      <tr>
        <td height="50" align="right" valign="middle" class="board_add3"><span class="font_black">运费：20元</span></td>
      </tr>
      <tr>
        <td height="50" align="right" valign="middle" class="board_add3"><span class="font_red">总计：<?php echo $order_total+20 ;?></span></td>
      </tr>
    </table>
    <p class="text-center"><input type="button" name="submit" class="btn btn-default" value="回上一页" onClick="window.history.back()";></p>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($web_orders);

mysql_free_result($web_orderList);
?>
