/**
 *定义学生发生，并存储学生所选课程
 */

import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;

public class Student{
  private String username;
  private String userpass;
  private Set<Course>course;

  protected Student(String username,String userpass){
    this.username = username;
    this.userpass = userpass;
    this.course = new HashSet<Course>();
  }

   protected void Iterator(){
    // Collections.sort(course);
     Iterator it = course.iterator();
     while(it.hasNext()){
       Course co = (Course)it.next();
       System.out.println(co.getId()+":"+co.getName());
     }
   }

  public Set<Course> getCourse(){
    return course;
  }


  public boolean removeCourse(String id){
    boolean sign = false;
    Iterator it = course.iterator();
     while(it.hasNext()){
       Course co = (Course)it.next();
       if(co.getId().equals(id)){
         sign = true;
         course.remove(co);
         return true;
       }else{
         System.out.println(co.getId()+":"+co.getName());
       }
     }
     return false;
  }

         
}