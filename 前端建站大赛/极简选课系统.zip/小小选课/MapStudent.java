/**
 *����ѧ��
 *�洢ѧ����ѡ�γ�
 */

import java.util.Map;
import java.util.HashMap;
public class MapStudent{
  protected Map<String,Student>student;

  protected  MapStudent(){
    this.student = new HashMap<String,Student>();
  }

  protected boolean Same(String username){
    Student is = student.get(username);
    if(!(is == null)){
       System.out.println("���˻����ѵ�½�����������룡");
       return false;
    }else{
       return true;
    }
  }
  protected void putStudent(String username,String userpass){
       Student stu = new Student(username,userpass);
       student.put(username,stu);
  }


//����
/**
  public static void main(String[] arguments){
    MapStudent ms = new MapStudent();
    ms.putStudent("κ��","weifan123");
  }
*/
}