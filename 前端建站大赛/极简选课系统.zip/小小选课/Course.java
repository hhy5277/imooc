/**
 *定义课程发生，初始化课程
 */

public class Course implements Comparable<Course>{
  private String id;//课程id
  private String name;//课程名称

  //初始化课程属性
  protected Course(String id,String name){
    this.id = id;
    this.name = name;
  }

  //通过get将私有变量传输出去
  protected String getId(){
    return id;
  }
  protected String getName(){
    return name;
  }
 
  //排序
  public int compareTo(Course o1){
    return this.id.compareTo (o1.id);
  }

  public boolean equals(Object obj){
    if(this == obj)
      return true;
    if(obj == null)
      return false;
    if(!(obj instanceof Course))
      return false;
    Course other = (Course)obj;
    if(this.name == null){
       if(other.name == null){
         return true;
       }else{
         return false;
       }
    }else{
       if(this.name.equals(other.name)){
          return true;
       }else{
          return false;
       }
    }
  }
}