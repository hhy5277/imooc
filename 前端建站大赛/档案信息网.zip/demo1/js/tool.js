/**
 * Created by Administrator on 2015-09-28.
 */
$(function(){
    //导航菜单点击
    navClick();

    //二级菜单
    navHover();

    //banner顶部业内内容切换
    dtSlide();

    //图片轮播
    picsSlider();

    //图片无缝滚动
    wsztImgScroll();

    //搜索框焦点事件
    placeValue($("#seachTxt"),"请输入关键字");

    //日期填充
    $("#getDay").html(getDate());

    //特色延平内容切换
    tsyp();

    //文字溢出显示省略号
    ellipsis($(".mainContent_left_body li a"),26);
    ellipsis($(".tsContent_left_body li a"),26);
    ellipsis($(".ynInfo_body li a"),22);
    ellipsis($(".dtDetail p"),55);
    ellipsis($(".list_body li a"),33);
    ellipsis($(".latest_body li a"),33);
    ellipsis($(".search_body li p"),200);
    ellipsis($(".img_body li p>a"),14);
    //轮播图图片宽度设置
    setWidth();
    $(".seachBtn").click(function(){
        getSearchResult();
    });

});
//导航菜单点击
function navClick(){
    var navLia=$("#nav li a");
    navLia.each(function(index,obj){
       $(this).click(function(){
           navLia.each(function(index,obj){
               $(this).removeClass("active");
           });
           $(this).addClass("active");
       })
    });
}
//二级菜单
function navHover(){
    var navLi=$("#nav>ul>li");
    navLi.each(function(index,obj){
        $(this).on("mouseover",function(){
            $(this).find("ul").css("display","block");
        });
        $(this).on("mouseout",function(){
            $(this).find("ul").css("display","none");
        })
    })
}

//banner顶部业内内容切换
function dtSlide(){
    var dtLia=$("#dt>ul>li>a"),
        dtI=$("#dt>i");
    dtLia.each(function(index,obj){
        $(this).on("click",function(){
            dtLia.removeClass("active");
            $(this).addClass("active");
            if($(this).html()=='业内动态'){
                dtI.removeClass();
                dtI.addClass("triangle-down");
                $("#jgdt_detail")[0].style.display="none";
                $("#jgdt_body")[0].style.display="none";
                $("#yndt_detail")[0].style.display="block";
                $("#yndt_body")[0].style.display="block";
            }else{
                dtI.removeClass();
                dtI.addClass("triangle-down1");
                $("#yndt_detail")[0].style.display="none";
                $("#yndt_body")[0].style.display="none";
                $("#jgdt_detail")[0].style.display="block";
                $("#jgdt_body")[0].style.display="block";
            }
        })
    });
}

//图片轮播
function picsSlider(){
    var picSlider=$("#picSlider"),
        pic=$("#pic"),
        listLi=$("#list li"),
        listTitle=$("#listTitle li"),
        listTitleLi=$("#listTitle li"),
        index=0,
        timer=null;
    function picChange(){
        index++;
        if(index<4){
            changeOption(index);
        }
        else{
            index=-1;
        }
    }
    function objHover(obj){
        obj.hover(function(){
            clearInterval(timer);
        },function(){
            timer=setInterval(picChange,3000);
        });
    };
    function changeOption(curentIndex){
        listLi.each(function(index,obj){
            $(this).removeClass();
        });
        listTitleLi.each(function(index,obj){
            $(this).removeClass();
        });
        if(listLi.get(index)!=null){
            listLi.get(index).className="active";
        }
        if( listTitleLi.get(index)!=null){
            listTitleLi.get(index).className="active";
        }
        pic.css("top",-(index*243)+'px');
        index=curentIndex;
    }
    objHover(pic);
    objHover(listTitle);
    listLi.each(function(index,obj){
        this.id=index;
        listLi.hover(function(){
            clearInterval(timer);
            changeOption(this.id);
        },function(){
            clearInterval(timer);
            timer=setInterval(picChange,3000);
        })
    });
    if(timer){
        clearInterval(timer);
    }
    timer=setInterval(picChange,3000);
}

//图片无缝滚动
function wsztImgScroll(){
    var wsztImg=$("#wsztImg"),
        slideli1=$(".slideli1"),
        slideli2=$(".slideli2"),
        timer=null;
    slideli2.html(slideli1.html());
    function imgScrollLeft(){
        if(wsztImg.scrollLeft()>=slideli1.width()){
            wsztImg.scrollLeft(0);
        }
        else{
            wsztImg.scrollLeft(wsztImg.scrollLeft()+1);

        }
    }
    timer=setInterval(imgScrollLeft,30);
    wsztImg.hover(function(){
        clearInterval(timer);
    },function(){
        timer=setInterval(imgScrollLeft,30);
    })
}
//搜索框焦点事件
function placeValue(obj,str){
    obj.focus(function(){
        var text=$(this).val();
        if(text==str){
            $(this).val("");
        }
    });
    obj.focusout(function(){
        var text=$(this).val();
        if(text==""){
            $(this).val(str);
        }
    })
}



//日期函数
function getDate(){
    var currentDate=new Date(),
        weekDays=["星期天","星期一","星期二","星期三","星期四","星期五","星期六"],
        weekDay=weekDays[currentDate.getDay()],
        currentMonth=currentDate.getMonth()+1;
    return currentDate.getFullYear()+"年"+currentMonth+"月"+currentDate.getDate()+"日"+"  "+weekDay;
}

//特色延平内容切换
function tsyp(){
    var tsContentLi=$(".tsContent_left_top li"),
        tsContentBody=$(".tsContent_left_body");
    tsContentLi.each(function(index,obj){
        this.id=index;
        $(this).click(function(){
            tsContentLi.each(function(index,obj){
                $(this).find("a").removeClass("active");
            });
            tsContentBody.each(function(index,obj){
                $(this).css("display","none");
            });
            $(this).find("a").addClass("active");
            tsContentBody.get(this.id).style.display="block";
        })
    });
}

//文字溢出显示省略号
function ellipsis(obj,objLen){
    obj.each(function(index,obj){
        if($(this).html().length>objLen){
            $(this).html($(this).html().substr(0,objLen)+"...");
        }
    })
}
//轮播图图片宽度设置
function setWidth(){
    var sliImg=$(".slideul2 img"),w;
    sliImg.each(function(index,obj){
        w=$(this).width();
        if(w==220){
            this.style.width="220px";
        }
    })
}

//获取搜索结果
function getSearchResult(){
    $.ajax({
        url:'search.html',
        type:'get',
        async:false,
        dataType:'html',
        //data:jQuery('form').eq(0).serialize(),
        success:function(data){
           window.open("search.html");
        },
        error:function(re){
            alert(re.message);
        }
    });
}
