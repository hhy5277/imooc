package com.imooc.rentsystem;

public class PassengerCar extends Car {
//	private int peopleCapacity;
	public PassengerCar(String name, double rent, int peopleCapacity){
		this.name = name;
		this.rent = rent;
		this.peopleCapacity = peopleCapacity;
	}
//	public int getPeopleCapacity() {
//		return peopleCapacity;
//
//
//	}
//	public void setPeopleCapacity(int peopleCapacity) {
//		this.peopleCapacity = peopleCapacity;
//	}
	
}
