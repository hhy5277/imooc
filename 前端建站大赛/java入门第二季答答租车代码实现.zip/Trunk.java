package com.imooc.rentsystem;

public class Trunk extends Car {
//	private int peopleCapacity;
//	private double cargoCapacity;
	public Trunk(String name, double rent, int peopleCapacity, double cargoCapacity){
		this.name = name;
		this.rent = rent;
		this.peopleCapacity = peopleCapacity;
		this.cargoCapacity = cargoCapacity;
	}
	/*public int getPeopleCapacity() {
		return peopleCapacity;
	}
	public void setPeopleCapacity(int peopleCapacity) {
		this.peopleCapacity = peopleCapacity;
	}
	public double getCargoCapacity() {
		return cargoCapacity;
	}
	public void setCargoCapacity(double cargoCapacity) {
		this.cargoCapacity = cargoCapacity;
	}*/
	
}
