package com.imooc.rentsystem;

public class PickupCar extends Car {
//	private double cargoCapacity;
	public PickupCar(String name, double rent, double cargoCapacity){
		this.name = name;
		this.rent = rent;
		this.cargoCapacity = cargoCapacity;
	}
	/*public double getCargoCapacity() {
		return cargoCapacity;
	}
	public void setCargoCapacity(double cargoCapacity) {
		this.cargoCapacity = cargoCapacity;
	}*/
	
}
