type = false;
// scroll();
$(window).scroll(function(){
	// scroll();
});

function scroll(){
	position = $(window).scrollTop();
	if(position >= 400){
		if(type === false){

			$(".callme").show()
			$(".about").css({
				"position" : "fixed" , 
				"box-shadow" : "none",
				"top" :"-500px"
			}).animate({"top" : "50px" , "left" : "-1280px"} , function(){
				// $(".header").animate({"height" : "0px"});
			}) ;
			type = true
		}

	}else{
		if(type === true){
			// $(".nav").css({
			// 	"position" : "" , 
			// 	"box-shadow" : "none",
			// });
			// $(".split").css({
			// 	"width" : "240px" , 
			// })
			// $(".nav-main").css({
			// 	"float" : "none" , 
			// })
			$(".callme").hide()
			$(".about").css({
				"position" : "absolute" , 
				"box-shadow" : "0px -12px 48px -9px #bbb",
				top:$(".about").offset().top+"px"
			}).animate({"left" : "-25px",top:"14px"} , 200) ;
			type = false
		}

	}
}