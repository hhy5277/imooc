var json_header_image = [

	'./static/image/element/04fd880a98b31dcf210f9eeff91e5d28.jpg',
	'./static/image/element/b8ddedc51703ddca38d008b38e50e067.jpg',
	'./static/image/element/home_header.jpg',
	'./static/image/element/home_header_1.jpg',
	'./static/image/element/home_header_2.jpg',
	'./static/image/element/home_header_3.jpg',
	'./static/image/element/home_header_4.jpg',
	'./static/image/element/home_header_5.jpg',
	'./static/image/element/home_header_6.jpg',
];
var header = {
	rule : " #333 center left no-repeat" , 
	$element : $(".header") , 
	cookie_value : getCookie('blog-header') , 
} , 
	default_image = header.cookie_value != null ? header.cookie_value : json_header_image[0] , 
	index = header.cookie_value != null ? getCookie('blog-header-index') : 0;

header.$element.css({
	background : "url(" + (default_image) + ")" + header.rule ,
	'background-position-x' : getCookie('blog-header-position') + 'px'
});
$("#js-re-header").click(function(){
	header.$element.fadeOut(500 , function(){
		header.$element.fadeIn(500).css({
			background : "url(" + json_header_image[index] + ")" + header.rule
		});
	});
	if(index >= json_header_image.length - 1) 
		index = 0 
	else 
		index ++;
	setCookie('blog-header' , json_header_image[index]);
	setCookie('blog-header-index' , index);
});





// header drag
drag = false , left = 0;
header.$element.mousedown(function(event){
	if(event.which === 1){
		drag = true;
		position_x = header.$element.css('background-position-x').replace('px' , '').replace('%' , '');
		left = event.clientX - parseInt(position_x);
		image_hide_width = parseInt('-' + (1980 - header.$element.width() - 90));
		$('.wrapper').addClass('not-user'); 
		$(this).css({cursor : '-webkit-grabbing'});
	}
}).mouseup(function(event){
	if(event.which === 1){
		drag = false
		$('.wrapper').removeClass('not-user')
		$(this).css({cursor : '-webkit-grab'});
	}
}).mousemove(function(event){
	if(drag){
		position = event.clientX - left;
		if(position < 124 && position > image_hide_width){
			header.$element.css({
				'background-position-x' : position+ 'px'
			})
			setCookie('blog-header-position' , position);
		}
	}
});










$("#js-search-button").click(function(){
	window.location.href="?search="+$("#js-search-text").val();
});

function setCookie(name,value){
	var Days = 30;
	var exp = new Date();
	exp.setTime(exp.getTime() + Days*24*60*60*1000);
	document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
}
function getCookie(name){
	var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
	if(arr=document.cookie.match(reg))
		return unescape(arr[2]);
	else
		return null;
}
// if($(window).height() - 160 > $(".warpper-right").height()){
// 	$(".footer").css({
// 		position : "relative" ,
// 		top : $(window).height() - $(".footer").height() -230 + "px"
// 	})
// }else{
// 	$(".footer").css({
// 		position : "" ,
// 		top : ""
// 	})
// }
