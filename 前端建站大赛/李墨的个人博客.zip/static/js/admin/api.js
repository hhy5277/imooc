var _api = {admin : {} , home : {}} , 
	isRequest = true ;

var doAjax = function(options){
	if(isRequest){
		isRequest = false;
		$.ajax({
			url : options.url , 
			data : options.data , 
			cache: false,
			type: "POST",
			contentType: "application/x-www-form-urlencoded; charset=UTF-8",
			dataType: "JSON",
			timeOut : 6000 , 
			content : window,
			success : function(data){
				if(data.STATE){
					options.promise.resolve(data.DATA);
				}else{
					options.promise.reject(data.ERROR);
				}
			},
			error : function(){
				options.promise.reject("请求出现异常，服务器繁忙无法处理您的请求，请稍候再试！");
			},
			complete : function(){
				isRequest = true;
			}
		});
	}else{
		options.promise.reject("请求正在处理中，请勿重复提交请求。");
	}
}



_api.adminUser = {
	apiUrl : "admin/msg/user/" , 
	login : function(data){
		var promise = $.Deferred();
		 doAjax({
			url : this.apiUrl + "login",
			data : data , 
        		promise: promise,
		});
		return promise;
	} , 
	outLogin : function(){

	}
}


_api.adminArticle = {
	apiUrl : "admin/msg/article/",
	create : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "create",
			data : data , 
        		promise: promise,
		});
		return promise;
	} , 
	remove : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "remove",
			data : data , 
        		promise: promise,
		});
		return promise;
	}
}



_api.admin_class = {
	apiUrl : "admin/msg/Class_admin/",
	bar : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "bar",
			data : data , 
        		promise: promise,
		});
		return promise;
	} ,
	list : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "list_top",
			data : data , 
        		promise: promise,
		});
		return promise;
	} ,
	create : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "create",
			data : data , 
        		promise: promise,
		});
		return promise;
	} , 
	remove : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "remove",
			data : data , 
        		promise: promise,
		});
		return promise;	
	} , 
	edit : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "edit",
			data : data , 
        		promise: promise,
		});
		return promise;	
	}
}



_api.admin.article = {
	apiUrl : "admin/msg/article/",
	check : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "check",
			data : data , 
        		promise: promise,
		});
		return promise;
	} , 
	upTop : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "upTop",
			data : data , 
        		promise: promise,
		});
		return promise;
	} ,
	removeCover : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "removeCover",
			data : data , 
        		promise: promise,
		});
		return promise;
	}

}

_api.admin.tag = {
	apiUrl : "admin/msg/Tag/",
	create : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "create",
			data : data , 
        		promise: promise,
		});
		return promise;
	} , 
	remove : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "remove",
			data : data , 
        		promise: promise,
		});
		return promise;
	}
}

_api.admin.fun = {
	apiUrl : "admin/function/fun/" , 
	removeCache : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "removeCache",
			data : data , 
        		promise: promise,
		});
		return promise;
	} , 
}




_api.home.article = {
	apiUrl : "Api/" , 
	browse : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "Article_browse",
			data : data , 
        		promise: promise,
		});
		return promise;
	} , 
}


_api.admin.friendship_link = {
	apiUrl : "admin/msg/friendship_link/" , 
	create : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "create",
			data : data , 
        		promise: promise,
		});
		return promise;
	} , 
	edit : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "edit",
			data : data , 
        		promise: promise,
		});
		return promise;
	} ,
	remove : function(data){
		var promise = $.Deferred();
		doAjax({
			url : this.apiUrl + "remove",
			data : data , 
        		promise: promise,
		});
		return promise;
	} , 
}
