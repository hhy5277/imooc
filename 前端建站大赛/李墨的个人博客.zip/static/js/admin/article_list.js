var tableDelete = function(article){
	var article_id = article.articleId;
	_api.adminArticle.remove({
		article_id : article_id
	}).then(function(data){
		window.location.reload();
		eject.close();
	} , function(msg){
		eject.alert({
			content : msg
		});
		eject.close();
	});
	eject.close();
} , uptop = function(article_id){
	_api.admin.article.upTop({
		article_id : article_id
	}).then(function(){eject.close();setTimeout(function(){eject.prompt({content:"置顶成功，原文章置顶已被取消" , type:true});window.location.reload();} , 300)} , function(data){eject.close();setTimeout(function(){eject.prompt({content:data , type:false})} , 300)})
}


$(".table").on("click" , "#js-uptop" , function(){
	eject.sure({
		content : "您确定要将该文章全网置顶吗？<br /><br />已置顶文章：<a href='./act/" + top_article.byid + ".html' target='_blank'>" + top_article.title + "</a><br /><br />如果您继续操作，那么上诉文章将会被取消全网置顶",
		functionName : "uptop(" +$(this).parent().parent().data("id")+ ")"
	})
});


$("#class").change(function(){
	var name = $(this).val() , 
		id = $(this).find("option[value='" + name + "']").data("id");
	window.location.href = thisLoction + "?class=" + id;
});
$("#back").click(function(){
	window.location.href = thisLoction ;
})