
function class_craete () {
	button.loading($(".btn-success"));
	params = getInputData([
		"#js-title",
		"#js-link",
		"#js-priority",
	]);
	if(params[2] > 1024) showAlert('优先度最高只能填写到1024，请检查后重新填写' , false);
	_api.admin.friendship_link.create({
		'title' : params[0],
		'link' : params[1],
		'priority' : params[2],
	}).then(function(){
		eject.prompt({content : "友情链接创建成功！" , type : true})
		setTimeout(function(){
			window.history.go(-1);
			button.recovery($this);
		} , 600);
	} , function(data){
		eject.alert({content : data , type : false});
		button.recovery($(".btn-success"));
	})
	button.recovery($(".btn-success"));
}

