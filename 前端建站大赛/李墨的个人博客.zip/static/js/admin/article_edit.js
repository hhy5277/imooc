(function(){

	// 监控编辑文章时编辑页面的删除封图按钮
	$("#js-remove-cover").click(function(){
		eject.sure({content : "您确定要删除这篇文章的封面图片吗？<br />注意：无封图的文章无权设为栏目置顶" , functionName : "removeCover()"});
	});


}());



// 删除文章封面图片函数
function removeCover(){
	_api.admin.article.removeCover({
		article_id : article_data.id
	}).then(function(){
		$("#browse").attr("src" , "");
		eject.close();
		setTimeout(function(){
			eject.prompt({
				type : true , 
				content : "文章封图删除成功，注意：无封图的文章无权设为栏目置顶"
			})
		})
	} , function(data){
		eject.close();
		setTimeout(function(){
			eject.prompt({
				type : false , 
				content : data
			})
		})
	});
}







function article_edit(){
	params = checkInput(getInputData([
		"#js-article-title",
		"#js-article-key",
	]) , [
		{name : "文章标题" , min : 5 , max : 60},
		{name : "关键词" , isNull : false},
	]);


	select_option = {
		release : document.getElementById("js-article-release").checked,
		comment : document.getElementById("js-article-comment").checked,
		anonymous : document.getElementById("js-article-anonymous").checked,
		grab : document.getElementById("js-article-grab").checked,
		cover : document.getElementById("js-article-cover").checked,
		top : document.getElementById("js-article-top").checked,
	}

	$("#js-article-option").val(JSON.stringify(select_option));
	$("#js-article-key-plus").val($("#js-article-key").val());

	article_content = um.getContentTxt();
	if(article_content.length < 80){
		showAlert("您文章内容太短了，不得少于80字" , false);
		return false;
	}

	if(params.state === false){
		showAlert(params.error , false);
		return false;
	}

	var option = {
		url : "./admin/msg/article/edit",
		type : "POST",
		dataType : "JSON",
		success : function(data){
			if(data.STATE){
				eject.alert({
					type : true , 
					content : "文章编辑成功！<br />稍候文章将会进入待审核状态，审核完毕后即可发布"
				})
				out_sure = false;
				setTimeout(function(){
					window.history.go(-1);
				}  , 1400);
			}else{
				showAlert(data.ERROR , false);
			}
		}
	}
	$("#js-article-edit").ajaxSubmit(option);





	/* if you don't upload photos , you can use it
	_api.adminArticle.create({
		article_title : params[0],
		article_key : params[1],
		article_form : params[2],
		article_content : um.getContent(),
		article_release : document.getElementById("js-article-release").checked,
		article_comment : document.getElementById("js-article-comment").checked,
		article_anonymous : document.getElementById("js-article-anonymous").checked,
		article_grab : document.getElementById("js-article-grab").checked,
		article_cover : document.getElementById("js-article-cover").checked,
		article_top : document.getElementById("js-article-top").checked,
	});*/
}

(function(){
	$("#js-article-title").focus(function(){
		$(this).css({"font-size" : "23px"})
	}).blur(function(){
		if($(this).val() === "") $(this).css({"font-size" : "14px"})
	});

	$(".select_search input[type='text']").blur(function(){
		$this = $(this).parent();
		$this.find("input[type='text']").animate({width : "0%"});
		$this.find("button").html('<i class="fa fa-search"></i> 搜索' + $this.data("type")).css({"width" : "95px" , "border-left" : "1px solid #ccc" });
		setTimeout(function(){
			$this.find("input[type='text']").hide();
			$this.parent().find(".article_header").show();
		} , 400);
	});

	$(".select_search").on("mouseup" , " #select_search" , function(e){
		$this = $(this).parent();
		$this.parent().find(".article_header").hide();
		$this.find("input[type='text']").show().animate({width : "60%"}).focus();
		$this.find("button").html('<i class="fa fa-search"></i>').css({"width" : "35px" , "border-left" : "none"});
	});
}())