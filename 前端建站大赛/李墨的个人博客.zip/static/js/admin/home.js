$(function () {

    $.ajax({
        url : "./admin/msg/get/get_cnzz",
        dataType : "JSON"
    }).then(function(data){
        var visits = [] , visitors = [] , index = 0;
        $.each(data.ip , function(key , value){
            index++;
            visits.push([index , value]);
        });
        index = 0;
        $.each(data.pv , function(key , value){
            index++;
            visitors.push([index , value]);
        }); 

        // eject.alert({
        //     title : "致编辑者们",
        //     content : "欢迎来到电脑医生后台管理系统，新版系统上线之初难免会有很多BUG，以及不足之处，如果您在日常使用中发现了问题或有什么建议，您可以发送email至tocurd<br/><br/><p>如果不想再看见我，<a href='javascript:;' onclick='alert(\"别想了，我正在想办法\")'>请点击这里</a></p>"
        // });

    // jQuery Flot Chart
var flot_type_list =  [ { data: visits, label: " UV"}, { data: visitors, label: " PV" }] , option = {
            series: {
                lines: { show: true,
                        lineWidth: 1,
                        fill: true, 
                        fillColor: { colors: [ { opacity: 0.1 }, { opacity: 0.13 } ] }
                     },
                points: { show: true, 
                         lineWidth: 1,
                         radius: 3
                     },
                shadowSize: 0,
                stack: true
            },
            grid: { hoverable: true, 
                   clickable: true, 
                   tickColor: "#f9f9f9",
                   borderWidth: 0
                },
            legend: {
                    // show: false
                    labelBoxBorderColor: "#fff"
                },  
            colors: ["#a7b5c5", "#30a0eb"],
            xaxis: {
                ticks: [
                            [1, "0点"],
                            [2, "1点"],
                            [3, "2点"],
                            [4, "3点"],
                            [5, "4点"],
                            [6, "5点"],
                            [7, "6点"],
                            [8, "7点"],
                            [9, "8点"],
                            [10, "9点"],
                            [11, "10点"],
                            [12, "11点"],
                            [13, "12点"],
                            [14, "13点"],
                            [15, "14点"],
                            [16, "15点"],
                            [17, "16点"],
                            [18, "17点"],
                            [19, "18点"],
                            [20, "19点"],
                            [21, "20点"],
                            [22, "21点"],
                            [23, "22点"],
                            [24, "23点"],
                            [25, "24点"]
                        ],
                font: {
                    size: 12,
                    family: "Open Sans, Arial",
                    variant: "small-caps",
                    color: "#697695"
                }
            },
            yaxis: {
                ticks:3, 
                tickDecimals: 0,
                font: {size:12, color: "#9da3a9"}
            }
         }

        var plot = $.plot($("#statsChart") , flot_type_list , option);
        var previousPoint = false , temp_index = -1;


        function showTooltip(x, y, contents , x_s){
              y = y - $("#tooltip").height() - 140;
              x = x - $("#tooltip").width() - ($(".top-flot").width() / 24) - ($("#tooltip").width() / 2) - 39;
              if(!previousPoint){
                    previousPoint = true;
                    $('<div id="tooltip">' + contents + '</div>').css( {
                            position: 'absolute',
                            display: 'none',
                            top: y,
                            left: x ,
                            color: "#fff",
                            padding: '4px 7px 10px 7px',
                            'border-radius': '6px',
                            'background-color': '#000',
                            opacity: 0.60
                    }).appendTo(".top-flot").fadeIn(200);
              }else{
                    $("#tooltip").css({
                         top: y ,
                         left: x ,
                    }).html(contents)
              }
        }
        $(".top-flot").on("mousemove"  , function(e){
             var index = e.pageX / (($(this).width() / 24) );
             index = (index - Math.floor(index) > 0.5 ? Math.ceil(index): Math.floor(index)) - 2;
             if(index < 0 || index > 23) return false;



             if(e.pageX - $("#tooltip").width() < $("#tooltip").width() +15){
                e.pageX = e.pageX +$("#tooltip").width() +40;
             }

            $(".position-line").css({"margin-left" :e.offsetX+4+"px"})
             showTooltip(e.pageX , e.pageY , "<span>2015-10-22 — " + index+"点</span><br><font>今日访问PV："+
                visitors[index][1]
                +"</font><br><font>今日访问IP："+
                visits[index][1]
                +"</font>" , e.pageX);
             temp_index = index;
        });


        $(".top-flot").hover(function(){},function(e){
                    previousPoint = false;
             $("#tooltip").fadeOut(200).remove() ;

        });


       





    })

});