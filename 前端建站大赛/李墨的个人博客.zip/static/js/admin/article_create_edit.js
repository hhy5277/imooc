// upload browser
um = UE.getEditor('editor');
out_sure = true;
(function(){
	var reader = new FileReader();
	$browse = $('#browse'),
	reader.onload = function (e) {
		$("#temp").attr('src', e.target.result);
		$browse.attr('src', e.target.result);
		height = $("#temp").height();
		width = $("#temp").width();
		$browseSize = $("#browseSize");
		$browseSize.html($browseSize.data("reconmmend") + "  当前尺寸：" +height+ "*" + width);
	}
	$("body").on("change" , 'input[type="file"]' , function(e){
		var file = e.target.files[0];
		if(typeof file === "undefined"){
			$(".browse img").attr({"src" : ""});
		}
		reader.readAsDataURL(file);
	});


	$("#js-push-tag").click(function(){
		$("#js-tag-window").show().find(".eject").css({
			"display" : "block",
			"top" : "20%" , 
			"opacity" : "1"
		});
	});


	$("#js-article-title").focus(function(){
		$(this).css({"font-size" : "23px"})
	}).blur(function(){
		if($(this).val() === "") $(this).css({"font-size" : "14px"})
	});

	$(".select_search input[type='text']").blur(function(){
		$this = $(this).parent();
		$this.find("input[type='text']").animate({width : "0%"});
		setTimeout(function(){
			$this.parent().find(".article_header").show();
			$this.find("button").html('<i class="fa fa-search"></i> 搜索' + $this.data("type")).css({"width" : "95px" , "border-left" : "1px solid #ccc" });
			$this.find("input[type='text']").hide();
		} , 400)
	});

	$(".select_search").on("mouseup" , " #select_search" , function(e){
		$this = $(this).parent();
		$this.parent().find(".article_header").hide();
		$this.find("input[type='text']").show().animate({width : "60%"}).focus();
		$this.find("button").html('<i class="fa fa-search"></i>').css({"width" : "35px" , "border-left" : "none"});
	});
}());



function pushTag(){
	_api.admin.tag.create({
		title : $("#js-input-name").val(),
		description : "" , 
		link : $("#js-input-link").val() ,
	}).then(function(data){
		eject.close();
		$("#js-article-select-tag").prepend("<option  selected='selected'>" + $("#js-input-name").val() + "<option>");
		$("#js-article-select-tag").get(0).selectedIndex = 0;  
		$("#js-input-link").val("")
		$("#js-input-name").val("")
		setTimeout(function(){
			eject.prompt({
				type : true , 
				content : "标签添加成功！稍候系统将会直接选中该标签"
			})
		})
	} , function(data){
		eject.close();
		setTimeout(function(){
			eject.prompt({
				type : false , 
				content : data
			})
		})
	})
}

