(function(){
	$(".table").on("click" , "#bar" , function(){
		_api.admin_class.bar({
			"id" : $(this).parent().parent().data("id")
		}).then(function(){
			window.location.reload();
		} , function(ERROR){
			eject.alert({content : ERROR , type : false});
		});
	});

	$(".table").on("click" , "#list" , function(){
		_api.admin_class.list({
			"id" : $(this).parent().parent().data("id")
		}).then(function(){
			window.location.reload();
		} , function(ERROR){
			eject.alert({content : ERROR , type : false});
		});
	});
	
})();




function tableDelete(data){
	_api.admin_class.remove({
		"article_id" : data.articleId
	}).then(function(){
		window.location.reload();
	} , function(ERROR){
		eject.alert({content : ERROR , type : false});
		eject.close();
	})
}

function class_edit(){
	$this = $(".btn-success");
	button.loading($this);
	params = checkInput(getInputData([
		"#js-class-title",
		"#js-class-link",
		"#js-class-key",
		"#js-class-description",
	]) , [
		{name : "分类标题" , min : 2 , max : 80},
		{name : "自定义链接" , min : 0 , max : 50},
		{name : "关键词" , isNull : false},
		{name : "分类描述" , min : 0 , max : 200},
	]);


	if(params.state === false){
		showAlert(params.error , false);
		button.recovery($this);
		return false;
	}

	_api.admin_class.edit({
		id : id,
		title : params[0],
		link : params[1],
		fuTitle : $("#js-class-fuTitle").val(),
		icon : $("#js-class-icon").val(),
		key : params[2],
		description : params[3],
	}).then(function(){
		eject.prompt({content : "分类编辑成功" , type : true})
		setTimeout(function(){
			window.history.go(-1);
			button.recovery($this);
		} , 600);
	} , function(ERROR){
		eject.alert({content : ERROR , type : false});
		button.recovery($this);
	})
}


function class_craete () {
	$this = $(".btn-success");
	button.loading($this);
	params = checkInput(getInputData([
		"#js-class-title",
		"#js-class-link",
		"#js-class-key",
		"#js-class-description",
	]) , [
		{name : "分类标题" , min : 2 , max : 80},
		{name : "自定义链接" , min : 0 , max : 50},
		{name : "关键词" , isNull : false},
		{name : "分类描述" , min : 0 , max : 200},
	]);

	if(params.state === false){
		showAlert(params.error , false);
		button.recovery($this);
		return false;
	}

	_api.admin_class.create({
		title : params[0],
		link : params[1],
		fuTitle : $("#js-class-fuTitle").val(),
		icon : $("#js-class-icon").val(),
		key : params[2],
		description : params[3],
	}).then(function(){
		eject.prompt({content : "分类创建成功" , type : true})
		setTimeout(function(){
			window.history.go(-1);
			button.recovery($this);
		} , 600);
	} , function(ERROR){
		eject.alert({content : ERROR , type : false});
		button.recovery($this);
	})
}