var Rule = {
	is_length : function(inputData){
		for(var i = 0; i < inputData.length; i++) {
			data = inputData[i];
			if($.trim(data.value) === "" || data.value == "" || data.value == undefined) return {error_msg : "不能为空" , index : i};
			if(data.value.length < data.min) return {error_msg : "太短了" , index : i};
			if(data.value.length > data.max) return {error_msg : "太长了" , index : i};
		}
		return true;
	},
},
button = {
	temp_button_value : "" ,
	loading : function($this){
		this.temp_button_value = $this.html();
		$this.attr({disabled : true}).removeClass("btn-danger").addClass("btn-success").html("<i class='fa fa-spinner fa-spin'></i> 正在加载中...");
	} , 
	recovery : function($this){
		$this.attr({disabled : false}).html(this.temp_button_value).removeClass("btn-danger").addClass("btn-success");
	} , 
	error : function($this){
		this.temp_button_value = $this.html();
		temp = $this.html();
		$this.attr({disabled : true}).html("<i class='fa fa-remove'></i> 加载失败").removeClass("btn-success").addClass("btn-danger");
		setTimeout(function(){
			$this.attr({disabled : false}).html(temp).removeClass("btn-danger").addClass("btn-success");
		} , 700)
	}
}
,eject = {
	loading : function(){
		$prompt = $(".prompt").show();
		$promptContent = $prompt.find(".content").html('<i class="fa fa-spinner fa-pulse"></i> 服务器正在处理您的请求，请稍候');
		setTimeout(function(){
			$prompt.css({top : "30%" , "opacity" : 0.9});
		});
	},
	alert : function(data){
		$(".eject").hide();
		$alert = $(".window , #alert").show().find("#alert");
		setTimeout(function(){
			$alert.css({"top" : "15%" , "opacity" : "1"});
		} , 100);
		$content = $alert.find(".eject-content").html("");
		!isset(data.type) ? -1 : (data.type ? $content.append("<i class='fa fa-check'></i>") : $content.append("<i class='fa fa-remove'></i>"));
		!isset(data.type) ? -1 : (data.type ? $alert.find(".eject-bottom button").addClass(".eject-bottom  btn-success") : $alert.find("button").addClass("btn-danger"));
		$alert.find("h2").text(!isset(data.title) ? "温馨提示" : data.title);
		$content.append(data.content);
	} , 
	sure : function(data){
		$(".eject").hide();
		$sure = $(".window , #sure").show().find("#sure");
		$sure.find(".btn-danger").attr("onclick" , data.functionName);
		setTimeout(function(){
			$sure.css({"top" : "15%" , "opacity" : "1"});
		} , 100);
		$content = $sure.find(".eject-content").html("");
		!isset(data.type) ? -1 : (data.type ? $content.append("<i class='fa fa-check'></i>") : $content.append("<i class='fa fa-remove'></i>"));
		$content.append(data.content);
	} , 
	prompt : function(data){
		$prompt = $(".prompt").show();
		$promptContent = $prompt.find(".content").html("");
		!isset(data.type) ? -1 : (data.type ? $promptContent.append("<i class='fa fa-check'></i>") : $promptContent.append("<i class='fa fa-remove'></i>"));
		$promptContent.append(typeof data != "object" ? data : data.content);
		setTimeout(function(){
			$prompt.css({top : "30%" , "opacity" : 0.9});
			setTimeout(function(){
				$prompt.css({top : "0%" , "opacity" : 0});
				setTimeout(function(){
					$prompt.hide();
				} , 500);
			} , 2000)
		});
	} , 
	close : function(is_close_window){
		$this = $(".eject");
		$this.css({top : 0 , opacity : 0});
		setTimeout(function(){
			if(is_close_window !== "no") $(".window").hide();
		} , 200);
	}
}



function showAlert(content , type){
	eject.prompt({
		type : type , 
		content : content , 
	});
}





// 页面初始的一些小工具
(function(){
	$(".window").on("click" , "#close" , function(){
		eject.close();
	});

	$("#list").click(function(){
		$("#js-sidebar").show()
	});


	$sidebar = $("#js-sidebar") , topType = false;
	$sidebar.height($(document).height() - (45 * 1) + "px");

	$(document).scroll(function(e){
		if($(document).scrollTop() > 45){
			if(!topType){
				$sidebar.css({top : 0 , position : "fixed"});
				topType = true;
			}
		}else{
			if(topType){
				$sidebar.css({top : 45 , position : "absolute"})
				topType = false;
			}
		}
	});


	var keyInit = function($this , keyCount , keyList ){
		var keyList = isset(keyList) ? keyList : [],
			keyCount = isset(keyCount) ? keyCount : 0,
			keyFunction = {},
			max_length = $this.data("length");

			console.log(keyCount);
		keyFunction.pushKey = function(keyWord){
			keyWord = removeHTMLTag(keyWord)
			if(!isset(keyWord)) return false;
		
			if(keyCount >= max_length){
				eject.prompt("您输入的关键词太多了，最多只能输入" + max_length + "个关键词");
				$this.find("input").hide();
				return -1;
			}
			if(in_array(keyList , keyWord)){
				eject.prompt("请勿输入重复的关键词");
				return -2;
			}
			
			$this.find("#key").prepend('<span data-value="'+keyWord+'">'+keyWord+' <a href="javascript:;" class="close">X</a></span>');
			keyList = [];
			$this.find("#key span").each(function(key , value){
				keyList.push($(value).data("value"));
			});
			keyCount = $this.find("#key span").length;

			$this.val(JSON.stringify(keyList));
			return true;
		}
		keyFunction.removeKey = function(keyWord){
			console.log(keyWord)
			keyWord = removeHTMLTag(keyWord);
			console.log(keyWord)
			keyCount --;
			keyList = [];
			if(keyCount <= max_length){
				$this.find("input").show();
			}
			$.each($this.find("span") , function(key , value){
				keyList.push($(value).data("value"));
			});
		}

		$this.on("click" , ".close" , function(){
			$(this).parent().remove();
			keyFunction.removeKey($(this).parent().data("value"));
		}).find("input[type='text']").keypress(function(e){
			if(e.keyCode === 13){
				if($this.find("input[type='text']").val() !== "" && keyFunction.pushKey($this.find("input[type='text']").val())){
					$(this).val("");
				}
			}
		}).blur(function(e){
			if($this.find("input[type='text']").val() !== "" && keyFunction.pushKey($this.find("input[type='text']").val())){
				$(this).val("");
			}
		});
		return keyFunction;
	}


	$.each($("[data-widget]") , function(key , value){
		switch($(value).data("widget")){
			case "key" : keyInit($(value));break;
		}
	});
}())







function removeHTMLTag(str) {
	str = str.replace(/<\/?[^>]*>/g,''); //去除HTML tag
	str = str.replace(/[ | ]*\n/g,'\n'); //去除行尾空白
	//str = str.replace(/\n[\s| | ]*\r/g,'\n'); //去除多余空行
	str=str.replace(/ /ig,'');//去掉 
	return str;
	}

function rePcyisheng(){
	eject.close("no");
	setTimeout(function(){
		eject.loading();
		_api.admin.fun.removeCache().then(function(){
			setTimeout(function(){
	 			$prompt = $(".prompt").show();
				$prompt.css({top : "0%" , "opacity" : 0});
				setTimeout(function(){
					$prompt.hide();
					setTimeout(function(){
						eject.prompt({content : "整站缓存更新成功！" , type : true});
					} , 200);
				} , 500);
				$(".window").hide();
			},600)
		});
	},400)

}



















/**
 * 搜索数组内的关键词
 * @param  {[type]} array        [description]
 * @param  {[type]} searchString [description]
 * @return {[type]}              [description]
 */
function in_array(array , searchString){
	for(var index = 0;index < array.length;index ++) {
		if(array[index] === searchString) return true;
	};
	return false;
}

/**
 * 检查某个变量是否存在
 * @param  {[type]} var_value [description]
 * @return {[bool]}           [description]
 */
function isset(var_value){
	return var_value === undefined || $.trim(var_value) == "" ? false : true;
}



/**
 * 批量获得表单内的数据并以数组返回
 * @param  {[array]} formNameArray [description]
 * @return {[array]}               [description]
 */
function getInputData(formNameArray){
	var $formData = $(formNameArray.join(",")),
		returnFormArray = new Array();
	$.each($formData , function(key , value){
		returnFormArray.push($.trim(value.value));
	});
	return returnFormArray;
}



/**
 * 检查输入的数据长度是否符合规则
 * @param  {[type]} data [description]
 * @param  {[type]} rule [description]
 * @return {[type]}      [description]
 */
function checkInput(data , rule){
	for (var i = 0; i < data.length; i++) {
		if(rule[i].isNull === true && data[i] === "" || data[i] === undefined){
			return {state : false , error : "您输入的" + rule[i].name + "不能为空！"};
		}else if(rule[i].isNull === false && rule[i].isNull != ""){
			if(data[i].length < rule[i].min){
				return {state : false , error : "您输入的" + rule[i].name + "太短，最少需要输入" + rule[i].min + "个字符"};
			}	
			if(data[i].length > rule[i].max){
				return {state : false , error : "您输入的" + rule[i].name + "太长，最多只能需要输入" + rule[i].max + "个字符"};
			}
		}else if(rule[i].isNull === undefined){
			if(data[i].length < rule[i].min){
				return {state : false , error : "您输入的" + rule[i].name + "太短，最少需要输入" + rule[i].min + "个字符"};
			}	
			if(data[i].length > rule[i].max){
				return {state : false , error : "您输入的" + rule[i].name + "太长，最多只能需要输入" + rule[i].max + "个字符"};
			}
		}
	};
	return data;
}








// 列表右侧组件事件监控
// delete edit
// 2015年11月4日 00:09:15

(function(){
	$(document).on("click" , "#delete" , function(){
		$this = $(this).parent().parent();
		eject.sure({
			title : "您确定删除吗？",
			content : "您确定删除掉您所选中的项目吗？删除后项目将无法恢复<br />点击确认按钮后删除这个项目，点击取消将不会进行下一步操作" , 
			functionName : "tableDelete({articleId : " + $this.data("id") + "})"
		})
	});
	$(document).on("click" , "#edit" , function(){
		$this = $(this).parent().parent();
		window.location.href = thisLoction + (typeof custom_edit  == 'undefined' ? '/edit' : custom_edit) + "/?id=" + $this.data("id");
	});


}())






