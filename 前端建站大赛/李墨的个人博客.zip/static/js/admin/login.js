
function Login(){
	$loginButton = $("#js-admin-login");
	if($loginButton.attr("disabled")) return;

	var username = $("#js-admin-username").val() ,
		password = $("#js-admin-password").val() , 
	ruleResult = Rule.is_length([
		{value : username , min : 6 , max : 16},
		{value : password , min : 6 , max : 16},
	]);

	switch(ruleResult.index){
		case 0 :showError("您输入的用户名" + ruleResult.error_msg);return;break;
		case 1 :showError("您输入的密码" + ruleResult.error_msg);return;break;
	}

	$loginButton.prepend("<i class='fa fa-spinner fa-spin'></i>").attr("disabled" , true);
	closeError();

	_api.adminUser.login({
		username : username,
		password : password
	}).then(function(data){
		window.location.reload();
	} , function(data){
		showError(data);
		$loginButton.attr("disabled" , false).find("i").remove();
	})
}


var errorShow = true,
	closeTimeId;
function showError(errorMsg){
	if(errorShow){
		errorShow = false;
		clearInterval(closeTimeId);
		$this = $("#js-admin-login-box").addClass("showError");
		$this.find(".error").remove();
		$this.append("<p class='error'><i class='fa fa-exclamation-triangle'></i>警告：" +errorMsg+ " ！！</p>");
		setTimeout(function(){
			$this.find(".error").addClass("show");
		},10)
		setTimeout(function(){
			errorShow = true;
		},1000)
		closeTimeId = setTimeout(function(){
			closeError();
		} , 2700)
	}
}
function closeError(){
	$this = $("#js-admin-login-box");
	$this.find(".error").addClass("closeError");
	$this.removeClass("showError");
	$this.addClass("closeError");
	$this.removeClass("closeError");
}