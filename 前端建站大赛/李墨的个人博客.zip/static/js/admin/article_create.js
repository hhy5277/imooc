function article_save(){
	params = checkInput(getInputData([
		"#js-article-title",
		"#js-article-key",
		"#js-article-form"
	]) , [
		{name : "文章标题" , min : 5 , max : 60},
		{name : "关键词" , isNull : true},
		{name : "文章来源" , isNull : false , min : 2 , max : 50},
	]);


	select_option = {
		release : document.getElementById("js-article-release").checked,
		comment : document.getElementById("js-article-comment").checked,
		anonymous : document.getElementById("js-article-anonymous").checked,
		grab : document.getElementById("js-article-grab").checked,
		cover : document.getElementById("js-article-cover").checked,
		top : document.getElementById("js-article-top").checked,
	}

	$("#js-article-option").val(JSON.stringify(select_option));
	$("#js-article-key-plus").val($("#js-article-key").val());

	article_content = um.getContentTxt();
	if(article_content.length < 10){
		showAlert("您文章内容太短了，不得少于10字" , false);
		return false;
	}

	

	if(params.state === false){
		showAlert(params.error , false);
		return false;
	}

	var option = {
		url : "./admin/msg/article/create",
		type : "POST",
		dataType : "JSON",
		success : function(data){
			if(data.STATE){
				out_sure = false;
				window.history.go(-1);
			}else{
				showAlert(data.ERROR , false);
			}
		}
	}
	$("#js-article-create").ajaxSubmit(option);





	/* if you don't upload photos , you can use it
	_api.adminArticle.create({
		article_title : params[0],
		article_key : params[1],
		article_form : params[2],
		article_content : um.getContent(),
		article_release : document.getElementById("js-article-release").checked,
		article_comment : document.getElementById("js-article-comment").checked,
		article_anonymous : document.getElementById("js-article-anonymous").checked,
		article_grab : document.getElementById("js-article-grab").checked,
		article_cover : document.getElementById("js-article-cover").checked,
		article_top : document.getElementById("js-article-top").checked,
	});*/
}
