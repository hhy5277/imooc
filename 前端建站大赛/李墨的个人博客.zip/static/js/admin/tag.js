function create_tag () {
	params = checkInput(getInputData([
		"#js-tag-title",
	]) , [
		{name : "标签名称" , min : 2 , max : 20},
	]);

	if(params.state === false){
		showAlert(params.error , false);
		return false;
	}

	_api.admin.tag.create({
		"title" : params[0] , 
		"description" : params[1] , 
		"link" : $("#js-tag-link").val()
	}).then(function(){
		eject.prompt({content : "创建成功" , type : false});
		setTimeout(function(){
			window.history.go(-1);
		},1000)
	} , function(error){
		eject.prompt({content : error , type : false});
	})

}


function edit_tag () {
	params = checkInput(getInputData([
		"#js-tag-title",
	]) , [
		{name : "标签名称" , min : 2 , max : 20},
	]);

	if(params.state === false){
		showAlert(params.error , false);
		return false;
	}

	_api.admin.tag.edit({
		"id" : id , 
		"title" : params[0] , 
		"description" : params[1] , 
		"link" : $("#js-tag-link").val()
	}).then(function(){
		eject.prompt({content : "编辑成功！" , type : false});
		setTimeout(function(){
			window.history.go(-1);
		},1000)
	} , function(error){
		eject.prompt({content : error , type : false});
	})

}


// 删除标签
function tableDelete(id){
	_api.admin.tag.remove({
		"id" : id.articleId , 
	}).then(function(){
		eject.prompt({content : "删除成功" , type : false});
		setTimeout(function(){
			window.location.reload();
		})
	} , function(error){
		eject.prompt({content : error , type : false});
	})
}