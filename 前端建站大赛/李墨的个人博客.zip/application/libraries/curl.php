<?php

class Curl{
	
	static function http($option = array()){

		$curl = curl_init($option['url']);
		curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
		curl_setopt($curl, CURLOPT_HEADER, 0);//设置header

		curl_setopt($curl, CURLOPT_REFERER, isset($option['referer']) ? $option['referer'] : ""); //来源
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, isset($option['reload']) ? $option['reload'] : true);//设置自动跳转
		curl_setopt($curl, CURLOPT_POST, isset($option['method']) ? $option['method'] : 0);//post提交方式
		curl_setopt($curl, CURLOPT_POSTFIELDS, isset($option['post_data']) ? $option['post_data'] : "");
		curl_setopt($curl, CURLOPT_COOKIE, isset($option['cookie']) ? $option['cookie'] : "" );
		curl_setopt($curl, CURLOPT_COOKIEJAR, isset($option['cookie_file']) ? $option['cookie_file'] : "");
		curl_setopt ($curl, CURLOPT_COOKIEFILE, isset($option['cookie_post']) ? $option['cookie_post'] : ""); //保存cookies 发送用户浏览器信息 发送访问来源
		$result = curl_exec($curl);//运行curl
		curl_close($curl);
		return $result;
	}

}