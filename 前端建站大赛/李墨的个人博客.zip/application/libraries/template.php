<?php
class Template {


	static function image($data = array() , $default = "./static/image/image.jpg" ){
		$image_name = "";
		return "<img src='./static/upload/' />";
	}



	static function each_article_class($data){
		foreach ($data as $key => $value) {
			echo "<div class='column pcyisheng-class'><div class='class_title'><h3>{$value['name']}</h3><div class='keywords'><ul>";
			foreach ($value['keyword'] as $keyword_value) {
				echo "<li><a href='{default_tag_controller}" . Template::is_cloumn($keyword_value) . ".html' target='_blank' title='{$keyword_value['name']}'>{$keyword_value['name']}</a></li>";
			}
			echo "</ul></div><a href='{default_class_controller}" . Template::is_cloumn($value) . "' target='_blank' title='{$value['name']}' class='label label-primary fr'>更多</a></div><div class='class_content'>";
		
			if(isset($value['top_article'])){
				echo "<a href='{default_article_controller}" . $value['top_article']['article_byid'] . ".html' target='_blank' title='" . $value['top_article']['title'] . "' class='image'>
					<img  src='{cdn_url}{default_upload}" . 	Template::replace_image($value['top_article']['article_photo_name'] , 1) . "' alt='{$value['top_article']['title']}'>
					<span class='title'>{$value['top_article']['title']}</span>
				</a>";
			}
			echo "<ul class='news'>";
			foreach ($value['article'] as $article_data) {
				echo '<li><a href="{default_article_controller}' . $article_data['article_byid'] . '.html" target="_blank" title="' . $article_data['title'] . '" class="title">' . $article_data['title'] . '</a><span class="time">' . $article_data['time'] . '</span></li>';
			}
			echo "</ul></div></div>";

		}
		
	}










	/**
	 * 用于输出首页的文章详细列表
	 * @return [type] [description]
	 */
	static function each_article_list($Article_descript){
		foreach ($Article_descript as $key => $value) {
			echo "<div class='article_description'>";
			if($value['article_photo_name'] != "-1.jpg"){
				echo "<a href='{default_article_controller}{$value['article_byid']}.html' target='_blank' class='description_image' title='{$value['title']}''>
					<img src='{cdn_url}{default_upload}" . Template::replace_image($value["article_photo_name"] , 3) . "'  alt='' class='article_photo'>
				</a>";
			}

			echo "<a href='{default_article_controller}{$value['article_byid']}.html' target='_blank' title='{$value['title']}''>
					<h2 class='title'>" . $value["title"] . "</h2>
					<p class='descriptiopn'>" . str_replace(" ", "", trim($value["content"])) . "......</p>
				</a>

				<div class='bottom'>
					<ul>
						<li><i class='fa fa-clock-o'></i><span>" . $value["time"] . "</span></li>
						<li><i class='fa fa-th-list'></i><a href='{default_class_controller}{$value['form_class']['link']}' target='_blank' title='{$value['form_class']['name']}'>" . $value["form_class"]["name"] . "</a></li>
						<li><i class='fa fa-tag'></i><a href='{default_tag_controller}{$value['form_tag']['name']}.html' target='_blank' title='{$value['form_tag']['name']}'>" . $value["form_tag"]["name"] . "</a></li>
						<li class='user'><i class='fa fa-user'></i><a href='javascript:void()'>" . $value["form_user"]["username"] . "</a></li>
						" . (isset($value['read']) ? "<li class='fr'><i class='fa fa-eye '></i><span>" . @$value["read"] . "</span></li>" : "") . "
					</ul>
				</div>
			</div>";
		}
	}




	// 文章列表新闻列表
	static function each_news($data , $level = false){
		$return_data = "";$index = 0;
		foreach ($data as $key => $value) {
			$index ++;
			$level = $level ? "<span class='level'>{$index}</span>" : "";
			$return_data .= "<li>{$level}<a href='{default_article_controller}{$value['article_byid']}.html' target='_blank' title='{$value['title']}' class='title'>{$value['title']}</a><span class='time'>{$value['time']}</span></li>";
		}
		return $return_data;
	}



	// 图片展示
	static function each_image($data , $count = 2 , $image_type = 3 , $type = "src" , $Template = array(
			"header" => "<li>",
			"footer" => "</li>" ,
		)){
		$return_data = "";
		$index = 0;
		foreach ($data as $key => $value) {
			$index ++;
			if($index > $count) break;
			$value['article_photo_name'] =  self::replace_image($value['article_photo_name'] , $image_type);
			$return_data .= $Template['header'] . "<a href='{default_article_controller}{$value['article_byid']}.html' target='_blank'  title='{$value['title']}'><img {$type}='{cdn_url}{default_upload}{$value['article_photo_name']}' alt='{$value['title']}'><span class='title'>{$value['title']}</span></a>" .  $Template['footer'];
		}
		return $return_data;
	}
	
	
	static function each_tags($data , $Template = array(
			"header" => "<span class='label label-default'>",
			"footer" => "</span>"
		)){
		$return_data = "";
		foreach ($data as $key => $value) {
			$return_data .= $Template['header'] . "<a href='{default_tag_controller}{$value['name']}.html' target='_blank' title='{$value['name']}'>{$value['name']}</a>" .  $Template['footer'];
		}
		return $return_data;
	}


	/*--------------------------------------<公共方法分割线>------------------------------------------------*/
	/** 用来检测某标签或分类是否设定了单独栏目 */
	static function is_cloumn($data){
		return isset($data['link']) && $data['link'] !== "" ? $data['link'] : $data['name'];
	}

	/** 这个函数用来更换文章图片的缩略图图片 */
	static function replace_image($url , $image_type){
		return $image_type . "_" . str_replace(".jpg" , "" , $url) . "_thumb.jpg";
	}

	
}