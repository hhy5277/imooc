<?php
class CONST_ERROR_FILE{

	const SERVER_ERROR = "服务器在处理请求中遇到了无法预料到的错误！";


	const ADMIN_USER_LOGIN_USERNAME_NULL = "您输入的用户名不存在，请检查后再输入";
	const ADMIN_USER_LOGIN_PASSWORD_ERROR = "您输入的密码错误，请检查后再输入";
}