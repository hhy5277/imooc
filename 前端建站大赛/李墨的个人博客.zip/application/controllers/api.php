<?php
/**
 * 前台首页控制器
 * date : 2015年10月15日 16:07:43
 */
defined('BASEPATH') OR exit('No direct script access allowed');
include_once(APPPATH . "controllers\Bin\Base_user.php");
class Api extends Base_user {
	public function __construct(){
		parent::__construct();
		$this->load->model("Article_model");
		$this->load->model("Article_content_model");
	}

	public function get_data(){
		$params = parent::get_params(array('class_id' , 'page') , 'POST');
		extract($params);
		if( ! $this->Class_model->is_exist(array("id" => $class_id))) $this->end(false);
		$article_data = $this->Article_model->get_list_home(array('form_class' => intval($class_id)) , $page , 10);
		if(isset($article_data[0]['title'])) exit(json_encode($article_data , true));
		$this->end(false);
	}

	public function Article_browse(){
		$params = parent::get_params(array('byid') , 'POST');
		extract($params);
		if( ! $this->Article_model->is_exist(array("article_byid" => $byid))) show_404();
		$Article_data = $this->Article_model->get(array("article_byid" => $byid));

		// browse value
		if(!isset($_SESSION[$byid])){
			$_SESSION[$byid] = true;
			$this->Article_model->edit(array("id" => $Article_data['id']) , array("hot" => $Article_data['hot'] + 0.2));
		}else{
			$this->Article_model->edit(array("id" => $Article_data['id']) , array("hot" => $Article_data['hot'] + 0.05));
		}
		$Article_content_data = $this->Article_content_model->get(array("from_article" => $Article_data['id']));


		$this->Article_content_model->edit(array("id" => $Article_content_data['id']) , array("article_read" => $Article_content_data['article_read'] + 1));
		$Article_content_data['article_read'] = $Article_content_data['article_read'] + 1;
		parent::end(TRUE , json_encode(array(
			'byid' => $byid,
			"read" => $Article_content_data['article_read'],
			"link" => $Article_content_data['article_link'],
		)));
		
	}
}