<?php

defined('BASEPATH') OR exit('No direct script access allowed');
include_once(APPPATH . "controllers\Bin\Base_user.php");
class Home extends Base_user {

	public function __construct(){
		parent::__construct();
	}
	public function Css(){
		$this->load->helper('file');
		foreach ($_GET as $key => $value) {
			$key = str_replace("_" , "." , $key);
			echo read_file(dirname(APPPATH) . "/static/css/{$key}") . "\r\n";
		}
	}

}