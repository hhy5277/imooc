<?php

// 标签管理系统
defined('BASEPATH') OR exit('No direct script access allowed');
include_once(APPPATH . "controllers\Bin\Base_admin.php");
class Tag extends Base_admin{
	public function __construct(){
		parent::__construct();
		$this->load->model("Tag_model");
		$this->load->model("Class_model");
	}

	public function index(){
		if(parent::is_login()) return false;
		$page = !isset($_GET['page']) ? 1 : $this->input->get("page");
		$Tag_list = $this->Tag_model->get_list(array() , $page , 10);
		foreach ($Tag_list as &$value) {
			$value['class'] = $this->Class_model->get(array("id" => $value['father_class']));
		}
		parent::view_load(array("template/header","tag/Tag_list") , array(
			"Tag_list" => $Tag_list , 
			"Tag_count" => $this->Tag_model->get_count(array())
		));
	}

	public function create(){
		if(parent::is_login()) return false;
		parent::view_load(array("template/header","tag/Tag_create"));
	}

	public function edit(){
		if(parent::is_login()) return false;
		$params = parent::get_params(array("id") , "GET");
		if(!$this->Tag_model->is_exist(array("id" => $params['id']))) {
			parent::view_load(array(
				"template/header" , 
				"template/top_header" , 
				"template/left_nav" , 
				"template/footer" , 
			) , array(
				"active" => 1
			));
			echo '
				<base href="' . base_url() . '">
				<script src="static/js/jquery-2.1.4.min.js"></script>
				<script src="static/js/admin/base.js"></script>
				<script src="static/js/admin/api.js"></script>
				<script>
					var reList = function(){
						window.location.href=".' . dirname($_SERVER['PATH_INFO']) . '"
					}
					$(document).ready(function(){
						eject.sure({
							type : false , 
							content : "很抱歉，您要编辑的这个标签不存在<br>所以该标签无法编辑，请点击下方的的确认按钮后返回文章列表	",
							functionName : "reList()"
						});
						$(".window").on("click" , "#close" , function(){
							reList();
						});
					})
				</script>';
			return false;
		}
		parent::view_load(array("template/header","tag/Tag_edit") , array(
			'Tag_data' => $this->Tag_model->get(array('id' => $params['id']))
		));
	}
}