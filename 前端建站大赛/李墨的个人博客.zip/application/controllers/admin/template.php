<?php

// 模板系统
defined('BASEPATH') OR exit('No direct script access allowed');
include_once(APPPATH . "controllers\Bin\Base_admin.php");
class Template extends Base_admin{
	public function __construct(){
		parent::__construct();
	}

	public function index(){
		if(parent::is_login()) return false;
		

		parent::view_load(array("template/header","Template"));
	}


}