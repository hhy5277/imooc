<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once(APPPATH . "controllers/Bin/Base_admin.php");
class Class_admin extends base_admin{

	public function __construct(){
		parent::__construct();
		if(!$this->input->is_ajax_request()) $this->end(false, '非法请求');
		$this->load->model("Class_model");
		$this->load->model("Tag_model");
	}
	

	/**
	 * 对某栏目进行导航置顶操作
	 * @param $id
	 * @return [type] [description]
	 */
	public function bar(){
		if(parent::is_login(false)) parent::end("未登录"  , false);
		$params = parent::get_params(array("id") , "POST");
		extract($params);
		if( ! $this->Class_model->is_exist(array("id" => $id))) parent::end("没有找到分类无法进行操作" , false);
		$class_data = $this->Class_model->get(array("id" => $id));
		$type = $class_data['type'] == 1 ? 0 : 1;
		$this->Class_model->edit(array("id" => $id) , array("type" => $type));
		parent::end();
	}

	/**
	 * 对指定栏目进行普通置顶操作
	 * @param  $[id] [<class id>]
	 * @return [type] [description]
	 */
	public function list_top(){
		if(parent::is_login(false)) parent::end("未登录"  , false);
		$params = parent::get_params(array("id") , "POST");
		extract($params);
		if( ! $this->Class_model->is_exist(array("id" => $id))) parent::end("没有找到分类无法进行操作" , false);
		$class_data = $this->Class_model->get(array("id" => $id));
		$this->Class_model->edit(array("id" => $id) , array("type" => $class_data['type'] == 2 ? 0 : 2));
		parent::end();
	}




	public function edit(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("id" , "title" , "description" , "key" , "link" , "icon" , "fuTitle") , "POST");
		extract($params);
		parent::is_length(array(
			array("name" => "分类标题" , "value" => $title , "min" => 2 , "max" => 80),
			array("name" => "分类描述" , "value" => $description , "min" => 10 , "max" => 200),
			array("name" => "关键词" , "value" => $key , "isNull" => false),
			array("name" => "分类链接" , "value" => $link , "min" => 10 , "max" => 50),
			array("name" => "图标" , "value" => $icon , "min" => 2 , "max" => 50),
			array("name" => "副标题" , "value" => $fuTitle , "min" => 2 , "max" => 100),
		));

		$title = htmlspecialchars($title);
		$description = htmlspecialchars($description);
		$link = htmlspecialchars($link);

		// 检测文章关键词
		if(json_decode($key , true) == NULL) parent::end(false , "您输入的关键词异常");
		$key = json_decode($key);
		if(count($key) < 2) parent::end(false , "您至少输入两个关键词");
		if(count($key) > 7) parent::end(false , "您最多只能输入七个个关键词");

		foreach ($key as $value) {
			$value = htmlspecialchars($value);
		}

		$this->Class_model->edit(array("id" => $id) , array(
			"name" => $title , 
			"description" => $description , 
			"link" => $link , 
			"icon" => $icon , 
			"vice_title" => $fuTitle , 
			"class_key" => json_encode($key)
		));
		parent::end(true);
	}

	public function remove(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("article_id") , "POST");
		extract($params);
		if( ! $this->Class_model->is_exist(array("id" => $article_id))) parent::end(false , "您欲删除的分类不存在");
		if($this->Class_model->remove(array("id" => $article_id))){
			parent::end(true);
		}else{
			parent::end(false , "服务器异常");
		}	
	}

	public function create(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("title" , "description" , "key" , "link" , "icon" , "fuTitle") , "POST");
		extract($params);
		parent::is_length(array(
			array("name" => "分类标题" , "value" => $title , "min" => 2 , "max" => 80),
			array("name" => "分类描述" , "value" => $description , "min" => 10 , "max" => 200),
			array("name" => "关键词" , "value" => $key , "isNull" => false),
			array("name" => "分类链接" , "value" => $link , "min" => 10 , "max" => 50),
			array("name" => "图标" , "value" => $icon , "min" => 2 , "max" => 50),
			array("name" => "副标题" , "value" => $link , "min" => 2 , "max" => 100),
		));

		$title = htmlspecialchars($title);
		$description = htmlspecialchars($description);
		$link = htmlspecialchars($link);

		// 检测文章关键词
		if(json_decode($key , true) == NULL) parent::end(false , "您输入的关键词异常");
		$key = json_decode($key);
		if(count($key) < 1) parent::end(false , "您至少输入一个关键词");
		if(count($key) > 7) parent::end(false , "您最多只能输入七个个关键词");

		foreach ($key as $value) {
			$value = htmlspecialchars($value);
		}

		if($this->Class_model->is_exist(array("name" => $title))) parent::end(false , "您欲添加的分类已经存在了");
		$this->Class_model->create(array(
			"name" => $title , 
			"description" => $description , 
			"link" => $link , 
			"icon" => $icon , 
			"vice_title" => $fuTitle , 
			"class_key" => json_encode($key)
		));
		parent::end(true);
	}

}