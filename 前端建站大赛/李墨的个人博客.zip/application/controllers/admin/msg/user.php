<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once(APPPATH . "controllers/Bin/Base_admin.php");
class User extends base_admin{

	public function __construct(){
		parent::__construct();
		if(!$this->input->is_ajax_request()) $this->end(false, '非法请求');
	}

	public function login(){
		sleep(1);
		$params = parent::get_params(array("username" , "password") , "POST");
		extract($params);
		parent::is_length(array(
			array("name" => "用户名" , "value" => $username , "max" => 16 , "min" => 6),
			array("name" => "密码" , "value" => $password , "max" => 16 , "min" => 6)
		));
		$user_login_data = $this->admin_user_model->login(array(
			"username" => $username,
			"password" => $password
		));
		switch ($user_login_data) {
			case -1:parent::end(FALSE , CONST_ERROR_FILE::ADMIN_USER_LOGIN_USERNAME_NULL);break;
			case -2:parent::end(FALSE , CONST_ERROR_FILE::ADMIN_USER_LOGIN_PASSWORD_ERROR);break;
			default:$_SESSION['admin_user'] = $user_login_data;parent::end(TRUE);break;
		}
	}
}