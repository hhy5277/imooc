<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once(APPPATH . "controllers/Bin/Base_admin.php");
class Article extends base_admin{

	public function __construct(){
		parent::__construct();
		if(!$this->input->is_ajax_request()) $this->end(false, '非法请求');
		$this->load->model("Key_model");
		$this->load->model("Tag_model");
		$this->load->model("Class_model");
		$this->load->model("Article_model");
		$this->load->model("Article_content_model");
	}

	public function upTop(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("article_id") , "POST");
		extract($params);
		if( ! $this->Article_model->is_exist(array("id" => $article_id))) parent::end(false , "您欲操作的文章不存在");
		$this->Article_model->edit(array("article_type" => "999") , array("article_type" => "0"));
		if($this->Article_model->edit(array("id" => $article_id) , array("article_type" => "999"))){
			parent::end(true);
		}else{
			parent::end(false , "服务器异常");
		}
	}

	/** 
	 * 删除文章的封面图片
	 * @param article_id
	 * @return bool
	 */
	public function removeCover($article_id = ""){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("article_id") , "POST");
		extract($params);
		$article_data = $this->Article_model->get(array("id" => $article_id));
		if( ! isset($article_data['article_byid'])) parent::end(false);
		
		// remove pretreatment (cover)
		$this->removeCover_bin($article_data);

		// edit article data
		$this->Article_model->edit(array("id" => $article_id) , array("article_photo_name" => "-1.jpg"));
		parent::end(true);
	}


	/**
	 * 删除指定的文章，需删除下属图片、内容、评论
	 * @return [type] [description]
	 */
	public function remove(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("article_id") , "POST");
		extract($params);
		if( ! $this->Article_model->is_exist(array("id" => $article_id))) parent::end(false , "您欲删除的文章不存在");
		if($this->Article_model->remove(array("id" => $article_id))){
			$this->removeCover_bin($this->Article_model->get(array("id" => $article_id)));
			$this->Article_content_model->remove(array("from_article" => $article_id));
			$this->Key_model->remove(array("from_article" => $article_id));
			parent::end(true);
		}else{
			parent::end(false , "服务器异常");
		}
	}




	public function check(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("article_id") , "POST");
		extract($params);
		if( ! $this->Article_model->is_exist(array("id" => $article_id , "article_type" => "-1"))) parent::end(false , "您欲通过审核的文章不存在");
		$this->Article_model->edit(array("id" => $article_id) , array("article_type" => "0"));
		parent::end(true);
	}




	public function edit(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("article_byid" , "article_title" , "editorValue" , "article_tag" , "article_source" , "article_key" , "article_option" , "article_class") , "POST");
		extract($params);
		parent::is_length(array(
			array("name" => "文章标题" , "value" => $article_title , "min" => 10 , "max" => 140),
			array("name" => "文章内容" , "value" => $editorValue , "min" => 80),
			array("name" => "关键词" , "value" => $article_key , "isNull" => false),
		));
		$article_title = htmlspecialchars($article_title);
		$article_class = htmlspecialchars($article_class);
		$article_tag = htmlspecialchars($article_tag);

		// 检测文章关键词
		if(json_decode($article_key , true) == NULL) parent::end(false , "您输入的关键词异常");
		$article_key = json_decode($article_key);
		if(count($article_key) < 3) parent::end(false , "您至少输入三个关键词");
		if(count($article_key) > 7) parent::end(false , "您最多只能输入七个个关键词");
		
		// is_exist class
		if(!$this->Class_model->is_exist(array("name" => $article_class))) parent::end(false , "您欲加入的分类不存在，您可以添加分类");
		$class_data = $this->Class_model->get(array("name" => $article_class));

		// is_exist tag
		if(!$this->Tag_model->is_exist(array("name" => $article_tag))) parent::end(false , "您欲加入的分类不存在，您可以添加分类");
		$tag_data = $this->Tag_model->get(array("name" => $article_tag));

		// 处理置顶事件
		$article_option = json_decode($article_option , true);
		if(isset($article_option['top']) && $article_option['top']){
			$article_type = 1;
			$article_data = $this->Article_model->get(array("article_type" => "1" , "form_class" => $class_data['id']));
			$article_data_option = json_decode($article_data['article_option'] , true);
			$article_data_option['top'] = false;
			if(count($article_data) > 0) $this->Article_model->edit(array(
				"id" => $article_data['id']
			) , array(
				"article_type" => "0" , 
				"article_option" => json_encode($article_data_option)
			));
		}else{
			$article_type = -1;
		}

		// 处理编辑
		// $son_tag_temp = array();
		// $son_tag = json_decode($class_data['son_tag'] , true);
		// foreach ($son_tag as $value) {
		// 	if($value !== $class_data['id']){
		// 		$son_tag_temp[] = $class_data['id'];
		// 	}
		// }
		// $son_tag = json_encode($son_tag_temp);
		// $article_data = $this->Article_model->get(array("article_byid" => $article_byid));
		// $this->Class_model->edit(array("id" => $article_data['form_class']) , array("son_tag" => $son_tag));

		

		// 处理文章关键词与标签的关系
		foreach ($article_key as $value) {
			$value = htmlspecialchars($value);
			$where = array("name" => $value);
			if($this->Key_model->is_exist($where)){
				$this->Key_model->edit($where , array() , $tag_data['id']);
			}else{
				$this->Key_model->create(array("name" => $value , "fatcher_tag" => "[\"{$tag_data['id']}\"]"));
			}
			$key_data = $this->Key_model->get($where);
			$this->Tag_model->push_key($tag_data['id'] , $key_data['id']);
		}


		// 处理标签与分类的关系
		$this->Class_model->push_tag($class_data['id'] , $tag_data['id']);
		$this->Tag_model->edit(array('id' => $tag_data['id']) , array("father_class" => $class_data['id']));


		// 处理相关设置
		$article_option_temp = array();
		$option_need = array("release" , "comment" , "anonymous" , "grab" , "cover" , "top");
		foreach ($option_need as $value) {
			$article_option_temp[$value] = array_key_exists($value, $article_option) === false ? false : $article_option[$value];
		}
		$article_option = json_encode($article_option_temp);


		// 处理文章内容
		$this->load->helper('typography');
		$article_content = $editorValue;
		$article_content = auto_typography($article_content);
		$article_content = $this->security->xss_clean($article_content);
		// preg_match_all('/<pre class="brush:(.*);toolbar:(.*);">/U', $article_content , $array);
		// if(count($array[0]) > 0){
		// 	foreach ($array[1] as $key => $value) {
		// 		$str_replace_data[] = '<pre class="brush:' .$value . ';toolbar:false;"><code class="' . $value . '">';
		// 		$value = array();
		// 	}
		// 	$array[0] = array_unique($array[0]);
		// 	$str_replace_data = array_unique($str_replace_data);
		// 	$article_content = str_replace($array[0] , $str_replace_data , $article_content );
		// 	$article_content = str_replace("</pre>" , "</code></pre>" , $article_content );
		// }


		$this->load->library("Template");
		// $article_content = Template::compress_html($article_content);
		$article_content = str_replace('<p><br/></p>' , '<br/>' , $article_content );

		
		$article_data = $this->Article_model->get(array("article_byid" => $article_byid));
		if(count($_FILES) > 0){
			$article_data['article_photo_name'] = $article_data['article_photo_name'] === "-1.jpg" ? "2016" . parent::rands(14).".jpg" : $article_data['article_photo_name'];
			$photo = parent::upload_photo(str_replace(".jpg", "", $article_data['article_photo_name']) , "article_browse");
			if($photo === false) parent::end(false , "无法上传照片到服务器！");
		}else{
			$photo['file_name'] = $article_data['article_photo_name'];
		}


		$this->Article_model->edit(array("article_byid" => $article_byid) , array(
			"title" => $article_title,
			"form_class" => $class_data['id'],
			"form_tag" => $tag_data['id'],
			"article_source" => $article_source,
			"article_key" => json_encode($article_key),
			"article_option" => $article_option,
			"article_type" => $article_type,
			"article_photo_name" => $photo['file_name'],
		));

		$article_id = $this->Article_model->get(array("article_byid" => $article_byid));
		$this->Article_content_model->edit(array("from_article" => $article_id['id']) , array(
			"article_content" => $article_content,
		));

		parent::end(true);
	}








	public function create(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("article_title" , "editorValue" , "article_tag" , "article_source" , "article_key" , "article_option" , "article_class") , "POST");
		extract($params);
		parent::is_length(array(
			array("name" => "文章标题" , "value" => $article_title , "min" => 10 , "max" => 140),
			array("name" => "文章内容" , "value" => $editorValue , "min" => 80),
			array("name" => "关键词" , "value" => $article_key , "isNull" => false),
		));

		if($this->Article_model->is_exist(array("title" => $article_title))) parent::end(false , "您欲添加的文章已经存在了");
		$article_byid = date("Ymd") . parent::rands(8);
		$article_title = htmlspecialchars($article_title);
		$article_class = htmlspecialchars($article_class);
		$article_tag = htmlspecialchars($article_tag);

		// 检测文章关键词
		if(json_decode($article_key , true) == NULL) parent::end(false , "您输入的关键词异常");
		$article_key = json_decode($article_key);
		if(count($article_key) < 3) parent::end(false , "您至少输入三个关键词");
		if(count($article_key) > 7) parent::end(false , "您最多只能输入七个个关键词");

		// is_exist class
		if(!$this->Class_model->is_exist(array("name" => $article_class))) parent::end(false , "您欲加入的分类不存在，您可以添加分类");
		$class_data = $this->Class_model->get(array("name" => $article_class));

		// is_exist tag
		if(!$this->Tag_model->is_exist(array("name" => $article_tag))) parent::end(false , "您欲加入的分类不存在，您可以添加分类");
		$tag_data = $this->Tag_model->get(array("name" => $article_tag));


		// 处理置顶事件
		$article_option = json_decode($article_option , true);
		if(isset($article_option['top']) && $article_option['top']){
			$article_type = 1;
			$article_data = $this->Article_model->get(array("article_type" => "1" , "form_class" => $class_data['id']));
			$article_data_option = json_decode($article_data['article_option'] , true);
			$article_data_option['top'] = false;

			if(count($article_data) > 0) $this->Article_model->edit(array(
				"id" => $article_data['id']
			) , array(
				"article_type" => "0" , 
				"article_option" => json_encode($article_data_option)
			));
		}else{
			$article_type = -1;
		}





		// 处理标签与分类的关系
		$this->Class_model->push_tag($class_data['id'] , $tag_data['id']);
		$this->Tag_model->edit(array('id' => $tag_data['id']) , array("father_class" => $class_data['id']));


		// 处理相关设置
		$article_option_temp = array();
		$option_need = array("release" , "comment" , "anonymous" , "grab" , "cover" , "top");
		foreach ($option_need as $value) {
			$article_option_temp[$value] = array_key_exists($value, $article_option) === false ? false : $article_option[$value];
		}
		$article_option = json_encode($article_option_temp);


		// 处理文章内容
		$this->load->helper('typography');
		$article_content = $editorValue;
		$article_content = auto_typography($article_content);
		$article_content = $this->security->xss_clean($article_content);

		// preg_match_all('/<pre class="brush:(.*);toolbar:(.*);">/U', $article_content , $array);
		// if(count($array[0]) > 0){
		// 	foreach ($array[1] as $key => $value) {
		// 		$str_replace_data[] = '<pre class="brush:' .$value . ';toolbar:false;"><code class="' . $value . '">';
		// 		$value = array();
		// 	}
		// 	$array[0] = array_unique($array[0]);
		// 	$str_replace_data = array_unique($str_replace_data);
		// 	$article_content = str_replace($array[0] , $str_replace_data , $article_content );
		// 	$article_content = str_replace("</pre>" , "</code></pre>" , $article_content );
		// }




		// 上传图片
		if(count($_FILES) > 0){
			$photo = parent::upload_photo(parent::rands(32) , "article_browse");
			if($photo === false){
				parent::end(false , "无法上传照片到服务器！");
			}
		}else{
			$photo['file_name'] = "-1.jpg";
		}



		$insert = $this->Article_model->create(array(
			"title" => $article_title,
			"article_byid" => $article_byid,
			"time" => time(),
			"form_user" => $_SESSION['admin_user']['id'],
			"form_class" => $class_data['id'],
			"form_tag" => $tag_data['id'],
			"article_source" => $article_source,
			"article_photo_name" => $photo['file_name'],
			"article_key" => json_encode($article_key),
			"article_option" => $article_option,
			"article_type" => $article_type,
		));
		$this->Article_content_model->create(array(
			"from_article" => $insert,
			"article_content" => $editorValue,
		));
		
		// 处理文章关键词与标签的关系
		foreach ($article_key as $value) {
			$value = htmlspecialchars($value);
			$where = array("name" => $value);
			if($this->Key_model->is_exist($where)){
				$this->Key_model->edit($where , array() , $tag_data['id']);
			}else{
				$this->Key_model->create(array("name" => $value , "father_article" =>  $insert, "fatcher_tag" => "[\"{$tag_data['id']}\"]"));
			}
			$key_data = $this->Key_model->get($where);
			$this->Tag_model->push_key($tag_data['id'] , $key_data['id']);
		}

		parent::end(true);
	}






	// ========================【私有函数】=========================
	private function removeCover_bin($article_data){
		$this->load->helper('file');
		@unlink($this->config->item('default_upload') . "/" . $article_data['article_photo_name']);
		$image_config = $this->config->item("image_lib_size");
		for ($index = 0;$index < count($image_config); $index++) { 
			@unlink($this->config->item('default_upload') . "/{$index}_" . str_replace(".jpg" , "_thumb.jpg" , $article_data['article_photo_name']));
		}
	} 

	private function Article_upload(){

	}







}






