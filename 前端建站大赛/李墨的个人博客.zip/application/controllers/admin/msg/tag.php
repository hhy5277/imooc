<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once(APPPATH . "controllers/Bin/Base_admin.php");
class Tag extends base_admin{

	public function __construct(){
		parent::__construct();
		if(!$this->input->is_ajax_request()) $this->end(false, '非法请求');
		$this->load->model("Tag_model");
	}

	public function edit(){
		$params = parent::get_params(array("title" , "id") , "POST");
		$link = $this->input->post("link");
		$description = $this->input->post("description");
		extract($params);
		parent::is_length(array(
			array("name" => "标签名称" , "value" => $title , "min" => 2 , "max" => 20),
			array("name" => "标签描述" , "value" => $description , "is_null" => true , "min" => 2 , "max" => 140),
		));
		$title = htmlspecialchars($title);
		$description = htmlspecialchars($description);
		$link = htmlspecialchars($link);
		if( ! $this->Tag_model->is_exist(array("name" => $title))) parent::end(false , "标签不存在无法编辑该标签");

		$this->Tag_model->edit(array('id' => $id) , array(
			'name' => $title,
			'link' => $link , 
			'description' => $description
		));
		parent::end(true , $id);
	}

	public function create(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("title") , "POST");
		$link = $this->input->post("link");
		$description = $this->input->post("description");
		extract($params);
		parent::is_length(array(
			array("name" => "标签名称" , "value" => $title , "min" => 2 , "max" => 20),
			array("name" => "标签描述" , "value" => $description , "is_null" => true , "min" => 2 , "max" => 140),
		));
		$title = htmlspecialchars($title);
		$description = htmlspecialchars($description);
		$link = htmlspecialchars($link);
		if($this->Tag_model->is_exist(array("name" => $title))) parent::end(false , "这个标签已经存在了，请勿重复创建");

		$id = $this->Tag_model->create(array(
			"name" => $title , 
			"description" => $description , 
			"link" => $link
		));
		parent::end(true , $id);
	}

	public function remove(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("id") , "POST");
		extract($params);
		$this->Tag_model->remove(array("id" => $id));
		parent::end();
	}

}