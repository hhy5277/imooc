<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once(APPPATH . "controllers/Bin/Base_admin.php");
class Friendship_link extends base_admin{

	public function __construct(){
		parent::__construct();
		if(!$this->input->is_ajax_request()) $this->end(false, '非法请求');
		$this->load->model("Tag_model");
		$this->load->model("Friendship_link_model");
	}

	public function create(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("title" , "link" , "priority") , "POST");
		extract($params);
		$title = htmlspecialchars($title);
		$link = htmlspecialchars($link);
		if($this->Friendship_link_model->is_exist(array("name" => $title))) parent::end(false , "这个链接已经存在了，请勿重复创建");
		$id = $this->Friendship_link_model->create(array(
			"name" => $title , 
			"link" => $link , 
			"priority" => $priority,
			"type" => '0'
		));
		parent::end(true , $id);
	}

	public function edit(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("title" , "link" , "priority" , 'id') , "POST");
		extract($params);
		$title = htmlspecialchars($title);
		$link = htmlspecialchars($link);
		$id = $this->Friendship_link_model->edit(array('id' => $id) , array(
			"name" => $title , 
			"link" => $link , 
			"priority" => $priority,
			"type" => '0'
		));
		parent::end(true , $id);
	}

	public function remove(){
		if(parent::is_login(false)) parent::end("未登录" , false);
		$params = parent::get_params(array("id") , "POST");
		extract($params);
		if($this->Friendship_link_model->remove(array('id' => $id))){
			parent::end(true);
		}else{
			parent::end(false , "未知的服务器错误！");
		}

	}

}
