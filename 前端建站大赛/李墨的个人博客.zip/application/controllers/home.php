<?php
/**
 * 前台首页控制器
 * date : 2015年10月15日 16:07:43
 */
defined('BASEPATH') OR exit('No direct script access allowed');
include_once(APPPATH . "controllers\Bin\Base_user.php");
class Home extends Base_user {
	public function __construct(){
		parent::__construct();
		$this->load->model("Article_model");
		$this->load->model("Article_content_model");
		$this->load->model("Class_model");
		$this->load->model("Tag_model");
		$this->load->model("Key_model");
		$this->load->model("Admin_user_model");
		$this->load->model("Friendship_link_model");
		// $this->output->cache(2);
// 	if($this->agent->is_mobile()){
// 		exit('<meta name="viewport" content="user-scalable=no, width=device-width" />  
// <link rel="stylesheet" href="./static/bin/css/font-awesome.min.css"><i class="fa fa-refresh fa-spin"></i> sorry 本站暂时没有适配手机，请移驾电脑端访问本页面。站长正在努力中!! 2016.2.13 2:18');
// 		return false;		
// 	}
		$this->not_article = array();
		$this->not_article_temp = array();
		$this->load->library("Template");
	}

	public function about(){
		$data['Class_list'] = $this->Class_model->get_list();
		$data['title'] = "李墨的个人简历 - 专注分享最有用WEB前端知识，最前沿的WEB前端技术，最好玩WEB前端资讯的博客";

		parent::view_load(array("template/header","About") , $data);
	}

	public function works(){
		$data['Class_list'] = $this->Class_model->get_list();
		$data['Class_data'] = $this->Class_model->get(array('name' => 'Works'));
		if( ! isset($data['Class_data']['name'])) show_404();
		$data['title'] = "博主作品集 - 专注分享最有用WEB前端知识，最前沿的WEB前端技术，最好玩WEB前端资讯的博客";

		parent::view_load(array("template/header","works/home") , $data);
	}


	public function talk(){
		$data['Class_list'] = $this->Class_model->get_list();

		parent::view_load(array("template/header","talk/home") , $data);
	}



	/* 用来操纵默认CLASS pcyisheng.com/xxxx */
	public function controller_class($link){
		$Class_data = $this->Class_model->get(array("link" => $link));
		if( ! isset($Class_data['name'])) show_404();
		$this->class_("{$link}.html");
	}



	public function index(){
		$index_data['Friendship_link_list'] = $this->Friendship_link_model->get_list(array() , 0 , 0 , array() , 'all');
		$index_data['Class_list'] = $this->Class_model->get_list();
		$index_data['title'] = "李墨 - 专注分享最有用WEB前端知识，最前沿的WEB前端技术，最好玩WEB前端资讯的博客";
		$index_data['page'] = isset($_GET['page']) && $_GET['page'] > 0 ? $this->input->get('page') : 1;
		if(isset($_GET['search']) || $this->input->get('search') != ""){
			$key = $this->input->get('search');
			$index_data['Article_list'] = $this->Article_model->get_list_new(array() , 1 , 10 , array() , array(
				"is_ok" => false ,
				"search" => false ,
				"search_data" => array(
					'title' => $key,
				)
			) );
			$index_data['max_page'] = $index_data['Article_list']['count'];
			parent::view_load(array("template/header","Search") , $index_data);
		}else{
			$index_data['Article_list'] = $this->Article_model->get_list_new("article_type != -1" , 1 , 10 , array() , array("is_ok" => false) );
			$index_data['max_page'] = $this->Article_model->get_count("article_type != -1");
			parent::view_load(array("template/header","Home") , $index_data);
		}
	}



	private function not($article){
		foreach ($article as $value) {
			$this->not_article[] = $value['id'];
			$this->not_article_temp[] = array("id !=" => $value['id']);
		}
		return "`id` != " . implode(" and `id` != ", array_unique($this->not_article)) . " and article_type != -1";
	}




	public function tag($name){
		$model_type = "tag";
		$name = trim(urldecode(str_replace(".html", "", $name)));
		if( ! isset($name) || $name == "") show_404();
		$Tag_data = $this->Tag_model->get("`link` = '{$name}' or `name` = '{$name}'");
		if( ! count($Tag_data)){
			$Tag_data = $this->Key_model->get(array("name" => $name));
			$model_type = "keyword";
		}
		if( ! isset($Tag_data['name'])) show_404();




		// not update down|
		$data['Tag_data'] = $Tag_data; 
		$data['title'] = $Tag_data['name'] . " - 专注分享最有用WEB前端知识，最前沿的WEB前端技术，最好玩WEB前端资讯的博客";
		$data['description'] = $Tag_data['description'] === "" ? $Tag_data['name'] : $Tag_data['description'];
		$data['keyword'] = $Tag_data['name'];
		$data['Class_list'] = $this->Class_model->get_list();
		$data['page'] = isset($_GET['page']) && $_GET['page'] > 0 ? $this->input->get('page') : 1;

		if($model_type == "tag"){
			$data['Tag_data']['class_data'] = $this->Class_model->get(array('id' => $data['Tag_data']['father_class'])); 
			parent::view_load(array("template/header","Tag") , array_merge($data , array(
				"Article_list" => $this->Article_model->get_list(array("form_tag" => $Tag_data['id']) , 1 , 10 , array() , "Not all" , TRUE) ,
				"max_page" => $this->Article_model->get_count(array("form_tag" => $Tag_data['id'])) , 
			)));
		}else{
			$data['Article_list'] = $this->Article_model->get_list(array("id" => $Tag_data['father_article']) , 1 , 9);
			$data['max_page'] = 1;
			if(count($data['Article_list']) <= 0) show_404();
			parent::view_load(array("template/header","Tag") , $data);
		}
	}
	
	public function class_($name){

		$name = urldecode(htmlspecialchars(str_replace('.html' , '' , $name)));
		$Class_visit_type = $this->Class_model->is_exist(array('name' => $name)) ? 0 : ($this->Class_model->is_exist(array('link' => $name)) ? 1 : -1);
		if($Class_visit_type === -1) show_404();
		$Class_data = $this->Class_model->get(array(($Class_visit_type === 0 ? 'name' : 'link') => $name));


		// for class son tag
		$Class_son_tag = json_decode($Class_data['son_tag'] , TRUE);
		$Class_data['son_tag'] = array();
		foreach (array_unique($Class_son_tag) as &$tag_data) {
			$tag_data_temp = $this->Tag_model->get(array('id' => $tag_data));
			$tag_data_temp['article_count'] = $this->Article_model->get_count(array('form_tag' => $tag_data_temp['id']));
			$Class_data['son_tag'][] = $tag_data_temp;
		}

		$page = isset($_GET['page']) && $_GET['page'] > 0 ? $this->input->get('page') : 1;
		$Article_list = $this->Article_model->get_list(array("form_class" => $Class_data['id'] , "article_type !=" => -1) , $page , 10 , array() , "Not all" , TRUE);
		$Article_count = $this->Article_model->get_count(array("form_class" => $Class_data['id'] , "article_type !=" => -1));




		parent::view_load(array("template/header","Class") , array(
			"Class_data" => $Class_data ,
			"Article_list" => $Article_list,
			"max_page" => $Article_count,
			'Class_list' => $this->Class_model->get_list(),
			"page" => $page,

			"title" => $Class_data['name'] . ($Class_data['vice_title'] === "" ? " - 专注分享最有用WEB前端知识，最前沿的WEB前端技术，最好玩WEB前端资讯的博客" : $Class_data['vice_title']),
			"description" => $Class_data['description'],
			"keyword" => implode(json_decode($Class_data['class_key']) , ",")
		) ,  $Class_data['id']);

	}

	public function article($byid){
		// 处理传递过来的数据
		$byid = explode("_", $byid);
		if(count($byid) > 2 || count($byid) < 1) show_404();
		if(count($byid) <= 1) $page = 1;
		if(count($byid) > 1 && count($byid) === 2){
			if($byid[1] == "" || !is_numeric($byid[1])) show_404();
			$page = $byid[1]; 
		}


		$byid = htmlspecialchars($byid[0]);
		// is not article
		if(!$this->Article_model->is_exist(array("article_byid" => $byid))) show_404();

		$Article_data = $this->Article_model->get(array("article_byid" => $byid));
		$Article_data['form_tag'] = $this->Tag_model->get(array("id" => $Article_data['form_tag']));
		$Article_data['form_class'] = $this->Class_model->get(array("id" => $Article_data['form_class']));
		$Article_data['form_user'] = $this->Admin_user_model->get(array("id" => $Article_data['form_user']));
		$Article_data['time_'] = $Article_data['time'];
		$Article_data['time'] = $this->Article_model->time_interval($Article_data['time']);

		// Hot article list
		$hot_article = $this->Article_model->hot_list(array() , 1 , 10 , array() , "Not all" , true);

		$tag_list = $this->Tag_model->get_list(array() , 1 , 41);
		$class_article_list = $this->Article_model->get_random(array("form_class" => $Article_data['form_class']['id'] , "article_type" => "0"  , "article_photo_name !=" => "-1.jpg") , 1 , 7);
		$tag_article_list = $this->Article_model->get_random(array("form_tag" => $Article_data['form_tag']['id'] , "article_type" => "0"  , "article_photo_name !=" => "-1.jpg") , 1 , 7);


		$Article_content_data = $this->Article_content_model->get(array("from_article" => $Article_data['id']));
		$Article_content_data['article_content'] = explode("<blockquote></blockquote>" , $Article_content_data['article_content']);
		$max_page = count($Article_content_data['article_content']) ;
		if($page >= $max_page + 1) show_404();
		if($page <= 0) show_404();

		$cdn = $this->config->item("config_set")['cdn_url'];
		$Article_content_data['article_content'] = $Article_content_data['article_content'][$page - 1];
		$Article_content_data['article_content'] = str_replace('<img src="http://www.pcyisheng.com/ueditor/php/upload/image' , '<img src="' . $cdn . '/ueditor/php/upload/image' , $Article_content_data['article_content'] );
		$Article_content_data['article_content'] = str_replace('<img src="http://cdn.pcyisheng.com/ueditor/php/upload/image' , '<img src="' . $cdn . '/ueditor/php/upload/image' , $Article_content_data['article_content'] );
		$Article_content_data['article_content'] = str_replace('<img src="/ueditor/php/upload/image' , '<img src="' . $cdn . '/ueditor/php/upload/image' , $Article_content_data['article_content'] );
		$Article_content_data['article_content'] = str_replace('<p><br/></p>' , '<br/>' , $Article_content_data['article_content'] );
		
	


		// 处理文章内的整站的标签关键词替换
		$temp_url = array();
		$temp_md5 = array();
		$tag_list = $this->Tag_model->get_list(array() , 0 , 0 , array('name' , 'link') , "all");
		$content = $Article_content_data['article_content'];
		$content = preg_split("/<a href=(.*?)>(.*?)<\/a>/" , $content);
		foreach ($content as $value) {
			if(trim(strip_tags($value))){
				$content_temp = $value;
				foreach ($tag_list as $tag_data) {
					if(strstr($value , $tag_data['name']) !== FALSE){
						$url = "<a href='./tag/" .($tag_data['link'] === "" ? $tag_data['name'] : $tag_data['link']). "' title='{$tag_data['name']}' >{$tag_data['name']}</a>";
						$md5 = md5($url . rand(100000,999999));
						$temp_md5[] = $md5;
						$temp_url[] = $url;
						$value = parent::str_replace_once($tag_data['name'], $md5 , $value);
					}
				}
				$Article_content_data['article_content'] = parent::str_replace_once($content_temp, $value, $Article_content_data['article_content']);
			}
		}
		$Article_content_data['article_content'] = str_replace($temp_md5, $temp_url, $Article_content_data['article_content']);
		preg_match_all('/<pre class="brush:(.*)">/U', $Article_content_data['article_content'] , $array);
		if(count($array[0]) > 0){
			foreach ($array[1] as $key => $value_data) {
				$value_data=str_replace(";toolbar:false", "" , $value_data);
				$value_data=str_replace("js", "javascript" , $value_data);
				$value_data=str_replace(";", "" , $value_data);
				$str_replace_data[] = '<pre><code class="hljs ' . $value_data . '">';
				$value = array();
			}
			$array[0] = array_unique($array[0]);
			$str_replace_data = array_unique($str_replace_data);
			$Article_content_data['article_content'] = str_replace($array[0] , $str_replace_data , $Article_content_data['article_content'] );
			$Article_content_data['article_content'] = str_replace("</pre>" , "</code></pre>" , $Article_content_data['article_content'] );
		}



		parent::view_load(array("template/header","Article") , array(
			'Class_list' => $this->Class_model->get_list(),	
			"Article_data" => $Article_data , 
			"Article_content_data" => $Article_content_data , 
			'title' => $Article_data['title'] . "_" . $Article_data['form_class']['name'] . "_李墨的博客_分享最有用WEB前端知识",
			"description" => str_replace(array(" " , "	"), array("" , ""), trim(mb_substr(strip_tags($Article_content_data['article_content']), 0 , 100))) , 
			"keyword" => implode("," , json_decode($Article_data['article_key'])) , 
		) );

	}
}

