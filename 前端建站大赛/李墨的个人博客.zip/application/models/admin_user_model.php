<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
include_once(APPPATH . "models/Base_model.php");
class Admin_user_model extends Base_model{
	public function __construct(){
		parent::__construct();
		$this->table_name = $this->config->item("mysql_database_header")."admin_user";
	}


	public function get_user_list($params = array()){
		foreach ($params as $key => $value) {
			$return_data[$value['id']] = $value['username'];
		}
		return $return_data;
	}

	public function login($params = array()){
		extract($params);
		$user_data = parent::get(array("username" => $username));
		if(count($user_data) <= 0) return -1;
		if(md5($password . $user_data['salt']) === $user_data['password']){
			return $user_data;
		}else{
			return -2;
		}
	}
}