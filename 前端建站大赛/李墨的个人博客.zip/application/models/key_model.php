<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
include_once(APPPATH . "models/Base_model.php");
class Key_model extends Base_model{
	public function __construct(){
		parent::__construct();
		$this->table_name = $this->config->item("mysql_database_header")."key";
	}

	public function edit($where = array() , $params = array() , $tag_id = ""){
		$key_data = parent::get($where);
		$fatcher_tag = json_decode($key_data['fatcher_tag']);
		if($tag_id !== ""){
			if(array_search($tag_id , $fatcher_tag) === false){
				$fatcher_tag[] = $tag_id;
				return parent::edit($where , array("fatcher_tag" => json_encode($fatcher_tag)));
			}
		}else{
			return parent::edit($where , $params);
		}
	}

	/**
	 * 向key中添加一个父Tag
	 * @param  string $class_id [description]
	 * @param  string $tag_id   [description]
	 * @return [type]           [description]
	 */
	public function push_tag($key_id = "" , $tag_id = ""){
		$class_data = parent::get(array("id" => $key_id));
		$fatcher_tag = json_decode($class_data['fatcher_tag']);
		if(array_search($tag_id , $fatcher_tag) === false){
			$fatcher_tag[] = $tag_id;
			return parent::edit(array("id" => $key_id) , array("fatcher_tag" => json_encode($fatcher_tag)));
		}
		return false;
	}
}