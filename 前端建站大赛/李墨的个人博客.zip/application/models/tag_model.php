<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
include_once(APPPATH . "models/Base_model.php");
class Tag_model extends Base_model{
	public function __construct(){
		parent::__construct();
		$this->table_name = $this->config->item("mysql_database_header")."tag";
	}

	public function get_random($params = array() , $page = 1 , $count = 10 , $select = array() , $is_all  = "Not all"){
		$this->db->select($select);
		if($is_all === "Not all"){
			$this->db->limit($count , ($page - 1) * $count);
		}
		return $this->db->order_by('id' , 'random')->get($this->table_name)->result_array();
	}


	public function edit($where = array() , $params = array() , $class_id = ""){
		$tag_data = $this->Tag_model->get($where);
		$father_class = json_decode($tag_data['father_class'] , true);
		if($class_id !== ""){
			if(array_search($class_id , $father_class) === false){
				$father_class[] = $class_id;
				return parent::edit($where , array("father_class" => json_encode($father_class)));
			}
		}else{
			return parent::edit($where , $params);
		}
	}

	/**
	 * 给tag中添加一个子key
	 * @param  string $tag_id [description]
	 * @param  string $key_id   [description]
	 * @return [type]           [description]
	 */
	public function push_key($tag_id = "" , $key_id = ""){
		$tag_data = parent::get(array("id" => $tag_id));
		$son_key = json_decode($tag_data['son_key'] , true);
		if(array_search($key_id , $son_key) === false){
			$son_key[] = $key_id;
			return parent::edit(array("id" => $tag_id) , array("son_key" => json_encode($son_key)));
		}
		return false;
	}
}