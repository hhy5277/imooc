<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
include_once(APPPATH . "models/Base_model.php");
class Article_model extends Base_model{
	public function __construct(){
		parent::__construct();
		$this->table_name = $this->config->item("mysql_database_header")."article";
		$this->load->model("Article_content_model");
		$this->load->model("Class_model");
		$this->load->model("Tag_model");
		$this->load->model("Admin_user_model");
	}

	public function hot_list($params = array() , $page = 1 , $count = 10){
		$this->db->where($params);
		$data_list = $this->db->order_by('hot' , 'desc')->get($this->table_name , $count , ($page - 1) * $count)->result_array();
		foreach($data_list as &$value){
			$value['time'] = $this->time_interval($value['time']);
			$value['browse'] = $this->Article_content_model->get(array("from_article" => $value['id']));
		}		
		return $data_list ;
	}


	public function get_random($params = array() , $page = 1 , $count = 10 , $select = array() , $is_all  = "Not all"){
		$this->db->select($select);
		$this->db->where("article_type" , "0");
		$this->db->where($params);
		if($is_all === "Not all"){
			$this->db->limit($count , ($page - 1) * $count);
		}
		$data_list = $this->db->order_by('id' , 'random')->get($this->table_name)->result_array();
		foreach($data_list as &$value){
			$value['time'] = $this->time_interval($value['time']);
			$value['browse'] = $this->Article_content_model->get(array("from_article" => $value['id']));
		}
		return $data_list;
	}

	public function get_list_home($where = array() , $page = 1 , $count = 10 , $select = array() , $config = array()){
		$this->db->select($select);
		$this->db->where($where);
		if(isset($config['search']) || @$config['search'] === true){
			$this->db->or_like($config['search_data']);
		}

		if( ! isset($config['is_ok']) || $config['is_ok'] === true) $this->db->where("article_type" , "0");
		$data_list = $this->db->order_by("article_type desc , id desc")->get($this->table_name , $count , ($page - 1) * $count)->result_array();
		foreach($data_list as &$value){
			// $value['form_class'] = isset($value['form_class']) ? $this->Class_model->get(array("id" => $value['form_class'])) : "";
			// $value['form_tag'] = isset($value['form_tag']) ? $this->Tag_model->get(array("id" => $value['form_tag'])) : "";
			// $value['form_user'] = isset($value['form_user']) ? $this->Admin_user_model->get(array("id" => $value['form_user'])) : "";
			// $value['time_'] = $value['time'];
			$temp = $value['article_photo_name'];
			$value['article_photo_name'] = "2_" . str_replace(".jpg" , "_thumb.jpg" , $value['article_photo_name']);
			$img_info = @getimagesize('./static/upload/' . $value['article_photo_name']);

			if(isset($img_info[0]) && $temp != "-1.jpg"){
				$value['height'] = $img_info[1];
				$value['width'] = $img_info[0];
			}else{
				$value['height'] = 0;
				$value['width'] = 0;
			}
			
			$value['content'] = str_replace(array(" " , "　") , "" , trim(mb_substr(strip_tags($this->Article_content_model->get(array("from_article" => $value['id']))['article_content']), 0 , 90)));
			if( ! isset($config['is_time'])  || $config['is_time'] === true) $value['time'] = $this->time_interval($value['time']);
		}
		 return $data_list;
	}


	public function get_list_new($where = array() , $page = 1 , $count = 10 , $select = array() , $config = array()){
		$this->db->select($select);
		$this->db->where($where);
		if(isset($config['search']) || @$config['search'] === true){
			$this->db->or_like($config['search_data']);
		}

		if( ! isset($config['is_ok']) || $config['is_ok'] === true) $this->db->where("article_type" , "0");
		$count = $this->db->count_all_results($this->table_name);
		$data_list = $this->db->order_by("article_type desc , id desc")->get($this->table_name , $count , ($page - 1) * $count)->result_array();
		foreach($data_list as &$value){
			$value['form_class'] = isset($value['form_class']) ? $this->Class_model->get(array("id" => $value['form_class'])) : "";
			$value['form_tag'] = isset($value['form_tag']) ? $this->Tag_model->get(array("id" => $value['form_tag'])) : "";
			$value['form_user'] = isset($value['form_user']) ? $this->Admin_user_model->get(array("id" => $value['form_user'])) : "";
			$value['content'] = str_replace(array(" " , "　") , "" , trim(mb_substr(strip_tags($this->Article_content_model->get(array("from_article" => $value['id']))['article_content']), 0 , 500)));
			$value['time_'] = $value['time'];
			if( ! isset($config['is_time'])  || $config['is_time'] === true) $value['time'] = $this->time_interval($value['time']);
		}
		 $data_list['count'] = $count;
		 return $data_list;
	}



	public function get_list($where = array() , $page = 1 , $count = 10 , $select = array() , $is_all  = "Not all" , $is_time = true , $order = array("id" => "desc") , $is_ok = true){
		$this->db->select($select);
		if($is_ok) $this->db->where("article_type" , "0");
		$this->db->where($where);
		$data_list = $this->db->order_by("id" , "desc")->get($this->table_name , $count , ($page - 1) * $count)->result_array();
		foreach($data_list as &$value){
			$value['form_class'] = isset($value['form_class']) ? $this->Class_model->get(array("id" => $value['form_class'])) : "";
			$value['form_tag'] = isset($value['form_tag']) ? $this->Tag_model->get(array("id" => $value['form_tag'])) : "";
			$value['form_user'] = isset($value['form_user']) ? $this->Admin_user_model->get(array("id" => $value['form_user'])) : "";
			$value['content'] = str_replace(array(" " , "　") , "" , trim(mb_substr(strip_tags($this->Article_content_model->get(array("from_article" => $value['id']))['article_content']), 0 , 400)));
			$value['time_'] = $value['time'];
			if($is_time) $value['time'] = $this->time_interval($value['time']);
		}
		 return $data_list;
	}



	public function time_interval($lost_time = 0){
		$time_interval = time() - $lost_time;
		if($time_interval < 60){
			return "刚刚";
		}else if($time_interval > 60 && $time_interval < 3600){
			return floor($time_interval / 60) . "分钟前";
		}else if($time_interval > 3600 && $time_interval < 86400){
			return floor($time_interval / 3600) . "小时前";
		}else if($time_interval > 86400 && $time_interval < 2592000){
			return floor($time_interval / 86400) . "天前";
		}else if($time_interval > 2592000 && $time_interval < 5184000){
			return floor($time_interval / 2592000) . "个月前";
		}else if($time_interval > 5184000 && $time_interval < 5184000 * 12){
			return date("m月d日" , $lost_time);
		}else if($time_interval > 5184000 * 12){
			return date("Y-m-d" , $lost_time);
		}


		return $time_interval;
	}


}