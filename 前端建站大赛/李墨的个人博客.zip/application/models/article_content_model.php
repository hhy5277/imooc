<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
include_once(APPPATH . "models/Base_model.php");
class Article_content_model extends Base_model{
	public function __construct(){
		parent::__construct();
		$this->table_name = $this->config->item("mysql_database_header")."article_content";
	}



	public function get_read($article_id){
		return $this->get(array("from_article" => $article_id))['article_read'];
	}


}