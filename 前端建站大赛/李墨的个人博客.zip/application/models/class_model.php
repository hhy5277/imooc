<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
include_once(APPPATH . "models/Base_model.php");
class Class_model extends Base_model{
	public function __construct(){
		parent::__construct();
		$this->table_name = $this->config->item("mysql_database_header")."class";
	}


	/**
	 * 向Class中添加一个子Tag
	 * @param  string $class_id [description]
	 * @param  string $tag_id   [description]
	 * @return [type]           [description]
	 */
	public function push_tag($class_id = "" , $tag_id = ""){
		$class_data = parent::get(array("id" => $class_id));
		$son_tag = json_decode($class_data['son_tag']);
		if(array_search($tag_id , $son_tag) === false){
			$son_tag[] = $tag_id;
			return parent::edit(array("id" => $class_id) , array("son_tag" => json_encode($son_tag)));
		}
		return false;
	}
}