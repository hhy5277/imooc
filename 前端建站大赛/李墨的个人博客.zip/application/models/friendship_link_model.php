<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
include_once(APPPATH . "models/Base_model.php");
class Friendship_link_model extends Base_model{
	public function __construct(){
		parent::__construct();
		$this->table_name = $this->config->item("mysql_database_header")."friendship_link";
	}
	public function get_list($params = array() , $page = 1 , $count = 10 , $select = array() , $is_all  = "Not all"){
		if($is_all === "Not all"){
			$this->db->limit($count , ($page - 1) * $count);
		}
		return $this->db->select($select)->order_by('priority' , 'desc')->get_where($this->table_name , $params)->result_array();
	}




}