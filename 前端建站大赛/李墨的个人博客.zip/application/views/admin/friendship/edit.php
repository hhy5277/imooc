	<link rel="stylesheet" href="./static/css/admin/class_craeat.css">
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 6));
	?>

	<div class="document">
		<div class="info-box header">
			<h2 class="fl">编辑友情链接 <span>edit friendship link</span></h2>
		</div>

		<div class="form">

			<table>
				<form action="javascript:void(0)" onsubmit="class_craete(this)">
					<tr><td><input  type="text"  placeholder="请这里输入友情链接标题" id="js-title" value="<?=$Friendship_link_data['name']?>"></td></tr>
					<tr><td><input  type="text"  placeholder="请在此输入友情链接地址" id="js-link" value="<?=$Friendship_link_data['link']?>"></td></tr>
					<tr><td><input  type="text"  placeholder="请输入优先度（最高为1024）" id="js-priority" value="<?=$Friendship_link_data['priority']?>"></td></tr>
					<tr><td>
						<div class="notice padding notLeft">
					    		<span>小贴士：新的数据添加完成后需要点击右上角的旋转按钮更新网站缓存</span>
					    	</div>
					</td></tr>
					<tr><td><button class="btn btn-success" id="success" type="submit" ><i class="fa fa-save"></i>编辑友情链接</button></td></tr>
				</form>
			</table>

		</div>




		
	</div>


	<script type="text/javascript">
		id = <?=$Friendship_link_data['id']?>
	</script>
	<?php $this->load->view($this->template_name . "/template/footer");?>
	<script src="./static/js/admin/Friendship_edit.js"></script>
</body>
</html>