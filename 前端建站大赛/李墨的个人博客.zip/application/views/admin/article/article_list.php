	<link rel="stylesheet" href="./static/css/admin/article.css">
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 1));
	?>

	<div class="document">
		<div class="info-box article noneborder">
			<h2 class="fl">文章列表 <span>article list</span> </h2>

			<button class="btn btn-success fr" onclick="window.location.href= thisLoction + '/create'"><i class="fa fa-list"></i>添加文章</button>
			<button class="btn btn-info fr" onclick="window.location.href= thisLoction + '/config'"><i class="fa fa-cogs"></i>文章配置</button>
			<button class="btn btn-danger fr" id="delete"><i class="fa fa-trash"></i>删除</button>
			
			<div class="search fr">
				<?php
					if(isset($class_id['form_class'])) echo '<i class="fa fa-arrow-left" id="back"></i>';
				?>
				
				<select name="" id="class">
					<option value="-1" data-id="-1">全部分类</option>
					<?php
						foreach ($class_list as $key => $value) {
							if(@$class_id['form_class'] === $value['id']){
								echo '<option value="' . $value['name'] . '" data-id="' . $value['id'] . '" selected="selected">' . $value['name'] . '</option>';				
							}else{
								echo '<option value="' . $value['name'] . '" data-id="' . $value['id'] . '">' . $value['name'] . '</option>';				
							}
						}
					?>
				</select>
			</div>
		</div>
		<div class="info-box noneborder">
			<table class="table list">
				<tr>
					<th width="3%"><input type="checkbox"></th>
					<th width="30%">文章标题</th>
					<th width="13%">文章地址</th>
					<th width="7%">文章作者</th>
					<th width="11%">分类</th>
					<th width="4%">状态</th>
					<th width="10%">添加时间</th>
					<th width="6%">操作</th>
				</tr><tr></tr>
				<?php

					foreach($article_list as $value){
						switch ($value['article_type']) {
							case -1:$article_type = "danger"; $article_desc = "待审核";break;
							case 1:$article_type = "success"; $article_desc = "栏目置顶";break;
							case 999:$article_type = "warning"; $article_desc = "全网置顶";break;
							default:$article_type = "primary";$article_desc = "正常";break;
						}
						// form_user
						echo '<tr data-id="' . $value['id'] . '">
								<td><input type="checkbox"></td>
								<td>' . $value['title'] . '</td>
								<td><a href="./act/' . $value['article_byid'] . '.html" target="_blank">' . $value['article_byid'] . '.html</a></td>
								<td>' . $value['form_user']['username'] . '</td>
								<td class="class_tag">
									<span class="label label-default fl">' . $value['form_class']['name'] . '</span>
									<span class="label label-default fl">' . $value['form_tag']['name'] . '</span>
								</td>
								<td><span class="label label-' . $article_type . '">' . $article_desc . '</span></td>
								<td>' . $value['time'] . '</td>
								<td><i class="fa fa-arrow-circle-up" id="js-uptop"></i><i class="fa fa-edit" id="edit"></i><i class="fa fa-trash" id="delete"></i></td>
							</tr>';
					}
				?>
			</table>
			<?php
				$this->load->view($this->template_name . "/template/page.php",array(
					"max_count" => $article_list_count,
					"hot" => $class_id == array() ? "" : "&class=" . $class_id['form_class']
				));
			?>
		</div>
	</div>

	<?php
		$this->load->model("Article_model");
		$article_data = $this->Article_model->get(array("article_type" => "999"));
	?>
	<script>
		var top_article = {
			"title" : "<?=$article_data['title']?>",
			"byid" : "<?=$article_data['article_byid']?>",
		}
	</script>

	<?php $this->load->view($this->template_name . "/template/footer");?>
	<script type="text/javascript" charset="utf-8" src="static/js/admin/article_list.js"></script>
</body>
</html>