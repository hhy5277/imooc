
	<link href="./ueditor/themes/default/css/umeditor.min.css" type="text/css" rel="stylesheet">
	<link rel="stylesheet" href="./static/css/admin/article.css">
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 1));
	?>

	<div class="document">
		<div class="info-box article">
			<h2 class="fl">文章配置</h2>
			<div class="btn-group" role="group" aria-label="...">
				<button type="button" class="btn btn-default active">文章审核</button>
				<button type="button" class="btn btn-default">文章设置</button>
				<button type="button" class="btn btn-default" onclick="window.location.href= '.<?=dirname($_SERVER['PATH_INFO'])?>/top' ">头条设置</button>
			</div>	
			<button class="btn btn-info fr" onclick="window.location.href= '.<?=dirname($_SERVER['PATH_INFO'])?>' "><i class="fa fa-arrow-left"></i>返回</button>
		</div>
		<div class="info-box noneborder">
			<table class="table list">
				<tr>
					<th width="3%"><input type="checkbox"></th>
					<th width="30%">文章标题</th>
					<th width="10%">文章地址</th>
					<th width="7%">文章作者</th>
					<th width="11%">分类</th>
					<th width="4%">状态</th>
					<th width="10%">添加时间</th>
					<th width="6%">操作</th>
				</tr><tr></tr>
				<?php
					foreach($article_list as $value){
						switch ($value['article_type']) {
							case -1:$article_type = "danger"; $article_desc = "需审核";break;
							case 1:$article_type = "success"; $article_desc = "置顶";break;
							default:$article_type = "primary";$article_desc = "正常";break;
						}
						// form_user
						echo '<tr data-id="' . $value['id'] . '">
								<td><input type="checkbox"></td>
								<td>' . $value['title'] . '</td>
								<td><a href="./act/' . $value['article_byid'] . '.html" target="_blank">' . $value['article_byid'] . '.html</a></td>
								<td>' . $value['form_user']['username'] . '</td>
								<td class="class_tag">
									<span class="label label-default fl">' . $value['form_class']['name'] . '</span>
									<span class="label label-default fl">' . $value['form_tag']['name'] . '</span>
								</td>
								<td><span class="label label-' . $article_type . '">' . $article_desc . '</span></td>
								<td>' . $value['time'] . '</td>
								<td>
									<i class="fa fa-check" id="check"></i>
									<a href="./act/' . $value['article_byid'] . '.html" target="_blank"><i class="fa fa-link"></i></a>
									<i class="fa fa-trash" id="delete"></i>
								</td>
							</tr>';
					}
				?>
			</table>
			<?php
				if(count($article_list) <= 0) echo '<p class="error">截止到目前为止，还没有任何文章需要您审核</p>';

				$this->load->view($this->template_name . "/template/page.php",array(
					"max_count" => $article_list_count,
				));
			?>
		</div>
		
	</div>
	<script>
		var tableDelete = function(article){
			var article_id = article.articleId;
			_api.adminArticle.remove({
				article_id : article_id
			}).then(function(data){
				window.location.reload();
				eject.close();
			} , function(msg){
				eject.alert({
					content : msg
				});
				eject.close();
			});
			eject.close();
		};
	</script>

	<?php $this->load->view($this->template_name . "/template/footer");?>
	<script type="text/javascript" charset="utf-8" src="static/js/admin/article_config.js"></script>
</body>
</html>