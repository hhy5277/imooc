<script>
	var article_data = {
		"id" : <?=$this->input->get('id')?>
	}
</script>
<div class="window" id="js-tag-window" >
	<div class="eject">
		<div class="eject-title">
			<h2 class="fl">添加新的标签</h2>
			<a href="javascript:viod(0)" class="close" id="close">X</a>
		</div>
		<div class="eject-content">
			<table class="form">
				<tr><td width="80"></td></tr>
				<tr><td><span>标签名称：</span></td><td><input type="text" id="js-input-name" placeholder="请在此处输入标签的名称"></td></tr>
				<tr><td><span>自定地址：</span></td><td><input type="text" id="js-input-link" placeholder="请在此处输入自定义地址"> </td></tr>
			</table>
		</div>
		<div class="eject-bottom">
			<button class="btn btn-default" id="close">取消</button>
			<button class="btn btn-danger" onclick="pushTag()">确认</button>
		</div>
	</div>
</div>