
	<link href="./ueditor/themes/default/css/umeditor.min.css" type="text/css" rel="stylesheet">
	<link rel="stylesheet" href="./static/css/admin/article.css">
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 1));
	?>

	<div class="document">
		<div class="info-box article">
			<h2 class="fl">文章配置</h2>
			<div class="btn-group" role="group" aria-label="...">
				<button type="button" class="btn btn-default" onclick="window.location.href= '.<?=dirname($_SERVER['PATH_INFO'])?>/config' ">文章审核</button>
				<button type="button" class="btn btn-default">文章设置</button>
				<button type="button" class="btn btn-default active">头条设置</button>
			</div>	
			<button class="btn btn-info fr" onclick="window.location.href= '.<?=dirname($_SERVER['PATH_INFO'])?>' "><i class="fa fa-arrow-left"></i>返回</button>
		</div>
		<div class="info-box noneborder">
			<!-- <div class="checkbox">
				<label>
					<input type="checkbox"> Remember me
				</label>
			</div> -->
			<p class="error" >该功能移植到文章列表内的UP小图标按钮</p>
		</div>
	</div>


	<?php $this->load->view($this->template_name . "/template/footer");?>
	<script type="text/javascript" charset="utf-8" src="static/js/admin/article_config.js"></script>
</body>
</html>