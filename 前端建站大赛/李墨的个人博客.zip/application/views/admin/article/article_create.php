	<link href="./ueditor/themes/default/css/ueditor.css" type="text/css">
	<link rel="stylesheet" href="./static/css/admin/article.css">
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 1));
		$this->load->view($this->template_name . "/article/article_window");
	?>
	
	<div class="document">
		<form action="javascript:;" enctype="" id="js-article-create">
			<div class="info-box article">
				<h2 class="fl">创建文章 <span>create article</span></h2>
			</div>
			<div class="left">
				<div class="form">
					<input type="hidden" name="article_key" id="js-article-key-plus">
					<table>
						<tr><td><input id="js-article-title" name="article_title" type="text"  placeholder="请这里输入文章的标题"></td></tr>
						<tr><td><div id='js-article-key' class="widget-key"  data-widget='key' data-length='7'><div id='key'><input type='text' placeholder='在此输入标签'/></div></div></tr>
						<tr><td><input id='js-article-form' name="article_source"  type="text" placeholder="请在此输入文章来源（为空则不显示文章的来源）"></td></tr>
						<tr><td>
							<script type="text/plain" id="editor" height="736" width="100%"></script>
						</td></tr>
					</table>
				</div>
			</div>

			<div class="right">
				<div class="notice padding notLeft">
					<i class="fa fa-exclamation-circle"></i>
			    		<span>在这个页面您可以创建新文章，下面给您一些温馨提示
		    				<br>1、当您编辑完文章后可以点击保存按钮发布文章 
		    				<br>2、当页面不小心被关闭时不用担心系统会自动存储草稿
		    				<br>3、重新进入页面会自动载入草稿
			    		</span>
			    	</div>
				
				<div class="right-min">
					<table width="100%">
						<input type="hidden" name="article_option" id="js-article-option">
						<tr>
							<td><div class="checkbox"><label><input type="checkbox" checked="checkbox" id="js-article-release" disabled="false">文章是否可见</label></div></td>
							<td><div class="checkbox"><label><input type="checkbox" checked="checkbox" id="js-article-comment" disabled="false">文章是否可评论</label></div></td>
							<td><div class="checkbox"><label><input type="checkbox" 	id="js-article-anonymous" disabled="false">匿名发布</label></div></td>
						</tr>
						<tr>
							<td><div class="checkbox"><label><input type="checkbox" checked="checkbox" id="js-article-grab" disabled="false">搜索引擎可否抓取</label></div></td>
							<td><div class="checkbox"><label><input type="checkbox" checked="checkbox" id="js-article-cover" disabled="false">是否显示封图</label></div></td>
							<td><div class="checkbox"><label><input type="checkbox" id="js-article-top">所在板块置顶</label></div></td>
						</tr>
					</table>

					<!-- article class start -->
					<div class="article_class">
						<div class="article_header">
							<b>选择文章分类</b>
						</div>
						<select class="form-control" id="js-article-select" name="article_class">
							{class_list}
								<option>{name}</option>
							{/class_list}
						</select>
					</div>
					<!-- article class end -->


					<!-- article class start -->
					<div class="article_tag">
						<div class="article_header">
							<b>选择文章标签</b>
							<a href="javascript:;" style="margin-left:13px;" class="plusTag" id="js-push-tag" ><i class="fa fa-plus"></i>添加新的标签</a>
						</div>
						<div class="select_search" data-type="标签">
							<button class="btn btn-default" id="select_search"><i class="fa fa-search"></i> 搜索标签</button>
							<input type="text" placeholder="请输入搜索的关键词">
						</div>
						<select class="form-control" id="js-article-select-tag" name="article_tag">
							{tag_list}
								<option>{name}</option>
							{/tag_list}
						</select>
					</div>
					<!-- article class end -->
			

					<!-- article upload photo start -->
					<div class="upload btn-primary">
						<i class="fa fa-cloud-upload"></i>
						上传文章图片
						<input type="file" name="article_browse" id="js-article-browse">
					</div>
					<div class="browse">
						未上传图片
						<img src="" id="browse" >
					</div>
					<img src="" id="temp" style="display:none">
					<p id="browseSize" data-reconmmend="推荐尺寸：1024 * 1000" data-width="1024" data-height="1000"></p>
					<!-- article upload photo end -->
			    		

			    		<button class="btn btn-success" type="button" onclick="article_save();"><i class="fa fa-save"></i>保存文章</button>
			    		<button class="btn btn-danger"><i class="fa fa-trash"></i>删除草稿</button>
				</div>
			</div>
		</form>
		
	</div>



	<?php $this->load->view($this->template_name . "/template/footer");?>
	<script type="text/javascript" charset="utf-8" src="./ueditor/ueditor.config.js"></script>
	<script type="text/javascript" charset="utf-8" src="./ueditor/ueditor.all.js"></script>
	<script type="text/javascript" charset="utf-8" src="static/js/jquery-from.js"></script>
	<script type="text/javascript" charset="utf-8" src="static/js/admin/article_create_edit.js"></script>
	<script type="text/javascript" charset="utf-8" src="static/js/admin/article_create.js"></script>
</body>
</html>