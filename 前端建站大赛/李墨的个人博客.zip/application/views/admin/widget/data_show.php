<?php
	/**
	 * 后台通用的数据列表展示组件
	 *
	 * data 数据
	 * top_nav 顶部的标题 array
	 * 
	 */


?>


	<?php
		foreach ($data as $value) {
			foreach ($value as $data) {
				# code...
			}
			echo "<tr><td>{$value['test']}</td></tr>";
		}
	?>
