	<?php
	$nav_data = array(
		array(
			"name" => "后台首页",
			"icon" => "home",
			"link" => "./admin",
			"active" => false,
			
		) , array(
			"name" => "文章管理",
			"icon" => "file-text-o",
			"link" => "./admin/Article",
			"active" => false,
			
		) , array(
			"name" => "栏目管理",
			"icon" => "list-ol",
			"link" => "./admin/Class_list",
			"active" => false,
			
		) , array(
			"name" => "标签管理",
			"icon" => "tags",
			"link" => "./admin/Tag",
			"active" => false,
			
		) , array(
			"name" => "用户管理",
			"icon" => "user",
			"link" => "./admin/User",
			"active" => false,
		) , array(
			"name" => "模板设置",
			"icon" => "th-large",
			"link" => "./admin/Template",
			"active" => false,
		) , array(
			"name" => "其他设置",
			"icon" => "cog",
			"link" => "./admin/Config",
			"active" => false
		) ,array(
			"name" => "帮助",
			"icon" => "question-circle",
			"link" => "./admin/Help",
			"active" => false
		) ,
	);
?>

<div class="sidebar" id="js-sidebar">
	<div class="sidebar_main">
		<ul>
			<?php
				$nav_data[!isset($active) ? 0 : $active]['active'] = true;
				foreach ($nav_data as $value) {
					echo '<a href="' . $value['link'] . '"><li ' . ($value['active'] ? 'class="active"' : '') . '><i class="fa fa-' . $value['icon'] . '"></i><p>' . $value['name'] . '</p></li></a> ';
				}
			?>
		</ul>
	</div>
</div>


