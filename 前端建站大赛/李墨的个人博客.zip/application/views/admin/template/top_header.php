<?php
	$username = $_SESSION["admin_user"]["username"];
?>
<div class="top_header">
	<i class="fa fa-list" id="list"></i>
	<a href="admin" class="header_logo"><img src="static/image/admin/cloudLogo.png" alt="" class="fl"></a>

	<div class="user_info fr">
		<img src="./static/image/admin/upload/<?=$username?>.jpg" alt="" class="user_photo" width="30">
		<a href="javascript:;" class="username"><?=$username?></a>
		<a href="javascript:;" class="level">超级管理员</a>
		<div class="user_button fr">
			<a href="javascript:;" class="header_btn" title="更新整站缓存" onclick='eject.sure({content : "您确定要更新网站的缓存文件吗？<br>更新缓存时，会将网站内所有缓存的页面删除所以需要一定的时间来处理您的操作<br>请耐心等待 wait..." , functionName: "rePcyisheng()" })'><i class="fa fa-refresh fa-spin"></i></a>
			<div class="note fl">
				<span id="js-note-math" class="note-digital">1</span>
				<a href="javascript:;" class="header_btn"><i class="fa fa-envelope-o"></i></a>
			</div>
			<a href="javascript:;" class="header_btn"  onclick='eject.sure({content : "您真的要退出吗？"})'><i class="fa fa-power-off"></i></a>
		</div>
	</div>
</div>

<div class="sorry">
	<p>很遗憾的通知您</p>
	<p>分辨率小于340PX的机器是无法使用本系统的</p>
</div>