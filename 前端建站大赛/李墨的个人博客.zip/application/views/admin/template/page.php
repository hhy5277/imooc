<?php
	$page_count = !isset($page_count) ? 10 : $page_count;
	$hot = !isset($hot) ? "" : $hot;
	$page = isset($_GET['page']) ? $this->input->get("page") : 1;
	$count = ceil($max_count / $page_count);
	$active = "class='active'";
	if($count > 1){
?>
<div class="page">
	<ul>
		<li><a href=".<?=$_SERVER['PATH_INFO'] . "?page=1" . $hot?>"><<</a></li>
		<li><a href=".<?=$_SERVER['PATH_INFO'] . "?page=" . ($page-1) . $hot?>">上一页</a></li>
		<?php
			for ($index = $page - 3 <= 0 ? 1 : $page - 3; $index < $page + 5; $index ++) {
				if($index <= $count){
					$isLost = $index == $count;
					echo "<li><a href='.{$_SERVER['PATH_INFO']}?page={$index}{$hot}' ".($index == $page ? $active : "").">{$index}</a></li>";
				}else{
					break;
				}
			}
			if(!$isLost){
				echo "<li><a href='javascript:;'>······</a></li>";
				echo "<li><a href='.{$_SERVER['PATH_INFO']}?page={$count}{$hot}'>{$count}</a></li>";
			}
		?>
		<li><a href=".<?=$_SERVER['PATH_INFO'] . "?page=" . ($page+1) . $hot?>">下一页</a></li>
		<li><a href=".<?=$_SERVER['PATH_INFO'] . "?page={$count} . $hot"?>">>></a></li>
	</ul>
</div>
<?php }?>