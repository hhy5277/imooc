<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Cloud cms 后台管理系统</title>
	<base href="<?=base_url();?>">
	<link rel="stylesheet" href="./static/css/admin/base.css">
	<link rel="stylesheet" href="./static/css/font-awesome.min.css">
	<link rel="stylesheet" href="http://cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<script type="text/javascript">
		var thisLoction = ".<?=$_SERVER['PATH_INFO']?>";
	</script>