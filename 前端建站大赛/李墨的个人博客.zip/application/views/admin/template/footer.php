<div class="window">
	<div class="eject" id="sure">
		<div class="eject-title">
			<h2 class="fl">温馨提示</h2>
			<a href="javascript:viod(0)" class="close" id="close">X</a>
		</div>
		<div class="eject-content">
			
		</div>
		<div class="eject-bottom">
			<button class="btn btn-danger">确认</button>
			<button class="btn btn-default" id="close">取消</button>
		</div>
	</div>


	<div class="eject" id="alert">
		<div class="eject-title">
			<h2 class="fl">温馨提示</h2>
			<a herf="javascript:viod(0)" class="close" id="close">X</a>
		</div>
		<div class="eject-content">
			
		</div>
		<div class="eject-bottom">
			<button class="btn btn-success" id="close">确定</button>
		</div>
	</div>
</div>

<div class="prompt">
	<div class="content">
		
	</div>
</div>
<?php
	switch($this->agent->browser()) {
	    case 'Opera':
	    case 'Chrome':
	    case 'Firefox':
	    case 'Safari':
	        echo '<script src="static/js/jquery-2.1.4.min.js"></script>';
	        break;
	    default:
	        echo '<script src="static/js/jquery-1.11.3.min.js"></script>';
	        break;
	}
?>
<script src="static/js/admin/base.js"></script>
<script src="static/js/admin/api.js"></script>
