	<link rel="stylesheet" href="./static/css/admin/class_craeat.css">
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 2));
	?>

	<div class="document">
		<div class="info-box header">
			<h2 class="fl">编辑分类 <span>Edit class</span></h2>
		</div>
		<div class="form">
			<table>
				<tr><td><input  type="text"  placeholder="请这里输入分类的标题" id="js-class-title" value="<?=$class_data['name']?>"></td></tr>
				<tr><td><input  type="text"  placeholder="请在此输入自定义的地址" id="js-class-link" value="<?=$class_data['link']?>"></td></tr>
				<tr><td><input  type="text"  placeholder="请再这输入自定义ICON (fa-user || fa-trash)" id="js-class-fuTitle" value="<?=$class_data['icon']?>"></td></tr>
				<tr><td><input  type="text"  placeholder="请在此输入副标题（为空则默认网站首页标题）" id="js-class-icon" value="<?=$class_data['vice_title']?>"></td></tr>
				<tr><td><div class="widget-key" data-widget='key' data-length='7' id="js-class-key"><div id='key'><input type='text' placeholder='请输入分类关键词'/></div></div></tr>
				<tr><td> <textarea placeholder="请在这里输入对分类的描述" id="js-class-description"><?=$class_data['description']?></textarea> </td></tr>
				<tr><td><div class="checkbox"><label><input type="checkbox"> 使用独立页面<span>（需手动编写控制器或使用模板）</span></label></div></td></tr>
				<tr><td>
					<div class="notice padding notLeft">
				    		<span>在这里可以添加新的分类，您也可以自定义一个页面来建立活动页面</span>
				    	</div>
				</td></tr>
				<tr><td><button class="btn btn-success" id="success" onclick="class_edit(this)"><i class="fa fa-edit"></i>编辑该分类</button></td></tr>
			</table>

		</div>




		
	</div>

	<?php 
	$this->load->view($this->template_name . "/template/footer");?>
	<script type="text/javascript">
		$("#js-article-title").css({"font-size" : "23px"});
		class_key = JSON.parse('<?=$class_data['class_key']?>');
		$.each(class_key , function(key , value){
			$("#js-class-key").find("#key").prepend('<span data-value="'+value+'">'+value+' <a href="javascript:;" class="close">X</a></span>');
		});
		$("#js-class-key").val('<?=$class_data["class_key"]?>');
		id = <?=$class_data['id']?>;
	</script>
	<script src="./static/js/admin/class_min.js"></script>

</body>
</html>