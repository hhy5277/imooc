	<link rel="stylesheet" href="./static/css/admin/class_craeat.css">
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 2));
	?>

	<div class="document">
		<div class="info-box header">
			<h2 class="fl">创建分类 <span>create class</span></h2>
		</div>

		<div class="form">

			<table>
				<form action="javascript:void(0)" onsubmit="class_craete(this)">
					<tr><td><input  type="text"  placeholder="请这里输入分类的标题" id="js-class-title"></td></tr>
					<tr><td><input  type="text"  placeholder="请在此输入自定义的地址" id="js-class-link"></td></tr>
					<tr><td><input  type="text"  placeholder="请在此输入副标题（为空则默认网站首页标题）" id="js-class-fuTitle"></td></tr>
					<tr><td><input  type="text"  placeholder="请再这输入自定义ICON (fa-user || fa-trash)" id="js-class-icon"></td></tr>
					<tr><td><div class="widget-key"  data-widget='key' data-length='7' id="js-class-key"><div id='key'><input type='text' placeholder='请输入分类关键词'/></div></div></tr>
					<tr><td> <textarea placeholder="请在这里输入对分类的描述" id="js-class-description"></textarea> </td></tr>
					<tr><td>
						<div class="notice padding notLeft">
					    		<span>在这里可以添加新的分类，新建的分类可以定义成一个独立活动页面（暂未实现）</span>
					    	</div>
					</td></tr>
					<tr><td><button class="btn btn-success" id="success" type="submit" ><i class="fa fa-save"></i>创建新分类</button></td></tr>
				</form>
			</table>

		</div>




		
	</div>



	<?php $this->load->view($this->template_name . "/template/footer");?>
	<script src="./static/js/admin/class_min.js"></script>
</body>
</html>