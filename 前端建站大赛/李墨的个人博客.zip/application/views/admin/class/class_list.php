	<link rel="stylesheet" href="./static/css/admin/list.css">
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 2));
	?>

	<div class="document">
		<form action="javascript:;" enctype="" id="js-article-create">
			<div class="info-box article noneborder">
				<h2 class="fl">栏目列表 <span>Class list</span></h2>

				<button class="btn btn-success fr" onclick="window.location.href=thisLoction+'/create'">
					<i class="fa fa-plus"></i>添加栏目
				</button>
				<button class="btn btn-danger fr">
					<i class="fa fa-trash"></i>
					删除选中
				</button>
			</div>
		</form>
			
		<div class="info-box noneborder">
			<table class="table list">
				<thead>
					<tr>
						<th width="20"><input type="checkbox"></th>
						<th width="130">列表名称</th>
						<th width="40%">列表描述</th>
						<th>关键词</th>
						<th width="190">自定地址</th>
						<th width="90">下属标签</th>
						<th width="70">页面</th>
						<th width="70">状态</th>
						<th width="140">操作</th>
					</tr>
				</thead>

				<tbody>
					<?php
						foreach ($class_list as $key => $value) {
							if($value['type'] == 0){
								$type = "<span class='label label-primary'>正常</span>";
							}else if($value['type'] == 1){
								$type = "<span class='label label-success'>置顶</span>";
							}else if($value['type'] == 2) {
								$type = "<span class='label label-info'>栏目</span>";
							}
							if($value['type'] == 0){
								$domin = "<span class='label label-default'>Class</span>";
							}else if($value['type'] == 1){
								$domin = "<span class='label label-danger'>Alone</span>";
							}


							echo "<tr data-id='{$value['id']}'>
							<td><input type='checkbox'></td>
							<td>{$value['name']}</td>
							<td>{$value['description']}</td>
							<td></td>
							<td><a href='{$value['link']}'>{$value['link']}</a></td>
							<td>" . count(json_decode($value['son_tag'])) . " 个</td>
							<td>{$domin}</td>
							<td>{$type}</td>
							<td>
								<i class='fa fa-bars' id='bar'></i>
								<i class='fa fa-list' id='list'></i>
								<i class='fa fa-edit' id='edit'></i>
								<i class='fa fa-trash' id='delete'></i>
							</td>
						</tr>";
						}
					?>
				</tbody>
			</table>
			<?php
				$this->load->view($this->template_name . "/template/page.php",array(
					"max_count" => $class_count,
				));
			?>

		</div>
	</div>


	<script>
		custom_edit='/edit'
	</script>
	<?php $this->load->view($this->template_name . "/template/footer");?>
	<script src="./static/js/admin/class_min.js"></script>
</body>
</html>