	<link rel="stylesheet" href="./static/css/admin/template.css">
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 5));
	?>
	<div class="document">
		<div class="info-box header noneborder">
			<h2 class="fl">模板设置 <span>Template</span></h2>

		</div>


		<div class="info-box noneborder template-page">
			<div class="info-box noneborder">
				<table>
					<tr><td><span>首页轮播所属栏目：</span></td></tr>
				</table>
			</div>

			<div class="template-left" style="margin-top:-14px;">
				<ul>

					<li>
						<div class="template">
							<img src="./static/index.jpg" alt="">
							<div class="template-bottom">
								<i class="fa fa-check"></i><span>已选中</span>
								<a href="" class="fr">模板设置</a>
							</div>
						</div>
					</li>
				
					<li>
						<div class="template">
							<img src="./static/index2.jpg" alt="">
							<div class="template-bottom">
								<span>未使用</span>
								<a href="" class="fr">设置模板</a>
							</div>
						</div>
					</li>


				</ul>
			</div>
			<div class="template-right fr">
			</div>


		</div>

	</div>

	<?php $this->load->view($this->template_name . "/template/footer");?>
</body>
</html>