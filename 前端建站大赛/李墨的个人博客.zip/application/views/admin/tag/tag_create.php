	<link rel="stylesheet" href="./static/css/admin/class_craeat.css">
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 3));
	?>

	<div class="document">
		<div class="info-box header">
			<h2 class="fl">创新标签 <span>Create tag</span></h2>
		</div>
		<div class="form">
			<table>
				<tr><td><input  type="text"  placeholder="请这里输入标签的名字" id="js-tag-title"></td></tr>
				<tr><td><input  type="text"  placeholder="请输入自定义地址" id="js-tag-link"></td></tr>
				<tr><td><textarea  placeholder="请输入标签的描述" id="js-tag-description"></textarea></tr>
				<tr><td>
					<div class="notice padding notLeft">
				    		<span>在这里可以添加新的分类，新建的分类可以定义成一个独立活动页面（暂未实现）</span>
				    	</div>
				</td></tr>
				<tr><td><button class="btn btn-success" id="success" onclick="create_tag()"><i class="fa fa-plus"></i>创建标签</button></td></tr>
			</table>

		</div>




		
	</div>

	<?php $this->load->view($this->template_name . "/template/footer");?>
	<script src="./static/js/admin/tag.js"></script>

</body>
</html>