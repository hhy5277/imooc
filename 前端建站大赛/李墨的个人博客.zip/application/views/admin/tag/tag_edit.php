	<link rel="stylesheet" href="./static/css/admin/class_craeat.css">
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 3));
	?>

	<div class="document">
		<div class="info-box header">
			<h2 class="fl">编辑标签 <span>Edit tag</span></h2>
		</div>
		<div class="form">
			<table>
				<tr><td><input  type="text"  placeholder="请这里输入标签的名字" id="js-tag-title" value='<?=$Tag_data['name']?>'></td></tr>
				<tr><td><input  type="text"  placeholder="请输入自定义地址" id="js-tag-link" value='<?=$Tag_data['link']?>'></td></tr>
				<tr><td><textarea  placeholder="请输入标签的描述" id="js-tag-description" value='<?=$Tag_data['description']?>'></textarea></tr>
				<tr><td>
					<div class="notice padding notLeft">
				    		<span>在此您可以编辑标签的相关数据</span>
				    	</div>
				</td></tr>
				<tr><td><button class="btn btn-success" id="success" onclick="edit_tag()"><i class="fa fa-edit"></i>编辑标签</button></td></tr>
			</table>

		</div>




		
	</div>
	<script type="text/javascript">id = <?=$Tag_data['id']?></script>
	<?php $this->load->view($this->template_name . "/template/footer");?>
	<script src="./static/js/admin/tag.js"></script>

</body>
</html>