</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 3));
	?>

	<div class="document">
		<form action="javascript:;" enctype="" id="js-article-create">
			<div class="info-box header noneborder">
				<h2 class="fl">标签管理 <span>Tag list</span></h2>
				<button class="btn btn-success fr" onclick="window.location.href=thisLoction+'/create'">
					<i class="fa fa-plus"></i>添加栏目
				</button>
				<button class="btn btn-danger fr">
					<i class="fa fa-trash"></i>
					删除选中
				</button>
			</div>
		</form>
			
		<div class="info-box noneborder">
			<table class="table list">
				<thead>
					<tr>
						<th><input type="checkbox"></th>
						<th>标签名称</th>
						<th>自定地址</th>
						<th>标签描述</th>
						<th>下属关键词</th>
						<th>父级分类</th>
						<th width="100">操作</th>
					</tr>
				</thead>

				<tbody>
					<?php
						foreach ($Tag_list as $value) {
							echo "<tr data-id='{$value['id']}'>
								<td><input type='checkbox'></td>
								<td>{$value['name']}</td>
								<td>{$value['link']}</td>
								<td>{$value['description']}</td>
								<td>" . count(json_decode($value['son_key'])). " 个</td>
								<td><a href='./class/" . $value['class']['link'] . "' target='_blank'>" . $value['class']['name'] . "</a></td>
								<td><i class='fa fa-edit' id='edit'></i><i class='fa fa-trash' id='delete'></i></td>
							</tr>";
						}
					?>
				</tbody>
			</table>
			<?php
				$this->load->view($this->template_name . "/template/page.php",array(
					"max_count" => $Tag_count,
				));
			?>
		</div>
	</div>



	<?php $this->load->view($this->template_name . "/template/footer");?>
	<script src="./static/js/admin/tag.js"></script>
</body>
</html>