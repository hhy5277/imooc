	<style>
		.form input , .form textarea{color:#888;}
		.btn{line-height: 0;height: 30px;}
	</style>
</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 6));
	?>
	<div class="document">
		<div class="info-box  header noneborder">
			<h2 class="fl">友情链接设置 <span>Friendship link</span> </h2>
		</div>
		<div class="info-box ">
			<table class="table list">
				<tr>
					<th width="20"><input type="checkbox"></th>
					<th width="220">友链名称</th>
					<th>友链链接</th>
					<th width="150">优先度</th>
					<th width="150">跳转方式</th>
					<th width="100">操作</th>
				</tr>
				{Friendship_link_list}
				<tr data-id="{id}">
					<td><input type="checkbox"></td>
					<td>{name}</td>
					<td><a href="{link}" target="_blank">{link}</a></td>
					<td>{priority}</td>
					<td>{type}</td>
					<td><i class="fa fa-edit" id="edit"></i><i class="fa fa-trash" id="delete"></i></td>
				</tr>
				{/Friendship_link_list}
			</table>
			<div class="footer">
				<table>
					<tr>
						<td>
							<button class="btn btn-success" style="" onclick="window.location.href=thisLoction + '/Friendship_create'"><i class="fa fa-plus"></i>添加友链</button>
							<button class="btn btn-danger" style=""><i class="fa fa-trash"></i>删除选中</button>
						</td>
						<td class="fr"><button class="btn btn-success" style="" disabled='disabled'>保存配置</button></td>
						<td class="fr"><span>呈现方式：</span><select name="" id=""  disabled='disabled'>
								<option value="">仅在首页显示</option>
								<option value="">全部页面显示</option>
								<option value="">仅文章不显示</option>
							</select>
						</td>
						<td class="fr"><div class="checkbox" style="position:relative;top:3px;"><label><input type="checkbox" checked="checked" disabled='disabled'> 启用友情链接功能</label></div></td>
					</tr>
				</table>
			</div>
		</div>

		<div class="info-box  header noneborder">
			<h2 class="fl">网站SEO设置 <span>seo</span> </h2>
		</div>
		<div class="info-box ">
			<table class="form" style="margin-left:0">
				<tr><td><input id="js-article-title" value="电脑医生网 - 最全的电脑基础知识，最有用的电脑软件教程，最有效的电脑维修知识" name="article_title" type="text"  placeholder="请输入网站的标题"></td></tr>
				<tr><td><input id="js-article-title" value="电脑基础知识,办公软件教程,电脑安全知识,电脑常用软件,电脑维修知识" name="article_title" type="text"  placeholder="请输入网站的关键词"></td></tr>
				<tr><td><textarea placeholder="请输入网站的描述">电脑医生网提供电脑入门知识,计算机基础知识学习。包括学电脑入门教程,电脑技巧,网络技术,办公软件,操作系统,视频教程等。让您快速掌握从入门到精通的电脑知识。</textarea></td></tr>
				<tr><td><button class="btn btn-success"><i class="fa fa-save"></i>保存上诉配置</button><button class="btn btn-danger"><i class="fa fa-user"></i>使用默认配置</button></td></tr>
			</table>

		</div>
		<div class="info-box  header noneborder">
			<h2 class="fl">LOGO设置 <span>logo</span> </h2>
		</div>
		<div class="info-box" style="padding:32px 20px">
			<i style="display: block; float: left;background-position: 0 0;width: 370px;height: 23px;background-image: url(./static/image/pcyisheng_map.png);"></i>
			<button class="btn btn-success" style="position: relative;left:20px;top:-14px;	"><i class="fa fa-upload"></i>更换图片</button>
		</div>
		<div class="info-box  header noneborder">
			<h2 class="fl">设置网站模板 <span>template</span> </h2>
		</div>
		<div class="info-box">
			<table class="form" style="margin-left:0">
				<tr><td><input id="js-article-title" value="pcyisheng" name="article_title" type="text"  placeholder="请输入网站的标题"></td></tr>
				<tr><td><input id="js-article-title" value="admin" name="article_title" type="text"  placeholder="请输入网站的标题"></td></tr>
			</table>
		</div>

		<div class="info-box  header noneborder">
			<h2 class="fl">404页面设置 <span>404</span> </h2>
		</div>
		<div class="info-box">
			<table class="form" style="margin-left:0">
				<tr><td><input id="js-article-title" value="errors/html/error_404" name="article_title" type="text"  placeholder="请输入网站的标题"></td></tr>
			</table>
		</div>

	</div>

	<script type="text/javascript">
		custom_edit = '/friendship_link_edit';
		function tableDelete(data){
			_api.admin.friendship_link.remove({
				"id" : data.articleId
			}).then(function(){
				window.location.reload();
			} , function(ERROR){
				eject.alert({content : ERROR , type : false});
				eject.close();
			})
		}
	</script>
	<?php $this->load->view($this->template_name . "/template/footer");?>
</body>
</html>