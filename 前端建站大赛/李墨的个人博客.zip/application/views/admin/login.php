	<link rel="stylesheet" href="./static/css/admin/login.css">
</head>
<body>

	<div class="box center" id="js-admin-login-box">
		<img src="./static/image/admin/logo.png" alt="">
		<form onsubmit="Login();return false;">
			<input type="text" placeholder="请输入管理员账号" maxlength="16" id="js-admin-username">
			<input type="password" placeholder="请输入管理员密码" maxlength="16" id="js-admin-password">
			<button href="javascript:;" type="submit" class="btn  btn-danger" id="js-admin-login">登录后台管理系统</button>
		</form>
	</div>

	<?php $this->load->view($template_file_name . '/template/footer.php');?>
	
	<script src="static/js/admin/login.js"></script>
	
</body>
</html>