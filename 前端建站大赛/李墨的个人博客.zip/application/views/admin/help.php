</head>
<body>
	<?php
		$this->load->view($this->template_name . "/template/top_header");
		$this->load->view($this->template_name . "/template/left_nav" , array("active" => 7));
	?>

	

	<?php $this->load->view($this->template_name . "/template/footer");?>
</body>
</html>