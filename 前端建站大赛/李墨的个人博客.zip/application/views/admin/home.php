	<link rel="stylesheet" href="./static/css/admin/home.css?12332">
</head>
<body>
    <?php
    	$this->load->view($this->template_name . "/template/top_header");
    	$this->load->view($this->template_name . "/template/left_nav");
    ?>
    <div class="document">
    	<div class="top_statistics">
    		<div class="box"><span class="content"><span class="number">1023</span><span class="type">今日访问PV</span></span></div>
    		<div class="box"><span class="content"><span class="number">1023</span><span class="type">今日访问UV</span></span></div>
    		<div class="box"><span class="content"><span class="number">1023</span><span class="type">近七日总PV</span></span></div>
    		<div class="box"><span class="content"><span class="number">1023</span><span class="type">近七日总UV</span></span></div>
    		<div class="box lost"><span class="content"><span class="number">1023</span><span class="type">近三十日总UV</span></span></div>
    	</div>

    	<!-- <div class="notice ">
    		<i class="fa fa-volume-up"></i>
    		<span>欢迎来到电脑医生后台管理系统，新版系统上线之初难免会有很多BUG，以及不足之处，如果您在日常使用中发现了问题或有什么建议，您可以发送email至tocurd@qq.com，向我们反馈意见或问题！</span>
    	</div>
 -->
    	<div class="info-box top-flot">
                            <!-- <div class="position-line"></div> -->
    			<div id="statsChart"></div>
    	</div>

    	<div class="user-list">
    		<div class="user-list-main">
    			<div class="title">
    				<h2>站内新闻</h2>
    			</div>
    		</div>
    			<table class="table">
    				<tr><td><img src="./static/image/admin/upload/pcyisheng.jpg" alt="" width="40"></td><td><h3>用几种方法实现table隔行改变颜色风格的技术_西西软件资讯</h3></td></tr>
    				<tr><td><img src="./static/image/admin/upload/pcyisheng.jpg" alt="" width="40"></td><td><h3>有一个table如何写样式才会形成隔一行一个颜色有一个table如何写样式才会形成隔一行一个颜色有一个table如何写样式才会形成隔一行一个颜色,添加类..._百度知道</h3></td></tr>
    				<tr><td><img src="./static/image/admin/upload/pcyisheng.jpg" alt="" width="40"></td><td><h3>JavaScript 操作table,可以新增行和列并且隔一行换背景色</h3></td></tr>
    				<tr><td><img src="./static/image/admin/upload/pcyisheng.jpg" alt="" width="40"></td><td><h3>jQuery实现table隔行换色和鼠标经过变色的两种方法</h3></td></tr>
    				<tr><td><img src="./static/image/admin/upload/pcyisheng.jpg" alt="" width="40"></td><td><h3>JavaScript 操作table,可以新增行和列并且隔一行换背景色代</h3></td></tr>
                                                                    <tr><td><img src="./static/image/admin/upload/pcyisheng.jpg" alt="" width="40"></td><td><h3>用几种方法实现table隔行改变颜色风格的技术_西西软件资讯</h3></td></tr>
    				<tr><td><img src="./static/image/admin/upload/pcyisheng.jpg" alt="" width="40"></td><td><h3>用几种方法实现table隔行改变颜色风格的技术_西西软件资讯</h3></td></tr>
    			</table>
    		<!-- 	<ul>
    				<li><h2>PCYISHENG</h2></li>
    			</ul> -->
    	</div>


    	<div class="info-box server-info">
    		<h2>硬盘信息 <span>disk info</span></h2>
    		<table class="info">
    			<tr><th width="70"></th><th width="220"></th><th width="100"></th><th width="40"></th></tr>
    			<tr><td>占用率 : </td><td>14GB / 40GB 35.5%</td><td>硬盘状态：</td><td>正常</td></tr>
    			<tr></tr>
    		</table>
    		<div class="progress" style="margin-top:15px;margin-left:8px;width:100%">
    			<div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 35.5%">
    				<span class="sr-only">45% Complete</span>
    			</div>
    		</div>
    	</div>
    	<div class="info-box server-info">
    		<h2>服务器信息 <span>server info</span></h2>
    <table class="info">
        <tr><th></th></tr>
        <tr><td>Cms 版本：</td><td>1.0 <a href="#" style="margin-left:15px">检查更新</a></td></tr>
        <tr><td>服务器IP：</td><td>112.124.43.1</td></tr>
        <tr><td>环境信息：</td><td>apache</td></tr>
        <tr><td>版本号：</td><td>5.1.2.3</td></tr>
        <tr><td>运行时长：</td><td>6 天 10 时 52 分</td></tr>
    </table>
    			
    			
    	</div>

    	<div class="info-box server-info">
    		<h2>文章信息 <span>article info</span></h2>
    <table class="info" width="100%">
        <tr><th width="170"></th></tr>
        <tr><td>今日文章浏览数：</td><td>0 篇</td></tr>
        <tr><td>七日文章浏览数：</td><td>0 篇</td></tr>
        <tr><td>三十日文章浏览数：</td><td>0 篇</td></tr>
        <tr><td>今日发布：</td><td>0 篇</td></tr>
        <tr><td>昨日发布：</td><td>0 篇</td></tr>
        <tr><td>总文章数：</td><td>0 篇</td></tr>
        
    </table>
    		
    	</div>
    </div>


    <?php $this->load->view($this->template_name . "/template/footer");?>
    <script src="./static/js/admin/flot/jquery.flot.js"></script>
    <script src="./static/js/admin/flot/jquery.flot.stack.js"></script>
    <script src="./static/js/admin/flot/jquery.flot.resize.js"></script>
    <script type="text/javascript" src="./static/js/admin/home.js"></script>
</body>
</html>