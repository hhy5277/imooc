	<link rel="stylesheet" href="./static/css/home/article.css">
<link class="codestyle" rel=" stylesheet" href="./static/bin/css/highlightjs-monokai-sublime.css">
</header>

<body>
<div class="wrapper">
	<?php $this->load->view($default_template . "/widget/left_nav" , array(
		"class_active_index" => $Article_data['form_class']['id']
	));$this->load->view($default_template . "/widget/top_header" , array(
		"show_header_image" => FALSE , 
	))?>
	<div class="warpper-right" >
		<?php $this->load->view($default_template . "/widget/nav")?>
		<div class="article">
			<div class="article-view">
				<div class="article-header">
					<h1><?=$Article_data['title']?></h1>
					<div class='article-data'>
						<ul>
							<li><i class='fa fa-clock-o'></i><span>发表于：<?=$Article_data['time']?> （<?=date("m月d日",$Article_data['time_'])?>）</span></li>
							<li><i class='fa fa-bars'></i><span><?=$Article_data['form_class']['name']?></span></li>
							<li><i class='fa fa-tags'></i><span><?=$Article_data['form_tag']['name']?></span></li>
							<li><i class='fa fa-user'></i><a href='javascript:void()'>李墨丶</a></li>
							<li><i class='fa fa-eye'></i><span>0 次</span></li>
							<li><i class='fa fa fa-thumbs-o-up'></i><span>0 次</span></li>
						</ul>
					</div>
				</div>
				<div class="article-content">
					<?=$Article_content_data['article_content']?>
				</div>
			</div>
		</div>
	</div>
	<?php $this->load->view($default_template . "/template/footer") ?>
	<script src="./static/bin/js/highlight.min.js"></script>
	<script src="./static/js/home/home.js"></script>
	<script>hljs.initHighlightingOnLoad();</script>
</body>
</html>