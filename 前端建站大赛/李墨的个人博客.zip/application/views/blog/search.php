	<link rel="stylesheet" href="./static/css/home/home.css">
<link class="codestyle" rel=" stylesheet" href="./static/bin/css/highlightjs-monokai-sublime.css">
</header>

<body>
<div class="wrapper">
	<?php $this->load->view($default_template . "/widget/left_nav" , array(
		"class_active_index" => @$Tag_data['class_data']['id']
	));$this->load->view($default_template . "/widget/top_header" , array(
		"show_header_image" => false , 
	))?>

	<div class="warpper-right" >
		<?php $this->load->view($default_template . "/widget/nav")?>
		<div class="article">
			<div class='article_list class_header search_header'>
				<h2><i class="fa fa-search"></i>搜索结果</h2>
				<p class="search_query"><?=$max_page > 0 ? "搜索完成，共找到 ".$max_page." 个相关的搜索结果" : '很抱歉，没有搜索到您要查询的内容，请检查您的关键词是否输入正确'?></p>
			</div>
				<?=$max_page > 0 ? "<div class='article_list list'>" : ''?>
				<?php
					if($max_page > 0){
						foreach ($Article_list as $key => $value) {
							if($value['title'] != "") echo "<a href='./act/{$value['article_byid']}.html'><h2 class='title'>{$value['title']}<span class='fr'>{$value['time']}</span></h2></a>";
						}
					}
				?>
				<?=$max_page > 0 ? "</div>" : ''?>
			
			<?php
				$this->load->view($default_template . "/widget/page" , array(
					"max_page" => ceil($max_page / 10),
					"page" => $page
				));
			?>

			
			
		</div>
	</div>

	<?php $this->load->view($default_template . "/template/footer") ?>
</body>
</html>