	<link rel="stylesheet" href="./static/css/home/home.css">
<link class="codestyle" rel=" stylesheet" href="./static/bin/css/highlightjs-monokai-sublime.css">
</header>

<body>
<div class="wrapper">
	<?php $this->load->view($default_template . "/widget/left_nav" , array(
		"class_active_index" => $Class_data['id']
	));$this->load->view($default_template . "/widget/top_header" , array(
			"show_header_image" => false , 
	))?>
	<div class="warpper-right">
		<?php $this->load->view($default_template . "/widget/nav")?>
		<div class="article">
			<div class='article_list class_header'>
				<h2><i class="fa fa-list"></i><?=strtoupper($Class_data['name'])?></h2>
				<ul class="key_list">
					<?php
						foreach ($Class_data['son_tag'] as $key => $value) {
							if(@$value["name"] != "") echo '<li><a href="./tag/' . ($value["link"] != "" ? $value["link"] : $value["name"]) .'">' . $value["name"] .'</a></li>';
						}
					?>
				</ul>
			</div>
			<?php
				$this->load->view($default_template . "/widget/Article_list" , array('Article_list' => $Article_list));
				$this->load->view($default_template . "/widget/page" , array(
					"max_page" => ceil($max_page / 10),
					"page" => $page
				))
			?>
			
		</div>
	</div>

	<?php $this->load->view($default_template . "/template/footer") ?>
</body>
</html>