	<link rel="stylesheet" href="static/css/home/works.css">
</header>

<body>
	<div class="wrapper">
		<?php $this->load->view($default_template . "/widget/left_nav" , array(
			"class_active_index" => 2
		));$this->load->view($default_template . "/widget/top_header" , array(
			"show_header_image" => true , 
			"active_name" => "Works"
		))?>
		<div class="warpper-right" >
			<?php $this->load->view($default_template . "/widget/nav")?>
			<div class="work_nav">
				<ul>
					<li class="active-a"><a href="">全部作品</a><i class="active"></i></li>
					<li><a href="">电脑页面</a></li>
					<li><a href="">手机页面</a></li>
					<li><a href="">web组件</a></li>
					<li><a href="">摄影欣赏</a></li>
					<li><a href="">其他作品</a></li>
				</ul>
			</div>
			<div class="content">
				
			</div>
			<div class="loading" id="js-loading">
				<i class="fa fa-spinner fa-spin"></i>数据正在加载中，请稍等片刻.....
			</div>
		</div>




	</div>
	<script>
		var Class = {
			id : <?=$Class_data['id']?>
		}
	</script>
	<?php $this->load->view($default_template . "/template/footer" , array('show_footer' => false)) ?>
	<script type="text/javascript">
		(function(){
			$work_nav = $(".work_nav");
			$work_nav.on('mouseover', 'li', function(event) {
					$work_nav.find(".active-a a").css({
						color : "#aaa"
					})
					$work_nav.find(".active-a .active").css({
						left : ($(this).offset().left - $work_nav.offset().left) - 10 + "px"
					})
					$(this).find("a").css({
						color : "#fff"
					})
			}).on('mouseout', 'li', function(event) {
				setTimeout(function(){
					$work_nav.find("a").css({
						color : "#aaa"
					})	
					setTimeout(function(){
						$work_nav.find(".active-a a").css({
							color : "#fff"
						})
					} , 200)
					$work_nav.find(".active-a .active").css({
						left : "0px"
					})
				} , 0)
			});
		})()




		var default_config = {
			'column' : 4 , 
			'box_padding' : 0,
			'left_margin' : 13, 
			'top_margin' : 25 , 
			'animate_time' : 300 ,
			'father_element' : '.content',
			'box_name' : '.article_list' , 
			'box_content_name' : '.work_content' , 
		};

		get_data().done(function(data) {
			waterfall(data , default_config);
		});
		function get_data(){
			return $.ajax({
				url: './api/get_data',
				type: 'post',
				dataType: 'JSON',
				data: {
					class_id : Class.id , 
					page : 1
				}
			})
		}


		

		var sizeOutTime = false , 
			page = 1;


		$loading = $("#js-loading");
		$(window).scroll(function(){
			page ++;
			if(sizeOutTime == false){
				sizeOutTime = true
				if(is_show($loading)){
					$.ajax({
						url: './api/get_data',
						type: 'post',
						dataType: 'JSON',
						data: {
							class_id : Class.id , 
							page : page
						}
					}).done(function(data) {
						if(data.STATE === false){
							$loading.empty();
						}else{
							waterfall(data , default_config);
						}
					})
				}
				setTimeout(function(){
					sizeOutTime = false
				} , 10)
			}
		})
		function is_show($Element){
			return $(window).scrollTop() > $Element.offset().top - $($Element).outerHeight() - $(window).height()
		}

		/**
		 * 瀑布流组件
		 * @param  {[type]} article_data [文章列表数据]
		 * @param  {[type]} Config       [array]
		 * @param  {[type]} Config   -	column 				栏目数量
		 * @param  {[type]} Config   -	box_padding 			盒子的padding
		 * @param  {[type]} Config   -	left_margin 			距离左侧盒子的高度
		 * @param  {[type]} Config   -	top_margin 			距离上一盒子的高度
		 * @param  {[type]} Config   -	animate_time 			动画时长
		 * @param  {[type]} Config   -	father_element 		栏目数量
		 * @param  {[type]} Config   -	box_name 				盒子名称
		 * @param  {[type]} Config   -	box_content_name 	内容盒子名字
		 * @return {[type]}              [description]
		 */
		function waterfall(article_data , Config){
			var $Element = $(Config.father_element) , 
				$Box = $Element.find(Config.box_name) , 
				left_index = 0 , 
				array_index = 0 , 
				image_height = 0 , 
				artcile_top = 0 , 
				temp_height = 0;
			box_width = (($Element.outerWidth() / Config.column) - (Config.box_padding * 2) - (Config.left_margin)) - Config.left_margin / 2;
			for (var sum =  $Box.length;sum < $Box.length + article_data.length;sum ++) {

				if(left_index >= Config.column){
					temp_height = 0;
					left_index = 0;
				}
				array_index = sum - $Box.length;
				if(parseInt(article_data[array_index].height) <= 0){
					image_height= 0;
				}else{
					image_height = parseInt(article_data[array_index].height) / (article_data[array_index].width / box_width);
				}
		 		if(sum >= Config.column){
		 			artcile_top = $Element.find(Config.box_name).eq(sum - Config.column).attr('data-height');
		 			this_height = image_height + parseInt(artcile_top);
		 		}
		 		content = '<div class="work_content"><a href="./article/' +article_data[array_index].article_byid+ '.html"><h1 class="article_title">' + article_data[array_index].title + '</h1>';
		 		content += '<p class="article_description">' + article_data[array_index].content + '</p></a>';
		 		content += '<div class="work_bottom"><ul>';
		 		key = JSON.parse(article_data[array_index].article_key);
		 		for (var index=0;index < key.length;index++) {
		 			content += '<li><a href="./tag/'+key[index]+'".html>'+key[index]+'</a></li>';
		 		}
		 		content += '</ul></div>';
		 		content += '</div>';

				var $value = $('<div class="article_list' + (left_index != 0 ? " on" : "") + '" >')
				.append(image_height <= 0 ? "" : '<a href="./article/' +article_data[array_index].article_byid+ '.html"><img src="./static/upload/' + article_data[array_index].article_photo_name + '" height="' +image_height + '" width="'+box_width+'"></a>')
				.append(content)
				.css({
					width : box_width , 
					left : ((box_width + Config.left_margin + (Config.box_padding * 2)) * left_index), 
				}).animate({
					"top" : parseInt(artcile_top) + parseInt(Config.top_margin * Math.floor(sum / Config.column)) + "px"
				} , Config.animate_time)
				.appendTo($Element);
				height = Math.floor($value.find('.work_content').outerHeight() + (sum < Config.column ? image_height : this_height));
				if(height === NaN) height = 0;
				$value.attr('data-height' , height)
				left_index ++;
				height = parseInt(artcile_top) + parseInt(Config.top_margin * Math.floor(sum / Config.column)) + image_height + $value.find('.work_content').outerHeight() ;
				temp_height > height ? temp_height = temp_height : temp_height = height;
			}
			$Element.height(temp_height + 50);

			// 注册窗口监控事件
			$(window).resize(function(event){
				if(sizeOutTime === false){
					sizeOutTime = true;
					var width = $(this).width();
					var height = $(this).height();
					$Element.find(Config.box_name).width((($Element.outerWidth() / Config.column) - (Config.box_padding * 2) - (Config.left_margin)) - Config.left_margin / 2);
					setTimeout(function(){
						sizeOutTime = false;
					});
				}
			});

		}


		



	</script>
</body>
</html>