	<link rel="stylesheet" href="./static/css/home/about.css">
</header>
<body>
	<?php $this->load->view($default_template . "/widget/left_nav");
	$this->load->view($default_template . "/widget/top_header" , array(
		"show_header_image" => false , 
		"active_name" => "About"
	))?>

	<div class="warpper-right">
		<div class="top-header" id="js-top-header">
			<img src="./static/image/element/277719_3ff11369637794584699a462c96c1.jpg" alt="">
			<div class="top-header-after">
				<div class="top-header-center">
					<h1>匠心精神，引以为傲</h1>
					<p>我们要保留我们最珍贵的，最引以为傲的</p>
					<p>专注做点东西，至少对得起光阴岁月，其他的就留给时间去说吧</p>
				</div>
			</div>
		</div>
		<div class="data">
			<div class="user-data" id="js-user-data">
				<div class="wrapper">
					<img src="./static/image/element/me_2.jpg" alt="">
					<div class="user">
						<table>
							<tr>
								<td><h2>李墨</h2></td>
								<td><span>(tocurd)</span></td>
								<td><span>(tocurd)</span></td>
							</tr>
						</table>
						
						<p>专注做点东西，至少对得起光阴岁月，其他的就留给时间去说吧</p>

					</div>


				</div>
			</div>
			<!--   -->
			<div class="wrapper base">
				<h2 class="header-title">
					<i class="fa fa-list"></i>基础资料 <span>/ Receive education </span>
				</h2>
				<div class="content">
					<table>
						<tr><td>姓名：郭梦琪</td><td>出生年月：1996年1月26日</td><td>工作经验：半年</td><td>学历：在读大专</td></tr>
					</table>
				</div>
			</div>
			<div class="wrapper">
				<h2 class="header-title">
					<i class="fa fa-list"></i>技能标签 <span>/ Receive education </span>
				</h2>
				<div class="content">
					<ul>
						<li><div class="tag">Codeigniter</div></li>
						<li><div class="tag">Less</div></li>
						<li><div class="tag">Sass</div></li>
						<li><div class="tag">Jquery</div></li>
					</ul>
				</div>
			</div>
			<div class="wrapper skills">
				<h2 class="header-title">
					<i class="fa fa-code"></i>掌握技能 <span>/ Possess skills </span>
				</h2>
				<div class="content">
					<table width="100%;">
						<tr><td width="130"></td></tr>
						<tr><td><h3>HTML/CSS</h3></td><td><div class="progress"><span>95% <strong>熟练</strong></span><div class="progress-content" data-width="95" style="background-color: #5cb85c"></div></div></td></tr>
						<tr><td><h3>javascript</h3></td><td><div class="progress"><span>75% <strong>熟练</strong></span><div class="progress-content" data-width="75" style="background-color: #5cb85c"></div></div></td></tr>
						<tr><td><h3>PHP</h3></td><td><div class="progress"><span>65% <strong>掌握</strong></span><div class="progress-content" data-width="65" style="background-color: #5bc0de"></div></div></td></tr>
						<tr><td><h3>html5/css3</h3></td><td><div class="progress"><span>45% <strong>掌握</strong></span><div class="progress-content" data-width="45" style="background-color: #5bc0de"></div></div></td></tr>
						<tr><td><h3>Photoshop</h3></td><td><div class="progress"><span>40% <strong>熟悉</strong></span><div class="progress-content" data-width="40" style="background-color: #d9534f"></div></div></td></tr>
						<tr><td><h3>Android</h3></td><td><div class="progress"><span>20% <strong>熟悉</strong></span><div class="progress-content" data-width="20" style="background-color: #d9534f"></div></div></td></tr>
					</table>
				</div>
			</div>

			<div class="wrapper">
				<h2 class="header-title">
					个人经历 <span>/ Personal experience </span>
				</h2>
				<div class="content">
					<div class="list-view">
						<div class="list-view-left">
							<p class="time">2014年8月 - 2015年3月</p>
							<p class="type">微信活动运营</p>
						</div>
						<div class="list-view-right">
							<p class="list-view-title">济宁悦读传媒责任有限公司</p>
							<p class="list-view-description">负责公司日常活动运营，制作日常活动所需要的微信端网页界面。协助公司运营众多公众号活动如“济宁圈”、“教子有方”、“育儿亲子百科”等，曾开发并运营过“最美宝宝”投票、微信贺卡、济宁圈信息交易平台....。在职期间表现优异，后因个人原因离职</p>
						</div>
					</div>

					
				</div>

			</div>

			<div class="wrapper ">
				<h2 class="header-title">
					接受教育 <span>/ Receive education </span>
				</h2>
				<div class="content">
					<div class="list-view">
						<div class="list-view-left">
							<p class="time">2012年9月 - 直到今日</p>
							<p class="type">计算机应用（专科）</p>
						</div>
						<div class="list-view-right">
							<p class="list-view-title">山东理工职业学院</p>
							<p class="list-view-description">在校期间表现优异，曾获得一等奖学金1次，三等奖学金两次，优秀班级干部及三好学生等殊荣。在校期间曾参与学院创业项目并获得了优异的成果。</p>
						</div>
					</div>
				</div>
			</div>

			<div class="wrapper about">
				<h2 class="header-title">
					开发大型项目 <span>/ Development project </span>
				</h2>

				<div class="content">
					<div class="list-view">
						<div class="list-view-left">
							<p class="time">2014年12月 - 次年1月</p>
							<p class="type">个人独立开发</p>
						</div>
						<div class="list-view-right">
							<p class="list-view-title">电脑医生网</p>
							<p class="list-view-description"><a href="http://pcyisheng.com ">pcyisheng.com </a>电脑医生网提供电脑入门知识,计算机基础知识学习。包括学电脑入门教程,电脑技巧,网络技术,办公软件,操作系统,视频教程等。让您快速掌握从入门到精通的电脑知识。</p>
						</div>
					</div>
					<div class="list-view">
						<div class="list-view-left">
							<p class="time">2015年8月 - 2015年9月</p>
							<p class="type">前端设计与后端开发</p>
						</div>
						<div class="list-view-right">
							<p class="list-view-title">天地君道官方网站</p>
							<p class="list-view-description"><a href="http://tiandipeixun.com/">tiandipeixun.com</a>天地君道培训是国内最专业的游戏开发在线教育平台。天地君道培训提供了丰富的适用于零基础学习游戏开发及IT职业技能的在线直播课程。课程内容涵盖多个热门技术方向，例如Unity3D、Cocos2dx、Android、iOS、HTML5等。天地君道培训同时推出的秒答、在线课堂、学习印记和精英汇让编程学习更轻松，学完就业有保障。用编程实现梦想！</p>
						</div>
					</div>

					<div class="list-view">
						<div class="list-view-left">
							<p class="time">2015年8月 - 2015年9月</p>
							<p class="type">前端设计与后端开发</p>
						</div>
						<div class="list-view-right">
							<p class="list-view-title">天地君道秒问秒答</p>
							<p class="list-view-description"><a href="http://91miaoda.com ">91miaoda.com </a>秒答是国内首个针对零基础初学者学习编程的编程社区。在这里你能提问Unity3D、Web、Cocos2D-X等热门编程领域的问题。每个问题都能被快速准确地解答，绝不留着难题过夜。让编程初学者不再走弯路，想提升编程学习效率，上秒答，就对了。</p>
						</div>
					</div>


					<div class="list-view">
						<div class="list-view-left">
							<p class="time">2015年12月 - 次年4月</p>
							<p class="type">独立开发</p>
						</div>
						<div class="list-view-right">
							<p class="list-view-title">Cloud Cms 管理系统</p>
							<p class="list-view-description">可以方便管理网站前端的文章，测试账号admin 测试密码admin</p>
						</div>
					</div>
				</div>
			</div>
		</div>






	</div>
	<?php $this->load->view($default_template . "/template/footer" , array('show_footer' => false)) ?>

	<script type="text/javascript">
		setTimeout(function(){
			$("#js-top-header").find('img').addClass('img_hover');
		} , 500);
		(function(){
			$.each($(".progress-content") , function(key , value){
				$(value).animate({
					width : $(value).data('width')+"%"
				} , ($(value).data('width') * (key + 1)) * 10)
			})

			var $user_data = $("#js-user-data") , 
				type = false
			$(window).scroll(function(event){
				var this_top = $(window).scrollTop();
				if(this_top > 260 && type == false){
					$(".data").css({"marginTop" : 380})
					$user_data.css({
						position: 'fixed',
						top: '0',
						"z-index" : 1025 ,
					});
					$user_data.find("p").animate({
						"margin-left" : "100px"
					},300)
					$user_data.find("h2 , p").animate({
						"margin-left" : "0"
					},500)
					$user_data.find("img").animate({
						top : "1px" , 
					} , 100).css({
						width : 70
					})
						$user_data.find("img").css({
							position : "relative" , 
						})
					type = true;
				}

				if(this_top < 260 && type == true){
					$(".data").css({"marginTop" : 270})
					type = false;
					$user_data.css({
						position: 'relative',
						top: '0',
					}).find("img").css({
						position : "absolute" , 
						top : "-60px",
						width : 150
					});
					$user_data.find("h2 , p").animate({
						"margin-left" : "180px"
					})
				}
			});
			


		})()
	</script>
</body>
</html>

