<?php
	$url = "./"  ;
	if($max_page > 1){
		echo '<div class="widget-page"><ul>';
		echo $page > 1 ? "<li><a href='{$url}?page=" . ($page - 1) . "'>上一页</a></li>" : "";
		for($index = 1;$index < $max_page + 1;$index ++) {
			echo '<li><a href="' . $url . '?page=' . $index . '" class="' . ($page == $index ? 'active' : '') . '">' . $index . '</a></li>';
		}
		echo ($page < $max_page ? "<li><a href='{$url}?page=" . ($page + 1) . "'>下一页</a></li>" : "") . '</ul></div>';
	}