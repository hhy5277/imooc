<div class="nav <?=!isset($show_header_image) || $show_header_image == true ? '' : 'none-header	'?>">
	<ul>
		<li><a href="" title="首页"><i class="fa fa-home"></i>Home</a></li>
		<li><a href="./" title="博客"><i class="fa fa-newspaper-o"></i>Blog</a></li>
		<li><a href="./about" title="简介"><i class="fa fa-bars"></i>About</a></li>
		<?php
			foreach ($Class_list as $key => $value) {
				if($value['type'] == 1) 
					echo '<li><a href="./' . $value['link'] . '" class="' . ($value['name'] == @$active_name ? "active" : "") . '" title="' . $value['name'] . '"><i class="fa ' . $value['icon'] . '"></i>' . $value['name'] . '</a></li>';
			}
		?>
		<div class="search">
			<input type="text" placeholder="在此处输入您要搜索的文章关键词" value="<?=isset($_GET['search']) ? $this->input->get('search') : ''?>" id="js-search-text">
			<div class="submit" id="js-search-button">
				<i class="fa fa-search"></i>
				搜索
			</div>
		</div>
	</ul>
</div>