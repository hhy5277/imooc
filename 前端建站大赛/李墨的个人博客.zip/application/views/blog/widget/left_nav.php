<div class="warpper-left">
	<div class="about">
		<img src="./static/image/element/me.jpg" alt="">
			<ul class="about-list">
				<li><a href="https://github.com/Tocurd" target="_blank"><i class="fa fa-github"></i></a></li>
				<li><a href="http://weibo.com/u/3740666764" target="_blank"><i class="fa fa-weibo"></i></a></li>
				<li><i class="fa fa-weixin"></i>
					<img src="./static/image/element/code.jpg" alt="" class="Qrcode">
				</li>
			</ul> 
		<h2 class="name">李墨 <span>Tocurd</span></h2>
		<p class="description">世上没有不可能的事，而我们只是缺少一颗坚持不懈走在正道上的决心。</p>
	</div>
	<ul class="class-list">
		<li><h2><i class="fa fa-list"></i>目录</h2></li>
		<li><a href="./" class="background <?=isset($class_active_index) ? '' : "active"?>">最新发布</a></li>
		<?php
			foreach ($Class_list as $key => $value) {
				if($value['type'] == 0){
					$active = $value['id'] == @$class_active_index ? 'active' : '';
					echo "<li><a href='{default_class_controller}/{$value['link']}' class='{$active}' background=''>{$value['name']}</a></li>";
				}
			}
		?>
	</ul>
</div>