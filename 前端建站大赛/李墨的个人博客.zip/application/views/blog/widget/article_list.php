<?php
foreach ($Article_list as $key => $value) {
	if($value['title'] != ""){
		echo "<div class='article_list'>";
		echo "<a href='act/{$value['article_byid']}.html' title='{$value['title']}'>
				<h2 class='title'>
					{$value['title']}
					<span>" . date("M d" , $value['time_']) . "</span>
				</h2>
				<p class='descriptiopn'>";
		if($value['article_type'] === "1" || $value['article_type'] === "999"){
			if($value['article_photo_name'] != "-1.jpg")
			echo "<img src='./static/upload/0_" . str_replace(".jpg", "_thumb.jpg", $value['article_photo_name']) . "' class='img_top' alt='{$value['title']}' />";
		}else{
			if($value['article_photo_name'] != "-1.jpg")
			echo "<img src='./static/upload/1_" . str_replace(".jpg", "_thumb.jpg" , $value['article_photo_name']) . "' alt='{$value['title']}'/>";
		}

		echo "{$value['content']}<ul class='key_list'>";
		foreach (json_decode($value['article_key'] , true) as $data) {
			echo "<li><a href='./tag/{$data}'>{$data}</a></li>";
		}
		echo "</ul></p></a><div class='bottom'>
				<ul>
					<li><i class='fa fa-clock-o'></i><span>{$value['time']} （" . date("m月d",$value['time_']) . "）</span></li>
					<li><i class='fa fa-th-list'></i><a href='{$default_class_controller}/{$value['form_class']['link']}' title='{$value['form_class']['name']}'>{$value['form_class']['name']}</a></li>
					<li><i class='fa fa-tag'></i><a href='{$default_tag_controller}/" . ($value['form_tag']['link'] === "" ? $value['form_tag']['name'] : $value['form_tag']['link']) . "'  title='{$value['form_tag']['name']}'>{$value['form_tag']['name']}</a></li>
					<li class='user'><i class='fa fa-user'></i><a href='javascript:void()'>李墨丶</a></li>
					<li class='fr'><i class='fa fa-eye'></i><span>0 °C</span></li>
					<li class='fr'><i class='fa fa fa-thumbs-o-up'></i><span>0 次</span></li>
				</ul>
			</div>";
		echo "</div>";
	}
}