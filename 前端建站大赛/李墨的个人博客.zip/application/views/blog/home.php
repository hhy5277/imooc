	<link rel="stylesheet" href="./static/css/home/home.css">
</header>

<body>

	<div class="wrapper">
		<?php $this->load->view($default_template . "/widget/left_nav") ?>
		<?php $this->load->view($default_template . "/widget/top_header") ?>
		<div class="warpper-right">
			<?php $this->load->view($default_template . "/widget/nav") ?>
			<div class="article">
				<?php
					$this->load->view($default_template . "/widget/Article_list" , array('Article_list' => $Article_list));
					$this->load->view($default_template . "/widget/page" , array(
						"max_page" => ceil($max_page / 10),
						"page" => $page
					))
				?>
			</div>
		</div>
	</div>
	<?php $this->load->view($default_template . "/template/footer" , array(
		'show_footer_link' => true
	)) ?>
	
</body>
</html>