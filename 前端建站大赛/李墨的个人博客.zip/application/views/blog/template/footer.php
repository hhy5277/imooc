<?php
	if(isset($show_footer_link)){
?>
<div class="article_list friend-link">
	<h4>友情连接：</h4>
	<ul class="key_list">
		<?php
			foreach ($Friendship_link_list as $key => $value) {
				echo '<li><a href="' . $value['link'] . '" target="_blank">' . $value['name'] . '</a></li>';
			}
		?>
	</ul>
</div>
<?php } if( ! isset($show_footer)){ ?>
<div class="footer no-friend-link">
	<div class="footer-content">
		<table width="100%">
			<tr>
				<td class="fl list" width="400">
					<ul>
						<a href=""><i class="fa fa-map"></i>博客地图</a>
						<a href=""><i class="fa fa-code"></i>博主作品</a>
						<a href=""><i class="fa fa-bars"></i>博主经历</a>
						<a href=""><i class="fa fa-user"></i>博主介绍</a>
						<li></li>
					</ul>
					<p class="description">欢迎来到李墨的博客，该博客专注分享最有用WEB前端知识，最前沿的WEB前端技术，最好玩WEB前端资讯</p>
					<p>Copyright © 2015 - 2016 LIMO. All Rights Reserved 
						<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1257424119'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s11.cnzz.com/z_stat.php%3Fid%3D1257424119%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script>
						<script>
							var _hmt = _hmt || [];
							(function() {
							  var hm = document.createElement("script");
							  hm.src = "//hm.baidu.com/hm.js?ff75dd674e631a70b7d781cc2c89ae3b";
							  var s = document.getElementsByTagName("script")[0]; 
							  s.parentNode.insertBefore(hm, s);
							})();
						</script>


				</p>
					
				</td>
				<td class="fr left"><h3>微信二维码<span>（李墨）</span></h3><p>这个世上根本没有什么不可能的事情，我们只是缺少那么一颗坚持不懈走在正道上的决心</p></td>
				<td class="fr"><img src="./static/image/element/code.jpg" alt="" class="Qrcode"></td>
		
			</tr>
		</table>
		
	</div>
</div>
<?php } ?>
<div class="up_top fr">
	<i class="fa fa-arrow-up"></i>
</div>


<?php
	switch($this->agent->browser()) {
	    case 'Opera':
	    case 'Chrome':
	    case 'Firefox':
	    case 'Safari':
	        echo '<script src="static/js/jquery-2.1.4.min.js"></script>';
	        break;
	    default:
	        echo '<script src="static/js/jquery-1.11.3.min.js"></script>';
	        break;
	}
?>
<script src="static/js/home/base.js"></script>
