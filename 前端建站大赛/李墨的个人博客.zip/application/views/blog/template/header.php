<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>{title}</title>
	<meta name="description" content="{description}">
	<meta name="keywords" content="{keyword}">
	<base href="<?=base_url();?>">
	<link rel="stylesheet" href="./static/css/base.css">
	<link rel="stylesheet" href="./static/bin/css/font-awesome.min.css">
