

  /*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50545
Source Host           : localhost:3306
Source Database       : exam

Target Server Type    : MYSQL
Target Server Version : 50545
File Encoding         : 65001

Date: 2016-01-04 22:32:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_class`
-- ----------------------------
DROP TABLE IF EXISTS `t_class`;
CREATE TABLE `t_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_class
-- ----------------------------
INSERT INTO `t_class` VALUES ('1', '20150819');
INSERT INTO `t_class` VALUES ('2', '20150309');

-- ----------------------------
-- Table structure for `t_question`
-- ----------------------------
DROP TABLE IF EXISTS `t_question`;
CREATE TABLE `t_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(2000) DEFAULT NULL,
  `answer` char(4) DEFAULT NULL,
  `optiona` varchar(200) DEFAULT NULL,
  `optionb` varchar(200) DEFAULT NULL,
  `optionc` varchar(200) DEFAULT NULL,
  `optiond` varchar(200) DEFAULT NULL,
  `degree` int(1) DEFAULT NULL,
  `subjectId` int(11) DEFAULT NULL,
  `teacherId` int(11) DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ow2cdvkdtg34kh7wgipl8dsp6` (`subjectId`),
  CONSTRAINT `FK_ow2cdvkdtg34kh7wgipl8dsp6` FOREIGN KEY (`subjectId`) REFERENCES `t_subject` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_question
-- ----------------------------
INSERT INTO `t_question` VALUES ('1', '下列选项中关于java中this关键字的说法错误的是() ', 'B', 'this关键字是在对象内部指代对象自身的引用', 'this关键字可以在类中的任何位置使用', 'this只和特定的对象关联，而不是和类关联', '同一个类的不同对象有不同的this', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('2', '在Java中,关于分层开发的有点描述错误的是()（选择一项） ', 'A', '每一层专注于自己功能的实现,层与层之间不易实现数据传递', '便于分工协作,从而提高效率', '便于代码复用', '便于程序扩展', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('3', '在Java中,下列关于读写文件的描述错误的是()（选择一项） ', 'B', 'Reader类的read()方法用来从源中读取一个字符的数据', 'Reader类读取文件时可以不用关闭流', 'Writer类的write(int n)方法用来向输出流写入单个字符', 'Writer类的write(String str)方法用来向输出流写入一个字符串', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('4', '在Java中，已有public int sum(){return 0;}方法，在同一个类中，以下不能与此方法构成重载的是（）。\r\n', 'C', 'public void sum(int start,int end){return 10;}', 'public void sum(int start){return 10;}', ' public double sum(){return 10;}', 'public int sum(double start){return 10;}', '3', '1', '1', null);
INSERT INTO `t_question` VALUES ('5', '在java中，以下关于构造方法描述错误的是（）\r\n', 'A', '构造方法的返回类型只能是void', '构造方法是类的一种特殊方法，它的方法名必须与类名相同。', ' 构造方法的主要作用是完成对象的初始化工作', ' 一般创建新对象时，系统会自动调用构造方法。', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('6', 'java中的InputStream类和Reader类的子类都属于（） ', 'A', '输入流', '输出流', '输入/输出流 ', ' 以上说法都不对', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('7', '在JAVA中，下列选择可以存储无序，不重复的数据的是（） ', 'D', 'ArrayList', 'LinkedList', 'HashMap ', ' Set', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('8', '下列选项中关于java中this关键字的说法错误的是() ', 'B', 'this关键字是在对象内部指代对象自身的引用', 'this关键字可以在类中的任何位置使用', 'this只和特定的对象关联，而不是和类关联', '同一个类的不同对象有不同的this', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('9', '字符流是以()传输数据的 ', 'C', '1个字节', '8位字符', '16位Unicode字符', '1比特', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('10', '以下声明()是对BufferedReader的正确声明。', 'A', 'BufferedReader(Reader in);', 'BufferedReader(String encoding,InputStream in);', 'BufferedReader(String encoding,File f);', 'BufferedReader(File f);', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('11', '下面哪些不是Thread类的方法（） ', 'C', 'start()', 'run()', 'exit()', 'getPriority()', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('12', '0.6332的数据类型是（）', 'B', 'float', 'tdouble', 'Float', 'Double', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('13', '在Java程序中，包含以下代码，则程序运行结果正确的是() ', 'B', '编译时发生错误', '正确运行，输出:str1', '正确运行,输出:str2', '运行时引发一次', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('14', '对于以下Java代码的运行结果描述正确的是()。', 'C', '程序运 行100次，分别输出0到99', '程序运行101次，分别输出0到100', '程序编译 错误', '程序可能出现死循环', '3', '1', '1', null);
INSERT INTO `t_question` VALUES ('15', '下列选项中关于Java中super关键字的说法正确的是（）。 ', 'A', 'this关键字是在对象 内部指代对象自身的引用', 'super关键字不仅可以指代子类的直接父类，还可以指代父类的父类。', '子类通过super关键字只能调用父类的方法，而不能调用父类的属性。', '子类通过super关键字只 能调用父类的属性，而不能调用父类的方法。', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('16', '以下选项中关于持久化的说法错误的是() ', 'B', 'A) 持久化是相对瞬时化,短暂化而言的', 'B) 把数据保存到文本文件中不属于持久化', 'C) 把数据保存到数据库中属于持久化', 'D) 持久化主要操作包括保存，删除，修改。', '3', '1', '1', null);
INSERT INTO `t_question` VALUES ('17', '以下声明()是对BufferedReader的正确声明。', 'B', 'BufferedReader(Reader in)', 'BufferedReader(String encoding,InputStream in);', 'BufferedReader(String encoding,File f);', 'BufferedReader(File f);。', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('18', '（）方法可以用来清空流。', 'C', 'void release()', 'void close()', 'void Remove()', 'void flush()', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('19', '在Java中，以下不是多态实现条件的是()。', 'C', ' 要实现多态必然要有接口', '继承的存在', '子类重写父类的方法', '父类引用变量指向子类的对象', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('20', '下列不可作为java语言修饰符的是() ', 'D', 'a1', ' $1', '_1', '11', '3', '1', '1', null);
INSERT INTO `t_question` VALUES ('21', '整型数据类型中，需要内存空间最少的是（） ', 'A', 'short ', ' long', 'int', 'byte', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('22', '在JAVA中，关于多态的说法错误的是() ', 'B', '简单的说，多态是用基类的引用指向子类的对象', '多态只能用在方法的参数中 ', '使用多态可以解决项目中紧耦合的问题', 'Object类 中的equals(Object obj)方法，就是体现了多态', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('23', '在MVC设计模式中,客户端通过视图提交的表单数据会直接转交给（）处理', 'A', 'Servlet', 'JSP', 'JavaBean', 'HTML', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('24', '在Spring与Struts2集成应用中，默认需要配置三个配置文件，以下选项不属于这三个配置文件的是（）', 'B', 'struts.xml', 'struts-config.xml', 'applicationContext.xml', 'web.xml', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('25', '在Struts2体系中，（）表示Action的执行状态，它保存拦截器、Action实例', 'D', 'ActionMapper', 'ActionMapping', 'ActionProxy', 'ActionInvocation', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('26', '在Struts2中，通过（）类可以获取ServletAPI对应的Map对象', 'B', 'ActionMapper', 'ActionContext', 'ActionServlet', 'ActionApplication', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('27', '下面选项中关于MVC模式的特点的描述错误的是', 'D', '各司其职，互不干涉', '有利于开发中的分工', '有利于组件的重用', '适用于大、中、小规模的应用程序开发', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('28', '下面选项中关于struts2中Action作用的说法错误的是', 'D', '封装工作单元', '数据转移的场所', '返回结果字符串', '完成业务逻辑操作', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('29', '关于Struts2对表单验证文件的命名规则要求中，以下说法正确的是（）', 'A', '目标Action类名-validation.xml', '目标Action中方法名-validation.xml', 'Action类名-访问别名-validation.xml', '目标Action所在的包名-validation.xml', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('30', '关于java中的多态，以下说法不正确的为（  ） ', 'B', '多态不仅可以减少代码量，还可以提高代码的可扩展性和可维护性', '把子类转换为父类，称为向下转型，自动进行类型转换', '多态是指同一个实现接口，使用不同的实例而执行不同的操作', '继承是多态的基础，没有继承就没有多态', '1', '1', '1', null);
INSERT INTO `t_question` VALUES ('31', '假定已经获得一个数据库连接，使用变量conn表示，删除name值为“张三”的记录，则横线处可以填入以下（ ）代码 ', 'B', 'pstmt.setString(0,\"张三\")', 'pstmt.setString(1,\"张三\")', 'pstmt.setInt(0,\"张三\")', 'pstmt.setInt(1,\"张三\")', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('32', '列选项中，关于JAVA的抽象类和抽象方法说法正确的是（）', 'C', '抽象类中必须有 抽象方法', '抽象类中不可以有构造方法', '一个类中若有抽象方法，则这个类必为抽象类', '子类必须重写父类所有的抽象方法', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('33', '在java中,下列选项可以存储无序、不重复的数据的是()', 'B', 'ArrayList', 'LinkedList', 'HashMap', 'Set', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('34', '以下关于java中static关键字说法错误的是（）', 'B', '声明为static的成员可以在它的类的对象创建之前被访问', '声明为static的变量称为静态变量或类变量', '声明为static的方法称为静态方法，静态方法可以访问实例变量和实例方法', 'static可以用来修饰属性，方法和代码块', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('35', '以下关于java中的DAO模式说法不正确的是（）', 'D', 'DAO(Data Access Object)位于业务逻辑和持久数据之间实现对持久化数据的访问', '使用DAO模式隔离了数据访问代码和业务逻辑代码，也隔离了不同数据库实现', '一个典型的DAO模式主要由DAO接口。DAO实现类，实体类。数据库连接和关闭工具类组成', '使用DAO模式会增加大量冗余代码，不利于程序复用和维护，但是实现了“高内聚，低耦合\"的目标', '2', '1', '1', null);
INSERT INTO `t_question` VALUES ('36', '关于Oracle数据的连接，以下说法正确的是： ', 'B', 'Oracle客户端与服务器端的连接是通过客户端发出连接请求，由数据库服务器对客户端的连接请求进行合法检查，如果请求有效则进行连接，否则拒绝该连接。', '要远程连接数据库服务器，客户端必须先连接驻留在数据库服务器上的监听进程。', 'Oracle的SQL*Plus是与Oracle数据库进行交互的唯一客户端工具', ' Oracle客户端与服务器端的连接是通过客户端发出连接请求，由数据库服务器对客户端的连接请求进行合法检查，如果请求有效则进行连接，否则拒绝该连接。', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('37', '141.关于Java中List接口的说法错误的是()', 'B', ' ArrayList和LinkedList都是List接口的实现类', 'ArrayList和LinkedList都不允许存储重复数据', 'ArrayList的优点在于遍历元素和随机访问元素的效率比较高', 'LinkedList的优点在于插入、删除元素时效率比较高', '2', '1', '2', null);
INSERT INTO `t_question` VALUES ('38', '143.关于使用log4j日志记录工具，下列说法错误的是()。', 'B', '在使用log4j日志记录工具时，需要在项目中加入log4j的jar文件', 'log4j的配置文件可以按自己的喜好命名，只要扩展名是.properties即可', 'log4j配置文件中，可以配置输出级别，输出目的地，日志布局类型等', '输出级别优先级为:fatal>error>warn>info>debug', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('39', '141.关于Java中List接口的说法错误的是()', 'B', ' ArrayList和LinkedList都是List接口的实现类', 'ArrayList和LinkedList都不允许存储重复数据', 'ArrayList的优点在于遍历元素和随机访问元素的效率比较高', 'LinkedList的优点在于插入、删除元素时效率比较高', '2', '1', '2', null);
INSERT INTO `t_question` VALUES ('40', '143.关于使用log4j日志记录工具，下列说法错误的是()。', 'B', '在使用log4j日志记录工具时，需要在项目中加入log4j的jar文件', 'log4j的配置文件可以按自己的喜好命名，只要扩展名是.properties即可', 'log4j配置文件中，可以配置输出级别，输出目的地，日志布局类型等', '输出级别优先级为:fatal>error>warn>info>debug', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('41', '在使用super 和this关键字时，以下描述正确的是()', 'A', '在子类构造方法中使用super（）显示调用父类的构造方法，super（）必须写在子类构造方法的第一行，否则编译不通过', 'B) super（）和this（）不一定要放在构造方法内第一行', 'this（）和super（）可以同时出现在一个构造函数中', 'this（）和super（）可以在static环境中使用，包括static方法和static语句块', '2', '1', '2', null);
INSERT INTO `t_question` VALUES ('42', ' 以下对封装的描述正确的是()', 'D', '只能对一个类中的方法进行封装，不能对属性进行封装', '如果子类继承了父类，对于父类中进行封装的方法，子类仍然可以直接调用', '封装的意义不大，因此在编码时尽量不要使用', '封装的主要作用在于对外隐藏内部实现细节，增强程序的安全性', '3', '1', '2', null);
INSERT INTO `t_question` VALUES ('43', '下列选项中关于java中this关键字的说法错误的是() ', 'B', 'this关键字是在对象内部指代对象自身的引用', 'this关键字可以在类中的任何位置使用', 'this只和特定的对象关联，而不是和类关联', '同一个类的不同对象有不同的this', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('44', '在以下Java程序的方法中，两个方法之间属于方法重载的是（） ', 'A', 'int f1(){}int f1(int a){}', 'void f1(int a){} int f1(int a){}', 'void f1(){}int f1(int a){}', 'int f1(int b){} int f1(int a){}', '2', '1', '2', null);
INSERT INTO `t_question` VALUES ('45', '下面有关Java异常处理模型的说法错误的是（） ', 'A', '一个try块只能有一条catch语句', '一个try块中可以不使用catch语句', 'catch块不能单独使用，必须始终与try块在一起', 'finally块不能单独使用，必须始终与try块在一起', '3', '1', '2', null);
INSERT INTO `t_question` VALUES ('46', '在子类的构造方法中,使用()关键字调用父类的构造方法（） ', 'B', 'base', 'super', 'this', 'extends', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('47', '下列关于JAVA中抽象方法说法正确的是（） ', 'C', '抽象类中不可以有非抽象方法', '某个非抽象类的父类是抽象类,则这个类必须重载父类的所有抽象方法', '抽象类无法实例化', '抽象方法的方法体部分必须用一对大括号{ }括住', '2', '1', '2', null);
INSERT INTO `t_question` VALUES ('48', 'Java中在使用interface声明一个接口时，只可以使用（ ）修饰符修饰该接口 ', 'D', 'private', 'protected', ' private protected', 'public', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('49', '以下对象可以使用键-值的形式保存数据（ ） ', 'D', 'ArrayList', ' Collection', ' LinkedList', 'HashMap', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('50', '下面选项中能单独和finally语句一起使用的是（）', 'A', 'try', 'catch', 'throw', 'throws', '3', '1', '2', null);
INSERT INTO `t_question` VALUES ('51', '在Java中，LinkedList类的ArrayList类同属于集合框架类，下列（ ）选项中的方法是LinkedList类有而ArrayList类没有的。', 'D', 'add(Object o)', 'add(int index,Object o)', 'remove(Object o)', 'removeLast()', '2', '1', '2', null);
INSERT INTO `t_question` VALUES ('52', '下面选项中能单独和finally语句一起使用的是（）', 'A', 'try', 'catch', 'throw', 'throws', '2', '1', '2', null);
INSERT INTO `t_question` VALUES ('53', '在Java中，LinkedList类的ArrayList类同属于集合框架类，下列（ ）选项中的方法是LinkedList类有而ArrayList类没有的。', 'D', 'add(Object o)', 'add(int index,Object o)', 'remove(Object o)', 'removeLast()', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('54', '关于Java中static关键字的说法错误的是() ', 'D', 'static 可以用来修饰属性、方法和代码块', 'static 修饰的属性和方法可称为类属性、类方法', '不使用static关键字修饰的属性和方法，通常称为实例属性、实例方法', '使用static修饰的变量和方法只能使用类名来访问，不能使用对象名来访问', '2', '1', '2', null);
INSERT INTO `t_question` VALUES ('55', '使用Java编写如下的代码，则运行结果正确的是()', 'C', '10', '5', '编译错误', 'null', '2', '1', '2', null);
INSERT INTO `t_question` VALUES ('56', '阅读下列Java代码，有标注的四行代码中，有错误的是第()处。\r\nimport java.io.FileWriter;\r\nimport java.io>IOException;\r\npublic class Test{\r\n    public static void main(String args){\r\n    String str=\"Hello World\";\r\n	FileWriter fw = null;\r\n	try{\r\n	    fw = new FileWriter(\"c:\\hello.txt\");   //1\r\n	    fw.write(str);                         //2\r\n	}catch(IOException e){\r\n	    e.printStackTrace();                    //3\r\n	}finally{\r\n	    fw.close();                             //4\r\n	}\r\n    }\r\n}\r\n', 'D', '1', '2', '3', '4', '2', '1', '2', null);
INSERT INTO `t_question` VALUES ('57', '执行以下Java代码，正确的输出是()。\r\npublic static void main(String[] args){\r\n   try{\r\n	String name=null;\r\n	System.out.println(name.length());\r\n   }catch(Exception e){\r\n	System.out.println(\"有异常出现\");\r\n   }finally{\r\n	System.out.println(\"执行结束\");\r\n   }\r\n}\r\n', 'D', '编译错误', '有异常出现', '执行结束', '有异常出现\r\n    执行结束\r\n', '3', '1', '2', null);
INSERT INTO `t_question` VALUES ('58', '下列选项中关于java中this关键字的说法错误的是()public class Person{\r\n    private String name;\r\n    private int age;\r\n    private Person(){\r\n    }\r\n}\r\n ', 'B', 'public Person(String name){\r\n        this.name = name;\r\n    }\r\n', 'public String Person(String name){\r\n        return name;\r\n    }\r\n', 'public Person(int age){\r\n        this.age = age;\r\n    }\r\n', 'public Person(String name,int age){\r\n        this.name = name;\r\n        this.age = age;\r\n    }\r\n', '2', '1', '2', null);
INSERT INTO `t_question` VALUES ('59', '在Java中，关于继承的说法错误的是() ', 'B', '使用extends关键字实现一个类继承另一个类', '所有的java类都直接或间接地继承了java.lang.Object类', '在子类的构造方法中，必须显试调用父类的构造方法', '在子类的构造方法中，可以通过super关键字调用父类的构造方法', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('60', '以下关于java中JDBC说法错误的是() ', 'B', '加载JDBC驱动时，如果系统中不存在给定的类，则会引发的异常类型是SQLException', 'DriverManager类调用getConnection()方法，创建连接对象并返回引用。', 'PreparedStatement接口是Statement的子接口，它比Statement对象使用起来更加灵活，更有效率，更具安全性。', 'ResultSet负责保存和处理查询结果，此对象的nextInt()方法可以使光标向下移动一行,然后通过一系列getXXX方法实现对当前行各列数据的操作。', '1', '2', '2', null);
INSERT INTO `t_question` VALUES ('61', '以下在java中定义接口正确的是() ', 'B', 'public interface PersonDao{\r\n            public int age;\r\n            public int getAge();\r\n        }', 'public interface PersonDao{\r\n            private String getName();\r\n            private int getAge();\r\n        }', 'public interface PersonDao{\r\n            public String getName(){};\r\n            public int getAge(){};\r\n        }', 'public interface PersonDao{\r\n           public void work();\r\n           public void eat();\r\n        }', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('62', '使用java编写如下的代码，则运行结果正确的是() ', 'B', '10', '5', '编译出错', 'null', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('63', '在java中，假设下列每个选项中的两个方法在同一个类中,则属于方法重载的是() ', 'B', 'public void work()和public void work(String type)', ' public String work(String type)和public void work(String type)', 'public void work1(String type)和public void work2(String type)', 'public void work(String type)和public void work(String type,int time)\r\n', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('64', '在Java中，关于继承的说法错误的是()。', 'C', '使用extends关键字实现一个类继承另一个类', '所有的Java类都直接或间接地继承了java.lang.Object类', '在子类的构造方法中，必须显式调用父类的构造方法', '在子类的构造方法中，可以通过super关键字调用父类的构造方法', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('65', '以下关于Java中的final关键字说法错误的是()。', 'D', '被final修饰的类不能被继承', '被final修饰的方法不能被子类重写', '被final修饰的变量将成为常量', 'final可以和abstract同时修饰一个类或方法', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('66', '关于Java中List接口的说法错误的是()', 'B', 'ArrayList和LinkedList都是List接口的实现类', 'ArrayList和LinkedList都不允许存储重复数据', 'ArrayList的优点在于遍历元素和随机访问元素的效率比较高', 'LinkedList的优点在于插入、删除元素时效率比较高', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('67', '关于使用log4j日志记录工具，下列说法错误的是()。', 'B', '在使用log4j日志记录工具时，需要在项目中加入log4j的jar文件', 'log4j的配置文件可以按自己的喜好命名，只要扩展名是.properties即可', 'log4j配置文件中，可以配置输出级别，输出目的地，日志布局类型等', '输出级别优先级为:fatal>error>warn>info>debug', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('68', '有以下Java代码，对构造方法重载错误的是()。public class Person{\r\n    private String name;\r\n    private int age;\r\n    public Person(){\r\n    }\r\n} 	\r\n\r\n（选择一项）\r\n ', 'B', ' public Person(String name){\r\n            this.name=name;\r\n        }\r\n', 'public String Person(String name){\r\n            return name;\r\n        }\r\n', 'public Person(int age){\r\n           this.age = age;\r\n        }\r\n', 'public Person(String name,int age){\r\n           this.name = name;\r\n           this.age = age;\r\n        }\r\n', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('69', '在Java中，以下不是多态实现条件的是()。 ', 'B', '要实现多态必然要有接口', '继承的存在', '子类重写父类的方法', ' 父类引用变量指向子类的对象', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('70', '以下关于Java中static关键字说法错误的是()。 ', 'B', '声明为static的成员可以在它的类的对象创建之前被访问', '声明为static的变量称为静态变量或类变量', '声明为static的方法称为静态方法，静态方法可以访问实例变量和实例方法', 'static可以用来修饰属性、方法和代码块', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('71', '在Java中，关于继承的说法错误的是(). ', 'B', '使用extends关键字实现一个类继承另一个类', '所有的java类都直接或间接地继承了java.lang.Object类', '在子类的构造方法中，必须显试调用父类的构造方法', '在子类的构造方法中，可以通过super关键字调用父类的构造方法', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('72', '在JavaScript中，以下变量命名非法的是（） ', 'B', 'numb_1', '2numb', 'sum', 'de2$f', '1', '1', '2', null);
INSERT INTO `t_question` VALUES ('73', 'JavaScript是运行在（）的脚本语言 ', 'B', '服务器端', '客户端', '在服务器运行后，把结果返回到客户端', '在客户端运行后，把结果返回到服务端', '1', '1', '2', null);

-- ----------------------------
-- Table structure for `t_record`
-- ----------------------------
DROP TABLE IF EXISTS `t_record`;
CREATE TABLE `t_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `score` double DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  `stuId` int(11) DEFAULT NULL,
  `subjectId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_nthta4162p5che1vakm2fiiqm` (`stuId`),
  KEY `FK_9s0s3q26aq3p8ho48wqr10t9p` (`subjectId`),
  CONSTRAINT `FK_9s0s3q26aq3p8ho48wqr10t9p` FOREIGN KEY (`subjectId`) REFERENCES `t_subject` (`id`),
  CONSTRAINT `FK_nthta4162p5che1vakm2fiiqm` FOREIGN KEY (`stuId`) REFERENCES `t_student` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_record
-- ----------------------------
INSERT INTO `t_record` VALUES ('2', '40', null, '12', '1');
INSERT INTO `t_record` VALUES ('3', '20', null, '12', '1');
INSERT INTO `t_record` VALUES ('4', '20', null, '12', '1');
INSERT INTO `t_record` VALUES ('5', '20', null, '12', '1');

-- ----------------------------
-- Table structure for `t_record_detail`
-- ----------------------------
DROP TABLE IF EXISTS `t_record_detail`;
CREATE TABLE `t_record_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `answer` varchar(255) DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `questionId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_s4njd48x4c0hghfiw5xje8l12` (`recordId`),
  KEY `FK_ts7y8ljs9n65gxvf8erno539` (`questionId`),
  CONSTRAINT `FK_s4njd48x4c0hghfiw5xje8l12` FOREIGN KEY (`recordId`) REFERENCES `t_record` (`id`),
  CONSTRAINT `FK_ts7y8ljs9n65gxvf8erno539` FOREIGN KEY (`questionId`) REFERENCES `t_question` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_record_detail
-- ----------------------------
INSERT INTO `t_record_detail` VALUES ('1', 'A', '2', '2');
INSERT INTO `t_record_detail` VALUES ('2', 'A', '2', '3');
INSERT INTO `t_record_detail` VALUES ('3', 'A', '2', '4');
INSERT INTO `t_record_detail` VALUES ('4', 'A', '2', '5');
INSERT INTO `t_record_detail` VALUES ('5', 'A', '2', '6');
INSERT INTO `t_record_detail` VALUES ('6', 'null', '2', '7');
INSERT INTO `t_record_detail` VALUES ('7', 'null', '2', '8');
INSERT INTO `t_record_detail` VALUES ('8', 'A', '2', '9');
INSERT INTO `t_record_detail` VALUES ('9', 'A', '2', '10');
INSERT INTO `t_record_detail` VALUES ('10', 'A', '2', '11');
INSERT INTO `t_record_detail` VALUES ('11', 'A', '2', '12');
INSERT INTO `t_record_detail` VALUES ('12', 'A', '2', '13');
INSERT INTO `t_record_detail` VALUES ('13', 'null', '2', '14');
INSERT INTO `t_record_detail` VALUES ('14', 'null', '2', '15');
INSERT INTO `t_record_detail` VALUES ('15', 'null', '2', '16');
INSERT INTO `t_record_detail` VALUES ('16', 'null', '2', '17');
INSERT INTO `t_record_detail` VALUES ('17', 'null', '2', '18');
INSERT INTO `t_record_detail` VALUES ('18', 'null', '2', '19');
INSERT INTO `t_record_detail` VALUES ('19', 'null', '2', '20');
INSERT INTO `t_record_detail` VALUES ('20', 'null', '2', '21');
INSERT INTO `t_record_detail` VALUES ('21', 'null', '2', '22');
INSERT INTO `t_record_detail` VALUES ('22', 'null', '2', '23');
INSERT INTO `t_record_detail` VALUES ('23', 'null', '2', '24');
INSERT INTO `t_record_detail` VALUES ('24', 'null', '2', '25');
INSERT INTO `t_record_detail` VALUES ('25', 'null', '2', '26');
INSERT INTO `t_record_detail` VALUES ('26', 'null', '2', '27');
INSERT INTO `t_record_detail` VALUES ('27', 'null', '2', '28');
INSERT INTO `t_record_detail` VALUES ('28', 'null', '2', '29');
INSERT INTO `t_record_detail` VALUES ('29', 'null', '2', '30');
INSERT INTO `t_record_detail` VALUES ('30', 'null', '2', '31');
INSERT INTO `t_record_detail` VALUES ('31', 'null', '2', '32');
INSERT INTO `t_record_detail` VALUES ('32', 'null', '2', '33');
INSERT INTO `t_record_detail` VALUES ('33', 'null', '2', '34');
INSERT INTO `t_record_detail` VALUES ('34', 'null', '2', '35');
INSERT INTO `t_record_detail` VALUES ('35', 'null', '2', '37');
INSERT INTO `t_record_detail` VALUES ('36', 'null', '2', '39');
INSERT INTO `t_record_detail` VALUES ('37', 'null', '2', '41');
INSERT INTO `t_record_detail` VALUES ('38', 'null', '2', '42');
INSERT INTO `t_record_detail` VALUES ('39', 'null', '2', '43');
INSERT INTO `t_record_detail` VALUES ('40', 'null', '2', '44');
INSERT INTO `t_record_detail` VALUES ('41', 'null', '2', '45');
INSERT INTO `t_record_detail` VALUES ('42', 'null', '2', '46');
INSERT INTO `t_record_detail` VALUES ('43', 'null', '2', '47');
INSERT INTO `t_record_detail` VALUES ('44', 'null', '2', '48');
INSERT INTO `t_record_detail` VALUES ('45', 'null', '2', '49');
INSERT INTO `t_record_detail` VALUES ('46', 'null', '2', '50');
INSERT INTO `t_record_detail` VALUES ('47', 'null', '2', '51');
INSERT INTO `t_record_detail` VALUES ('48', 'null', '2', '52');
INSERT INTO `t_record_detail` VALUES ('49', 'null', '2', '53');
INSERT INTO `t_record_detail` VALUES ('50', 'null', '2', '54');
INSERT INTO `t_record_detail` VALUES ('51', 'null', '2', '55');
INSERT INTO `t_record_detail` VALUES ('52', 'null', '2', '56');
INSERT INTO `t_record_detail` VALUES ('53', 'null', '2', '57');
INSERT INTO `t_record_detail` VALUES ('54', 'null', '2', '58');
INSERT INTO `t_record_detail` VALUES ('55', 'null', '2', '59');
INSERT INTO `t_record_detail` VALUES ('56', 'null', '2', '62');
INSERT INTO `t_record_detail` VALUES ('57', 'null', '2', '63');
INSERT INTO `t_record_detail` VALUES ('58', 'null', '2', '64');
INSERT INTO `t_record_detail` VALUES ('59', 'null', '2', '65');
INSERT INTO `t_record_detail` VALUES ('60', 'null', '2', '66');
INSERT INTO `t_record_detail` VALUES ('61', 'null', '2', '68');
INSERT INTO `t_record_detail` VALUES ('62', 'null', '2', '69');
INSERT INTO `t_record_detail` VALUES ('63', 'null', '2', '70');
INSERT INTO `t_record_detail` VALUES ('64', 'null', '2', '71');
INSERT INTO `t_record_detail` VALUES ('65', 'null', '2', '72');
INSERT INTO `t_record_detail` VALUES ('66', 'null', '2', '73');
INSERT INTO `t_record_detail` VALUES ('67', 'A', '3', '4');
INSERT INTO `t_record_detail` VALUES ('68', 'A', '3', '12');
INSERT INTO `t_record_detail` VALUES ('69', 'A', '3', '17');
INSERT INTO `t_record_detail` VALUES ('70', 'A', '3', '35');
INSERT INTO `t_record_detail` VALUES ('71', 'A', '3', '42');
INSERT INTO `t_record_detail` VALUES ('72', 'B', '3', '46');
INSERT INTO `t_record_detail` VALUES ('73', 'A', '3', '52');
INSERT INTO `t_record_detail` VALUES ('74', 'A', '3', '54');
INSERT INTO `t_record_detail` VALUES ('75', 'A', '3', '58');
INSERT INTO `t_record_detail` VALUES ('76', 'A', '3', '67');
INSERT INTO `t_record_detail` VALUES ('77', 'A', '4', '1');
INSERT INTO `t_record_detail` VALUES ('78', 'A', '4', '12');
INSERT INTO `t_record_detail` VALUES ('79', 'A', '4', '20');
INSERT INTO `t_record_detail` VALUES ('80', 'null', '4', '22');
INSERT INTO `t_record_detail` VALUES ('81', 'B', '4', '27');
INSERT INTO `t_record_detail` VALUES ('82', 'D', '4', '33');
INSERT INTO `t_record_detail` VALUES ('83', 'A', '4', '37');
INSERT INTO `t_record_detail` VALUES ('84', 'A', '4', '44');
INSERT INTO `t_record_detail` VALUES ('85', 'A', '4', '45');
INSERT INTO `t_record_detail` VALUES ('86', 'A', '4', '51');
INSERT INTO `t_record_detail` VALUES ('87', 'D', '5', '11');
INSERT INTO `t_record_detail` VALUES ('88', 'D', '5', '20');
INSERT INTO `t_record_detail` VALUES ('89', 'A', '5', '21');
INSERT INTO `t_record_detail` VALUES ('90', 'null', '5', '33');
INSERT INTO `t_record_detail` VALUES ('91', 'null', '5', '38');
INSERT INTO `t_record_detail` VALUES ('92', 'null', '5', '45');
INSERT INTO `t_record_detail` VALUES ('93', 'null', '5', '49');
INSERT INTO `t_record_detail` VALUES ('94', 'null', '5', '52');
INSERT INTO `t_record_detail` VALUES ('95', 'null', '5', '55');
INSERT INTO `t_record_detail` VALUES ('96', 'null', '5', '70');

-- ----------------------------
-- Table structure for `t_student`
-- ----------------------------
DROP TABLE IF EXISTS `t_student`;
CREATE TABLE `t_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stuNo` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `clussId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_9nmd833xeaqguw9pg6c2wjk5r` (`clussId`),
  CONSTRAINT `FK_9nmd833xeaqguw9pg6c2wjk5r` FOREIGN KEY (`clussId`) REFERENCES `t_class` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_student
-- ----------------------------
INSERT INTO `t_student` VALUES ('1', '1101', '张三丰', '1111', '男', '1');
INSERT INTO `t_student` VALUES ('2', '1102', '秦思荣', '1111', '女', '1');
INSERT INTO `t_student` VALUES ('5', '1003', '王二麻', null, '女', '1');
INSERT INTO `t_student` VALUES ('6', 'A1106', '小明', '1111', '男', '1');
INSERT INTO `t_student` VALUES ('7', 'A1107', '小红', '1111', '女', '1');
INSERT INTO `t_student` VALUES ('8', 'A1108', '小萌', '1111', '女', '2');
INSERT INTO `t_student` VALUES ('9', '1110', '老王', '1111', '男', '1');
INSERT INTO `t_student` VALUES ('10', '1111', '老李', '1111', '女', '1');
INSERT INTO `t_student` VALUES ('11', '1112', '老张', '1111', '女', '2');
INSERT INTO `t_student` VALUES ('12', '1104', 'zhangsan', '123456', '男', '1');

-- ----------------------------
-- Table structure for `t_subject`
-- ----------------------------
DROP TABLE IF EXISTS `t_subject`;
CREATE TABLE `t_subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_subject
-- ----------------------------
INSERT INTO `t_subject` VALUES ('1', 'jsp');
INSERT INTO `t_subject` VALUES ('2', 'java');

-- ----------------------------
-- Table structure for `t_teacher`
-- ----------------------------
DROP TABLE IF EXISTS `t_teacher`;
CREATE TABLE `t_teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `workNo` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_teacher
-- ----------------------------
INSERT INTO `t_teacher` VALUES ('1', '1122', '老李', '123456', '女');
INSERT INTO `t_teacher` VALUES ('2', '1111', 'lisi', '123456', '男');
INSERT INTO `t_teacher` VALUES ('3', '1223', 'zhangsan', '123456', '男');

-- ----------------------------
-- Table structure for `t_temp`
-- ----------------------------
DROP TABLE IF EXISTS `t_temp`;
CREATE TABLE `t_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `startTime` bigint(20) DEFAULT NULL,
  `timeLength` int(11) DEFAULT NULL,
  `stuId` int(11) DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_3rmep8lvi689ltu2mkd4w3xso` (`stuId`),
  KEY `FK_nelh8r91vxhx7gyllml7q48rd` (`recordId`),
  CONSTRAINT `FK_3rmep8lvi689ltu2mkd4w3xso` FOREIGN KEY (`stuId`) REFERENCES `t_student` (`id`),
  CONSTRAINT `FK_nelh8r91vxhx7gyllml7q48rd` FOREIGN KEY (`recordId`) REFERENCES `t_record` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_temp
-- ----------------------------

-- ----------------------------
-- Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', 'zhangsan', '18');
INSERT INTO `t_user` VALUES ('2', 'lisi', '20');
INSERT INTO `t_user` VALUES ('3', 'wangwu', '23');
INSERT INTO `t_user` VALUES ('4', 'zhaoliu', '24');
INSERT INTO `t_user` VALUES ('5', 'wangermazi', '32');

-- ----------------------------
-- Table structure for `t_weight`
-- ----------------------------
DROP TABLE IF EXISTS `t_weight`;
CREATE TABLE `t_weight` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `easy` int(11) DEFAULT NULL,
  `middle` int(11) DEFAULT NULL,
  `hard` int(11) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `totalCount` int(11) DEFAULT NULL,
  `timeLength` int(11) DEFAULT NULL,
  `examTime` datetime DEFAULT NULL,
  `subjectId` int(11) DEFAULT NULL,
  `clussId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_e773jmvccipvuyoxwgsle9do5` (`subjectId`),
  KEY `FK_pp686fmlhf544iuwj4kdp2kkw` (`clussId`),
  CONSTRAINT `FK_e773jmvccipvuyoxwgsle9do5` FOREIGN KEY (`subjectId`) REFERENCES `t_subject` (`id`),
  CONSTRAINT `FK_pp686fmlhf544iuwj4kdp2kkw` FOREIGN KEY (`clussId`) REFERENCES `t_class` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_weight
-- ----------------------------
INSERT INTO `t_weight` VALUES ('1', '30', '50', '20', '100', '10', '30', '2015-12-17 17:40:26', '1', '1');
INSERT INTO `t_weight` VALUES ('2', '30', '40', '30', '100', '10', '0', null, '1', '1');


