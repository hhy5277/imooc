package cn.sxt.service.student;

import java.io.File;
import java.util.List;

import cn.sxt.exception.student.ExcelException;
import cn.sxt.vo.student.Student;

public interface StudentService {
	public List<Student> getList();
	public int add(Student student);
	public int delete(Student student);
	public int update(Student student);
	public Student getById(Integer id);
	public void batch(File file) throws ExcelException;
	public Student login(String username, String password);
}
