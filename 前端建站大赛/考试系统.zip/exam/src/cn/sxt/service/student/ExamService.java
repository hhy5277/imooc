package cn.sxt.service.student;

import java.util.List;

import cn.sxt.vo.student.Record;
import cn.sxt.vo.student.Student;
import cn.sxt.vo.teacher.Question;
import cn.sxt.vo.teacher.Subject;

public interface ExamService {

	List<Question> page(Subject subject, Student student);

	List<Question> getPaper(Record record);

	double submitPaper(Student student, Subject subject, List<Integer> questionId, List<String> answer);
	
}
