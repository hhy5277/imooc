package cn.sxt.service.system;

import cn.sxt.vo.student.Record;
import cn.sxt.vo.student.Student;

public interface TempService {
	public boolean isExaming(Student student);

	public Record getCurrentRecord(Student student);
}
