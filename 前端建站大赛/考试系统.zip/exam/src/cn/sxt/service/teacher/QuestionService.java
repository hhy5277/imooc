package cn.sxt.service.teacher;

import java.util.List;

import cn.sxt.util.Page;
import cn.sxt.vo.teacher.Question;

public interface QuestionService {
	public List<Question> getList();
	public int add(Question question);
	public int delete(Question question);
	public int update(Question question);
	public Question getById(Integer id);
	public List<Question> getList(Page pager);
	public List<Question> query(Question question);
}
