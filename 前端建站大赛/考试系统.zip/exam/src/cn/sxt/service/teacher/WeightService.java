package cn.sxt.service.teacher;

import java.util.List;

import cn.sxt.vo.student.Student;
import cn.sxt.vo.teacher.Subject;
import cn.sxt.vo.teacher.Weight;

public interface WeightService {
	public List<Weight> getList();
	public int add(Weight weight);
	public int delete(Weight weight);
	public int update(Weight weight);
	public Weight getById(Integer id);
	public boolean isExamPlan(Student student, Subject subject);
}
