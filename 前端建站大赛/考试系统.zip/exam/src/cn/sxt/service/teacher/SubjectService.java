package cn.sxt.service.teacher;

import java.util.List;

import cn.sxt.vo.teacher.Question;
import cn.sxt.vo.teacher.Subject;

public interface SubjectService {
	public List<Subject> getList();
	public int add(Subject subject);
	public int update(Subject subject);
	public int delete(Subject subject);
	public Subject getById(Integer id);
}
