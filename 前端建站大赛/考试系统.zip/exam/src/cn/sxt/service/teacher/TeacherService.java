package cn.sxt.service.teacher;

import java.util.List;

import cn.sxt.vo.teacher.Teacher;

public interface TeacherService {
	public List<Teacher> getList();
	public Teacher getById(Integer id);
	public int add(Teacher teacher);
	public int update(Teacher teacher);
	public int delete(Teacher teacher);
	public Teacher login(String username, String password);
	
}
