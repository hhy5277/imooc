package cn.sxt.service.impl.teacher;

import java.util.List;

import cn.sxt.dao.implteacher.SubjectDaoImpl;
import cn.sxt.dao.teacher.SubjectDao;
import cn.sxt.service.teacher.SubjectService;
import cn.sxt.vo.teacher.Question;
import cn.sxt.vo.teacher.Subject;

public class SubjectServiceImpl implements SubjectService{
	private SubjectDao subjectDao=new SubjectDaoImpl();
	@Override
	public List<Subject> getList() {
		return subjectDao.getList();
	}

	@Override
	public int add(Subject subject) {
		return subjectDao.add(subject);
	}

	@Override
	public int update(Subject subject) {
		return subjectDao.update(subject);
	}

	@Override
	public int delete(Subject subject) {
		return subjectDao.delete(subject);
	}

	@Override
	public Subject getById(Integer id) {
		return subjectDao.getById(id);
	}


}
