package cn.sxt.service.impl.student;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import cn.sxt.dao.implstudent.StudentDaoImpl;
import cn.sxt.dao.student.StudentDao;
import cn.sxt.exception.student.ExcelException;
import cn.sxt.service.student.StudentService;
import cn.sxt.vo.student.Student;
import cn.sxt.vo.teacher.Cluss;

public class StudentServiceImpl implements StudentService {
	private StudentDao studentDao = new StudentDaoImpl();

	@Override
	public List<Student> getList() {
		return studentDao.getList();
	}

	@Override
	public int add(Student student) {
		return studentDao.add(student);
	}

	@Override
	public int delete(Student student) {
		return studentDao.delete(student);
	}

	@Override
	public int update(Student student) {
		return studentDao.update(student);
	}

	@Override
	public Student getById(Integer id) {
		return studentDao.getById(id);
	}

	@Override
	public void batch(File file) throws ExcelException {
		List<Student> stus = getStudentsByFile(file);
		studentDao.batch(stus);

	}

	List<Student> getStudentsByFile(File file) throws ExcelException {
		List<Student> stus = new ArrayList<Student>();
		try {
			InputStream inp = new FileInputStream(file);
			Workbook wb = WorkbookFactory.create(inp);
			Sheet sheet = wb.getSheetAt(0);
			int rows = sheet.getPhysicalNumberOfRows();
			for (int i = 1; i < rows; i++) {
				Row row = sheet.getRow(i);
				int cols = row.getPhysicalNumberOfCells();
				Student stu = new Student();
				stu.setStuNo(row.getCell(0).getStringCellValue());
				stu.setName(row.getCell(1).getStringCellValue());
				stu.setSex(row.getCell(2).getStringCellValue());
				stu.setPwd("1111");
				Cluss cluss = new Cluss();
				cluss.setId((int) row.getCell(3).getNumericCellValue());
				stu.setCluss(cluss);
				stus.add(stu);
			}
			return stus;
		} catch (EncryptedDocumentException e) {
			e.printStackTrace();
			throw new ExcelException("文件格式不合法");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new ExcelException("文件上传失败");
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ExcelException("文件格式不合法");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ExcelException("文件格式不合法");
		}

	}

	@Override
	public Student login(String username, String password) {
		return studentDao.login(username,password);
	}
}
