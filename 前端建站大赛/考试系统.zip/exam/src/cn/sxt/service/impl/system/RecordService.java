package cn.sxt.service.impl.system;

import java.util.List;

import cn.sxt.bean.record.RecordBean;
import cn.sxt.vo.student.Record;
import cn.sxt.vo.student.RecordDetail;
import cn.sxt.vo.student.Student;

public interface RecordService {

	public List<Record> getListByStudent(Student student);

	public Record getById(Record record);

	public List<RecordDetail> getByRecord(Record record);

	public List<Record> getRocordsByCondition(RecordBean recordBean);
}
