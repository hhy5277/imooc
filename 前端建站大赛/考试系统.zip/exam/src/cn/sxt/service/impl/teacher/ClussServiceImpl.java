package cn.sxt.service.impl.teacher;

import java.util.List;

import cn.sxt.dao.implteacher.ClussDaoImpl;
import cn.sxt.dao.teacher.ClussDao;
import cn.sxt.service.teacher.ClussService;
import cn.sxt.vo.teacher.Cluss;

public class ClussServiceImpl implements ClussService{
	private ClussDao clussDao=new ClussDaoImpl();
	@Override
	public List<Cluss> getList() {
		return clussDao.getList();
	}

	@Override
	public int add(Cluss cluss) {
		return clussDao.add(cluss);
	}

	@Override
	public int delete(Cluss cluss) {
		return clussDao.delete(cluss);
	}

	@Override
	public int update(Cluss cluss) {
		return clussDao.update(cluss);
	}

	@Override
	public Cluss getById(Integer id) {
		return clussDao.getById(id);
	}

}
