package cn.sxt.service.impl.student;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;

import cn.sxt.dao.implstudent.RecordDaoImpl;
import cn.sxt.dao.implstudent.RecordDetailDaoImpl;
import cn.sxt.dao.implsystem.TempDaoImpl;
import cn.sxt.dao.implteacher.QuestionDaoImpl;
import cn.sxt.dao.implteacher.WeightDaoImpl;
import cn.sxt.dao.student.RecordDao;
import cn.sxt.dao.student.RecordDetailDao;
import cn.sxt.dao.system.TempDao;
import cn.sxt.dao.teacher.QuestionDao;
import cn.sxt.dao.teacher.WeightDao;
import cn.sxt.service.impl.system.TempServiceImpl;
import cn.sxt.service.student.ExamService;
import cn.sxt.service.system.TempService;
import cn.sxt.vo.student.Record;
import cn.sxt.vo.student.RecordDetail;
import cn.sxt.vo.student.Student;
import cn.sxt.vo.system.Temp;
import cn.sxt.vo.teacher.Question;
import cn.sxt.vo.teacher.Subject;
import cn.sxt.vo.teacher.Weight;

public class ExamServiceImpl implements ExamService{
	private WeightDao weightDao=new WeightDaoImpl();
	private QuestionDao  questondDao=new QuestionDaoImpl();
	private RecordDao recordDao=new RecordDaoImpl();
	private RecordDetailDao recordDetailDao=new RecordDetailDaoImpl();
	private TempDao tempDao=new TempDaoImpl();
	private TempService tempService=new TempServiceImpl();
	private QuestionDao questionDao=new QuestionDaoImpl();
	@Override
	public List<Question> page(Subject subject, Student student) {
		//获取权重信息
		Weight weight =getWeight(subject.getId(), student);
		//根据权重分别获取各种题目
		List<Question> list=createPaper(subject.getId(), weight);
		//添加考试记录
		Record record=saveRecord(subject, student);
		//添加考试记录详情
		saveRecordDetail(list, record);
		//保存考试状态
		saveExamStatus(student, weight, record);
		return list;
	}

	private void saveExamStatus(Student student, Weight weight, Record record) {
		Temp temp = new Temp();
		temp.setRecord(record);
		temp.setStudent(student);
		temp.setTimeLength(weight.getTimeLength());
		long start=System.currentTimeMillis();
		temp.setStartTime(start);
		tempDao.add(temp);
		ActionContext.getContext().getSession().put("timeLength", weight.getTimeLength()*60);
	}

	private void saveRecordDetail(List<Question> list, Record record) {
		for(Question q:list){
			RecordDetail recordDetail=new RecordDetail();
			recordDetail.setQuestion(q);
			recordDetail.setRecord(record);
			recordDetailDao.add(recordDetail);
		}
	}

	private Record saveRecord(Subject subject, Student student) {
		Record record=new Record();
		record.setStudent(student);
		record.setSubject(subject);
		recordDao.save(record);
		return record;
	}

	private List<Question> createPaper(Integer subjectId, Weight weight) {
		int easy=weight.getEasy()*weight.getTotalCount()/100;
		int middle=weight.getMiddle()*weight.getTotalCount()/100;
		int hard=weight.getTotalCount()-easy-middle;
		List<Question> easyQuestion=getQuestionBySql(1, easy, subjectId);
		List<Question> middleQuestion=getQuestionBySql(2, middle, subjectId);
		List<Question> hardQuestion=getQuestionBySql(3, hard, subjectId);
		easyQuestion.addAll(middleQuestion);
		easyQuestion.addAll(hardQuestion);
		Collections.sort(easyQuestion);
		return easyQuestion;
	}
	
	private List<Question> getQuestionBySql(int degree,int count,int subjectId){
		String sql="select * from t_question where  degree="+degree +" and subjectId="+subjectId+" ORDER BY RAND() limit "+count;
		return  questondDao.getQuestionBySql(sql);
	}
	private Weight getWeight(Integer subjectId, Student student) {
		String hql="from Weight w where w.subject.id='"+subjectId+"' and w.cluss.id='"+student.getCluss().getId()+"'";
		return weightDao.getWeightByHql(hql);
	}

	@Override
	public List<Question> getPaper(Record record) {
		String hql="select d.question.id from RecordDetail d where d.record.id="+record.getId();
		List<Integer> questionIds=recordDetailDao.getQuestionId(hql);
		return questionDao.getQuestionByIds(questionIds);
	}

	@Override
	public double submitPaper(Student student, Subject subject, List<Integer> questionIds, List<String> answer) {
		//1、删除临时表中的记录信息
		String hql="from Temp t where t.student.id="+student.getId();
		Temp temp=tempDao.getByStudent(hql);
		tempDao.delete(temp);
		//2、获取考试记录对象Record
		Record record = recordDao.getById(temp.getRecord().getId());
		//3、获取考试记录的详情
		hql="from RecordDetail where record.id="+record.getId();
		List<RecordDetail> recordDetails=recordDetailDao.getDetailsByHql(hql);
		//4、获取考试题目信息
		List<Question> questions=questionDao.getQuestionByIds(questionIds);
		//5、评分
		Map<Integer, RecordDetail> detailMap=recordDetailListToMap(recordDetails);
		//正确答案
		Map<Integer, String> answerMap=answerListToMap(questions);
		//正确题目数
		int sum=0;
		for (int i = 0; i < questionIds.size(); i++) {
			//获取提交的答案
			String submitAnswer=answer.get(i).trim();
			//获取正确答案
			String realAnswer=answerMap.get(questionIds.get(i)).trim();	
			//获取记录详情
			RecordDetail recordDetail=detailMap.get(questionIds.get(i));		
			//更新记录详情中的答案
			recordDetail.setAnswer(submitAnswer);		
			//更新记录详情
			recordDetailDao.update(recordDetail);
			//判断是否正确----如果每个题目分数不一致 应在if中做分数的累计
			if(submitAnswer.equals(realAnswer)){
				sum++;
			}
		}
		//考试分数
		//获取权重信息---根据科目id和班级id
		Weight weight=getWeight(subject.getId(), student);			
		double score=weight.getScore()/weight.getTotalCount()*sum;
		record.setScore(score);
		recordDao.update(record);
		return score;
	}

	private Map<Integer, String> answerListToMap(List<Question> questions) {
		Map<Integer, String> map=new HashMap<Integer, String>();
		for (Question question : questions) {
			map.put(question.getId(), question.getAnswer());
		}
		return map;
	}

	private Map<Integer, RecordDetail> recordDetailListToMap(List<RecordDetail> recordDetails) {
		Map<Integer, RecordDetail> map=new HashMap<Integer, RecordDetail>();
		for (RecordDetail recordDetail : recordDetails) {
			map.put(recordDetail.getQuestion().getId(), recordDetail);
		}
		return map;
	}

}
