package cn.sxt.service.impl.system;

import com.opensymphony.xwork2.ActionContext;

import cn.sxt.dao.implstudent.RecordDaoImpl;
import cn.sxt.dao.implsystem.TempDaoImpl;
import cn.sxt.dao.student.RecordDao;
import cn.sxt.dao.system.TempDao;
import cn.sxt.service.system.TempService;
import cn.sxt.vo.student.Record;
import cn.sxt.vo.student.Student;
import cn.sxt.vo.system.Temp;

public class TempServiceImpl implements TempService{
	private TempDao tempDao=new TempDaoImpl();
	private RecordDao recordDao=new RecordDaoImpl();
	@Override
	public boolean isExaming(Student student) {
		String hql="from Temp t where t.student.id ="+student.getId();
		Temp temp=tempDao.getByStudent(hql);
		if(temp==null){
			return false;
		}
		long currentTime=System.currentTimeMillis();
		if((currentTime-temp.getStartTime()-temp.getTimeLength()*60*1000)>0){
			tempDao.delete(temp);
			return false;
		}
		long useTime=(currentTime-temp.getStartTime())/1000;
		long timeLength=temp.getTimeLength()*60-useTime;
		ActionContext.getContext().getSession().put("timeLength", timeLength);
		return true;
	}
	@Override
	public Record getCurrentRecord(Student student) {
		String hql="from Temp t where t.student.id ="+student.getId();
		Temp temp=tempDao.getByStudent(hql);
		Record record= recordDao.getById(temp.getRecord().getId());
		return record;
	}
	
}
