package cn.sxt.service.impl.student;

import java.text.SimpleDateFormat;
import java.util.List;

import cn.sxt.bean.record.RecordBean;
import cn.sxt.dao.implstudent.RecordDaoImpl;
import cn.sxt.dao.implstudent.RecordDetailDaoImpl;
import cn.sxt.dao.student.RecordDao;
import cn.sxt.dao.student.RecordDetailDao;
import cn.sxt.service.impl.system.RecordService;
import cn.sxt.vo.student.Record;
import cn.sxt.vo.student.RecordDetail;
import cn.sxt.vo.student.Student;

public class RecordServiceImpl implements RecordService{
	private RecordDao recordDao=new RecordDaoImpl();
	private RecordDetailDao recordDetailDao=new RecordDetailDaoImpl();
	@Override
	public List<Record> getListByStudent(Student student) {
		String hql="from Record r where r.student.id="+student.getId();
		return recordDao.getListByHql(hql);
	}
	@Override
	public Record getById(Record record) {
		
		return recordDao.getById(record.getId());
	}
	@Override
	public List<RecordDetail> getByRecord(Record record) {
		String hql="from RecordDetail d where d.record.id="+record.getId();
		return recordDetailDao.getDetailsByHql(hql);
	}
	
	@Override
	public List<Record> getRocordsByCondition(RecordBean recordBean) {
		String hql="from Record r where 1=1";
		if(recordBean.getSubject().getId()!=0){
			hql+=" and r.subject.id="+recordBean.getSubject().getId();
		}
		if(recordBean.getCluss().getId()!=0){
			hql+=" and r.student.cluss.id="+recordBean.getCluss().getId();
		}
		if(recordBean.getStartScore()<recordBean.getEndScore()){
			hql+=" and r.score between "+recordBean.getStartScore()+" and "+recordBean.getEndScore();
		}
		if(recordBean.getStuName()!=null&recordBean.getStuName().length()>0){
			hql+=" and r.student.name like '"+recordBean.getStuName()+"%'";
		}
		if(recordBean.getExamTime()!=null){
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			String str=sdf.format(recordBean.getExamTime());
			String d1=str+" 00:00:00";
			String d2=str+" 23:59:59";
			hql+=" and r.createTime between '"+d1+"' and '"+d2+"'";
		}
		return recordDao.getListByHql(hql);
	}
}
