package cn.sxt.service.impl.teacher;

import java.util.Date;
import java.util.List;

import cn.sxt.dao.implteacher.WeightDaoImpl;
import cn.sxt.dao.teacher.WeightDao;
import cn.sxt.service.teacher.WeightService;
import cn.sxt.vo.student.Student;
import cn.sxt.vo.teacher.Subject;
import cn.sxt.vo.teacher.Weight;

public class WeightServiceImpl implements WeightService{
	private WeightDao weightDao=new WeightDaoImpl();
	@Override
	public List<Weight> getList() {
		return weightDao.getList();
	}

	@Override
	public int add(Weight weight) {
		return weightDao.add(weight);
	}

	@Override
	public int delete(Weight weight) {
		return weightDao.delete(weight);
	}

	@Override
	public int update(Weight weight) {
		return weightDao.update(weight);
	}

	@Override
	public Weight getById(Integer id) {
		return weightDao.getById(id);
	}

	@Override
	public boolean isExamPlan(Student student, Subject subject) {
		String hql="from Weight w where w.subject.id='"+subject.getId()+"' and w.cluss.id='"+student.getCluss().getId()+"'";
		Weight weight= weightDao.getWeightByHql(hql);
		Date examDate=weight.getExamTime();
		long examtime=examDate.getTime();
		long currentTime=System.currentTimeMillis();
		//涓嶅埌鑰冭瘯鏃堕棿
		if(examtime-120000>currentTime)
			return false;
		//瓒呰繃鑰冭瘯鏃堕棿
		if(currentTime-examtime>weight.getTimeLength()*60*1000)
			return false;
		return true;
	}

}
