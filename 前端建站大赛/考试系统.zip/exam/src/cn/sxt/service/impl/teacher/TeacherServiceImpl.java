package cn.sxt.service.impl.teacher;

import java.util.List;

import cn.sxt.dao.implteacher.TeacherDaoImpl;
import cn.sxt.dao.teacher.TeacherDao;
import cn.sxt.service.teacher.TeacherService;
import cn.sxt.vo.teacher.Teacher;

public class TeacherServiceImpl implements TeacherService{
	private TeacherDao teacherDao = new TeacherDaoImpl();
	@Override
	public List<Teacher> getList() {
		return teacherDao.getList();
	}

	@Override
	public Teacher getById(Integer id) {
		return teacherDao.getById(id);
	}

	@Override
	public int add(Teacher teacher) {
		teacher.setPwd("123456");
		return teacherDao.add(teacher);
	}

	@Override
	public int update(Teacher teacher) {
		teacher.setPwd("123456");
		return teacherDao.update(teacher);
	}

	@Override
	public int delete(Teacher teacher) {
		return teacherDao.delete(teacher);
	}

	@Override
	public Teacher login(String username, String password) {
		return teacherDao.login(username,password);
	}
	
}
