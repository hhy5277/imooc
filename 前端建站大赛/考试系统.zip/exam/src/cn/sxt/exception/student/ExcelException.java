package cn.sxt.exception.student;

public class ExcelException extends Throwable{
	public ExcelException() {
		super();
	}
	public ExcelException(String msg){
		super(msg);
	}
}
