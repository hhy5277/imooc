package cn.sxt.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import cn.sxt.util.HibernateUtil;
import cn.sxt.vo.student.Student;
import cn.sxt.vo.teacher.Cluss;
import cn.sxt.vo.teacher.Teacher;

public class OpenSessionInviewFilter implements Filter{

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpSession hs=((HttpServletRequest)request).getSession();
//		Teacher teacher=new Teacher();
//		teacher.setId(1);
//		teacher.setName("寮犱笁");
//		teacher.setPwd("123456");
//		hs.setAttribute("teacher", teacher);
//		Student student=new Student();
//		student.setId(1);
//		student.setName("鏉庡洓");
//		Cluss cluss = new Cluss();
//		cluss.setId(1);
//		student.setCluss(cluss);
//		hs.setAttribute("user", student);
		Session session = HibernateUtil.getSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			chain.doFilter(request, response);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			if(transaction!=null){
				transaction.rollback();
			}
		} finally {
			HibernateUtil.closeSession();
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		
	}
	
	@Override
	public void destroy() {
		
	}
}
