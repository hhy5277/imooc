package cn.sxt.util;

import cn.sxt.dao.implteacher.SubjectDaoImpl;
import cn.sxt.vo.teacher.Subject;

public class Test {
	public static void main(String[] args) {
		/*SubjectDaoJdbcImpl subjectDaoJdbcImpl=new SubjectDaoJdbcImpl();
		System.out.println(subjectDaoJdbcImpl.getList().size());
		
		SubjectDaoHibernateImpl sdh=new SubjectDaoHibernateImpl();
		
		System.out.println("Test.main()+"+sdh.getList().size());*/
		SubjectDaoImpl subjectDaoImpl=new SubjectDaoImpl();
		//Subject subject=new Subject();
		/*subject.setName("servlet");
		int x=subjectDaoImpl.add(subject);
		System.out.println("新增了："+x+"条数据！");*/
		System.out.println("增加了："+subjectDaoImpl.add(new Subject(1, "java"))+"条数据！");
	}
}
