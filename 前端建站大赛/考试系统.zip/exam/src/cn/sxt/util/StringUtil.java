package cn.sxt.util;

public class StringUtil {
	public static String stringArrayToString(String[] array) {
		StringBuffer sb = new StringBuffer();
		if (array != null) {
			for (String str : array) {
				sb.append(str);
			}
		}
		return sb.toString();
	}
}
