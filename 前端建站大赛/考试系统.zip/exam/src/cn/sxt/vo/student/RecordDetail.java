package cn.sxt.vo.student;

import cn.sxt.vo.teacher.Question;

public class RecordDetail {
	private int id;
	private Record record;
	private Question question;
	private String answer;
	
	
	/**
	 * get set Method
	 * @return
	 */
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Record getRecord() {
		return record;
	}
	public void setRecord(Record record) {
		this.record = record;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
}
