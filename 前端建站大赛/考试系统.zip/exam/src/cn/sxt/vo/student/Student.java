package cn.sxt.vo.student;

import cn.sxt.vo.teacher.Cluss;

public class Student {
	private int id;
	private String stuNo;
	private String name;
	private String pwd;
	private String sex;
	private Cluss cluss;
	
	public Student() {
	
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStuNo() {
		return stuNo;
	}

	public void setStuNo(String stuNo) {
		this.stuNo = stuNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Cluss getCluss() {
		return cluss;
	}

	public void setCluss(Cluss cluss) {
		this.cluss = cluss;
	}

		
	
}
