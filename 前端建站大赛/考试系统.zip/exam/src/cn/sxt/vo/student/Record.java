package cn.sxt.vo.student;



import java.util.Date;

import cn.sxt.vo.teacher.Subject;

public class Record {//id stuId subjectId score createTime
	private int id;
	private Student student;
	private Subject subject;
	private double score;
	private Date createTime;
	
	/**
	 * get set Method
	 * @return
	 */
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	
	
	
}
