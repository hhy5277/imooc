package cn.sxt.vo.system;


import cn.sxt.vo.student.Record;
import cn.sxt.vo.student.Student;

public class Temp {
	private int id;
	private Student student;
	private Record record;
	private long startTime;
	private int timeLength;
	
	
	/**
	 * get set Method
	 * @return
	 */
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Record getRecord() {
		return record;
	}
	public void setRecord(Record record) {
		this.record = record;
	}
	public long getStartTime() {
		return startTime;
	}
	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}
	public int getTimeLength() {
		return timeLength;
	}
	public void setTimeLength(int timeLength) {
		this.timeLength = timeLength;
	}
	

	
}
