package cn.sxt.vo.teacher;

public class Subject {
	private int id;
	private String name;
	
	public Subject() {
		
	}

	public Subject(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	/**
	 * 
	 *  涓嬮潰鏄痝et鍜宻et鏂规硶
	 */
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
