package cn.sxt.dao.student;

import java.util.List;

import cn.sxt.vo.student.Student;

public interface StudentDao {
	public List<Student> getList();
	public int add(Student student);
	public int delete(Student student);
	public int update(Student student);
	public Student getById(Integer id);
	public void batch(List<Student> stus);
	public Student login(String username, String password);
}
