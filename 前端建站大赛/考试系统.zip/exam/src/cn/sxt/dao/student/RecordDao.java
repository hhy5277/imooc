package cn.sxt.dao.student;

import java.util.List;

import cn.sxt.vo.student.Record;
import cn.sxt.vo.student.Student;

public interface RecordDao {
	public List<Record> getList();
	public int save(Record record);
	public int delete(Record record);
	public int update(Record record);
	public Record getById(Integer id);
	public List<Record> getListByHql(String hql);
}
