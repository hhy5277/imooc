package cn.sxt.dao.student;

import java.util.List;

import cn.sxt.vo.student.Record;
import cn.sxt.vo.student.RecordDetail;

public interface RecordDetailDao {
	public List<RecordDetail> getList();
	public int add(RecordDetail detail);
	public int delete(RecordDetail detail);
	public int update(RecordDetail detail);
	public RecordDetail getById(Integer id);
	public List<Integer> getQuestionId(String hql);
	public List<RecordDetail> getDetailsByHql(String hql);
}
