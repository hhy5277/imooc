package cn.sxt.dao.system;

import cn.sxt.vo.system.Temp;

public interface TempDao {
	public int add(Temp temp);
	public int delete(Temp temp);
	public Temp getByStudent(String hql);
}
