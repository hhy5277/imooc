package cn.sxt.dao.teacher;

import java.util.List;

import cn.sxt.util.Page;
import cn.sxt.vo.teacher.Question;

public interface QuestionDao {
	public List<Question> getList();
	public int add(Question question);
	public int update(Question question);
	public int delete(Question question);
	public Question getById(Integer id);
	public List<Question> getList(Page pager);
	public List<Question> query(String hql);
	public List<Question> getQuestionBySql(String sql);
	public List<Question> getQuestionByIds(List<Integer> questionIds);
	public long count();
}
