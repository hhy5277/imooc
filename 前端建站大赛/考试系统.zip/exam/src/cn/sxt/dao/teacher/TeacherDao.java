package cn.sxt.dao.teacher;

import java.util.List;

import cn.sxt.vo.teacher.Teacher;

public interface TeacherDao {
	public List<Teacher> getList();
	public int add(Teacher teacher);
	public int delete(Teacher teacher);
	public int update(Teacher teacher);
	public Teacher getById(Integer id);
	public Teacher login(String username, String password);
}
