package cn.sxt.dao.teacher;

import java.util.List;

import cn.sxt.vo.teacher.Question;
import cn.sxt.vo.teacher.Subject;

public interface SubjectDao {
	public List<Subject> getList();
	public int add(Subject subject);
	public Subject getById(Integer id);
	public int delete(Subject subject);
	public int update(Subject subject);
}
