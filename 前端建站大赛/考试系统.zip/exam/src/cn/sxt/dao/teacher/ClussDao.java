package cn.sxt.dao.teacher;

import java.util.List;

import cn.sxt.vo.teacher.Cluss;

public interface ClussDao {
	public List<Cluss> getList();
	public int add(Cluss cluss);
	public int delete(Cluss cluss);
	public int update(Cluss cluss);
	public Cluss getById(Integer id);
}
