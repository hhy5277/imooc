package cn.sxt.dao.teacher;

import java.util.List;

import cn.sxt.vo.teacher.Weight;

public interface WeightDao {
	public List<Weight> getList();
	public int add(Weight weight);
	public int delete(Weight weight);
	public int update(Weight weight);
	public Weight getById(Integer id);
	public Weight getWeightByHql(String hql);
}
