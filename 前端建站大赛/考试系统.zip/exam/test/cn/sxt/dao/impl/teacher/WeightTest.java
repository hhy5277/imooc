package cn.sxt.dao.impl.teacher;

import cn.sxt.service.impl.teacher.WeightServiceImpl;
import cn.sxt.service.teacher.WeightService;
import cn.sxt.vo.teacher.Cluss;
import cn.sxt.vo.teacher.Subject;
import cn.sxt.vo.teacher.Weight;

public class WeightTest {
	public void testUpdate(){
		Weight weight=new Weight();
		Cluss cluss=new Cluss();
		cluss.setId(1);
		Subject subject=new Subject();
		subject.setId(1);
		weight.setCluss(cluss);
		weight.setSubject(subject);
		WeightService weightService=new WeightServiceImpl();
		int x=weightService.update(weight);
		System.out.println(x);
	}
}
