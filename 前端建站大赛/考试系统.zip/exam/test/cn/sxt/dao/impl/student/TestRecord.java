package cn.sxt.dao.impl.student;

import org.junit.Test;

import cn.sxt.dao.implstudent.RecordDaoImpl;
import cn.sxt.dao.student.RecordDao;
import cn.sxt.vo.student.Record;
import cn.sxt.vo.student.Student;
import cn.sxt.vo.teacher.Subject;

public class TestRecord {
	@Test
	public void testRecordDao(){
		RecordDao recordDao=new RecordDaoImpl();
		Record record=new Record();
		Student student =new Student();
		student.setId(1);
		Subject subject=new Subject();
		subject.setId(1);
		record.setStudent(student);
		record.setSubject(subject);
		System.out.println(recordDao.save(record));
	}
}
