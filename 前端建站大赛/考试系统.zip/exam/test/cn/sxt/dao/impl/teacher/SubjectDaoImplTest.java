package cn.sxt.dao.impl.teacher;

import org.junit.Test;

import cn.sxt.dao.implteacher.SubjectDaoImpl;
import cn.sxt.vo.teacher.Subject;
import static org.junit.Assert.*;
public class SubjectDaoImplTest {
	@Test
	public void testAdd(){
		Subject subject=new Subject();
		subject.setName("junit");
		SubjectDaoImpl  subjectDaoImpl=new SubjectDaoImpl();
		int result= subjectDaoImpl.add(subject);
		assertEquals(1, result);
	}
	public void testAdd1(){
		SubjectDaoImpl subjectDaoImpl=new SubjectDaoImpl();
		int result=subjectDaoImpl.add(null);
		assertEquals(0, result);
	}
}
