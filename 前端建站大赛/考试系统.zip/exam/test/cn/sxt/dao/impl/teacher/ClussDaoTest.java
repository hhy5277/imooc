package cn.sxt.dao.impl.teacher;

import org.junit.Test;

import cn.sxt.dao.implteacher.ClussDaoImpl;
import cn.sxt.dao.teacher.ClussDao;

public class ClussDaoTest {
	@Test
	public void testGet(){
		ClussDao clussDao=new ClussDaoImpl();
		System.out.println(clussDao.getList().size());
	}
}
