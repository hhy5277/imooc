package cn.sxt.dao.impl.student;

import org.junit.Test;

import cn.sxt.dao.implsystem.TempDaoImpl;
import cn.sxt.dao.system.TempDao;
import cn.sxt.vo.system.Temp;

public class TestTempDao {
	@Test
	public void testTempDao(){
		String hql="from Temp t where t.student.id=1";
		TempDao tempDao=new TempDaoImpl();
		Temp temp=tempDao.getByStudent(hql);
		System.out.println(temp);
	}
}
