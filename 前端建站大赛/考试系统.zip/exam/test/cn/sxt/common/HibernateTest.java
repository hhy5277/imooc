package cn.sxt.common;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.junit.Test;

import cn.sxt.util.HibernateUtil;
import cn.sxt.vo.student.Student;
import cn.sxt.vo.teacher.Cluss;

public class HibernateTest {
	/**
	 * 数据库清空并重建
	 */
	
	@Test
	public void testCreateDB(){
		Configuration configuration=new Configuration().configure();
		SchemaExport sExport=new SchemaExport(configuration);
		sExport.create(true, true);
	}
	/**
	 * 数据库初始化
	 */
	@Test
	public void testInitDB(){
		Session session = HibernateUtil.getSession();
		Transaction transaction=session.beginTransaction();
		Cluss cluss = new Cluss();
		cluss.setName("20151202");
		//session.save(cluss);
		Student student = new Student();
		student.setStuNo("2015120201");
		student.setName("科比");
		student.setPwd("wanisha");
		student.setSex("男");
		student.setCluss(cluss);
		Student student2=new Student();
		student2.setStuNo("2015120202");
		student2.setName("库里");
		student2.setPwd("kadaishan");
		student2.setSex("男");
		student2.setCluss(cluss);
		session.save(student);
		session.save(student2);
		transaction.commit();
	}
	
}
