package cn.sxt.common;

import org.hibernate.Session;
import org.junit.Test;

import cn.sxt.util.HibernateUtil;
import cn.sxt.vo.student.Student;

public class StudentTest {
	@Test
	public void testGet(){
		Session session=HibernateUtil.getSession();
		Student student =(Student) session.get(Student.class, 2);
		System.out.println(student.getName());
		System.out.println(student.getCluss().getName());
	}
}
