package cn.sxt.common;

import org.hibernate.Session;
import org.junit.Test;

import cn.sxt.util.HibernateUtil;
import cn.sxt.vo.student.Student;
import cn.sxt.vo.teacher.Cluss;

public class ClussTest {
	@Test
	public void testGet(){
		Session session = HibernateUtil.getSession();
		Cluss cluss = (Cluss) session.get(Cluss.class, 1);
		System.out.println("cluss的名称"+cluss.getName());
		System.out.println("-----------------------");
		for(Student student:cluss.getStudents()){
			System.out.println(student.getName());
		}
	}
}
