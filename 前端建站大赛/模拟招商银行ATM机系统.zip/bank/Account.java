package sunday.bank;

public class Account {
	private String name;
	private int id;
	private int passwd;
	private double money;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPasswd() {
		return passwd;
	}
	public void setPasswd(int passwd) {
		this.passwd = passwd;
	}	
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	public Account(){
		
	}
	public Account(int id,String name,int passwd,double money){
		this.id=id;
		this.name=name;
		this.passwd=passwd;
		this.money=money;
	}
	public void add(double m){
		this.money+=m;
	}
	public void minus(double m){
		this.money-=m;
	}
	
}
