package sunday.bank;

import java.util.Scanner;

public class ATM {
	Scanner input=new Scanner(System.in);
	Account ac1=new Account(6214,"ranarang",123456,100);
	Account ac2=new Account(6215,"耶律阿古宝",666666,20000);
	Account ac3=new Account(6216,"doubledumbao",888888,30000);
	Account []a={ac1,ac2,ac3};
	public void welcome(){
		System.out.println("*******************************");
		System.out.println("*******欢迎使用招商银行ATM机*********");
		System.out.println("*******************************");
	}
	int index;
	public int login(){
		System.out.print("请输入账号：");
		int idIn=input.nextInt();
		for(int i=0;i<a.length;i++){
			if(idIn==a[i].getId()){
				index=i;				
				break;
			}		
		}
		passIn();
		System.out.println("登录成功！");
		return index;		
	}
	//输入密码
	public void passIn(){
		System.out.print("请输入6位数字密码：");
		int pass=input.nextInt();
		while(true){
			if(pass==a[index].getPasswd()){				
				break;
			}else{
				System.out.println("您输入的密码不正确！请重新输入密码！");
				pass=input.nextInt();
			}
		}	
	}
	
	//显示服务菜单
	public void menu(){
		System.out.println("本ATM机提供以下服务：");
		System.out.println("1.查询"+"\n2.修改密码"+"\n3.存款"+"\n4.取款"+"\n5.转账"+"\n6.退出");
		
	}
	//查询功能实现
	public void inquiry(){
		passIn();
		System.out.println("您的银行账号为："+a[index].getId());
		System.out.println("您的用户名为："+a[index].getName());
		System.out.println("您的账户余额为"+a[index].getMoney());
	}
	//修改密码实现
	public void changePasswd(){
		System.out.println("请输入新的6位数密码");
		int np=input.nextInt();
		System.out.println("请再次输入您的新的6位数密码");
		int nnp=input.nextInt();
		while(true){
			if(np==nnp){
				System.out.println("密码修改成功，请保管好您的新密码！");
				a[index].setPasswd(np);
				break;
			}else{
				System.out.println("新密码不匹配，请重新输入新密码！");
				nnp=input.nextInt();
			}
		}
	}
	//存款功能实现
	public void deposit(){
		System.out.println("请输入存款金额：");
		double m=input.nextDouble();
		a[index].add(m);
	
	}
	//取款功能实现
	public void drawMoney(){
		System.out.println("请输入取款金额：");
		double m=input.nextDouble();
		a[index].minus(m);
	}
	//转账功能实现
	public void transfor(){
		System.out.println("该功能暂未开放，敬请期待！");
	}
	//退出功能实现
	public void exit(){
		System.out.println("谢谢使用招行ATM机，欢迎下次光临！");
		System.exit(0);
	}	
}
