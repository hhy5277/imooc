package sunday.bank;

import java.util.Scanner;

public class Test {
	public static void main(String []args){
		ATM atm=new ATM();
		atm.welcome();
		atm.login();		
		atm.passIn();
		System.out.println("登录成功！");
		while(true){
			atm.menu();			
			Scanner input=new Scanner(System.in);
			int choice=input.nextInt();
		
			switch(choice){
				case 1:
					atm.inquiry();
					break;
				case 2:
					atm.changePasswd();
					break;
				case 3:
					atm.deposit();
					break;
				case 4:
					atm.drawMoney();
					break;
				case 5:
					atm.transfor();
					break;
				case 6:
					atm.exit();
					break;
				default:
					System.out.println("您输入的序号不正确，请重新输入！");
					choice=input.nextInt();
			}			
		}
		
	}
}


