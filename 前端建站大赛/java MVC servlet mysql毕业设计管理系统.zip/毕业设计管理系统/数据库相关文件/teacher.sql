/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50149
Source Host           : localhost:3306
Source Database       : study

Target Server Type    : MYSQL
Target Server Version : 50149
File Encoding         : 65001

Date: 2015-12-29 11:36:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `teacher`
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `id` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `name` varchar(10) NOT NULL,
  `sex` varchar(2) DEFAULT NULL,
  `department` varchar(10) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('12345', '1020', '陈老师', '男', '计算机系', '5656');
INSERT INTO `teacher` VALUES ('123454', '1020', '董老师', '女', '计算机系', '智能家居项目 ');
INSERT INTO `teacher` VALUES ('12346', '1020', '陈老师', '男', '计算机系', '基于物联网');
INSERT INTO `teacher` VALUES ('12347', '1020', '王老师', '女', '计算机系', '企业网站开发');
INSERT INTO `teacher` VALUES ('12348', '1020', '黄老师', '女', '计算机系', '基于zigbee开发');
INSERT INTO `teacher` VALUES ('12349', '1020', '冯老师', '男', '计算机系', '安卓牵手物联网');
INSERT INTO `teacher` VALUES ('12355', '1020', '王吉林', '女', '计算机系', '企业网站开发');
INSERT INTO `teacher` VALUES ('12356', '1020', '许老师', '女', '计算机系', '基于物联网智能家居');
