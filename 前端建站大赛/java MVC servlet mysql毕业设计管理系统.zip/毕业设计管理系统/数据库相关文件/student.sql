/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50149
Source Host           : localhost:3306
Source Database       : study

Target Server Type    : MYSQL
Target Server Version : 50149
File Encoding         : 65001

Date: 2015-12-29 11:36:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(4) DEFAULT NULL,
  `cla` varchar(20) DEFAULT NULL,
  `grade` varchar(20) DEFAULT NULL,
  `task` varchar(20) DEFAULT NULL,
  `department` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1340705124', '1020', '张浩纯', '男', '13web', '90', 'java系统开发', '计算机系');
INSERT INTO `student` VALUES ('1340705125', '1020', '罗志祥', '男', '13物2', '', '安卓高级应用', '计算机系');
INSERT INTO `student` VALUES ('1340705126', '1020', '孙思远', '男', '13无线', '', '安卓与物联网结合', '计算机系');
INSERT INTO `student` VALUES ('1340705127', '1020', '庄为朋', '男', '13无线', '', 'zigbee物联网项目', '计算机系');
INSERT INTO `student` VALUES ('1340705128', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705129', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705130', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705131', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705132', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705133', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705134', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705135', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705136', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705137', '1020', '小明', '男', '13web', '100', '毕业设计管理系统', '计算机系');
INSERT INTO `student` VALUES ('1340705143', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705144', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705145', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705146', '1020', '张浩纯', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705147', '1020', '朱嘉锋', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705148', '1020', '朱嘉锋', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705149', '1020', '朱嘉锋', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705150', '1020', '朱嘉锋', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705151', '1020', '朱嘉锋', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705152', '1020', '朱嘉锋', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705153', '1020', '朱嘉锋', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705154', '1020', '朱嘉锋', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705155', '1020', '朱嘉锋', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340705156', '1020', '朱嘉锋', '男', '13web', '100', '传感器', '计算机系');
INSERT INTO `student` VALUES ('1340706161', '1020', '朱嘉锋', '男', '13web', '85', '数据库也开发管理', '计算机系');
INSERT INTO `student` VALUES ('1440705124', '1020', '小张', '男', '13web', '100', '', '计算机系');
