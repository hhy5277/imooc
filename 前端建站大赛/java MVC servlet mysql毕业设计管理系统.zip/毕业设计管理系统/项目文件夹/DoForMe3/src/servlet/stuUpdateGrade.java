package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Dao.studentDao;

public class stuUpdateGrade extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
	
		
		try {
			String department=request.getParameter("department");
			String[] id=request.getParameterValues("id");
			String[] name=request.getParameterValues("name");
			String[] grade=request.getParameterValues("grade");
			//System.out.println(name.length);
			studentDao sd=new studentDao();
			sd.updateStudentScore(grade, id, name, department);
			response.sendRedirect("/DoForMe3/index.jsp");
		} catch (Exception e) {
			
			response.sendRedirect("/DoForMe3/error.jsp");
		}
		
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		doPost(request, response);
	}
}
