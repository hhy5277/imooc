package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Vo.studentVo;
import Dao.studentDao;

public class studentLogin extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		//验证码部分
		String code=request.getParameter("code");
		String randStr = (String)session.getAttribute("randStr");
		response.setCharacterEncoding("gb2312");
		PrintWriter out = response.getWriter();
		if(!code.equals(randStr)){
			out.println("验证码错误！请后退重新登录");
		}
		else{
			
			
			//数据库部分
			String id=request.getParameter("id");
			String password=request.getParameter("password");
			studentDao sd=new studentDao ();
			   ArrayList<studentVo> message=new ArrayList<studentVo>();
			try {
				message = sd.getAllStudentMessage(id, password);
				if(message.size()>0){
					   	session.setAttribute("message",message);
					   	response.sendRedirect("/DoForMe3/Student/student.jsp");
					   //	request.getRequestDispatcher("book.jsp").forward(request, response);
				}else{
					response.sendRedirect("/DoForMe3/error.jsp");
				}
				
				 	
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}		
		
		
		  
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
}
