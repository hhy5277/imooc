package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.teacherDao;

public class admTeacherInsert extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String id=request.getParameter("id");
		String password=request.getParameter("password");
		String name=request.getParameter("name");
		String sex=request.getParameter("sex");
		String department=request.getParameter("department");
		String subject=request.getParameter("subject");
		teacherDao td=new teacherDao();
		
		try {
			 
			td.insertTeacherMessage(id, password, name, sex, department, subject);
			response.sendRedirect("/DoForMe3/Administrator/stuInsertSucceed.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//response.sendRedirect("/DoForMe3/Administrator/stuInsertSucceed.jsp");
		}
		
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		doPost(request, response);
	}
}
