package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.teacherDao;

import com.jspsmart.upload.File;
import com.jspsmart.upload.Request;
import com.jspsmart.upload.SmartUpload;
import com.jspsmart.upload.SmartUploadException;

public class teaUploadReport extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		SmartUpload smartupload=new SmartUpload();
		//初始化
		Request req=smartupload.getRequest();
		
		//得到对象
		ServletConfig config=this.getServletConfig();
		smartupload.initialize(config, request, response);
		
		
		try {
			//文件上传
			smartupload.upload();
			//得到上传的文件对象
			File smartFile=smartupload.getFiles().getFile(0);
			//保存文件
			smartFile.saveAs("G:/DoForMe3/teachers/"+smartFile.getFieldName(),smartupload.SAVE_PHYSICAL);
			String msg="上传成功！";
			request.setAttribute("msg", msg);
			
		} catch (SmartUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String subject=req.getParameter("subject");
		String id=(String) session.getAttribute("id");
		teacherDao td=new teacherDao();
		try {
			td.updateTeacherTask(subject, id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
			RequestDispatcher rd=request.getRequestDispatcher("/Teacher/teaUploadReport.jsp");
			rd.forward(request, response);
		//
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		doPost(request, response);
	}
}
