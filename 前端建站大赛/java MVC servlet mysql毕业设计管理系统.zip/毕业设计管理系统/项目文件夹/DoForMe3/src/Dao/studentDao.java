package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


import Vo.studentVo;

public class studentDao {
	private Connection conn=null;
	public void initConnection() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/study", "root", "root");
	}
	//找到数据库
	public ArrayList<studentVo> getAllStudentMessage(String id,String password) throws Exception{
		ArrayList<studentVo> al=new ArrayList<studentVo>();
		initConnection();
		String sql="select * from student where id=? and password=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, id);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			System.out.println("aaa");
			studentVo studentvo =new studentVo();
			studentvo.setId(rs.getString("id"));
			studentvo.setPassword(rs.getString("password"));
		 	studentvo.setName(rs.getString("name"));
		 	studentvo.setSex(rs.getString("sex"));
		 	studentvo.setCla(rs.getString("cla"));
		 	studentvo.setGrade(rs.getString("grade"));
		 	studentvo.setTask(rs.getString("task"));
			al.add(studentvo);
		}
		 
		conn.close();
		
		return al;
	}
	//返回学生详细信息
	
	public ArrayList<studentVo> getAllStudent(String department) throws Exception{
		ArrayList<studentVo> alll=new ArrayList<studentVo>();
		initConnection();
		String sql="select id,name,sex,cla,grade,task from student where department=?";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1, department);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			studentVo studentvo =new studentVo();
			studentvo.setId(rs.getString("id"));
			studentvo.setName(rs.getString("name"));
			studentvo.setSex(rs.getString("sex"));
			studentvo.setCla(rs.getString("cla"));
			studentvo.setGrade(rs.getString("grade"));
			studentvo.setTask(rs.getString("task"));
			alll.add(studentvo);
		}
		 
		conn.close();
		
		return alll;
	}
	
	
	
	
	//返回所有报考学生的信息()
	public void ChangeStudentPwd (String password,String id) throws Exception{
		initConnection();
		String sql="update student set password=? where id=?" ;
		PreparedStatement ps=conn.prepareStatement(sql);
		
		ps.setString(1,password);
		ps.setString(2,id);
		ps.executeUpdate();
		
		ps.close();
		conn.close();
	}
	//学生修改密码
	
	public void updateStudentScore(String[] grade,String[] id,String[] name,String department
			) {
		try {
			initConnection();
			String sql="update student set " +
					"grade=? where id=? and name=? and department=?" ;
			PreparedStatement ps=conn.prepareStatement(sql);
			for(int i=0;i<id.length;i++){
				System.out.println(name[i]);
				if(grade[i].equals("")||grade[i].equals(null)){
					ps.setString(1, grade[i]);
					
				}
			}
			ps.executeUpdate();
			
			ps.close();
			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	//教师提交成绩
	
	
	
	public void updateStudentMessage(String id,String password,String name,String sex,
			String cla,String grade,String task
			) throws Exception{
		initConnection();
		String sql="update student set " +
				"id=?,password=?,name=?,sex=?,cla=?,grade=?,task=?" ;
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1,id);
		ps.setString(2,password);
		ps.setString(3,name);
		ps.setString(4,sex);
		ps.setString(5, cla);
		ps.setString(6,grade);
		ps.setString(7, task);
		
		
		ps.executeUpdate();
		
		ps.close();
		conn.close();
	}
	//管理员修改自己的信息（改）
	public void insertStudentMessage(String id,String password,String name,
			String sex,String cla,String grade,String task,String department)throws Exception{
		initConnection();
		String sql="insert into student(id,password,name,sex,cla,grade,task,department) values" +
				"(?,?,?,?,?,?,?,?)" ;
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1, id);
		ps.setString(2,password);
		ps.setString(3,name);
		ps.setString(4,sex);
		ps.setString(5,cla);
		ps.setString(6, grade);
		ps.setString(7,task);
		ps.setString(8,department);
		ps.executeUpdate();
	
		ps.close();
		conn.close();
	}
	//学生提交课题
	public void updateStudentTask(String task,String id
			) throws Exception{
		initConnection();
		String sql="update student set task=? where id=?";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1, new String(new String(task.getBytes("gbk"),"utf-8")));
		ps.setString(2,id);
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
	
	
	public void deleteStudentMessage(String name,String id)throws Exception{
		initConnection();
		String sql="delete from student where name=? and id=?";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1, name);
		ps.setString(2,id);
		
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
}
