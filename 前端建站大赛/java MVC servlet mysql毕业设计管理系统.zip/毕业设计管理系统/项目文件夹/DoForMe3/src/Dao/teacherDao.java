package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;


import Vo.teacherVo;

public class teacherDao {
	private Connection conn=null;
	public void initConnection() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/study", "root", "root");
	}
	//找到数据库
	public ArrayList<teacherVo> getAllTeacherMessage(String id,String password) throws Exception{
		ArrayList<teacherVo> al=new ArrayList<teacherVo>();
		initConnection();
		String sql="select * from teacher where id=? and password=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, id);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			teacherVo teachervo =new teacherVo();
			teachervo.setId(rs.getString("id"));
			teachervo.setPassword(rs.getString("password"));
			teachervo.setName(rs.getString("name"));
			teachervo.setSex(rs.getString("sex"));
			teachervo.setSubject(rs.getString("subject"));
			al.add(teachervo);
		}
		 
		conn.close();
		
		return al;
	}
	//返回教师信息
	
	public ArrayList<teacherVo> getAllTeacher(String department) throws Exception{
		ArrayList<teacherVo> all=new ArrayList<teacherVo>();
		initConnection();
		String sql="select id,name,subject from teacher where department=?";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1, department);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			teacherVo teachervo =new teacherVo();
			teachervo.setId(rs.getString("id"));
			teachervo.setName(rs.getString("name"));
			teachervo.setSubject(rs.getString("subject"));
			all.add(teachervo);
		}
		 
		conn.close();
		
		return all;
	}
	
	
	
	//返回老师所有的信息()
	
	
	
	
	public void ChangeTeacherPwd (String password,String id) throws Exception{
		initConnection();
		String sql="update teacher set password=? where id=?" ;
		PreparedStatement ps=conn.prepareStatement(sql);
		
		ps.setString(1,password);
		ps.setString(2,id);
		ps.executeUpdate();
		
		ps.close();
		conn.close();
	}
	//教师修改密码
	
	
	
	
	public void updateTeacherMessage(String id,String password,String name,String sex,
			String subject
			) throws Exception{
		initConnection();
		String sql="update teacher set " +
				"password=?,name=?,sex=?,subejct=? where id=?" ;
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1,password);
		ps.setString(2,name);
		ps.setString(3,sex);
		ps.setString(4, subject);
		ps.setString(5,id);
		
		ps.executeUpdate();
		
		ps.close();
		conn.close();
	}
	//老师修改自己的信息（改）
	
	//老师提交课题
		public void updateTeacherTask(String subject,String id
				) throws Exception{
			initConnection();
			String sql="update teacher set subject=? where id=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, new String(new String(subject.getBytes("gbk"),"utf-8")));
			//这里有问题
			ps.setString(2,id);
			ps.executeUpdate();
			
			ps.close();
			conn.close();
		}
	
	
	
	public void insertTeacherMessage(String id,String password,String name,String sex,
			String department,String subject)throws Exception{
		initConnection();
		String sql="insert into teacher(id,password,name,sex,department,subject) values" +
				"(?,?,?,?,?,?)" ;
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1, id);
		ps.setString(2,password);
		ps.setString(3,name);
		ps.setString(4,sex);
		ps.setString(5, department);
		ps.setString(6,subject);
		ps.executeUpdate();
	
		ps.close();
		conn.close();
	}
	//管理员添加教师信息
	public void deleteTeacherMessage(String name,String id)throws Exception{
		initConnection();
		String sql="delete from teacher where name=? and id=?";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1, name);
		ps.setString(2,id);
		
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
}

