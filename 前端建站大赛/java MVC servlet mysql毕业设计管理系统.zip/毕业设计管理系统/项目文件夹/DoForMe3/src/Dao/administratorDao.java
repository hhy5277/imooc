package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import Vo.administratorVo;


public class administratorDao {
	private Connection conn=null;
	public void initConnection() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/study", "root", "root");
	}//找到数据库
	public ArrayList<administratorVo> getAllAdministratorMessage(String id,String password) throws Exception{
		ArrayList<administratorVo> al=new ArrayList<administratorVo>();
		initConnection();
		String sql="select * from administrator where id=? and password=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, id);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			administratorVo administratorvo =new administratorVo();
			administratorvo.setId(rs.getString("id"));
			administratorvo.setPassword(rs.getString("password"));
			al.add(administratorvo);
		}
		 
		conn.close();
		
		return al;
	}
	
	//返回老师所有的信息()

	
	public void updateAdministratorMessage(String id,String password) throws Exception{
		initConnection();
		String sql="update administrator set " +
				"password=? where id=?" ;
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1,password);
		ps.setString(2,id);
		
		ps.executeUpdate();
		
		ps.close();
		conn.close();
	}
}