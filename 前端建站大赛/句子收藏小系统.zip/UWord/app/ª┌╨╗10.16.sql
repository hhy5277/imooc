
CREATE TABLE remark
(
   ID                   INT NOT NULL AUTO_INCREMENT,
   CONTENT              VARCHAR(1000),
   ARTICLE_ID           INT,
   USER_ID              INT,
   CREATE_TIME          VARCHAR(50),
   FATHER_ID            INT,
   MARK_CODE            VARCHAR(100),
   PRIMARY KEY (ID)
);

CREATE TABLE article_type
(
   ID                   INT NOT NULL AUTO_INCREMENT,
   NAME                 VARCHAR(50),
   STATUS               INT,`user_info`
   PRIMARY KEY (ID)
);

CREATE TABLE user_info
(
   ID                   INT NOT NULL AUTO_INCREMENT,
   USER_NAME            VARCHAR(120),`article_type``user_info`
   PASSWORD             VARCHAR(50),
   REGISTER_TIME        VARCHAR(50),
   IMG                  VARCHAR(120),
   TEL                  VARCHAR(50),
   EMAIL                VARCHAR(120),
   PRIMARY KEY (ID)
);

CREATE TABLE article
(
   ID                   INT NOT NULL AUTO_INCREMENT,
   CREATE_TIME          VARCHAR(50),
   USER_ID              INT,
   AUTHOR               VARCHAR(120),
   CONTENT              VARCHAR(1000),
   TYPE_ID              INT,
   PRIMARY KEY (ID)
);

CREATE TABLE store
(
   ID                   INT NOT NULL AUTO_INCREMENT,
   USER_ID              INT,
   ARTICLE_ID           INT,
   CREATE_TIME          VARCHAR(50),
   STORE_TYPE           INT COMMENT '1点赞 2收藏',
   PRIMARY KEY (ID)
);

SELECT article_id FROM store WHERE store_type="1" ORDER BY create_time DESC LIMIT 0,10 

SELECT * FROM article  WHERE id IN (SELECT m.article_id FROM(SELECT * FROM store WHERE store_type=1 ORDER BY create_time DESC LIMIT 0,10) AS m )

//查询点赞最多的前10条文章数据
SELECT a.*,(SELECT COUNT(1) FROM store WHERE store_type=2  AND article_id = a.id) collect,(SELECT COUNT(1) FROM store WHERE store_type=1  AND article_id = a.id) dz FROM article a 

ORDER BY dz DESC LIMIT 0,2

WHERE id IN (
SELECT article_id FROM store GROUP BY article_id ) 

INSERT  INTO `article`(`CREATE_TIME`,`USER_ID`,`REGISTER_TIME`,`IMG`,`TEL`,`EMAIL`) VALUES (1,'周浩','123456','2015-10-10',NULL,'18576627167',NULL);

SELECT a.*,(SELECT COUNT(1) FROM store WHERE store_type=2  AND article_id = a.id) collect,(SELECT * FROM user_info WHERE id = a.user_id) USER,(SELECT COUNT(1) FROM store WHERE store_type=1  AND article_id = a.id) dz,(SELECT COUNT(1) FROM remark) pl FROM article a  ORDER BY dz DESC LIMIT 0,2 

SELECT a.*,(SELECT COUNT(1) FROM store WHERE store_type=2  AND article_id = a.id) collect,(SELECT * FROM user_info WHERE id = a.user_id) peo,(SELECT COUNT(1) FROM store WHERE store_type=1  AND article_id = a.id) dz,(SELECT COUNT(1) FROM remark) pl FROM article a  ORDER BY pl DESC LIMIT 0,2 

SELECT a.*,(SELECT COUNT(1) FROM store WHERE store_type=2  AND article_id = a.id) collect,(SELECT COUNT(1) FROM store WHERE store_type=1  AND article_id = a.id) dz,(SELECT COUNT(1) FROM remark) pl FROM article a WHERE type_id=4 ORDER BY create_time LIMIT 0,2



SELECT a.*,u.user_name,u.img,(SELECT COUNT(1) FROM store WHERE store_type=2  AND article_id = a.id) collect,(SELECT COUNT(1) FROM store WHERE store_type=1  AND article_id = a.id) dz FROM article a 

LEFT JOIN user_info u ON a.user_id = u.id













