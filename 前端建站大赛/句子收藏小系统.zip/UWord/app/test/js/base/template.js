/**
 * Created by zhouhao on 15-10-28.
 */
var Template = function(){
   this.baseUrl = Public.myTools.rootPath();
}
Template.prototype={
    init:function(){
        this.loadTmplHtml();
    },
    loadTmplHtml:function(){
        var url = this.baseUrl +"/template/Content.html";
        var sendData={};
        var callback = function(htmlData){
            $("body").html(htmlData);
        };
        $.ajax({
            url:url,
            data:sendData,
            success:function(jsonData){

            }

        })
        Public.myTools.ajaxLoadData(url,sendData,callback);
    }
};