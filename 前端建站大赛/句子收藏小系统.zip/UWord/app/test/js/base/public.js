/**
 * Created by zhouhao on 15-10-10.
 */
var Public = Public ? Public : {};
function IsPC()
{
    var userAgentInfo = navigator.userAgent;
    var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");
    var flag = true;
    for (var v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) > 0) {
            flag = false;
            break;
        }
    }
    return flag;
};
if(IsPC()){
    Public.eventType="click";
}else{
    Public.eventType="tap";
};
Public.myTools={
    stopBubble:function(e){
        if (e.stopPropagation) {
            // this code is for Mozilla and Opera
            e.stopPropagation();
        } else if (window.event) {
            // this code is for IE
            window.event.cancelBubble = true;
        }
        return false;
    },
    rootPath:function(){
        var fullPath = window.location.href;
        var targetUrl="http://yungu.yuanqu.cc/";
        if(targetUrl !=fullPath&&(fullPath.indexOf(".com")>0||fullPath.indexOf(".cc")>0)){
            return window.location.protocol + '//' + window.location.host;
        }else{
            var pathName = window.location.pathname.substring(1);
            var webName = pathName == '' ? '' : pathName.substring(0, pathName.indexOf('/'));
            if (webName == "") {
                return window.location.protocol + '//' + window.location.host;
            }
            else {
                return window.location.protocol + '//' + window.location.host + '/' + webName;
            }
        };
    },
    getParam:function(name){
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
        var r = window.location.search.substr(1).match(reg);  //匹配目标参数
        if (r != null) return unescape(r[2]);
        return null; //返回参数值
    },
    arrivalBottom:function(callback){
       $(window).scroll(function(){
           var bodyHeight = $("body").height();
           var scrollTop =document.body.scrollTop;
           var clientHeight= document.documentElement.clientHeight;
           if((bodyHeight-scrollTop)<=clientHeight){
               if(callback){
                   callback();
               }
           };
       });
    },
    errorImgSrc:function(){
        var img  = event.srcElement;
        img.src="images/default_horit.jpg";
        img.onerror=null;
    },
    showBgDiv:function(fn){
        $("#myShadeBg").height(document.body.scrollHeight).show();
        if(fn){
            fn();
        }
    },
    hideBgDiv:function(){
        $("#myShadeBg").hide();
    },
    bigLoading:function(id){
        $("#"+id).html("<div class=\"spinner\"></div>");
    },
    goToTarget:function(){
        var redirect_u = Public.myTools.getParam("redirect_u");
        if(typeof (redirect_u)=="undefined"||redirect_u==""||redirect_u==null){
            window.history.go(-1);
        }else{
            var path = decodeURIComponent(redirect_u);
            window.location.href=path;
        }
    },
    gotoLogin:function(){
        var fullPath = encodeURIComponent(window.location.href);
        window.location.href="login.html?redirect_u="+fullPath;
    },
    getSessionInfo:function(fn){
        var url="/isLogin";
        var sendData={}
        var callback = function(jsonData){
            var flag = jsonData.msg;
            if("0"==flag){
                var data={"isLogin":flag};
            }else if("1"==flag){
                var data = {isLogin:flag,user_info:jsonData.info};
            }
            Public.myTools.setLocalData(data);
            if(fn){
                fn();
            }
        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    },
    checkIsLogin:function(linkUrl,fn){
        var localDataObj = Public.myTools.getLocalStorage();
        var isLogin = localDataObj["isLogin"]; //0:未登录；1：已登录
        if(typeof (isLogin)=="undefined"||"0"==isLogin){
            Public.myTools.gotoLogin();
        }else if("1"==isLogin){
            if(linkUrl!=""){
                window.location.href=linkUrl;
            }else{
                if(fn){
                    fn();
                }
            };
        }
    },
    setLocalData:function(saveData,fn){
        if (window.localStorage) {
            var obj = localStorage.getItem("myData")||"{}";
            obj = JSON.parse(obj);
            $.extend(obj,saveData);
            localStorage.setItem("myData", JSON.stringify(obj));
            if(fn&&typeof(fn)=="function"){
                fn();
            }
        }else {
            /*Public.showTit("你的浏览器版本过低，请升级！", "no", function () { });*/
        }
    },
    getLocalStorage:function(){
        if (window.localStorage) {
            var obj = localStorage.getItem("myData")||"{}";
            obj = JSON.parse(obj);
            return obj;
        } else {
            /*Public.showTit("你的浏览器版本过低，请升级！", "no", function () { });*/
        }
    },
    ajaxLoadData:function(url, data, callback, errorCallback, async, contentType){
        async = typeof (async) != "undefined" ? async : true;
        $.ajax({
            url: url,
            data: data,
            type: "post",
            cache: false,
            contentType: contentType,
            success: function (jsonData) {
                var result=typeof (jsonData);
                if(result == "string"){
                    jsonData=eval('(' + jsonData + ')');
                };
                if (callback) {
                    callback(jsonData);
                };
            },
            ache: async,
            error: function (errorMsg) {
                var msg = "链接服务器失败";
                if (errorMsg.responseText) {
                    if (typeof (errorMsg.responseText) == "string") {
                        try {
                            msg = eval('(' + errorMsg.responseText + ')');
                            msg = msg.errormsg;
                        } catch (e) {

                        }
                    } else {
                        msg = errorMsg.responseText.errormsg;
                    }
                }
                if (errorCallback) {
                    errorCallback(msg);
                }
            }
        });
    }
}


//x消息提醒
var showTit = (function (w) {
    return function (msg,isClose,time,foo) {
        var time = time||3000;
        var isClose = isClose || "true";
        var _ico = "success_result";
        $("#successInfor").remove();
        $("body").append("<div class=\"public_result_div\" id=\"successInfor\"><span class=\"" + _ico + "\">" + msg + "</span></div>");
        var left = ($(window).width() - $("#successInfor").width()) / 2;
        var top = ($(window).height() - $("#successInfor").height()) / 2;
        $("#successInfor").css({ "left": left, "top": top });
        $("#successInfor").show();
        w.titHide = function () {
            if (isClose == "true") {
                $("#successInfor").hide("fast");
            }
            if (foo) {
                foo();
            }
        };
        setTimeout("titHide()", time);
    };
})(window);