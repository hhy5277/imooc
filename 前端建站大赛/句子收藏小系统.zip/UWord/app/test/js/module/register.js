/**
 * Created by zhouhao on 15-10-28.
 */
var Register = function(){

};

Register.prototype={
    init:function(){
        this.initFun();
    },
    initFun:function(){
        $(".js-reg").on(Public.eventType,function(){
            var reg=/^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
            var dataFlag = $(this).attr("data-flag");
            var mobileNum = $(".mobile").val();
            var pwd = $(".pwd1").val();
            var pwd2= $(".pwd2").val();
            var nickName = $(".nickName").val();
            if(mobileNum==""||pwd==""||pwd2==""){
                showTit("输入不能为空！","true","1500",function(){
                    return;
                });
            }else if(!reg.test(mobileNum)){
                showTit("手机号格式有误！","true","1500",function(){
                    return;
                });
            }else if(pwd.length<=5){
                showTit("密码长度过短！","true","1500",function(){
                    return;
                });
            }else if(pwd!=pwd2){
                showTit("两次密码不一致！","true","1500",function(){
                    return;
                });
            }else{
                var dataFlag = $(this).attr("data-flag")||0;
                if("0"==dataFlag){
                    var url="/action/user/insert";
                    var sendData={
                        user_name:nickName,
                        password:pwd,
                        tel:mobileNum
                    };
                    var callback = function(jsonData){
                        var flag = jsonData.flag;
                        if("1"==flag){
                            $(this).attr("data-flag",1);
                            showTit(jsonData.msg,"true","1500",function(){
                                window.location.href="login.html";
                            });
                        }else{
                            $(this).attr("data-flag",0);
                            showTit(jsonData.msg,"true","1500",function(){

                            });
                        }
                    };
                    Public.myTools.ajaxLoadData(url,sendData,callback);
                }
            }
        });
    }
};
$(function(){
    var register = new Register();
    register.init();
})