/**
 * Created by zhouhao on 15-10-19.
 */
var Login = function(){
    var _this =this;
    this.loginFlag=true;
    var getURL=decodeURIComponent(Public.myTools.getParam("redirect_u"));
    if(getURL==""||getURL=="null"){
        _this.redirect_u="person_center.html";
    }else{
        _this.redirect_u=getURL;
    }
}

Login.prototype={
    init:function(){
        this.checkLoginCondition();
    },
    loginAction:function(mobile,password){
        var _this = this;
        _this.loginFlag=false;
        var url="/action/loginin";
        var sendData={mobile:mobile,password:password};
        var callback = function(jsonData){
            var flag = jsonData.flag;
            if("0"==flag){
                //登陆失败
                showTit(jsonData.msg,"true",2000,function(){
                    _this.loginFlag=true;
                });
            }else if("1"==flag){
                showTit(jsonData.msg,"true",1500,function(){

                    window.location.href=_this.redirect_u;
                });
            }
        }
        Public.myTools.ajaxLoadData(url,sendData,callback);
    },
    checkLoginCondition:function(){
        var _this = this;
        $(".js-login").on(Public.eventType,function(){
            var mobile = $("#loginInZone").find("input[name='phone']").val();
            var password = $("#loginInZone").find("input[name='password']").val();
            if(mobile==""||password==""){
                showTit("填写信息不能为空！","true",2000,function(){
                    return false;
                })
            }else if(!/^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/.test(mobile)){
                showTit("手机号格式有误！","true",2000,function(){
                    return false;
                })
            }else{
                if(_this.loginFlag){
                    _this.loginAction(mobile,password);
                }
            }
        });
    }
};
$(function(){
    var login = new Login();
    login.init();
})