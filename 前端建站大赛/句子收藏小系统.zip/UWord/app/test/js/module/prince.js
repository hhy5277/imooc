var Prince=function(){
    this.bd = baidu.template;
    this.remark = new Remark();
}
Prince.prototype={
    init:function(){
        this.getSingleData("singleWordZone");
        this.initShakeFn();
        this.initAnimate();
    },
    getSingleData:function(id){
        var _this = this;
        Public.myTools.bigLoading(id);
        var url="/action/article/init";
        var sendData={type:3};
        var callback=function(jsonData){
            var localDataObj = Public.myTools.getLocalStorage();
            var isLogin = localDataObj["isLogin"]; //0:未登录；1：已登录
            var randomData = {articleList:jsonData,isLogin:isLogin};
            var tmplHtml = _this.bd("tmplArticleList",randomData);
            $("#"+id).html(tmplHtml);
            //初始化评论对象
            _this.remark.init();
        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    },
    initShakeFn:function(){
        var _this = this;
        var SHAKE_THRESHOLD = 3000;
        var last_update = 0;
        var x=y=z=last_x=last_y=last_z=0;
        function init(){
            if (window.DeviceMotionEvent) {
                window.addEventListener('devicemotion',deviceMotionHandler, false);
            }else{
                alert('not support mobile event');
            }
        };

        function deviceMotionHandler(eventData) {
            var acceleration =eventData.accelerationIncludingGravity;
            var curTime = new Date().getTime();
            if ((curTime - last_update)> 100) {
                var diffTime = curTime -last_update;
                last_update = curTime;
                x = acceleration.x;
                y = acceleration.y;
                z = acceleration.z;
                var speed = Math.abs(x +y + z - last_x - last_y - last_z) / diffTime * 10000;
                if (speed > SHAKE_THRESHOLD) {
                    _this.getSingleData("singleWordZone");
                }
                last_x = x;
                last_y = y;
                last_z = z;
            }
        }
        init();
    },
    publishWord:function($this,sendData){
        var url="/action/article/insert";
        var callback = function(jsonData){
            $this.attr("data-flag",1);
            var flag = jsonData.flag;
            if("0"==flag){
                showTit(jsonData.msg,"true","1500",function(){
                    $this.attr("data-flag",0);
                });
            }else{
                showTit(jsonData.msg,"true","1500",function(){
                    $(".close-btn").trigger(Public.eventType);
                });
            }
        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    },
    initAnimate:function(){
        var _this = this;
        $("#hPubBtn").on(Public.eventType,function(){
           Public.myTools.checkIsLogin("",function(){
                Public.myTools.showBgDiv(function(){
                    $("#publishInfoZone").show().animate({bottom:0},500,'ease-in-out');
                });
            });
        });
        $(".type-choose>select").on("change",function(){
            var num = $(this).val();
            if("4"==num){
                $("#authorSource").parent().hide();
            }else{
                $("#authorSource").parent().show();
            }
        })


        $(".close-btn").on(Public.eventType,function(e){
            Public.myTools.stopBubble(e);
            var rel=$(this).attr("rel");
            $("#"+rel).animate({bottom:"-231px"},500,'ease-in-out',function(){
                Public.myTools.hideBgDiv();
                $("#"+rel).hide();
            });
        });

        $(".js-pub-btn").on(Public.eventType,function(e){
            Public.myTools.stopBubble(e);
            var content = $("#contentSource").val();
            var author = $("#authorSource").val()||"";
            var typeId = $(".type-choose>select").val();
            if(content==""){
                showTit("请输入句子","true","1500",function(){
                    return;
                });
            }else{
                var dataFlag = $(this).attr("data-flag")||0;
                if("0"==dataFlag){
                    var sendData={
                        author:author,
                        content:content,
                        type_id:typeId
                    };
                    _this.publishWord($(this),sendData);
                }
            }
        });
    }
}
$(function(){
    var prince = new Prince();
    Public.myTools.getSessionInfo(function(){
        prince.init();
    });
});