/**
 * Created by zhouhao on 15-10-29.
 */
var ArticleContact = function(){
    this.bd = baidu.template;
    this.remark = new Remark();
    this.titleName="";
    this.titleArr=["我发布的","我收藏的","关于我的"];
    this.type=parseInt(Public.myTools.getParam("type"));
};

ArticleContact.prototype={
    init:function(){
        this.initData();
    },
    initData:function(){
        switch(this.type){
            case 4:
                this.titleName = this.titleArr[0];
                this.getData("singleWordZone");
                break;
            case 5:
                this.titleName = this.titleArr[1];
                this.getData("singleWordZone");
                break;
            case 6:
                this.titleName = this.titleArr[2];
                this.getData("singleWordZone");
                break;
        }
    },
    getData:function(id){
        window.document.title=this.titleName;
        $(".head-span").html(this.titleName);
        var _this = this;
        Public.myTools.bigLoading(id);
        var url="/action/article/init";
        var sendData={type:_this.type};
        var callback=function(jsonData){
            var randomData = {isLogin:1,articleList:jsonData,type:_this.type};
            var tmplHtml = _this.bd("tmplArticleList",randomData);
            $("#"+id).html(tmplHtml);
            //初始化评论对象
            _this.remark.init();
            _this.delCommonEven();
        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    },
    deleteById:function(articleId){
        var _this = this;
        var url = "/action/article/delete";
        var sendData={id:articleId};
        var callback = function(jsonData){
            var flag = jsonData.flag;
            if("1"==flag){
                showTit(jsonData.msg,"true","1500",function(){
                    _this.getData("singleWordZone");
                });
            }else{
                showTit(jsonData.msg,"true","1500",function(){

                });
            }
        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    },
    delCommonEven:function(){
        var _this = this;
        $(".del-span").on(Public.eventType,function(){
            var id = $(this).attr("data-id");
            $("#publishInfoZone").find(".del-li").attr("data-id",id);
            Public.myTools.showBgDiv(function(){
                $("#publishInfoZone").show().animate({bottom:0},500,'ease-in-out');
            });
        });

        $("#publishInfoZone li").on(Public.eventType,function(){
            var className = $(this).attr("class");
            if("del-li"==className){
                var articleId = $(this).attr("data-id");
                closeFn("publishInfoZone",function(){
                    _this.deleteById(articleId);
                });
            }else{
                closeFn("publishInfoZone");
            }
        });

        var closeFn = function(rel,fn){
            $("#"+rel).animate({bottom:"-231px"},500,'ease-in-out',function(){
                Public.myTools.hideBgDiv();
                $("#"+rel).hide();
                if(fn){
                    fn();
                }
            });
        };
    }
};

$(function(){
    var articleContent = new ArticleContact();
    Public.myTools.getSessionInfo(function(){
        Public.myTools.checkIsLogin("",function(){
            articleContent.init();
        });
    });
});