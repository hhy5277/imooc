/**
 * Created by zhouhao on 15-10-10.
 */
var Remark =function(){
    this.bd = baidu.template;
};
Remark.prototype={
    init:function(){
        this.initAnimate();
    },
    initAnimate:function(){
       var _this = this;
       $(".opera-zone li").on(Public.eventType,function(){
           var $this = $(this);
           var index = parseInt($(this).index());
           switch(index){
               case 0:
                   Public.myTools.checkIsLogin("",function(){
                       doZan($this);
                   });
                   break;
               case 1:
                   doRemark($this);
                   break;
               case 2:
                   Public.myTools.checkIsLogin("",function(){
                       doStore($this);
                   });
                   break;
           };
       });
        //赞函数
        var doZan = function($this){
            var spanObj =$this.find("span");
            var articleId = $this.attr("data-articleid");
            var dataNum = parseInt(spanObj.attr("data-num"));
            if(spanObj.hasClass("un-zan-icon")){
                //点赞
                var sendData = {article_id:articleId,store_type:1};
                _this.insertStore($this,sendData);
            }else{
                //取消赞
                var sendData = {article_id:articleId,store_type:1};
                _this.deleteStore($this,sendData);
            };
        }
        //评论函数
        var doRemark=function($this){
            var plFlag = $this.attr("plFlag")||0;
            $(".remark-zone").hide();
            var rel =$this.find("span").attr("rel");
            if(plFlag!=0){
                $("#"+rel).hide();
                $this.attr("plFlag",0);
            }else{
                $this.attr("plFlag",1);
                $("#"+rel).show();
                _this.initRemarkData($this);
            };
        };
        //收藏函数
        var doStore =function($this){
            var spanObj =$this.find("span");
            var articleId = $this.attr("data-articleid");
            var dataNum = parseInt(spanObj.attr("data-num"));
            if(spanObj.hasClass("un-store-icon")){
                //点赞
                var sendData = {article_id:articleId,store_type:2};
                _this.insertStore($this,sendData);
            }else{
                //取消赞
                var sendData = {article_id:articleId,store_type:2};
                _this.deleteStore($this,sendData);
            };

        };

        $(".remark-js-btn>span").on(Public.eventType,function(){
            var localDataObj = Public.myTools.getLocalStorage();
            var isLogin = localDataObj["isLogin"]; //0:未登录；1：已登录
            if("1"==isLogin){
                _this.publishRemark(this);
            }else{
                Public.myTools.gotoLogin();
            }

        });
    },
    publishRemark:function(_this){
        var that = this;
        var rel=$(_this).attr("rel");
        var messageVal = $("#"+rel).find("textarea").val();
        if(""==messageVal){
            showTit("输入不能为空哦！","true","800",function(){
                return;
            });
        }else{
            var articleId=$("#"+rel).attr("data-articleid");
            var sendData={ARTICLE_ID:articleId,CONTENT:messageVal};
            var subFlag = $(_this).attr("data-flag");
            if("1" == subFlag){
                $(_this).attr("data-flag","0");
                that.insertRemark(_this,sendData);
            };
        }
    },
    insertStore:function($this,sendData){
        var type=sendData["store_type"];
        var that = this;
        var url="/action/store/insert";
        var callback = function(jsonData){
            var flag = jsonData.flag;
            if("0"==flag){
                //失败
                showTit(jsonData.msg,"true","1000",function(){

                });
            }else if("1"==flag){
                //成功
                var spanObj=$this.find("span");
                if("1"==type){ //1赞2收藏
                    var dataNum = parseInt(spanObj.attr("data-num"));
                    ++dataNum;
                    if(dataNum>=1000){
                        dataNum="999+";
                    }
                    spanObj.removeClass("un-zan-icon").addClass("yi-zan-icon").html("取消赞("+dataNum+")");
                }else if("2"==type){
                    spanObj.removeClass("un-store-icon").addClass("yi-store-icon").text("取消收藏");
                }

            }
        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    },
    deleteStore:function($this,sendData){
        var type = sendData["store_type"];
        var that = this;
        var url="/action/store/delete";
        var callback = function(jsonData){
            var flag = jsonData.flag;
            if("0"==flag){
                //失败
                showTit(jsonData.msg,"true","1000",function(){

                });
            }else if("1"==flag){
                //成功
                var spanObj=$this.find("span");
                if("1"==type){
                    var dataNum = parseInt(spanObj.attr("data-num"));
                    --dataNum;
                    if(dataNum>=1000){
                        dataNum="999+";
                    }
                    spanObj.removeClass("yi-zan-icon").addClass("un-zan-icon").html("赞("+dataNum+")");
                }else if("2"==type){
                    var dataAdd  = $this.attr("data-add");
                    if("my-store"==dataAdd){
                        var articleContent = new ArticleContact();
                        articleContent.getData("singleWordZone");
                    }else{
                        spanObj.removeClass("yi-store-icon").addClass("un-store-icon").text("加入收藏");
                    }
                }
            }
        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    },
    insertRemark:function(_this,sendData){
        var that = this;
        var rel = $(_this).attr("rel");
        var plNum = parseInt($(_this).attr("pl-num"));
        var url="/action/remark/insert";
        var plObj = $("#"+$(_this).attr("plrel"));
        var callback = function(jsonData){

            var flag = jsonData.flag;
            if("1"==flag){
                ++plNum;
                if(plNum>=100){
                    plNum="99+";
                };
                $("#"+rel).find("textarea").val("");
                plObj.attr("data-num",plNum).find("span").html("评论("+plNum+")");
                that.initRemarkData(plObj);
                $(_this).attr("data-flag","1");
            }else{
                $(_this).attr("data-flag","1");
                showTit(jsonData.msg,"true",1500,function(){

                });
            }
        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    },
    deleteRemarkById:function(){
        var _this =this;
        $(".remark-del").on(Public.eventType,function(){
            var that=  this;
            var remarkId = $(this).attr("data-id");
            var url = '/action/remark/delete';
            var sendData={ID:remarkId};
            var callback = function(jsonData){
                var flag = jsonData.flag;
                if("1"==flag){
                    var parAllRemarkList = $(that).closest(".all-remark-list");
                    var plRel =parAllRemarkList.attr("pl-rel");
                    var plLiObj = $("#"+plRel);
                    var plNum =parseInt(plLiObj.attr("data-num"));
                    --plNum;
                    if(plNum>=100){
                        plNum="99+";
                    };
                    plLiObj.find("span").html("评论("+plNum+")");
                    _this.initRemarkData(plLiObj);

                }else{
                    showTit(jsonData.msg,"true","1500",function(){

                    });
                }
            };
            Public.myTools.ajaxLoadData(url,sendData,callback);
        });
    },
    initRemarkData:function($this){//$this为评论li对象
        var _this = this;
        var rel =$this.find("span").attr("rel");
        var plRel =$this.attr("plrel");
        /**加载动画**/
        var articleId = $("#"+rel).attr("data-articleid");
        var url="/action/remark/init";
        var sendData={article_id:articleId};
        var callback=function(jsonData){
            var localDataObj = Public.myTools.getLocalStorage();
            var isLogin = localDataObj["isLogin"]; //0:未登录；1：已登录
            var myData = {remarkList:jsonData};
            if("1"==isLogin){
                var userId = localDataObj["user_info"].ID;
                myData["userId"]=userId;
            };
            var tmplHtml  = _this.bd("tmplRemarkList",myData);
            $("#"+plRel).html(tmplHtml);
            _this.deleteRemarkById();
        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    }
};
