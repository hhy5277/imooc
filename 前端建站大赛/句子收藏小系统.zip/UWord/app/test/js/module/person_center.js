/**
 * Created by zhouhao on 15-10-19.
 */
var PersonCenter = function(){
    this.bd=baidu.template;
}
PersonCenter.prototype={
    init:function(){
        this.userInfo = Public.myTools.getLocalStorage();
        this.initData();
    },
    initData:function(){
        var _this =this;
        var tmplHtml = _this.bd("tmplUserInfor",this.userInfo);
        $("#userInfoZone").html(tmplHtml);
        _this.evenFn();
    },
    evenFn:function(){
        var _this = this;
        $(".exit-login>a").on("click",function(){
            var url='/action/logout';
            var sendData={};
            var callback=function(jsonData){
                var flag = jsonData.flag;
                if("1"==flag){
                    showTit(jsonData.msg,'true','1500',function(){
                        Public.myTools.gotoLogin();
                    });
                };
            };
            Public.myTools.ajaxLoadData(url,sendData,callback);
        });

       /* $("#userInfoZone").on("change",".img-input",function(){
            changeImg();
        });*/
    }
}

$(function(){
    var person = new PersonCenter();
    Public.myTools.getSessionInfo(function(){
        Public.myTools.checkIsLogin("",function(){
            person.init();
        });
    });
})

function changeImg(){

    return false;
}