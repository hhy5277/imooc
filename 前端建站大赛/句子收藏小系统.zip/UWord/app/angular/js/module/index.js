var index = angular.module('index',[]);

index.controller('ArticleList',function($scope,ArticleService){
    $scope.type=0;
    $scope.isOk=0;
    var initData = function(){
        var promise = ArticleService.query($scope.type);// 同步调用，获得承诺接口
        promise.then(function(data){  //调用承诺API获取数据 .resolve
            var localDataObj ={isLogin:0};
            var isLogin = localDataObj["isLogin"]; //0:未登录；1：已登录
            data["isLogin"]=isLogin;
            if("1"==isLogin){
                var userId = localDataObj["user_info"].ID;
                data["userId"]=userId;
            };
            $scope.isOk=1;
            $scope.articleList=data;
        },function(data){  //error
        });
    };

    $("#tabNav li").on("click",function(){
        var tabNum = parseInt($(this).attr("tab"));
        $scope.type=tabNum;
        console.log($scope);
        $(this).addClass("current").siblings().removeClass("current");
        //initData();
    });
   // $("#tabNav li").eq(0).trigger("click");
    $scope.$watch('type',function(newValue,oldValue,scope){
        console.log(newValue+"-----"+oldValue);
        initData();
    });
});
index.service('ArticleService',['$http','$q',function($http,$q){
    var url="/action/article/init?r="+Math.random();
    return {
        query:function(type){
            var deferred = $q.defer();// 声明延后执行，表示要去监控后面的执行
            $http({method:'POST',url:url,data:{type:type}}).
                success(function(data,status,headers,configs){
                    deferred.resolve(data); // 声明执行成功，即http请求数据成功，可以返回数据了
                }).
                error(function(data,status,headers,config){
                    deferred.reject(data);   // 声明执行失败，即服务器返回错误
                });
            return deferred.promise; // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        }
    };
}]);


