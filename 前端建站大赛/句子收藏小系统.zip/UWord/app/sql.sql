
CREATE TABLE remark
(
   ID                   INT NOT NULL AUTO_INCREMENT,
   CONTENT              VARCHAR(1000),
   ARTICLE_ID           INT,
   USER_ID              INT,
   CREATE_TIME          VARCHAR(50),
   FATHER_ID            INT,
   MARK_CODE            VARCHAR(100),
   PRIMARY KEY (ID)
);

CREATE TABLE article_type
(
   ID                   INT NOT NULL AUTO_INCREMENT,
   NAME                 VARCHAR(50),
   STATUS               INT,`user_info`
   PRIMARY KEY (ID)
);

CREATE TABLE user_info
(
   ID                   INT NOT NULL AUTO_INCREMENT,
   USER_NAME            VARCHAR(120),`article_type``user_info`
   PASSWORD             VARCHAR(50),
   REGISTER_TIME        VARCHAR(50),
   IMG                  VARCHAR(120),
   TEL                  VARCHAR(50),
   EMAIL                VARCHAR(120),
   PRIMARY KEY (ID)
);

CREATE TABLE article
(
   ID                   INT NOT NULL AUTO_INCREMENT,
   CREATE_TIME          VARCHAR(50),
   USER_ID              INT,
   AUTHOR               VARCHAR(120),
   CONTENT              VARCHAR(1000),
   TYPE_ID              INT,
   PRIMARY KEY (ID)
);

CREATE TABLE store
(
   ID                   INT NOT NULL AUTO_INCREMENT,
   USER_ID              INT,
   ARTICLE_ID           INT,
   CREATE_TIME          VARCHAR(50),
   STORE_TYPE           INT COMMENT '1点赞 2收藏',
   PRIMARY KEY (ID)
);

