/**
 * Created by zhouhao on 15-10-9.
 */
var Index=function(){

};
Index.prototype={
    init:function(){
        this.initSwiper();
        this.initAnimateFn();
    },
    initSwiper:function(){
        var mySwiper = new Swiper('.swiper-container',{
            autoplay:3000,
            loop:true,
            grabCursor: true
        });
    },
    loadingData:function(id,tabIndex){
        Public.myTools.bigLoading(id);
        var url="/action/getContentList";
        var sendData={type:tabIndex};
        var callback=function(jsonData){

            $("#"+id).html();
        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    },
    "initAnimateFn":function(){
        var _this = this;
        var tabIndex=0;
        $("#tabNav>ul>li").on(Public.eventType,function(){
            $(this).addClass("current").siblings().removeClass("current");
            tabIndex = $(this).attr("tab");
            _this.loadingData("ljZone",tabIndex);
        });
        $("#tabNav>ul>li").eq(0).trigger(Public.eventType);


        Public.myTools.arrivalBottom(function(){
            console.log("鍒颁簡");
        });
    }
};
$(function(){
    var index = new Index();
    index.init();
});

