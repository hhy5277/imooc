var Prince=function(){

}
Prince.prototype={
    init:function(){

       // this.getSingleData("singleWordZone");
        this.initShakeFn();
        this.initAnimate();

        //初始化评论对象
        var remark = new Remark();
        remark.init();
    },
    getSingleData:function(id){
        Public.myTools.bigLoading(id);
        var url="/action";
        var sendData={};
        var callback=function(){
            $("#"+id).html();
        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    },
    initShakeFn:function(){
        var _this = this;
        var SHAKE_THRESHOLD = 3000;
        var last_update = 0;
        var x=y=z=last_x=last_y=last_z=0;
        function init(){
            if (window.DeviceMotionEvent) {
                window.addEventListener('devicemotion',deviceMotionHandler, false);
            }else{
                alert('not support mobile event');
            }
        };

        function deviceMotionHandler(eventData) {
            var acceleration =eventData.accelerationIncludingGravity;
            var curTime = new Date().getTime();
            if ((curTime - last_update)> 100) {
                var diffTime = curTime -last_update;
                last_update = curTime;
                x = acceleration.x;
                y = acceleration.y;
                z = acceleration.z;
                var speed = Math.abs(x +y + z - last_x - last_y - last_z) / diffTime * 10000;
                if (speed > SHAKE_THRESHOLD) {
                    _this.getSingleData("singleWordZone");
                }
                last_x = x;
                last_y = y;
                last_z = z;
            }
        }
        init();
    },
    initAnimate:function(){
        $("#hPubBtn").on(Public.eventType,function(){
           Public.myTools.checkIsLogin("",function(){
                Public.myTools.showBgDiv();
                $("#publishInfoZone").show().animate({bottom:0},500);
            });
        });

        $(".close-btn").on(Public.eventType,function(){
            var rel=$(this).attr("rel");

            $("#"+rel).animate({bottom:"-231px"},500,'ease-in-out',function(){
                Public.myTools.hideBgDiv();
                $("#"+rel).hide();
            });
        });


    }
}
$(function(){
    var prince = new Prince();
    prince.init();
});