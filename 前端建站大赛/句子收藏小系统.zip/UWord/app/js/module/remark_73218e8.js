/**
 * Created by zhouhao on 15-10-10.
 */
var Remark =function(){

};
Remark.prototype={
    init:function(){
        this.initAnimate();
    },
    initAnimate:function(){
        var _this = this;
       $(".opera-zone li").on(Public.eventType,function(){
            var $this = $(this);
           var index = parseInt($(this).index());
           switch(index){
               case 0:
                   doZan($this);
                   break;
               case 1:
                   doRemark($this);
                   break;
               case 2:
                   doStore($this);
                   break;
           };
       });
        //赞函数
        var doZan = function($this){
            var spanObj =$this.find("span");
            var iObj=$this.find("i");
            var dataNum = parseInt(spanObj.attr("data-num"));
            if(spanObj.hasClass("un-zan-icon")){
                spanObj.removeClass("un-zan-icon").addClass("yi-zan-icon");
                ++dataNum;
            }else{
                spanObj.removeClass("yi-zan-icon").addClass("un-zan-icon");
                --dataNum;
            };
            spanObj.attr("data-num",dataNum);
            iObj.html(dataNum);
        }
        //评论函数
        var i=0;
        var doRemark=function($this){
            i++;
            $(".remark-zone").hide();
            var rel =$this.find("span").attr("rel");
            if(i%2==0){
                $("#"+rel).hide();
            }else{
                $("#"+rel).show();
                _this.initRemarkData("allRemarkList");
            };
        };
        //收藏函数
        var doStore =function($this){
            var spanObj =$this.find("span");
            if(spanObj.hasClass("un-store-icon")){
                spanObj.text("取消收藏");
                spanObj.removeClass("un-store-icon").addClass("yi-store-icon");
            }else{
                spanObj.text("加入收藏");
                spanObj.removeClass("yi-store-icon").addClass("un-store-icon");
            };
        };
        $(".publish-btn>span").on(Public.eventType,function(){
            _this.publishRemark(this);
        });
    },
    publishRemark:function(_this){
        Public.myTools.checkIsLogin("",function(){
            var messageVal = $(this).parent().siblings(".remark-textarea").find("textarea").val();
            if(""==messageVal){
                showTit("输入不能为空哦！","false","1000",function(){
                    return;
                });
            }else{

            }
        });
    },
    initRemarkData:function(id){
        /**加载动画**/
        var url="/action/remark/init";
        var sendData={};
        var callback=function(jsonData){

        };
        Public.myTools.ajaxLoadData(url,sendData,callback);
    }
};
