/**
 * Created by zhouhao on 15-10-16.
 */
var articleDao = require('../dao/articleDao.js');

exports.query=function(data,callback){
    articleDao.query(data,function(err,results){
        if(err){
            callback(true);
            return;
        }
        callback(false,results);
    })
};
exports.insert=function(data,callback){
    articleDao.insert(data,function(err){
        if(err){
            callback(true);
            return;
        }
        callback(false);
    })
};
exports.delete=function(data,callback){
    articleDao.delete(data,function(err){
        if(err){
            callback(true);
            return;
        }
        callback(false);
    })
}