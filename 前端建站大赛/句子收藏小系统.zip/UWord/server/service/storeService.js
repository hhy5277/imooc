/**
 * Created by zhouhao on 15-10-23.
 */
var storeDao = require('../dao/storeDao.js');

exports.insert=function(data,callback){
    storeDao.insert(data,function(err){
        if(err){
            callback(true);
            return;
        }
        callback(false);
    });
};
exports.delete=function(data,callback){
    storeDao.delete(data,function(err){
        if(err){
            callback(true);
            return;
        }
        callback(false);
    })
}
