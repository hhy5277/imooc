/**
 * Created by zhouhao on 15-10-21.
 */
var remarkDao = require('../dao/remarkDao.js');

//查询所有的评论数据
exports.query=function(data,callback){
    remarkDao.query(data,function(err,results){
        if(err){
            callback(true);
            return;
        }
        callback(false,results);
    })
};
//插入一条评论
exports.insert=function(data,callback){
    remarkDao.insert(data,function(err,results){
        if(err){
            callback(true);
            return;
        }
        callback(false,results);
    })
};
//删除一条评论
exports.delete=function(data,callback){
    remarkDao.delete(data,function(err){
        if(err){
            callback(true);
            return;
        }
        callback(false);
    })
}