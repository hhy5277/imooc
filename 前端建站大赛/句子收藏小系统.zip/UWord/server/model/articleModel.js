/**
 * Created by zhouhao on 15-10-16.
 */
var article={
    id:"",//文章id
    creat_time:'',//文章创建时间
    user_id:'',//用户id
    author:'',//句子作者
    content:'',//句子内容
    type_id:'',//句子类型，
    query:"SELECT DISTINCT a.*,u.user_name,u.img,(SELECT COUNT(1) FROM store WHERE store_type=2  AND article_id = a.id) collect,(SELECT COUNT(1) FROM remark WHERE article_id=a.id) pl,IF( s.store_type=2,'y','n') isStore,IF( s1.store_type=1,'y','n') isZan,(SELECT COUNT(1) FROM store WHERE store_type=1  AND article_id = a.id) dz FROM article a LEFT JOIN user_info u ON a.user_id = u.id",
    commonLeftJoin:" LEFT JOIN store s ON s.article_id=a.id AND s.store_type=2 AND s.USER_ID =",
    commonLeftJoin1:" LEFT JOIN store s1 ON s1.article_id=a.id AND s1.store_type=1 AND s1.USER_ID =",
    orderWord:' ORDER BY dz DESC LIMIT 0,10', //点赞前10条
    orderWord1:' ORDER BY pl DESC LIMIT 0,10', //评论前10条
    orderWord2:" WHERE a.type_id='4' ORDER BY create_time DESC LIMIT 0,10",//查原创句子后半句
    orderWord3:" ORDER BY RAND() LIMIT 1",//随机查后半句
    contactUser:" where a.user_id = ", //查询登陆用户发布的数据
    storeWord:"  WHERE s.user_id = ",//查询登陆用户收藏的数据
    storeWord1:" And s.store_type =2 ",
    queryLike:" where a.content LIKE ",//模糊查询
    queryLike1:" OR a.author LIKE ",
    orderWord4:" ORDER BY create_time",//查询与登陆用户发布的数据
    delete:"DELETE FROM article WHERE 1=1 ",
    insert:'INSERT  INTO `article` SET create_time=NOW(),'//新增

}

module.exports=article;
