/**
 * Created by zhouhao on 15-10-19.
 */
var user ={
    id:"",
    user_name:"",
    password:"",
    register_time:"",
    img_src:"",
    tel:"",
    email:"",
    query:"SELECT * FROM user_info WHERE 1=1",
    insert:"INSERT INTO user_info SET register_time=NOW(),",
    pk:"id"
}
module.exports = user;
