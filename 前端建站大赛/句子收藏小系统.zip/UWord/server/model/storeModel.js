/**
 * Created by zhouhao on 15-10-22.
 */
var store={
    id:"",
    user_id:'',
    article_id:'',
    create_time:'',
    store_type:'',
    insert:"INSERT INTO store SET create_time=NOW(),",
    delete:"delete from store where 1=1"
}

module.exports = store;