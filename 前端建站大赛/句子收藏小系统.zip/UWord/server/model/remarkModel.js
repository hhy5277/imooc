/**
 * Created by zhouhao on 15-10-21.
 */
var remark={
    id:'',
    content:'',
    article_id:'',
    user_id:'',
    create_time:'',
    father_id:'',
    mark_code:'',
    query:"SELECT r.*,u.user_name,u.img FROM remark r LEFT JOIN user_info u ON r.user_id = u.id WHERE 1=1",
    afterWord:"ORDER BY create_time DESC LIMIT 0,10",
    insert:"INSERT  INTO `remark` SET create_time=NOW(),",
    delete:"DELETE FROM remark WHERE 1=1 "

}

module.exports=remark;
