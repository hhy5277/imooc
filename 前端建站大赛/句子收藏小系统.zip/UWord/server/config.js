/* 
* @Author: zhouhao
* @Date:   2015-06-09 11:13:06
* @Last Modified by:   zhouhao
* @Last Modified time: 2015-06-09 11:17:05
*/

module.exports = {
    mysql_dev: {
        host: '192.168.1.182',
        user: 'root',
        password: '123456',
        database: 'UWord',
        connectionLimit: 10,
        supportBigNumbers: true
    }
};