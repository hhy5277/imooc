/**
 * Created by zhouhao on 15-10-16.
 */
var db = require("../database.js");
var articleModel = require('../model/articleModel.js');
var req2Sql = require('../util/req2Sql.js');

//查询点赞数量最多的前10条
exports.query=function(data,callback){
    var myData={};
    var userId = data.USER_ID;
    var type = parseInt(data["type"]); //0:点赞最多前10条；1：评论最多前10条；2：原创前10条 ； 3：随机查询 ,4:我发布的；5：我收藏的；6：模糊查询
    var sql = articleModel.query;
    var commonLeftJoin = articleModel.commonLeftJoin;
    if(typeof(userId)!="undefined"){
        commonLeftJoin+=userId;
    }else{
        commonLeftJoin+="u.id";
    };
    var commonLeftJoin1 = articleModel.commonLeftJoin1;
    if(typeof(userId)!="undefined"){
        commonLeftJoin1+=userId;
    }else{
        commonLeftJoin1+="u.id";
    };
    var allLeftJoin = commonLeftJoin + commonLeftJoin1;
    sql += allLeftJoin;
    switch(type){
        case 0:
            var orderWord = articleModel.orderWord;
            sql += orderWord;
            break;
        case 1:
            var orderWord1 = articleModel.orderWord1;
            sql += orderWord1;
            break;
        case 2:
            var orderWord2 = articleModel.orderWord2;
            sql += orderWord2;
            break;
        case 3:
            var orderWord3 = articleModel.orderWord3;
            sql += orderWord3;
            break;
        case 4:
            var contactUser = articleModel.contactUser;
            contactUser+=userId;
            sql += contactUser;
            var orderWord4 = articleModel.orderWord4;
            sql += orderWord4;
            break;
        case 5:
            var storeWord = articleModel.storeWord;
            storeWord+=userId;
            sql += storeWord;
            var storeWord1 = articleModel.storeWord1;
            sql += storeWord1;
            var orderWord4 = articleModel.orderWord4;
            sql += orderWord4;
            break;
        case 6:
            var queryLikeWord = articleModel.queryLike;
            queryLikeWord+="'%";
            var keyWord = data["keyName"];
            queryLikeWord+=keyWord;
            queryLikeWord+="%'";
            sql+=queryLikeWord;
            var queryLike1 = articleModel.queryLike1;
            queryLike1+="'%";
            queryLike1+=keyWord;
            queryLike1+="%'";
            sql+=queryLike1;
            var orderWord4 = articleModel.orderWord4;
            sql+=orderWord4;
            break;
    };
    req2Sql.getReqSqlByQeury(myData,function(reqSql){
        sql+=reqSql;
        console.log("查询类型为"+type+"的sql语句为：" + sql);
        db.mysqlPool.getConnection(function(err,connection){
            console.log(err);
            if(err){
                callback(true);
                connection.release();
                return;
            }
            connection.query(sql,function(err,results){
                if(err){
                    callback(true);
                    connection.release();
                    return;
                }
                callback(false,results);
                connection.release();
            });
        })
    })
};

//添加文章
exports.insert=function(data,callback){
    var sql = articleModel.insert;
    req2Sql.getReqSqlByInsert(data,function(reqSql){
        sql += reqSql;
        console.log("文章插入的sql语句为：" + sql);
        db.mysqlPool.getConnection(function(err,connection){
            if(err){
                connection.release();
                callback(true);
                return;
            }
            connection.query(sql,function(err){
                if(err){
                    connection.release();
                    callback(true);
                    return;
                }
                callback(false);
                connection.release();
            });
        });
    });

}

//删除自己的文字
exports.delete = function(data,callback){
    var sql = articleModel.delete;
    req2Sql.getReqSqlByDelete(data,function(rqlsql){
        sql += rqlsql;
        console.log("删除文章的sql语句为：" + sql);
        db.mysqlPool.getConnection(function(err,connection){
            if(err){
                callback(true);
                connection.release();
                return;
            };
            connection.query(sql,function(err){
                if(err){
                    callback(true);
                    connection.release();
                    return;
                }
                callback(false);
                connection.release();
            });
        });
    })
}

