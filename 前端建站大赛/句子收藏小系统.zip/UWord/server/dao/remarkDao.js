/**
 * Created by zhouhao on 15-10-21.
 */
var db = require('../database.js');
var remarkModel = require('../model/remarkModel.js');
var req2Sql  = require('../util/req2Sql.js');

//查询某条数据所有评论
exports.query = function(data,callback){
    var afterWord = remarkModel.afterWord;
    var sql = remarkModel.query;
    console.log(sql);
    req2Sql.getReqSqlByQeury(data,function(reqSql){
        console.log(reqSql);
        sql+=reqSql;
        sql+=afterWord;
        console.log("查询当前数据评论前10条数据的sql语句为："+sql);
        db.mysqlPool.getConnection(function(err,connection){
            if(err){
                callback(true);
                connection.release();
                return;
            }
            connection.query(sql,function(err,results){
                if(err){
                    callback(true);
                    connection.release();
                    return;
                }
                callback(false,results);
                connection.release();
            });
        });
    });
};
//插入一条评论
exports.insert=function(data,callback){
    var sql = remarkModel.insert;
    req2Sql.getReqSqlByInsert(data,function(reqSql){
        sql+=reqSql;
        console.log("插入一条评论的sql语句为："+sql);
        //connection db
        db.mysqlPool.getConnection(function(err,connection){
            if(err){
                callback(true);
                connection.release();
                return;
            }
            //start  query
            connection.query(sql,function(err){
                 if(err){
                     callback(true);
                     connection.release();
                     return;
                 }
                callback(false);
                connection.release();
            });
        });
    });
};

exports.delete=function(data,callback){
    var sql = remarkModel.delete;
    req2Sql.getReqSqlByDelete(data,function(reqsql){
        sql+=reqsql;
        console.log("删除一条评论的sql语句为："+sql);
        db.mysqlPool.getConnection(function(err,connection){
            if(err){
                callback(true);
                connection.release();
                return;
            };
            connection.query(sql,function(err){
                if(err){
                    callback(true);
                    connection.release();
                    return;
                }
                callback(false);
                connection.release();
            });
        });
    });
}

