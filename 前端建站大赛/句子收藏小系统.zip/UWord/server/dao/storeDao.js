/**
 * Created by zhouhao on 15-10-22.
 */
var db = require('../database.js');
var req2Sql = require('../util/req2Sql.js');
var storeModel = require('../model/storeModel.js');
//点赞
exports.insert=function(data,callback){
    var sql = storeModel.insert;
    req2Sql.getReqSqlByInsert(data,function(reqSql){
        sql+=reqSql;
        console.log("点赞的sql语句为："+sql);
        db.mysqlPool.getConnection(function(err,connection){
            if(err){
                callback(true);
                connection.release();
                return;
            }
            connection.query(sql,function(err){
                if(err){
                    callback(true);
                    connection.release();
                    return;
                }
                callback(false);
                connection.release();
            });
        })
    })
};

//取消赞
exports.delete=function(data,callback){
    var sql = storeModel.delete;
    req2Sql.getReqSqlByDelete(data,function(reqSql){
        sql+=reqSql;
        console.log("取消赞的sql语句为："+ sql);
        db.mysqlPool.getConnection(function(err,connection){
            if(err){
                callback(true);
                connection.release();
                return;
            }
            connection.query(sql,function(err){
                if(err){
                    callback(true);
                    connection.release();
                    return;
                }
                callback(false);
                connection.release();
            });
        });
    });
}