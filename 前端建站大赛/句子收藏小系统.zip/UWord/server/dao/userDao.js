/**
 * Created by zhouhao on 15-10-19.
 */
var db =require('../database.js');
var userModel = require('../model/userModel.js');
var req2Sql = require('../util/req2Sql.js');

//查询用户
exports.query=function(data,callback){
    var sql = userModel.query;
    req2Sql.getReqSqlByQeury(data,function(reqSql){
        sql+=reqSql;
        console.log("查询用户："+sql);
        db.mysqlPool.getConnection(function(err,connection){
            if(err){
                callback(true);
                connection.release();
                return;
            }
            connection.query(sql,function(err,results){
                if(err){
                    callback(true);
                    connection.release();
                    return;
                }
                callback(false, results);
                connection.release();
            })
        });
    })
};

//添加用户
exports.insert=function(data,callback){
    var sql = userModel.insert;
    req2Sql.getReqSqlByInsert(data,function(reqSql){
        sql+=reqSql;
        db.mysqlPool.getConnection(function(err,connection){
            if(err){
                callback(true);
                connection.release();
                return;
            }
            connection.query(sql,function(err){
               if(err){
                   callback(true);
                   connection.release();
                   return;
               }
               callback(false);
               connection.release();
            });
        });
    })
}