/**
 * Created by zhouhao on 15-10-23.
 */
var express = require('express');
var storeService = require('../service/storeService.js');
var router = express.Router();

router.post('/store/insert',function(req,res){
    var data = req.body;
    var user = req.session.user;
    data["USER_ID"]=user.ID;
    storeService.insert(data,function(err){
        if(err){
            res.json({flag:0,msg:"鎿嶄綔澶辫触"});
            return;
        };
        res.json({flag:1,msg:'鎿嶄綔鎴愬姛'});
    });
});
router.post('/store/delete',function(req,res){
    var data = req.body;
    var user = req.session.user;
    data["USER_ID"]=user.ID;
    storeService.delete(data,function(err){
        if(err){
            res.json({flag:0,msg:"鎿嶄綔澶辫触"});
            return;
        };
        res.json({flag:1,msg:'鎿嶄綔鎴愬姛'});
    });
});

module.exports=router;

