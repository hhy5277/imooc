/**
 * Created by zhouhao on 15-10-16.
 */
var express = require('express');
var articleService = require('../service/articleService.js');
var router = express.Router();
//查询前10条数据:0:力荐（点赞最多的），1：热门（评论最多的）,2:原创（类别为5），3：随机查询
router.post('/article/init',function(req,res){
    var data = req.body;
    var user = req.session.user;
    if(user||typeof (user)!="undefined"){
        data["USER_ID"]=user.ID;
    }
    articleService.query(data,function(err,results){
        if(err){
            res.json({msg:'查询失败'});
            return;
        }
        res.send(results);
    })
});

//插入文章
router.post('/article/insert',function(req,res){
    var data =req.body;
    var user = req.session.user;
    data["USER_ID"]=user.ID;
    articleService.insert(data,function(err){
       if(err){
           res.json({flag:0,msg:'插入失败'});
       }
       res.json({flag:1,msg:'插入成功'});
    });
});

router.post("/article/delete",function(req,res){
    var data = req.body;
    articleService.delete(data,function(err){
        if(err){
            res.json({flag:0,msg:"删除失败"});
        }
        res.json({flag:1,msg:"删除成功"});
    })
})
module.exports = router;