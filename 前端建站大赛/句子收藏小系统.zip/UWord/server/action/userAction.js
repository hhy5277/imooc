/**
 * Created by zhouhao on 15-10-29.
 */
var express = require('express');
var userService = require("../service/userService.js");
var router = express.Router();

//添加用户
router.post("/user/insert",function(req,res){
    var data = req.body;
    userService.insert(data,function(err){
       if(err){
           res.json({flag:0,msg:'注册失败'});
           return;
       };

       res.json({flag:1,msg:"注册成功！"});
    });
});



module.exports=router;