/**
 * Created by zhouhao on 15-10-19.
 */
var express =  require("express");
var userService = require('../service/userService.js');
var router = express.Router();

//登陆操作
router.post('/loginin',function(req,res){
    var data = {tel:req.body.mobile,password:req.body.password};
    userService.query(data,function(err,results){
        if(err || results.length==0){
            res.send({flag:0,msg:"账户或密码错误！"});
            return;
        };
        req.session.user = results[0];
        res.send({flag:1,msg:"登入成功！"});
    });
});

//登出操作
router.post("/logout", function(req, res){
    delete req.session.user;
    res.json({flag:1,msg: "登出成功"});
});

module.exports = router;