package com.laocaixw.dadaZuChe;

import java.util.Scanner;

public class CarRental {

	public static void main(String[] args) {
		
		Scanner input=new Scanner(System.in);
		
		System.out.println("是否要租车：1是  2否");
		int inInt = input.nextInt();
		while(!(inInt == 1 || inInt == 2)){
			System.out.print("重新输入：");
			inInt = input.nextInt();
		}
		if(inInt == 1){
			Car [] cars = new Car[5];
			cars = initialize();
			
			for (int i = 0; i < cars.length; i++) {
				System.out.println((i+1) + ":" + cars[i].getName() + "  " + cars[i].getType() + "  " + 
			cars[i].getRent() + "  " + cars[i].getLoad());
			}
			
		}else if(inInt == 2){
			input.close();
			System.out.println("再见！欢迎下次光临！");
			System.exit(0);
		}
		
	}
	
	public static Car[] initialize(){
		Car [] cars = new Car[5];
		Car bigTruck = new Truck("擎天柱", "BigTruCk", 800, 10);
		Car smallTruck = new Truck("威震天", "SmallTruck", 600, 5);
		Car bigPassengerCar = new PassengerCar("大巴", "BigPassengerCar", 800, 30);
		Car smallPassengerCar = new PassengerCar("大黄蜂", "SmallPassengerCar", 600, 5);
		Car pickup = new PickUp("抢险车", "Pickup", 500, 5, 5);
		
		cars[0] = bigTruck;
		cars[1] = smallTruck;
		cars[2] = bigPassengerCar;
		cars[3] = smallPassengerCar;
		cars[4] = pickup;
		
		return cars;
	}
}
