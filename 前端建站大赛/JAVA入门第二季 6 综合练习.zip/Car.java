package com.laocaixw.dadaZuChe;

public abstract class Car {
	
	protected String name;
	protected double rent;
	protected String type;

	public String getName() {
		return name;
	}

	public String getRent() {
		return rent + "元/天";
	}

	public String getType() {
		return type;
	}
	
	public abstract String getLoad();

}
