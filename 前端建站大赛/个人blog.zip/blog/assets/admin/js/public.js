$(function(){
	//删除用户、帖子
	$('.del').click(function(){
		return confirm('确定要删除吗？');
	})
	
})