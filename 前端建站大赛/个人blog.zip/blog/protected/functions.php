<?php
/**
 *格式化打印函数
 * 
 */

function p($arr){
    echo '<pre>';
    print_r($arr);
    echo '</pre>';
    
}