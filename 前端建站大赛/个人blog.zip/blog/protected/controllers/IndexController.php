<?php
/* 前台控制器


 */
class IndexController extends Controller{
    /*
    默认方法
     */
    public function actionIndex(){
        // echo Yii::app()->request->baseUrl;die;
        // $data = Array('title'=>'后盾网');
        // p($data);die;
        $this->render('index');
    }

    public function actionAdd(){
        $this->renderPartial('add');
    }

} 