<?php
/**
 * 文章管理控制器
 * 
 * 
 * 
 */
class ArticleController extends Controller{
/**
 * 默认显示
 */
public function actionIndex(){
    $this->render('index');
}

}