<?php
/**
 * 
 * 栏目管理控制器
 * 
 */

class CategoryController extends Controller{
    /**
     * 默认显示栏目页
     * 
     */
    public function actionIndex(){
        $this->render('index');
    }
    

}