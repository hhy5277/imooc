<link href="<?php echo Yii::app()->request->baseUrl ?>/assets/index/css/index.css" rel="stylesheet" />
	<div id="main">
		<div class='content'>
			<div  class='list'>
				<div class='title'>
					<h2>最新文章..</h2>
				</div>
				<ul>
					<li>
						<div class='post-image'>
							<span>
								<img width="" src="http://www.fqpai.com/wp-content/themes/fqp-three/includes/timthumb.php?src=/wp-content/uploads/2013/10/22221.jpg&h=174&w=294&zc=1&q=100" />
							</span>	
						</div>	
						<div class='post-content'>
							<h3>从相见恨晚到不如不见</h3>
							<p>花非花，雾非雾。夜半来，天明去。来如春梦不多时，去似朝云无觅处。浮华一生，淡忘一季。 空有回忆，打乱缠绵。 笑容不见，落寞万千。 弦，思华年。 那些年华，恍然如梦。 亦如，流水，一去不返。 不泣离别，不诉终殇。</p>
						</div>
					</li>
					<li>
						<div class='post-image'>
							<span>
								<img width="" src="http://www.fqpai.com/wp-content/themes/fqp-three/includes/timthumb.php?src=/wp-content/uploads/2013/10/22221.jpg&h=174&w=294&zc=1&q=100" />
							</span>	
						</div>	
						<div class='post-content'>
							<h3>从相见恨晚到不如不见</h3>
							<p>花非花，雾非雾。夜半来，天明去。来如春梦不多时，去似朝云无觅处。浮华一生，淡忘一季。 空有回忆，打乱缠绵。 笑容不见，落寞万千。 弦，思华年。 那些年华，恍然如梦。 亦如，流水，一去不返。 不泣离别，不诉终殇。</p>
						</div>
					</li>
					<li>
						<div class='post-image'>
							<span>
								<img width="" src="http://www.fqpai.com/wp-content/themes/fqp-three/includes/timthumb.php?src=/wp-content/uploads/2013/10/22221.jpg&h=174&w=294&zc=1&q=100" />
							</span>	
						</div>	
						<div class='post-content'>
							<h3>从相见恨晚到不如不见</h3>
							<p>花非花，雾非雾。夜半来，天明去。来如春梦不多时，去似朝云无觅处。浮华一生，淡忘一季。 空有回忆，打乱缠绵。 笑容不见，落寞万千。 弦，思华年。 那些年华，恍然如梦。 亦如，流水，一去不返。 不泣离别，不诉终殇。</p>
						</div>
					</li>
				</ul>
			</div>
			<div  class='list'>
				<div class='title'>
					<h2>热门文章..</h2>
				</div>
				<ul>
					<li>
						<div class='post-image'>
							<span>
								<img width="" src="http://www.fqpai.com/wp-content/themes/fqp-three/includes/timthumb.php?src=/wp-content/uploads/2013/10/22221.jpg&h=174&w=294&zc=1&q=100" />
							</span>	
						</div>	
						<div class='post-content'>
							<h3>从相见恨晚到不如不见</h3>
							<p>花非花，雾非雾。夜半来，天明去。来如春梦不多时，去似朝云无觅处。浮华一生，淡忘一季。 空有回忆，打乱缠绵。 笑容不见，落寞万千。 弦，思华年。 那些年华，恍然如梦。 亦如，流水，一去不返。 不泣离别，不诉终殇。</p>
						</div>
					</li>
					<li>
						<div class='post-image'>
							<span>
								<img width="" src="http://www.fqpai.com/wp-content/themes/fqp-three/includes/timthumb.php?src=/wp-content/uploads/2013/10/22221.jpg&h=174&w=294&zc=1&q=100" />
							</span>	
						</div>	
						<div class='post-content'>
							<h3>从相见恨晚到不如不见</h3>
							<p>花非花，雾非雾。夜半来，天明去。来如春梦不多时，去似朝云无觅处。浮华一生，淡忘一季。 空有回忆，打乱缠绵。 笑容不见，落寞万千。 弦，思华年。 那些年华，恍然如梦。 亦如，流水，一去不返。 不泣离别，不诉终殇。</p>
						</div>
					</li>
					<li>
						<div class='post-image'>
							<span>
								<img width="" src="http://www.fqpai.com/wp-content/themes/fqp-three/includes/timthumb.php?src=/wp-content/uploads/2013/10/22221.jpg&h=174&w=294&zc=1&q=100" />
							</span>	
						</div>	
						<div class='post-content'>
							<h3>从相见恨晚到不如不见</h3>
							<p>花非花，雾非雾。夜半来，天明去。来如春梦不多时，去似朝云无觅处。浮华一生，淡忘一季。 空有回忆，打乱缠绵。 笑容不见，落寞万千。 弦，思华年。 那些年华，恍然如梦。 亦如，流水，一去不返。 不泣离别，不诉终殇。</p>
						</div>
					</li>
				</ul>
			</div>
		</div>

