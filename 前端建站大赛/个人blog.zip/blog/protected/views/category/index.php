<link href="<?php echo Yii::app()->request->baseUrl ?>/assets/index/css/category.css" rel="stylesheet" />
<div id="main">
		<div class='news'>
			<div class='newsList'>
				<div class='newsImage'>
					<a href=""><img src="./public/images/timthumb.jpeg"/></a>
				</div>
				<div class='newsContent'>
					<h3><a href="">一时心血来潮报了个口译班</a></h3>
					<p>一时心血来潮报了个口译班，其中有一位老师大概30岁，长得很漂亮，打扮也很时尚，口译功夫了得，每次都来去匆匆，中午就花5分钟的时间泡一碗面吃。后来才知道，她大学学的是历史，她的本职工作是一家公司的公关部经理，儿子已经5岁，她每天要上班、做家务、带孩子。与我们不同的是，她拥有人事部二级口译证书，每个月都有天南海北的会议翻译任务，还兼任这家口译中心的导师。</p>
					<a href="" class='more'>更多>></a>
				</div>
			</div>
			<div class='newsList'>
				<div class='newsImage'>
					<a href=""><img src="./public/images/timthumb.jpeg"/></a>
				</div>
				<div class='newsContent'>
					<h3><a href="">一时心血来潮报了个口译班</a></h3>
					<p>一时心血来潮报了个口译班，其中有一位老师大概30岁，长得很漂亮，打扮也很时尚，口译功夫了得，每次都来去匆匆，中午就花5分钟的时间泡一碗面吃。后来才知道，她大学学的是历史，她的本职工作是一家公司的公关部经理，儿子已经5岁，她每天要上班、做家务、带孩子。与我们不同的是，她拥有人事部二级口译证书，每个月都有天南海北的会议翻译任务，还兼任这家口译中心的导师。</p>
					<a href="" class='more'>更多>></a>
				</div>
			</div>
			<div class='newsList'>
				<div class='newsImage'>
					<a href=""><img src="./public/images/timthumb.jpeg"/></a>
				</div>
				<div class='newsContent'>
					<h3><a href="">一时心血来潮报了个口译班</a></h3>
					<p>一时心血来潮报了个口译班，其中有一位老师大概30岁，长得很漂亮，打扮也很时尚，口译功夫了得，每次都来去匆匆，中午就花5分钟的时间泡一碗面吃。后来才知道，她大学学的是历史，她的本职工作是一家公司的公关部经理，儿子已经5岁，她每天要上班、做家务、带孩子。与我们不同的是，她拥有人事部二级口译证书，每个月都有天南海北的会议翻译任务，还兼任这家口译中心的导师。</p>
					<a href="" class='more'>更多>></a>
				</div>
			</div>
		</div>