<?php
/**
 * 后台登陆控制器
 */

class LoginController extends Controller{

    /**
     * 后台登陆控制器
     */
        public function actionIndex(){
            $loginForm = new LoginForm();
            $this->renderpartial('index',array('loginForm'=>$loginForm));
        }
        
        
        public function actions(){
        	return array(
        	'captcha' => array(
        	'class' =>'system.web.widgets.captcha.CCaptchaAction',
        	'height' => 25,
        	'width' => 80,
        	'minLength' => 4,
        	'maxLength' => 4
        	),
        	);
        
        }

}