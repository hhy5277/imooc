<?php
	session_start();
	
	require("dbconfig.php");
	
	$link = mysql_connect(HOST,USER,PASS) or die("SQL die");
	mysql_select_db(DBNAME,$link);
	$num = mysql_fetch_assoc(mysql_query("SELECT count(*) FROM goods"));
	$start = 0;
	if($num['count(*)']>30){
		$inputNum = ceil($num['count(*)']/30);
		if($_GET['page']>1){
			$start = ($_GET['page']-1)*30;
		}
	}
	
	$sql = "SELECT id,UserName,Typeid,Price,Total,Pic,Note,addtime FROM goods LIMIT {$start} ,30";

	$res = mysql_query($sql,$link);
	while($row = mysql_fetch_assoc($res)){
		$listss[] = $row;
	}
	include("showmycart.php");
?>