<?php 
  session_start();
?>
<html>
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# githubog: http://ogp.me/ns/fb/githubog#">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Contact GitHub · GitHub</title>
  <link rel="icon" type="image/x-icon" href="img/favicon.ico">
  <link href="css/github-0f5611c27a5a2a6928dc6e99d63581265b963e34.css" media="all" rel="stylesheet" type="text/css">
  <link href="css/github2-6102d7944435d804d870f38bf20f1e16fe40a4d0.css" media="all" rel="stylesheet" type="text/css">
  <script language="javascript"> 
    function IsDigit(cCheck) 
    { 
    return (('0'<=cCheck) && (cCheck<='9')); 
    } 

    function IsAlpha(cCheck) 
    { 
    return ((('a'<=cCheck) && (cCheck<='z')) || (('A'<=cCheck) && (cCheck<='Z'))) 
    } 

    function IsValid() 
    { 
    var struserName = reg.UserName.value; 
    for (nIndex=0; nIndex<struserName.length; nIndex++) 
    { 
    cCheck = struserName.charAt(nIndex); 
    if (!(IsDigit(cCheck) || IsAlpha(cCheck))) 
    { 
    return false; 
    } 
    } 
    return true; 
    } 
    function chkEmail(str) 
    { 
    return str.search(/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/)==0?true:false 
    }
    function docheck() 
    { 
    if(reg.UserName.value=="") 
    { 
    alert("Please fill in your name"); 
    return false; 
    } 
    else if(!IsValid()) 
    { 
    alert("Username English only"); 
    return false; 
    }
    else if(reg.Email.value =="") 
    { 
    alert("Please fill in the mailbox"); 
    return false; 
    } 
    else if(!chkEmail(reg.Email.value)) 
    { 
    alert("Please enter a valid Email address"); 
    return false; 
    }
    else if(reg.Subject.value=="") 
    { 
    alert("Please fill in the title"); 
    return false; 
    } 
    else if(reg.Body.value=="") 
    { 
    alert("Please enter the message content"); 
    return false; 
    } 
    else 
    { 
    return true; 
    } 
  } 
  </script>
</head>

<body class="logged_out  env-production windows  marketing" style="" screen_capture_injected="true">
<div class="wrapper">
  <div class="header header-logged-out">
    <div class="container clearfix">
      <a class="header-logo-wordmark" href="index.php">
        <span class="mega-octicon octicon-logo-github"><b>GitHub</b></span>
      </a>
      <?php
        include ("session.php");
      ?>
      <div class="command-bar js-command-bar  ">
        <ul class="top-nav">
          <li class="explore"><a href="404.php">Explore</a></li>
          <li class="features"><a href="404.php">Features</a></li>
          <li class="enterprise"><a href="404.php">Enterprise</a></li>
          <li class="blog"><a href="404.php">Blog</a></li>
        </ul>
        <form accept-charset="UTF-8" action="404.php" class="command-bar-form" id="top_search_form" method="get">
          <input type="text" data-hotkey="/ s" name="q" id="js-command-bar-field" placeholder="Search or type a command" tabindex="1" autocapitalize="off">
            <span class="octicon help tooltipped downwards" original-title="Show command bar help">
              <span class="octicon octicon-question"></span>
            </span>
            <input type="hidden" name="ref" value="cmdform">
        </form>
      </div>
    </div>
  </div>
  <div class="site clearfix">
    <div id="site-container" class="context-loader-container" data-pjax-container="">
      <div class="pagehead">
        <div class="container">
          <h1>Contact GitHub</h1>
            <p>
              We’re here to help with any questions or comments.
              If you just want to say hi, that's cool too.
            </p>
        </div>
      </div>
      <div class="container">
        <div class="columns contactcols">
          <div class="first">
            <div id="contact-github">
              <p>
                Feel free to email us at
                <a href="mailto:support.gitsub@gmail.com">support.github@gmail.com</a>
              </p>
              <div class="js-write-bucket" data-model="assets">
                <form accept-charset="UTF-8" action="actioncontact.php?action=add" autocomplete="off" method="post" enctype="multipart/form-data" target="_self" onsubmit="return docheck()" name="reg">
                  <div style="margin:0;padding:0;display:inline">
                    <input name="authenticity_token" type="hidden" value="Rcdhc2nTlv38jliTa+dmk543WHixlWsb9SJAxGY68MY=">
                  </div>
                  <dl class="form">
                    <dt class="input-label"><label for="form_name">Name</label></dt>
                    <dd><input id="form_name" name="UserName" size="30" type="text" placeholder="Please Put In Your Name"></dd>
                  </dl>
                  <dl class="form">
                    <dt class="input-label"><label for="form_email">Email</label></dt>
                    <dd><input id="form_email" name="Email" size="30" type="text" placeholder="Please Put In Your Email"></dd>
                  </dl>
                  <dl class="form">
                    <dt class="input-label"><label class="js-contact-documentation-suggestions" data-quicksearch-url="404.php" for="form_subject">Subject</label></dt>
                    <dd><input class="js-contact-documentation-suggestions" id="form_subject" name="Subject" size="30" type="text" placeholder="Please Put In Your Subject"></dd>
                  </dl>
                  <p class="checkbox">
                    <label>
                      <input id="form_shop" name="form[shop]" type="checkbox" value="1">
                      I need help with an order from shop.github.com
                    </label>
                  </p>
                  <dl class="form">
                    <dt><label for="form_body">Body</label></dt>
                    <dd>
                      <textarea class="js-comment-field" id="form_comments" name="Body" placeholder="If you use 140 characters or fewer, we&#39;ll give you a gold star." required="true"></textarea>
                    </dd>
                  </dl>
                  <div class="form-actions">
                    <button type="submit" class="button" name="sub">Send request</button>
                  </div>
                </form>
              </div>
            </div>
          </div><!-- /.column.main -->
          <div class="last">
            <h3>What's in a great support request?</h3>
            <ul class="checklist">
                <li>Be succinct, we'll ask if we need more info</li>
                <li>
                  The name of the user or repository you’re having troubles with
                </li>
            </ul>
            <div class="rule"></div>
            <h3>Reporting a security vulnerability?</h3>
            <p>
              Please review our
              <a href="404.php">
                Responsible Disclosure Policy
              </a>
            </p>
            <div class="rule"></div>
            <p>
              If you need help with a <strong>project hosted on GitHub</strong>,
              please contact the project's owner.
            </p>
            <img alt="Heartocat" class="heartocat" src="img/heartocat.png">
          </div><!-- /.column.sidebar -->
        </div><!-- /.columns.content -->
      </div>
    </div>
    <div class="modal-backdrop"></div>
  </div>
</div><!-- /.wrapper -->

<!--页尾-->
<hr width="100%" color="#fff" heigh="2px"/>
<div class="container">
  <div class="site-footer">
    <ul class="site-footer-links right">
      <li><a href="404.php">Status</a></li>
      <li><a href="404.php">API</a></li>
      <li><a href="404.php">Training</a></li>
      <li><a href="shop.php">Shop</a></li>
      <li><a href="404.php">Blog</a></li>
      <li><a href="404.php">About</a></li>
    </ul>
    <ul class="site-footer-links">
      <li>© 2013 <span title="index.php">GitHub</span>, Inc.</li>
      <li><a href="404.php">Terms</a></li>
      <li><a href="404.php">Privacy</a></li>
      <li><a href="404.php">Security</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="contactContent.php">Content</a></li>
    </ul>
  </div><!-- /.site-footer -->
</div><!-- /.container -->
</body>
</html>