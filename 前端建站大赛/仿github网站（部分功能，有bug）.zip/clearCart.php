<?php

	session_start();

	if($_GET['id']){

		unset($_SESSION["shoplist"][$_GET['id']]);
	}else{

		unset($_SESSION["shoplist"]);
	}

	header("Location:myCart.php");
?>