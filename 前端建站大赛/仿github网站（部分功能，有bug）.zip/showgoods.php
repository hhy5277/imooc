<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>github:shop</title>
  <link href="css/shopstyle.css" rel="stylesheet" type="text/css" media="all">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  <link rel="icon" type="image/x-icon" href="img/favicon.ico">
  <script type="text/javascript" async="" src="js/shopify_stats.js"></script>
  <script type="text/javascript" async="" src="js/limit-1_6.js"></script>
  <script type="text/javascript" async="" src="js/298_1339695471.js"></script>
  <script type="text/javascript" async="" id="gauges-tracker" data-site-id="4f299d38f5a1f5302d000003" src="js/track.js"></script>
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/option_selection.js" type="text/javascript"></script>
  <script type="text/javascript">
    function gotopage(i) {
      window.location.href="contactContent.php?page="+i;
    }
  </script>
</head>

<body id="page-index" screen_capture_injected="true">

  <div id="header-wrapper">
    <div id="header">
      <div>
        <a class="logo" href="shop.php"><img src="img/shop-logo.png" height="45"></a>
        <ul class="nav">
          <li><a href="index.php">Back to GitHub</a></li>
        </ul>
      </div>
    </div><!-- #header -->
  </div><!-- #header-wrapper -->

  <div id="wrapper">
  <hr>
    <div class="sub-head">
      <div class="breadcrumbs">
        <span><a href="shop.php">shop</a></span> / <span>Welcome</span>
      </div>
      <ul class="sub-nav">
        <li class="btn about"><a href="404.php"><span>&nbsp;</span>About Us</a></li>
        <li class="btn about"><a href="404.php"><span>&nbsp;</span>FAQ</a></li>
        <li class="btn terms"><a href="404.php"><span>&nbsp;</span>Terms &amp; Conditions</a></li>
        <li class="btn policy"><a href="404.php"><span>&nbsp;</span>Store Policy</a></li>
        <li class="cart"><span>0</span><a href="mycart.php" id="btn_cart">View Cart</a></li><!--turn to mycart-->
      </ul>
    </div>
    
    <div class="content">
      <?php
        foreach($lists as $row){
          echo "<div class='item'>
                  <div class='shell'>
                    <div class='header'>
                      <span class='icon'>&nbsp;</span>
                      <h3>{$row['UserName']}</h3>
                      <a href='#' class='details'>see details</a>
                    </div>
                    <a class='preview-image'>
                      <img src='uploads/s_{$row['Pic']}' alt='{$row['UserName']}'/>
                    </a>
                    <div class='footer in-stock'>
                      <p class='purchasable'>{$row['Note']}</p>
                      <a href='addCart.php?id={$row['id']}' class='btn-add'>Add to cart</a>
                      <p class='price'><span>$</span>{$row['Price']}</p>
                    </div>
                  </div>
                </div>";
        }

        echo "<div class='item'>
                <div class='shell'>
                  <div class='header'>
                    <span class='icon icon-clothing'>&nbsp;</span>
                    <h3>Add Name</h3>
                    <a href='#' class='details'>see details</a>
                  </div>
                  <a href='AddGoods.php' class='preview-image'><!--跳转到商品添加页面-->
                    <img src='img/add.jpg' alt='Pixelcat Shirt'>
                  </a>
                  <div class='footer in-stock'>
                    <p class='purchasable'>This item can be purchased</p>
                    <a href='AddGoods.php' class='btn-add'>Add New Goods</a><!--添加到购物车-->
                    <p class='price'><span>$</span>??.??</p>
                  </div>
                </div>
              </div>";

        /*for($i=1;$i<=$inputNum;$i++){
          echo "<input value='Page{$i}' type='button' onclick='gotopage({$i})'/>";
        }*/
        ?>
    </div>
  </div><!-- #wrapper -->

  <hr>

  <div id="footer-wrapper">
    <div id="footer">
      <div class="lower_footer">
        <div class="footer_inner clearfix">
            <div id="legal">
              <ul id="legal_links">
                <li><a href="404.php">About Us</a></li>
                <li><a href="404.php">FAQ</a></li>
                <li><a href="404.php">Terms &amp; Conditions</a></li>
                <li><a href="404.php">Store Policy</a></li>
              </ul>
              <p>© <span id="year">2013</span> GitHub Inc. All rights reserved.</p>
            </div><!-- /#legal or /#legal_ie-->
            <div class="sponsor">
              Powered by the fine folks at <a href="404.php">Shopify</a><br>
              You should try them out. No, really.
          </div>
        </div><!-- /.footer_inner -->
      </div><!-- /.lower_footer -->
    </div><!-- #footer -->
  </div><!-- #footer-wrapper -->
</body>
</html>