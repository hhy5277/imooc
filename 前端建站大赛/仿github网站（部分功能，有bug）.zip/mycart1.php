<?php
	session_start();
	
	require("dbconfig.php");
	
	$link = mysql_connect(HOST,USER,PASS) or die("SQL die");
	mysql_select_db(DBNAME,$link);
	$num = mysql_fetch_assoc(mysql_query("SELECT count(*) FROM goods"));
	$start = 0;
	if($num['count(*)']>3){
		$inputNum = ceil($num['count(*)']/3);
		if($_GET['page']>1){
			$start = ($_GET['page']-1)*3;
		}
	}
	
	$sql = "SELECT id,UserName,Typeid,Price,Total,Pic,Note,addtime FROM goods LIMIT {$start} ,3";

	$res = mysql_query($sql,$link);
	while($row = mysql_fetch_assoc($res)){
		$lists[] = $row;
	}
	include("showmycart.php");
?>