<?php
	require("dbconfig.php");
	$link = mysql_connect("localhost","root","");
	mysql_select_db("github",$link);

//获取action参数的值，并做对应的操作
	switch($_GET["action"]){
		case "add": //添加
			//1. 获取添加信息
			$UserName 	= $_POST["UserName"];
			$Email = $_POST["Email"];
			$UserPassword 	= $_POST["UserPassword"];
			$addtime = time();
			
			//验证邮箱或者昵称是否被注册
			if($Email || $UserName){
				$sql ="SELECT * FROM customs WHERE Email ='$Email' or UserName ='$UserName'";
				$res = mysql_query($sql);
				$row = mysql_fetch_assoc($res);
				if($row['Email']==$Email){
					echo "<script>alert('Sorry, your mailbox has been registered, please re-enter!')</script>";
					echo "<script>window.location.href='regist.php'</script>";
				}
				else if($row['UserName']==$UserName){
					echo "<script>alert('Sorry, your username is already registered, please re-enter!')</script>";
					echo "<script>window.location.href='regist.php'</script>";
				}
				else{
					$sql = "insert into `customs` values(null,'{$UserName}','{$Email}',{$UserPassword},{$addtime})";
					$res=mysql_query($sql,$link);
					//session_start();
					$_SESSION['Email']=$Email;

					echo "<script>alert('Congratulations on your successful registration!')</script>";
					echo "<script>window.location.href='index.php'</script>";
				}
			}
	}
//四、关闭数据库
	mysql_close($link);
?>