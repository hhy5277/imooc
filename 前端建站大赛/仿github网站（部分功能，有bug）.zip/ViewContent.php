<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>View Content · GitHub</title>
  <link rel="icon" type="image/x-icon" href="img/favicon.ico">
  <meta content="authenticity_token" name="csrf-param">
  <meta content="Rcdhc2nTlv38jliTa+dmk543WHixlWsb9SJAxGY68MY=" name="csrf-token">
  <link href="css/github-0f5611c27a5a2a6928dc6e99d63581265b963e34.css" media="all" rel="stylesheet" type="text/css">
  <link href="css/github2-6102d7944435d804d870f38bf20f1e16fe40a4d0.css" media="all" rel="stylesheet" type="text/css">
  <script language="javascript"> 
    function gotopage(i) {
      window.location.href="contactContent.php?page="+i;
    }
    function IsDigit(cCheck)
    { 
    return (('0'<=cCheck) && (cCheck<='9')); 
    } 

    function IsAlpha(cCheck) 
    { 
    return ((('a'<=cCheck) && (cCheck<='z')) || (('A'<=cCheck) && (cCheck<='Z'))) 
    } 

    function IsValid() 
    { 
    var struserName = reg.UserName.value; 
    for (nIndex=0; nIndex<struserName.length; nIndex++) 
    { 
    cCheck = struserName.charAt(nIndex); 
    if (!(IsDigit(cCheck) || IsAlpha(cCheck))) 
    { 
    return false; 
    } 
    } 
    return true; 
    } 
    function chkEmail(str) 
    { 
    return str.search(/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/)==0?true:false 
    }
    function docheck() 
    { 
    if(reg.UserName.value=="") 
    { 
    alert("Please fill in your name"); 
    return false; 
    } 
    else if(!IsValid()) 
    { 
    alert("Username English only"); 
    return false; 
    }
    else if(reg.Email.value =="") 
    { 
    alert("Please fill in the mailbox"); 
    return false; 
    } 
    else if(!chkEmail(reg.Email.value)) 
    { 
    alert("Please enter a valid Email address"); 
    return false; 
    }
    else if(reg.Subject.value=="") 
    { 
    alert("Please fill in the title"); 
    return false; 
    } 
    else if(reg.Body.value=="") 
    { 
    alert("Please enter the message content"); 
    return false; 
    } 
    else 
    { 
    return true; 
    } 
  } 
  </script>
  <style type="text/css">
    #show{
    width: auto;
    height: auto;
    /*background: #d7d3d3;*/
    float: left;
    }
    #totle{
    width: 100%;
    height: 32px;
    /*border:#dddbdb solid 1px;*/
    }
    #username{/*用户名*/
    width: 150px;
    height: 30px;
    float: left;
    background: #d3dad6;
    border:#23b2ed solid 4px;
    border-bottom: #6ba5b8 solid 4px;
    border-right:none; 
    }
    #subject{/*留言标题*/
    width: 396px;
    height: 30px;
    float: left;
    background: #42da7f;
    border:#23b2ed solid 4px;
    border-bottom: #6ba5b8 solid 4px;
    border-left:none; 
    }
    #contents{/*留言内容*/
    width: 546px;
    height: 200px;
    background: #fafafa;
    border:#23b2ed solid 4px;
    border-top: none;
    }
    #lastaction{
    height: auto;
    width: 100px;
    position: absolute;
    margin-top: -10px;
    margin-left: 20px;
    float: left;
    }
    /*#action{
    height: auto;
    width: 50px;
    position: relative;
    }*/
    #columns_contactcols{
    width: auto;
    height: auto;
    }
    #columns_contactcolscontent{
    width: 570px;
    height: auto;
    float: left;
    }
  </style>
</head>

<body class="logged_out  env-production windows  marketing" style="" screen_capture_injected="true">
<div class="wrapper">
  <div class="header header-logged-out">
    <div class="container clearfix">
      <a class="header-logo-wordmark" href="index.php">
        <span class="mega-octicon octicon-logo-github"><b>GitHub</b></span>
      </a>
      <?php
        include ("session.php");
      ?>
      <div class="command-bar js-command-bar">
        <ul class="top-nav">
          <li class="explore"><a href="404.php">Explore</a></li>
          <li class="features"><a href="404.php">Features</a></li>
          <li class="enterprise"><a href="404.php">Enterprise</a></li>
          <li class="blog"><a href="404.php">Blog</a></li>
        </ul>
        <form accept-charset="UTF-8" action="404.php" class="command-bar-form" id="top_search_form" method="get">
          <input type="text" data-hotkey="/ s" name="q" id="js-command-bar-field" placeholder="Search or type a command" tabindex="1" autocapitalize="off">
            <span class="octicon help tooltipped downwards" original-title="Show command bar help">
              <span class="octicon octicon-question"></span>
            </span>
            <input type="hidden" name="ref" value="cmdform">
        </form>
      </div>
    </div>
  </div>
  <div class="site clearfix">
    <div id="site-container" class="context-loader-container" data-pjax-container="">
      <div class="pagehead">
        <div class="container">
          <h1>Content GitHub</h1>
            <p>
              We’re here to help with any questions or comments.
              If you just want to say hi, that's cool too.
            </p>
        </div>
      </div>
      <div class="container">
        <div id="columns_contactcols">

          <div  id="columns_contactcolscontent"><!--反馈内容展示效果-->
            <?php
            // if(count('$list as $value')>0){
              // foreach ($list as $value) {
              //  echo "<div id='show'>
              //         <div id='totle'>
              //           <div id='username'><b>&nbsp;&nbsp;{$value['UserName']}</b></div>
              //           <div id='subject'><b>&nbsp;&nbsp;{$value['s']}</b></div>
              //         </div>
              //         <div id='contents'><b>&nbsp;&nbsp;{$value['Body']}</b></div>
              //       </div>";
              // }
              // for($i=1;$i<=$inputNum;$i++){
              //   echo "<input value='Page{$i}' type='button' onclick='gotopage({$i})'/>";
              // }
            // }
            if(empty('$list as $value')){
              echo "<div id='show'>
                      <div id='totle'>
                        <div id='username'><b>&nbsp;&nbsp;暂无内容</b></div>
                        <div id='subject'><b>&nbsp;&nbsp;暂无内容</b></div>
                      </div>
                      <div id='contents'><b>&nbsp;&nbsp;暂无内容</b></div>
                    </div>";
            }
            else{
              foreach ($list as $value) {
                 echo "<div id='show'>
                        <div id='totle'>
                          <div id='username'><b>&nbsp;&nbsp;{$value['UserName']}</b></div>
                          <div id='subject'><b>&nbsp;&nbsp;{$value['Subject']}</b></div>
                        </div>
                        <div id='contents'><b>&nbsp;&nbsp;{$value['Body']}</b></div>
                      </div>";
              }
              for($i=1;$i<=$inputNum;$i++){
                echo "<input value='Page{$i}' type='button' onclick='gotopage({$i})'/>";
              }
            }
          ?>
          </div>
          
          <div class="lastaction">
            <h3>What's in a great support request?</h3>
            <ul class="lastaction">
              Be succinct, we'll ask if we need more info</br>
              The name of the user or repository you’re having troubles with
            </ul>
            <h3>Reporting a security vulnerability?</h3>
            <p>
              Please review our
              <a href="404.php">
                Responsible Disclosure Policy
              </a>
            </p>
            <p>
              If you need help with a <strong>project hosted on GitHub</strong>,
              please contact the project's owner.
            </p>
            <img alt="Heartocat" class="heartocat" src="img/heartocat.png">
          </div><!-- /.column.sidebar -->
        </div><!-- /.column.main -->
      </div><!-- /.columns.content -->
    </div>
    <div class="modal-backdrop"></div>
  </div>
</div><!-- /.wrapper -->

<!--页尾-->
<hr width="100%" color="#fff" />
<div class="container">
  <div class="site-footer">
    <ul class="site-footer-links right">
      <li><a href="404.php">Status</a></li>
      <li><a href="404.php">API</a></li>
      <li><a href="404.php">Training</a></li>
      <li><a href="shop.php">Shop</a></li>
      <li><a href="404.php">Blog</a></li>
      <li><a href="404.php">About</a></li>
    </ul>
    <ul class="site-footer-links">
      <li>© 2013 <span title="index.php">GitHub</span>, Inc.</li>
      <li><a href="404.php">Terms</a></li>
      <li><a href="404.php">Privacy</a></li>
      <li><a href="404.php">Security</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="contactContent.php">Content</a></li>
    </ul>
  </div><!-- /.site-footer -->
</div><!-- /.container -->
</body>
</html>