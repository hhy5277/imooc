<p>未导入数据库情况会出现bug，目前在shop页面有分页功能错误，有爱心人士可以帮忙调试，所有数据库的信息在dbconfig.php文件中，打开文件请先将github.sql文件导入你的数据库中。</p><p>包含功能：</p><ol class=" list-paddingleft-2" style="list-style-type: decimal;"><li><p>登录、注册</p></li><li><p>添加商品</p></li><li><p>页面浏览</p></li><li><p>......<br/></p></li></ol>

