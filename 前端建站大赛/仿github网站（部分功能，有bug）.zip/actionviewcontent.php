<html>
<head>
	<META content="text/html; charset=utf-8" http-equiv=Content-Type>
	<link href="img/favicon.ico" type="image/x-icon" rel="shortcut  icon" />
	<title>View Content . GitHub</title>
</head>

<body>
<?php
//一、导入配置文件和函数库文件
	require("dbconfig.php");

//二、连接MySQL，选择数据库
	$link = mysql_connect(HOST,USER,PASS) or die("SQL die");
	mysql_select_db(DBNAME,$link);


//三、获取action参数的值，并做对应的操作
	switch($_GET["action"]){
		case "del": //删除
			//获取要删除的id号并拼装删除sql，执行
			$sql = "delete from contact where id={$_GET['id']}";
			mysql_query($sql,$link);
			//跳转到浏览界面
			header("Location:contactContent.php");
			break;

		case "update": //修改
			//1. 获取要修改的信息
			$UserName 	= $_POST["UserName"];
			$Email = $_POST["Email"];
			$Subject 	= $_POST["Subject"];
			$Body 	= $_POST["Body"];
			$id = $_POST['id'];

			//2. 执行修改
			$sql = "update contact set UserName='{$UserName}',Email={$Email},Subject={$Subject},Body={$Body}, where id={$id}";
			//echo $sql;
			mysql_query($sql,$link);
			
			//3. 判断是否修改成功
			if(mysql_affected_rows($link)>0){
				echo "update successed !";
				echo "<script>window.location.herf='contactContent.php'</script>";
			}else{
				echo "update failed".mysql_error();
				echo "<script>window.location.herf='contactContent.php'</script>";
			}
			break;
	}
//四、关闭数据库
mysql_close($link);
?>
</body>
</html>

