<?php 
  session_start();
?>
<html>
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# githubog: http://ogp.me/ns/fb/githubog#">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Sign in · GitHub</title>
  <meta name="msapplication-TileImage" content="/windows-tile.png">
  <meta name="msapplication-TileColor" content="#ffffff">
  <link rel="icon" type="image/x-icon" href="img/favicon.ico">
  <link href="css/github-0f5611c27a5a2a6928dc6e99d63581265b963e34.css" media="all" rel="stylesheet" type="text/css">
  <link href="css/github2-6102d7944435d804d870f38bf20f1e16fe40a4d0.css" media="all" rel="stylesheet" type="text/css">
  <script language="javascript"> 
      function IsDigit(cCheck) 
      { 
      return (('0'<=cCheck) && (cCheck<='9')); 
      } 

      function IsAlpha(cCheck) 
      { 
      return ((('a'<=cCheck) && (cCheck<='z')) || (('A'<=cCheck) && (cCheck<='Z'))) 
      } 

      function IsValid() 
      { 
      var struserName = reg.UserName.value; 
      for (nIndex=0; nIndex<struserName.length; nIndex++) 
      { 
      cCheck = struserName.charAt(nIndex); 
      if (!(IsDigit(cCheck) || IsAlpha(cCheck))) 
      { 
      return false; 
      } 
      } 
      return true; 
      } 
      function chkEmail(str) 
      { 
      return str.search(/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/)==0?true:false 
      }

      function docheck() 
      { 
        if(reg.Email.value =="") 
        { 
          alert("Please fill in the mailbox"); 
          return false; 
        } 
        else if(!chkEmail(reg.Email.value)) 
        { 
          alert("Please enter a valid Email address"); 
          return false; 
        }
        else if(reg.UserPassword.value=="") 
        { 
        alert("Please fill in your password"); 
        return false; 
        }
        
        else 
        { 
        return true; 
        } 
      } 
    </script>
</head>

<body class="logged_out  env-production windows  signin" style="" screen_capture_injected="true">
<div class="wrapper">
  <div class="header header-logged-out">
    <div class="container clearfix">
      <a class="header-logo-wordmark" href="index.php">
        <span class="mega-octicon octicon-logo-github"><b>GitHub</b></span>
      </a>
      <?php
        include ("session.php");
      ?>
      <div class="command-bar js-command-bar  ">
        <ul class="top-nav">
          <li class="explore"><a href="404.php">Explore</a></li>
          <li class="features"><a href="404.php">Features</a></li>
          <li class="enterprise"><a href="404.php">Enterprise</a></li>
          <li class="blog"><a href="404.php">Blog</a></li>
        </ul>
        <form accept-charset="UTF-8" action="404.php" class="command-bar-form" id="top_search_form" method="get">
          <input type="text" data-hotkey="/ s" name="q" id="js-command-bar-field" placeholder="Search or type a command" tabindex="1" autocapitalize="off" />
          <span class="octicon help tooltipped downwards" original-title="Show command bar help">
            <span class="octicon octicon-question"></span>
          </span>
          <input type="hidden" name="ref" value="cmdform" />
        </form>
      </div>
    </div>
  </div>
  <br><br>
  <div class="site clearfix">
    <div id="site-container" class="context-loader-container" data-pjax-container="">
      <div class="auth-form" id="login">
        <form accept-charset="UTF-8" action="actionlogin.php" method="post" enctype="multipart/form-data" target="_self" onsubmit="return docheck()" name="reg"><!--session-->
          <div style="margin:0;padding:0;display:inline">
            <input name="authenticity_token" type="hidden" value="Rcdhc2nTlv38jliTa+dmk543WHixlWsb9SJAxGY68MY=">
          </div>
          <div class="auth-form-header">
            <h1>Sign in</h1>
          </div>
          <div class="auth-form-body">
            <label for="login_field">
              Put In Your Email<br>
            </label>
            <input type="email" name="Email" class="input-block" placeholder="Put In Your Email" class="input-block" id="login_field" tabindex="2" type="text">
            <label for="password">
              Password <a href="ForgotPassword.php">(forgot password)</a>
            </label>
            <input class="input-block" id="password" tabindex="2" type="password" name="UserPassword" class="textfield" placeholder="Put Your Password">
            <input class="button" name="sub" tabindex="3" type="submit" value="Sign in">
          </div>
        </form>
      </div>
    </div>
    <div class="modal-backdrop"></div>
  </div>
</div><!-- /.wrapper -->
<br><br><br><br>
<!--页尾-->
<hr width="100%" color="#fff" />
<div class="container">
  <div class="site-footer">
    <ul class="site-footer-links right">
      <li><a href="404.php">Status</a></li>
      <li><a href="404.php">API</a></li>
      <li><a href="404.php">Training</a></li>
      <li><a href="shop.php">Shop</a></li>
      <li><a href="404.php">Blog</a></li>
      <li><a href="404.php">About</a></li>
    </ul>
    <ul class="site-footer-links">
      <li>© 2013 <span title="index.php">GitHub</span>, Inc.</li>
      <li><a href="404.php">Terms</a></li>
      <li><a href="404.php">Privacy</a></li>
      <li><a href="404.php">Security</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="contactContent.php">Content</a></li>
    </ul>
  </div><!-- /.site-footer -->
</div><!-- /.container -->
</body>
</html>