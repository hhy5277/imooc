-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2014-05-29 02:24:49
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `github`
--
CREATE DATABASE IF NOT EXISTS `github` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `github`;

-- --------------------------------------------------------

--
-- 表的结构 `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UserName` varchar(32) NOT NULL,
  `Email` varchar(24) NOT NULL,
  `Subject` varchar(32) NOT NULL,
  `Body` mediumtext NOT NULL,
  `addtime` int(40) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- 插入之前先把表清空（truncate） `contact`
--

TRUNCATE TABLE `contact`;
-- --------------------------------------------------------

--
-- 表的结构 `customs`
--

DROP TABLE IF EXISTS `customs`;
CREATE TABLE IF NOT EXISTS `customs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UserName` varchar(32) NOT NULL,
  `Email` varchar(24) NOT NULL,
  `UserPassword` varchar(32) NOT NULL,
  `addtime` int(40) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- 插入之前先把表清空（truncate） `customs`
--

TRUNCATE TABLE `customs`;
--
-- 转存表中的数据 `customs`
--

INSERT INTO `customs` (`id`, `UserName`, `Email`, `UserPassword`, `addtime`) VALUES
(1, 'test', '1@qq.com', '123', 1400547986),
(2, 'test2', '2@qq.com', '123', 1400548009);

-- --------------------------------------------------------

--
-- 表的结构 `goods`
--

DROP TABLE IF EXISTS `goods`;
CREATE TABLE IF NOT EXISTS `goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UserName` varchar(64) NOT NULL,
  `Typeid` varchar(64) NOT NULL,
  `Price` double(5,2) unsigned NOT NULL,
  `Total` int(10) unsigned NOT NULL,
  `Pic` varchar(32) NOT NULL,
  `Note` text NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- 插入之前先把表清空（truncate） `goods`
--

TRUNCATE TABLE `goods`;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
