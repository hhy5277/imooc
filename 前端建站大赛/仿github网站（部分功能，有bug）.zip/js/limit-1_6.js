var limitsJson = {};

var isValid = false;

var cartJson;

var originalSubmitText;

var errorMessage = "Cannot place order, conditions not met: \n\n";

function decorateCell(cell, message) {
	$(cell).append('<span style="color:red;font-size:large;" title="' + message + '">*</span>');
	errorMessage = errorMessage + message + "\n";
}

function showMessage() {
	if (isValid) {
		return true;
	}

	alert(errorMessage);
	return false;
}

function disableCheckout() {
	submitText = originalSubmitText;
	if (limitsJson['changetext']) {
		if ($.trim(limitsJson['submittext']) != "") {
			submitText = unescape(limitsJson['submittext']);
		} else {
			submitText = "Order not valid";
		}
	}

	$('[name="checkout"]').val(submitText);
	isValid = false;
}

function enableCheckout() {
	$('[name="checkout"]').val(originalSubmitText);
	isValid = true;
}

function setCheckoutToVerifying() {
	$('[name="checkout"]').val("Verifying");
	isValid = false;
}

function getSubtotal() {
	var subtotal = Number(cartJson['total_price']);
	subtotal = subtotal / 100.0;
	return subtotal;
}

function getSubTotalCell() {
	return $('.subtotal')[0];
}

function getCellForItem(item) {
	var id = item['id'];
	var quantity_id = '#updates_' + id;
	var cell = $(quantity_id).closest('td')[0];
	return cell;
}

function checkSubTotal() {
	var subtotal = getSubtotal();

	var minorder = Number(limitsJson['minorder']);
	var maxorder = Number(limitsJson['maxorder']);
	cell = getSubTotalCell();

	if (subtotal < minorder) {
		var message = "Must have at least $" + minorder + " in total.";
		decorateCell(cell, message);
		return false;
	}
	if ((maxorder > 0) && (subtotal > maxorder)) {
		var message = "Must have at most $" + maxorder + " in total.";
		decorateCell(cell, message);
		return false;
	}

	return true;
}

function getWeight() {
	var weight = Number(cartJson['total_weight']);
	return weight
}

function checkWeight() {
	var weight = getWeight();

	var minweight = Number(limitsJson['weightmin']);
	var maxweight = Number(limitsJson['weightmax']);
	cell = getSubTotalCell();

	if (weight < minweight) {
		var message = "Current weight: " + weight + " grams is less than the minimum order weight: " + minweight + " grams.";
		decorateCell(cell, message);
		return false;
	}
	if ((maxweight > 0) && (weight > maxweight)) {
		var message = "Current weight: " + weight + "grams is more than the maximum order weight: " + maxweight + " grams.";
		decorateCell(cell, message);
		return false;
	}

	return true;
}

function checkProductLimit(quantity, productName, item, min, max, multiple) {
	if (quantity < min) {
		var message = productName + ": Must have at least " + min + " of this item.";
		decorateCell(getCellForItem(item), message);
		return false;
	}
	
	if ((max > 0) && (quantity > max)) {
		var message = productName + ": Must have at most " + max + " of this item.";
		decorateCell(getCellForItem(item), message);
		return false;
	}
	
	if ((multiple > 1) && (quantity % multiple > 0)) {
		var message = productName + ": Quantity must be a multiple of " + multiple;
		decorateCell(getCellForItem(item), message);
		return false;
	}

	return true;
}

function collectProductQuantities() {
	var items = cartJson['items'];
	var products = {};

	for (var i = 0; i < items.length; i++) {
		var item = items[i];
		var handle = item['handle'];
		var prodLimit = getProductLimits(handle);
		var prodCombine = false;
		if (prodLimit && ('combine' in prodLimit))
			prodCombine = prodLimit['combine'];
		
		if ((getSkuFilter(item['sku']) != null) || !prodCombine) {
			var variant = handle + " " + item['sku'];
			if (item['sku'] == "") {
				variant += item['variant_id'];
			}
			
			var productDetails = {};
			productDetails['title'] = unescape(item['title']);
			productDetails['id'] = item['id'];
			productDetails['quantity'] = Number(item['quantity']);
			
			products[variant] = productDetails;
		} else {
			var productDetails = products[handle];
			if (productDetails == undefined) {
				productDetails = {};
				productDetails['title'] = unescape(item['title']);
				productDetails['id'] = item['id'];
				productDetails['quantity'] = Number(item['quantity']);
				products[handle] = productDetails;
			} else {
				productDetails['quantity'] += Number(item['quantity']);
			}
		}
	}

	return products;
}

function getSkuFilter(sku) {
	var skuFilters = limitsJson['skus'];
	for (var i in skuFilters) {
		var skuFilter = skuFilters[i];
		if(sku.indexOf(skuFilter['filter']) > -1) {
			return skuFilter;
		}
	}
	
	return null;
}

function getGroupFilter(handle) {
	var productGroups = limitsJson['groupLimits'];
	for (var i in productGroups) {
		var group = productGroups[i];
		
		if(group['combine'] == true) {
			continue;
		}
		
		if(handle.indexOf(group['filter']) > -1) {
			return group;
		}
	}
	
	return null;
}

function getProductLimits(handle) {
	var productLimits = limitsJson['productLimits'];
	var productLimit = productLimits[handle];
	return productLimit;
}

function checkItemLimits() {
	var itemsValid = true;

	var products = collectProductQuantities();
	for (product in products) {
		var productDetails = products[product];
		var quantity = Number(productDetails['quantity']);
		var productName = productDetails['title'];

		var limits = getLimitsForItem(product);
		itemsValid = checkProductLimit(quantity, productName, productDetails, Number(limits['min']), Number(limits['max']), Number(limits['multiple'])) && itemsValid;
	}

	return itemsValid;
}

function getLimitsForItem(product) {
	var limits = null; 
	var prodsplit = product.split(" ");
	var handle = prodsplit[0];
	var variant = prodsplit.length > 1 ? prodsplit[1] : "";
	var itemmin = Number(limitsJson['itemmin']);
	var itemmax = Number(limitsJson['itemmax']);
	var itemmult = Number(limitsJson['itemmult']);
	
	limits = getSkuFilter(variant);
	if (limits == null) limits = getProductLimits(handle);
	if (limits == null) limits = getGroupFilter(handle);
	if (limits == null) limits = {'min':itemmin, 'max':itemmax, 'multiple':itemmult};
	
	return limits;
}

function checkTotalItems() {
	var maxtotalitems = Number(limitsJson['maxtotalitems']);
	var mintotalitems = Number(limitsJson['mintotalitems']);
	var multtotalitems = Number(limitsJson['multtotalitems']);
	var totalItems = 0;
	var totalItemsValid = true;

	var items = cartJson['items'];
	for ( i = 0; i < items.length; i++) {
		var item = items[i];
		var quantity = Number(item['quantity']);
		totalItems += quantity;
	}

	if ((maxtotalitems != 0) && (totalItems > maxtotalitems)) {
		totalItemsValid = false;
		decorateCell(getSubTotalCell(), 'Must have at most ' + maxtotalitems + ' items total.');
	}

	if (totalItems < mintotalitems) {
		totalItemsValid = false;
		decorateCell(getSubTotalCell(), 'Must have at least ' + mintotalitems + ' items total.');
	}
	
	if ((multtotalitems > 1) && (totalItems % multtotalitems > 0)) {
		totalItemsValid = false;
		decorateCell(getSubTotalCell(), 'Must have a multiple of ' + multtotalitems + ' items total.');
	}

	return totalItemsValid;
}

function checkGroupLimits() {
	var groupTotals = [];
	var groupsValid = true;
	
	var productGroups = limitsJson['groupLimits'];
	for (var i in productGroups) {
		var group = productGroups[i];
		if(group['combine'] == true) {
			var quantity = 0;
			var items = cartJson['items'];
			for(var j in cartJson['items']) {
				var item = items[j];
				if(item['handle'].indexOf(group['filter']) > -1) {
					quantity += item['quantity']; 
				}
			}
			
			var title = unescape(group['title']);
			
			if (quantity == 0)
				continue;
			
			if ((group['min'] > 0) && (quantity < group['min'])) {
				groupsValid = false;
				decorateCell(getSubTotalCell(), 'Must have at least ' + group['min'] + ' of ' + title);
			}
			
			if ((group['max'] > 0) && (quantity > group['max'])) {
				groupsValid = false;
				decorateCell(getSubTotalCell(), 'Must have less than ' + group['max'] + ' of ' + title);
			}
			
			if ((group['multiple'] > 1) && (quantity % group['multiple'] > 0)) {
				groupsValid = false;
				decorateCell(getSubTotalCell(), title + ' quantity must be a multiple of ' + group['multiple']);
			}
		}
	}
	
	return groupsValid;
}

function checkOverride() {
	var subtotal = getSubtotal();

	var overridesubtotal = Number(limitsJson['overridesubtotal']);

	if ((overridesubtotal > 0) && (subtotal > overridesubtotal)) {
		return true;
	}
	
	return false;
}

function checkLimits() {
	var checkoutEnabled = true;

	if(!checkOverride()) {
		checkoutEnabled = checkSubTotal();
		checkoutEnabled = checkItemLimits() && checkoutEnabled;
		checkoutEnabled = checkGroupLimits() && checkoutEnabled;
		checkoutEnabled = checkTotalItems() && checkoutEnabled;
		checkoutEnabled = checkWeight() && checkoutEnabled;
	}

	if (checkoutEnabled)
		enableCheckout();
	else
		disableCheckout();

}

function checkCart() {
	$.ajax({
		url : "/cart.js",
		contentType : "text",
		type : "GET",
		cache: false,
		success : function(data) {
			cartJson = JSON.parse(data);
			checkLimits();
		},
		error : function(jqXHR, textStatus, errorThrown) {
			if (jqXHR.status == "200") {
				cartJson = $.parseJSON(jqXHR.responseText);
				checkLimits();
			}
		}
	});
}

function getLimits() {
	if($('#minmaxify_disable').length > 0) {
		return;
	}
	
	originalSubmitText = $('[name="checkout"]').val();
	
	$('[name="checkout"]').click(function() {
		return showMessage();
	});
	$('[name="goto_pp"]').click(function() {
		return showMessage();
	});
	setCheckoutToVerifying();
	//var url = "http://minmaxify.heroku.com/limits.js?callback=?&shop=" + getShopValue();
	var url = "https://s3.amazonaws.com/minmaxify/limits/" + getShopValue() + "?callback=?";
	$.getJSON(url, {
		jsonp : "handleLimits"
	});
}

function handleLimits(data) {
	limitsJson = JSON.parse(data);
	
	if (limitsJson['lockchange'] == true) {
		setChangeListener();
	}
	
	checkCart();
	showLimits();
}

function showLimits() {
	var handle = $('#minmaxify-product').text();
	
	var limits = getLimitsForItem(handle);
	if (limits == null)
		return;
	
	if('min' in limits && limits['min'] > 0) {
		$('.minmaxify-min').text(limits['min']);
		$('.minmaxify-min').parent().show();
		$('.minmaxify-minfield').val(limits['min']);
	}
	if('max' in limits && limits['max'] > 0) {
		$('.minmaxify-max').text(limits['max']);
		$('.minmaxify-max').parent().show();
		$('.minmaxify-maxfield').val(limits['max']);
	}
	if('multiple' in limits && limits['multiple'] > 0) {
		$('.minmaxify-multiple').text(limits['multiple']);
		$('.minmaxify-multiple').parent().show();
		$('.minmaxify-multfield').val(limits['multiple']);
	}
}

function getShopValue() {
	return Shopify.shop;
}

function onChange() {
	submitText = originalSubmitText;
	var updateText = "Cart needs to be updated";
	
	if (limitsJson['changetext']) {
		if ($.trim(limitsJson['updatetext']) != "") {
			updateText = unescape(limitsJson['updatetext']);
		} else {
			updateText = "Cart needs to be updated";
		}
	}

	$('[name="checkout"]').val(updateText);
	
	errorMessage = 'Cart contents have changed, you must click "Update quantities" before proceeding.';
	isValid = false;
}

function setChangeListener() {
	$('input[name^="updates["]').change(function(){onChange();})
}

getLimits();