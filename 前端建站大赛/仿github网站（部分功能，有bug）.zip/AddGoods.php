<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>github:shop</title>
  <link href="css/shopstyle.css" rel="stylesheet" type="text/css" media="all">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  <link rel="icon" type="image/x-icon" href="img/favicon.ico">
  <link href="css/github-0f5611c27a5a2a6928dc6e99d63581265b963e34.css" media="all" rel="stylesheet" type="text/css">
  <link href="css/github2-6102d7944435d804d870f38bf20f1e16fe40a4d0.css" media="all" rel="stylesheet" type="text/css">
  <script type="text/javascript" async="" src="js/shopify_stats.js"></script>
  <script type="text/javascript" async="" src="js/limit-1_6.js"></script>
  <script type="text/javascript" async="" src="js/298_1339695471.js"></script>
  <script type="text/javascript" async="" id="gauges-tracker" data-site-id="4f299d38f5a1f5302d000003" src="js/track.js"></script>
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/option_selection.js" type="text/javascript"></script>
  <style type="text/css">
  #PicturePreview{
  width: 400px;
  height: 500px;
  margin-left: 50px;
  float: left;
  border:#696262 solid 2px;
  }
  </style>
</head>

<body id="page-index" screen_capture_injected="true">

  <div id="header-wrapper">
    <div id="header">
      <div>
        <a class="logo" href="shop.php"><img src="img/shop-logo.png" height="45"></a>
        <ul class="nav">
          <li><a href="index.php">Back to GitHub</a></li>
        </ul>
      </div>
    </div><!-- #header -->
  </div><!-- #header-wrapper -->

  <div id="wrapper">
  <hr>
    <div class="sub-head">
      <div class="breadcrumbs">
        <span><a href="shop.php">shop</a></span> / <span>Welcome</span>
      </div>
      <ul class="sub-nav">
        <li class="btn about"><a href="404.php"><span>&nbsp;</span>About Us</a></li>
        <li class="btn about"><a href="404.php"><span>&nbsp;</span>FAQ</a></li>
        <li class="btn terms"><a href="404.php"><span>&nbsp;</span>Terms &amp; Conditions</a></li>
        <li class="btn policy"><a href="404.php"><span>&nbsp;</span>Store Policy</a></li>
        <li class="cart"><span>0</span><a href="mycart.php" id="btn_cart">View Cart</a></li><!--turn to mycart-->
      </ul>
    </div>
    
    <div class="content">
      <form accept-charset="UTF-8" action="action.php?action=add" autocomplete="off" method="post" enctype="multipart/form-data" target="_self" onsubmit="return docheck()" name="reg">
        <div style="margin:0;padding:0;display:inline">
          <input name="authenticity_token" type="hidden" value="Rcdhc2nTlv38jliTa+dmk543WHixlWsb9SJAxGY68MY=">
        </div>
        <dl class="form">
          <dt class="input-label">Name</dt>
          <dd><input id="form_name" name="UserName" size="30" type="text" placeholder="Please Put In its Name"></dd>
        </dl>
        <dl class="form">
          <dt class="input-label">
          Typeid
            <select name="typeid">
              <?php
                include("dbconfig.php");
                foreach($typelist as $k=>$v){
                  echo "<option value='{$k}'>{$v}</option>";
                }
              ?>
            </select>
          </dt>
        </dl>
        <dl class="form">
          <dt class="input-label">Price</dt>
          <dd><input class="js-contact-documentation-suggestions" id="form_subject" name="Price" size="30" type="text" placeholder="Please Put In its price"></dd>
        </dl>
        <dl class="form">
          <dt class="input-label">Total</dt>
          <dd><input class="js-contact-documentation-suggestions" id="form_subject" name="Total" size="30" type="text" placeholder="Please Put In its total"></dd>
        </dl>
        <dl class="form">
          <dt class="input-label">Picture</dt>
          <dd><input class="js-contact-documentation-suggestions" id="form_subject" name="Pic" size="30" type="file" placeholder="Please Put In its picture"></dd>
        </dl>
        <dl class="form">
          <dt><label for="form_body">Note</label></dt>
          <dd>
            <textarea class="js-comment-field" id="form_comments" name="Note" placeholder="Please briefly describe the functions and features of goods" required="true"></textarea>
          </dd>
        </dl>
        <div class="form-actions">
          <button type="submit" class="button" name="sub">Add</button>
        </div>
      </form>
    </div>
    <div id="PicturePreview">
      <img src="img/PicturePreview.jpg" width="100%" heigh="100%"><!--在左侧面板添加的图片在这里进行预览-->
    </div><!-- /.column.sidebar -->
  </div><!-- #wrapper -->

  <hr>

  <div id="footer-wrapper">
    <div id="footer">
      <div class="lower_footer">
        <div class="footer_inner clearfix">
            <div id="legal">
              <ul id="legal_links">
                <li><a href="404.php">About Us</a></li>
                <li><a href="404.php">FAQ</a></li>
                <li><a href="404.php">Terms &amp; Conditions</a></li>
                <li><a href="404.php">Store Policy</a></li>
              </ul>
              <p>© <span id="year">2013</span> GitHub Inc. All rights reserved.</p>
            </div><!-- /#legal or /#legal_ie-->
            <div class="sponsor">
              Powered by the fine folks at <a href="404.php">Shopify</a><br>
              You should try them out. No, really.
          </div>
        </div><!-- /.footer_inner -->
      </div><!-- /.lower_footer -->
    </div><!-- #footer -->
  </div><!-- #footer-wrapper -->
</body>
</html>