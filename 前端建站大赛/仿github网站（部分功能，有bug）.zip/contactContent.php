<?php
	session_start();
	
	require("dbconfig.php");
	
	// $link = mysql_connect(HOST,USER,PASS) or die("SQL die");
	$link = mysqli_connect(HOST,USER,PASS,DBNAME) or die("Error " . mysqli_error($link));
	// mysql_select_db(DBNAME,$link);

	$query = "SELECT count(*) FROM contact";
	$num = mysqli_fetch_array($link->query($query)); 
	
	// $num = mysql_fetch_assoc(mysql_query("SELECT count(*) FROM contact"));
	$start = 0;
	if($num['count(*)']>4){
		$inputNum = ceil($num['count(*)']/4);
		if($_GET['page']>1){
			$start = ($_GET['page']-1)*4;
		}

		$sql = "SELECT id,UserName,Email,Subject,Body,addtime FROM contact LIMIT {$start} ,4";

		$res = $link->query($sql);
		while($row = mysqli_fetch_array($res)){
			$list[] = $row;
		}

	}
	include("ViewContent.php");
	
?>