<html>
<head>
	<META content="text/html; charset=utf-8" http-equiv=Content-Type>
	<link href="img/favicon.ico" type="image/x-icon" rel="shortcut  icon" /> 
	<title>GitHub</title>
</head>
<body>
<?php
error_reporting(0);
$mysql_servername = "localhost"; //主机地址
$mysql_username = "root"; //数据库用户名
$mysql_password =""; //数据库密码
$mysql_database ="github"; //数据库
$con = mysql_connect($mysql_servername , $mysql_username , $mysql_password);
mysql_select_db($mysql_database); 
$Email=$_POST['Email'];
$UserPassword=$_POST['UserPassword'];

if ($Email && $UserPassword){
	$sql = "SELECT Email FROM customs WHERE Email = '$Email' and UserPassword = '$UserPassword'";
	$res = mysql_query($sql);
	$row = mysql_fetch_assoc($res);
	if($row['Email']==$Email){
		session_start();
		$_SESSION['Email']=$Email;
		echo "<script>alert('Congratulations on your successful landing!')</script>";
		echo "<script>window.location.href='index.php'</script>";
	}
	else{
		echo "<script>alert('Sorry, the user you entered does not exist! Please log in again!')</script>";
		echo "<script>window.location.href='login.php'</script>";
	}
	//session_destroy();
}
?>
</body>
</html>