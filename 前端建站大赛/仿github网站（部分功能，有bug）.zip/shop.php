<?php
	session_start();
	
	require("dbconfig.php");
	
	$link = mysqli_connect('localhost','root','','github') or die("SQL die");
	// mysql_select_db(DBNAME,$link);
	$num = mysqli_fetch_assoc(mysqli_query("SELECT count(*) FROM goods"));
	$start = 0;
	if($num['count(*)']>3){
		$inputNum = ceil($num['count(*)']/3);
		if($_GET['page']>1){
			$start = ($_GET['page']-1)*3;
		}
	}
	
	$sql = "SELECT id,UserName,Typeid,Price,Total,Pic,Note,addtime FROM goods LIMIT {$start} ,3";

	$res = mysqli_query($link,$sql);
	while($row = mysqli_fetch_assoc($res)){
		$lists[] = $row;
	}
	include("showgoods.php");
?>