<?php 
  session_start();
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>GitHub</title>
    <link rel="icon" type="image/x-icon" href="img/favicon.ico">
    <link href="css/github-0f5611c27a5a2a6928dc6e99d63581265b963e34.css" media="all" rel="stylesheet" type="text/css">
    <link href="css/github2-6102d7944435d804d870f38bf20f1e16fe40a4d0.css" media="all" rel="stylesheet" type="text/css">
    <link type="text/css" rel="stylesheet" href="css/style.css">
    <script language="javascript"> 
      function IsDigit(cCheck) 
      { 
      return (('0'<=cCheck) && (cCheck<='9')); 
      } 

      function IsAlpha(cCheck) 
      { 
      return ((('a'<=cCheck) && (cCheck<='z')) || (('A'<=cCheck) && (cCheck<='Z'))) 
      } 

      function IsValid() 
      { 
      var struserName = reg.UserName.value; 
      for (nIndex=0; nIndex<struserName.length; nIndex++) 
      { 
      cCheck = struserName.charAt(nIndex); 
      if (!(IsDigit(cCheck) || IsAlpha(cCheck))) 
      { 
      return false; 
      } 
      } 
      return true; 
      } 
      function chkEmail(str) 
      { 
      return str.search(/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/)==0?true:false 
      }

      function docheck() 
      { 
        if(reg.UserName.value=="") 
        { 
          alert("Please fill in your name"); 
          return false; 
        } 
        else if(!IsValid()) 
        { 
          alert("Username English only"); 
          return false; 
        }
        else if(reg.UserPassword.value=="") 
        { 
        alert("Please fill in your password"); 
        return false; 
        }
        else if(reg.Email.value =="") 
        { 
          alert("Please fill in the mailbox"); 
          return false; 
        } 
        else if(!chkEmail(reg.Email.value)) 
        { 
          alert("Please enter a valid Email address"); 
          return false; 
        }
        else 
        { 
        return true; 
        } 
      } 
    </script>
</head>

<body class="logged_out  env-production windows  homepage" style="" screen_capture_injected="true">
    <div class="wrapper">
      <div class="header header-logged-out">
        <div class="container clearfix">
          <a class="header-logo-wordmark" href="index.php">
            <span class="mega-octicon octicon-logo-github"><b>GitHub</b></span>
          </a>
            <?php
              include ("session.php");
            ?>
          <div class="command-bar js-command-bar  ">
            <ul class="top-nav">
                <li class="explore"><a href="404.php">Explore</a></li>
                <li class="features"><a href="404.php">Features</a></li>
                <li class="enterprise"><a href="404.php">Enterprise</a></li>
                <li class="blog"><a href="404.php">Blog</a></li>
            </ul>
            <form accept-charset="UTF-8" action="404.php" class="command-bar-form" id="top_search_form" method="get">
                <input type="text" data-hotkey="/ s" name="q" id="js-command-bar-field" placeholder="Search or type a command" tabindex="1" autocapitalize="off" />
                <span class="octicon help tooltipped downwards" original-title="Show command bar help">
                  <span class="octicon octicon-question"></span>
                </span>
                <input type="hidden" name="ref" value="cmdform" />
            </form>
          </div>
        </div>
      </div>
      <div class="site clearfix">
        <div id="site-container" class="context-loader-container" data-pjax-container="">
          <div class="marketing-section marketing-section-signup">
            <div class="container"><!--首页登录页面-->
              <form accept-charset="UTF-8" action="actionregist.php?action=add" autocomplete="off" class="form-signup-home js-form-signup-home" method="post" enctype="multipart/form-data" enctype="multipart/form-data" target="_self" onsubmit="return docheck()" name="reg">
                <div style="margin:0;padding:0;display:inline">
                  <input name="authenticity_token" type="hidden" value="Rcdhc2nTlv38jliTa+dmk543WHixlWsb9SJAxGY68MY=">
                </div>
                <dl class="form"><!--首页登录用户名-->
                  <dd>
                    <input type="text" name="UserName" class="textfield" placeholder="Pick a username"/>
                  </dd>
                </dl>
                <dl class="form"><!--首页登录电子邮箱-->
                  <dd>
                    <input type="email" name="Email" class="textfield" placeholder="Your email"/>
                  </dd>
                </dl>
                <dl class="form"><!--首页登录密码-->
                  <dd>
                    <input type="password" name="UserPassword" class="textfield" placeholder="Create a password"/>
                  </dd>
                  <p class="text-muted">Use at least one lowercase letter, one numeral, and seven characters.</p>
                </dl>
                <input type="hidden" name="source_label" value="Homepage Form">
                  <button class="button primary button-block" type="submit" name="sub">Sign up for GitHub</button>
                  <p class="text-muted">
                    By clicking "Sign up for GitHub", you agree to our
                    <a href="404.php" target="_blank">terms of service</a> and
                    <a href="404.php" target="_blank">privacy policy</a>.
                  </p>
              </form>
              <h1 class="heading">Build software better, together.</h1>
              <p class="subheading">Powerful collaboration, code review, and code management for open source and private projects. Need private repositories? <a href="404.php">Upgraded plans start at $7/mo.</a></p>
            </div><!-- /.container -->
            <div class="marketing-section-depth"></div>
          </div><!-- /.jumbotron -->
          <div class="marketing-section marketing-benefits">
            <div class="container">
              <div class="marketing-header">
                <h1>You’ll love GitHub.</h1>
              </div>
            </div><!-- /.container -->
          </div><!-- /.marketing-section -->
        </div>
      </div>
    </div>

<!--页尾-->
<hr width="100%" color="#fff" />
<div class="container">
  <div class="site-footer">
    <ul class="site-footer-links right">
      <li><a href="404.php">Status</a></li>
      <li><a href="404.php">API</a></li>
      <li><a href="404.php">Training</a></li>
      <li><a href="shop.php">Shop</a></li>
      <li><a href="404.php">Blog</a></li>
      <li><a href="404.php">About</a></li>
    </ul>
    <ul class="site-footer-links">
      <li>© 2013 <span title="index.php">GitHub</span>, Inc.</li>
      <li><a href="404.php">Terms</a></li>
      <li><a href="404.php">Privacy</a></li>
      <li><a href="404.php">Security</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="contactContent.php">Content</a></li>
    </ul>
  </div><!-- /.site-footer -->
</div><!-- /.container -->
</body>
</html>
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1253185465'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s13.cnzz.com/z_stat.php%3Fid%3D1253185465%26online%3D1%26show%3Dline' type='text/javascript'%3E%3C/script%3E"));</script>