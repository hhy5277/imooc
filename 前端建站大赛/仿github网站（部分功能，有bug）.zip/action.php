<?php
//执行商品信息的增、删、改的操作
//一、导入配置文件和函数库文件
	require("dbconfig.php");
	require("functions.php");

//二、连接MySQL，选择数据库
	$link = mysql_connect(HOST,USER,PASS) or die("SQL die");
	mysql_select_db(DBNAME,$link);


//三、获取action参数的值，并做对应的操作
	switch($_GET["action"]){
		case "add": //添加
			//1. 获取添加信息
			$UserName 	= $_POST["UserName"];
			$Typeid = $_POST["Typeid"];
			$Price 	= $_POST["Price"];
			$Total 	= $_POST["Total"];
			$Note 	= $_POST["Note"];
			$addtime = time();
			//2. 验证()省略
			/*if(!$UserName){
				echo ("<script>alert('UserName can't be empty !')</script>");
				echo ("<script>window.location.href='AddGoods.php'</script>");
			}
			else if(!$Typeid){
				echo ("<script>alert('Typeid can't be empty !')</script>");
				echo ("<script>window.location.href='AddGoods.php'</script>");
			}
			else if(!$Price){
				echo("<script>alert('Price can't be empty !')</script>");
				echo ("<script>window.location.href='AddGoods.php'</script>");
			}
			else if(!$Total){
				echo ("<script>alert('Total can't be empty !')</script>");
				echo ("<script>window.location.href='AddGoods.php'</script>");
			}
			else if(!$Note){
				echo ("<script>alert('Note can't be empty !')</script>");
				echo ("<script>window.location.href='AddGoods.php'</script>");
			}*/
			//3. 执行图片上传
			$upinfo = uploadFile("Pic","uploads/");
			if($upinfo["error"]===false){
				die("Photos upload failed：".$upinfo["info"]);
			}else{
				//上传成功
				$Pic = $upinfo[info];// 获取上传成功的图片名
			}
			//4. 执行图片缩放
			imageUpdateSize('uploads/'.$Pic,412,310);
			
			//5. 拼装sql语句，并执行添加
			$sql = "insert into goods values(null,'{$UserName}','{$Typeid}',{$Price},{$Total},'{$Pic}','{$Note}',{$addtime})";
			//echo $sql;
			$res=mysql_query($sql,$link);
			
			$count = mysql_affected_rows();
			//6. 判断并输出结果
			if($count>0){
				echo "<script>alert('Comments successful !')</script>";
				echo "<script>window.location.href='shop.php'</script>";
			}
			else{
				echo "<script>alert('Comments failure !')</script>".$sql();
				echo "<script>window.location.href='shop.php'</script>";
			}
			break;
		
		case "del": //删除
			//获取要删除的id号并拼装删除sql，执行
			$sql = "delete from goods where id={$_GET['id']}";
			mysql_query($sql,$link);
			//执行图片删除
			if(mysql_affected_rows($link)>0){
				@unlink("uploads/".$_GET['Picname']);
				@unlink("uploads/s_".$_GET['Picname']);
			}
			//跳转到浏览界面
			echo "<script>window.location.href='shop.php'</script>";
			break;
			
			
		case "update": //修改
			//1. 获取要修改的信息
			$UserName 	= $_POST["UserName"];
			$Typeid = $_POST["Typeid"];
			$Price 	= $_POST["Price"];
			$Total 	= $_POST["Total"];
			$Note 	= $_POST["Note"];
			$id = $_POST['id'];
			$Pic = $_POST['oldPic'];
			//2. 数据验证
			if(!$UserName){
				echo ("<script>alert('UserName can't be empty !')</script>");
				echo ("<script>window.location.href='AddGoods.php'</script>");
			}
			else if(!$Typeid){
				echo ("<script>alert('Typeid can't be empty !')</script>");
				echo ("<script>window.location.href='AddGoods.php'</script>");
			}
			else if(!$Price){
				echo("<script>alert('Price can't be empty !')</script>");
				echo ("<script>window.location.href='AddGoods.php'</script>");
			}
			else if(!$Total){
				echo ("<script>alert('Total can't be empty !')</script>");
				echo ("<script>window.location.href='AddGoods.php'</script>");
			}
			else if(!$Note){
				echo ("<script>alert('Note can't be empty !')</script>");
				echo ("<script>window.location.href='AddGoods.php'</script>");
			}
			
			//3. 判断有无图片上传
			if($_FILES['Pic']['error']!=4){
				//执行上传
				$upinfo = uploadFile("Pic","uploads/");
				if($upinfo["error"]===false){
					die("Photos upload failed：".$upinfo["info"]);
				}else{
					//上传成功
					$Pic = $upinfo[info];// 获取上传成功的图片名
					//4. 有图片上传，执行缩放
					imageUpdateSize('uploads/'.$Pic,424,310);//显示图片缩略图大小
				}
			
			}
			
			//5. 执行修改
			$sql = "update goods set UserName='{$UserName}',Typeid={$Typeid},Price={$Price},Total={$Total},Note='{$Note}',Pic='{$Pic}' where id={$id}";
			//echo $sql;
			mysql_query($sql,$link);
			
			//6. 判断是否修改成功
			if(mysql_affected_rows($link)>0){
				//若有图片上传，就删除老图片
				if($_FILES['Pic']['error']!=4){
					@unlink("uploads/".$_POST['oldPic']);
					@unlink("uploads/s_".$_POST['oldPic']);
				}
				echo "change successful ";
				echo "<script>window.location.href='shop.php'</script>";
			}else{
				echo "change failed".mysql_error();
				echo "<script>window.location.href='shop.php'</script>";
			}
			break;

	}

//四、关闭数据库
mysql_close($link);
?>