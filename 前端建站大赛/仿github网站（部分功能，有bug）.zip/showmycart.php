<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>github:shop.mycart</title>
  <link href="css/mycartstyle.css" rel="stylesheet" type="text/css" media="all">
  <script type="text/javascript" async="" src="js/shopify_stats.js"></script>
  <script type="text/javascript" async="" src="js/limit-1_6.js"></script>
  <script type="text/javascript" async="" src="js/298_1339695471.js"></script>
  <script type="text/javascript" async="" id="gauges-tracker" data-site-id="4f299d38f5a1f5302d000003" src="js/track.js"></script>
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/option_selection.js" type="text/javascript"></script>
</head>

<body id="page-cart" screen_capture_injected="true">
  <div id="header-wrapper">
    <div id="header">
      <div>
        <a class="logo" href="index.php"><img src="img/shop-logo.png" height="45"></a>
        <ul class="nav">
          <li><a href="index.php">Back to GitHub</a></li>
        </ul>
      </div>
    </div><!-- #header -->
  </div><!-- #header-wrapper -->

  <div id="wrapper">
    <div class="sub-head">
      <div class="breadcrumbs">
        <span><a href="shop.php">shop</a></span> / <span>Welcome</span>
      </div>
      <ul class="sub-nav">
        <li class="btn about"><a href="404.php"><span>&nbsp;</span>About Us</a></li>
        <li class="btn about"><a href="404.php"><span>&nbsp;</span>FAQ</a></li>
        <li class="btn terms"><a href="404.php"><span>&nbsp;</span>Terms &amp; Conditions</a></li>
        <li class="btn policy"><a href="404.php"><span>&nbsp;</span>Store Policy</a></li>
        <li class="cart"><span>0</span><a href="mycart.php" id="btn_cart">View Cart</a></li><!--turn to mycart-->
      </ul>
    </div>
    <div class="content">
      <script type="text/javascript">
        function remove_item(id) {
            document.getElementById('updates_'+id).value = 0;
            document.getElementById('cartform').submit();
        }
        function go() {
          document.getElementById('cartform').submit();
        }
      </script>
      <form action="addCart.php" method="post" id="cartform" name="cartform">
        <div id="cart" class="cart">
          <div class="shell">
            <div class="header">
              <span class="icon icon-cart">&nbsp;</span>
              <h3>Cart</h3>
              <a href="shop.php" class="continue"><span class="icon">&nbsp;</span>continue shopping</a>
            </div>
            <div id="cart_items">
              <table>
                <tbody>
                  <?php
                      $sum = 0;//定义总金额的变量
                      //$rest="SELECT * FROM contact WHERE Email='$Email'"
                        foreach($listss as $v){
                          echo "<tr>
                                  <td class='img'>
                                    <img src='uploads/s_{$v['Pic']}' alt='{$v['Note']}'>
                                  </td>
                                  <td>
                                    <h4 class='product-name'>Contribution Graph Shirt - Mens Small</h4>
                                      <p class='product-variant'>Mens Small</p>
                                  </td>
                                  <td class='qty'>
                                    <div>
                                      <span class='product-price'>{$v['Price']}<span class='mult'>x</span>{$v['num']}'</span>
                                      <a href='clearCart.php?id={$v['id']}' class='remove'>Remove</a>
                                    </div>
                                  <span style='color:red;font-size:large;' title=''>*</span>
                                  </td>
                                </tr>";
                        }
                  ?>
                  <tr class="update">
                    <td colspan="3">
                      Added items? <a href="updateCart.php?id={$v['id']}&num=1" id="btn-update">Update Cart</a>
                    </td>
                  </tr>
                  <tr class="footer">
                    <td colspan="3">
                      <div>
                        <span class="price"><span class="label">Total $</span>
                        <?php 
                          $sum+=$v["Price"]*$v['num'];
                          echo "$sum";
                        ?>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div> <!-- /# cart_items -->
          </div> <!-- /#shell -->
        </div> <!-- /#cart -->
        <div class="alternative-payment-method">
          <h3>Prefer Paypal?</h3>
          <p>Checkout with Paypal using the button below.</p>
          <input type="image" name="goto_pp" value="paypal_express" src="img/btn_xpressCheckoutsm.gif">
      </div>
    </form>
  </div>
</div><!-- #wrapper -->

<!--页尾-->
<hr width="100%" color="#fafafa" heigh="4px">
  <div id="footer-wrapper">
    <div id="footer">
      <div class="lower_footer">
        <div class="footer_inner clearfix">
            <div id="legal">
              <ul id="legal_links">
                <li><a href="404.php">About Us</a></li>
                <li><a href="404.php">FAQ</a></li>
                <li><a href="404.php">Terms &amp; Conditions</a></li>
                <li><a href="404.php">Store Policy</a></li>
              </ul>
              <p>© <span id="year">2013</span> GitHub Inc. All rights reserved.</p>
            </div><!-- /#legal or /#legal_ie-->
            <div class="sponsor">
              Powered by the fine folks at <a href="404.php">Shopify</a><br>
              You should try them out. No, really.
          </div>
        </div><!-- /.footer_inner -->
      </div><!-- /.lower_footer -->
    </div><!-- #footer -->
  </div><!-- #footer-wrapper -->
</body>
</html>