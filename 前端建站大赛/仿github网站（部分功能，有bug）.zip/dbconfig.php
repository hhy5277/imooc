<?php
define("HOST","localhost");
define("USER","root");
define("PASS","");
define("DBNAME","github");

$typelist = array(1=>"Apparel",2=>"Toy",3=>"Accessories",4=>"Others");
?> 