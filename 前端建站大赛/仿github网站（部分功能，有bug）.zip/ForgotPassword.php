<?php 
  session_start();
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Forgot your password? </title>
    <meta property="og:image" content="img/Octocat.png">
    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="/sessions/forgot_password" data-pjax-transient=""><!--忘记密码session记录-->
    <link rel="icon" type="image/x-icon" href="img/favicon.ico">
    <link href="css/github-0f5611c27a5a2a6928dc6e99d63581265b963e34.css" media="all" rel="stylesheet" type="text/css">
    <link href="css/github2-6102d7944435d804d870f38bf20f1e16fe40a4d0.css" media="all" rel="stylesheet" type="text/css">
</head>

<body class="logged_out  env-production windows" style="" screen_capture_injected="true">
<div class="wrapper">
  <div class="header header-logged-out">
    <div class="container clearfix">
      <a class="header-logo-wordmark" href="index.php">
        <span class="mega-octicon octicon-logo-github"><b>GitHub</b></span>
      </a>
      <?php
        include ("session.php");
      ?>
      <div class="command-bar js-command-bar  ">
        <ul class="top-nav">
          <li class="explore"><a href="404.php">Explore</a></li>
          <li class="features"><a href="404.php">Features</a></li>
          <li class="enterprise"><a href="404.php">Enterprise</a></li>
          <li class="blog"><a href="404.php">Blog</a></li>
        </ul>
        <form accept-charset="UTF-8" action="404.php" class="command-bar-form" id="top_search_form" method="get">
          <input type="text" data-hotkey="/ s" name="q" id="js-command-bar-field" placeholder="Search or type a command" tabindex="1" autocapitalize="off" />
          <span class="octicon help tooltipped downwards" original-title="Show command bar help">
            <span class="octicon octicon-question"></span>
          </span>
          <input type="hidden" name="ref" value="cmdform" />
        </form>
      </div>
    </div>
  </div>
  <div class="site clearfix">
    <div id="site-container" class="context-loader-container" data-pjax-container="">
      <div class="auth-form">
        <form accept-charset="UTF-8" action="actionForgotPassword.php" id="forgot_password_form" method="post">
          <div style="margin:0;padding:0;display:inline">
            <input name="authenticity_token" type="hidden" value="/lU/ucrDIKvYPsP55C3PLFWH305MKD4XiqRp+R69WRw=">
          </div>
          <div class="auth-form-header">
            <h1>Forgot password</h1>
          </div>
          <div class="auth-form-body">
            <label for="email_field">Email</label>
            <input autofocus="autofocus" class="input-block" id="email_field" name="email" type="text" value="">
            <input name="commit" type="submit" value="Submit" class="button">
          </div>
        </form>
      </div>
    </div>
    <div class="modal-backdrop"></div>
  </div>
</div><!-- /.wrapper -->

<!--页尾-->
<hr width="100%" color="#fff" />
<div class="container">
  <div class="site-footer">
    <ul class="site-footer-links right">
      <li><a href="404.php">Status</a></li>
      <li><a href="404.php">API</a></li>
      <li><a href="404.php">Training</a></li>
      <li><a href="shop.php">Shop</a></li>
      <li><a href="404.php">Blog</a></li>
      <li><a href="404.php">About</a></li>
    </ul>
    <ul class="site-footer-links">
      <li>© 2013 <span title="index.php">GitHub</span>, Inc.</li>
      <li><a href="404.php">Terms</a></li>
      <li><a href="404.php">Privacy</a></li>
      <li><a href="404.php">Security</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="contactContent.php">Content</a></li>
    </ul>
  </div><!-- /.site-footer -->
</div><!-- /.container -->
</body>
</html>