<?php 
	session_start();//启动会话
?>
<html>
<head>
	<title>Addcart github . GitHub</title>
	<META content="text/html; charset=utf-8" http-equiv=Content-Type>
	<!--<meta http-equiv="Refresh" content="5; URL=myCart.php" />-->
	<link href="img/favicon.ico" type="image/x-icon" rel="shortcut  icon" />
</head>

<body>
<?php
//从数据库中读取要购买的信息并添加到购物车
//1.导入配置文件 
require("dbconfig.php");
//2. 连接数据库，并选择数据库
$link = @mysql_connect(HOST,USER,PASS)or die("SQL die");
mysql_select_db(DBNAME,$link);
//3. 执行商品信息查询（获取要购买的信息）
$sql = "select * from goods where id={$_GET['id']}";
$result = mysql_query($sql,$link);
//4. 判断是否没有找到要购买的信息,若有就读取出要购买的信息
if(empty($result) || mysql_num_rows($result)==0){
	die("Did not find the information you want to buy goods!");
}
else{
	$shop = mysql_fetch_assoc($result);
}
$shop["num"]=1;//添加一个数量的字段	
//5.放入购物车中（若已存在的商品实现数量累加）
if(isset($_SESSION[Email][$shop['id']])){
	//若存在数量加加
	$_SESSION[Email][$shop['id']]["num"]++;
}
else{
	//若不存在，作为新购买的商品添加到购物车中
	$_SESSION[Email][$shop['id']]=$shop;
}
?>
</body>
</html>