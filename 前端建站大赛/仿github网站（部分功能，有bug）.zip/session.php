<?php
if(!array_key_exists("Email",$_SESSION))
{
 echo("<div class='header-actions'><a class='button primary' href='regist.php'>Regist</a></div>
        <div class='header-actions'><a class='button signin' href='login.php'>Login</a></div>");
}else{
  $rest1 = substr($_SESSION['Email'],0,1);
  $rest2 = substr($_SESSION['Email'],-2);
  echo "<div class='header-actions'><a href='#' class='button signin'>$rest1...$rest2</a></div>";
  echo "<div class='header-actions'><a href='session_destroy.php' class='button Logout'>Logout</a></div>";
  //session_destroy("<div class='header-actions'><a class='button Logout'>Logout</a></div>");
}
?>