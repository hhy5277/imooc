<?php 
  session_start();
?>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Join GitHub · GitHub</title>
  <meta name="msapplication-TileImage" content="/windows-tile.png">
  <meta name="msapplication-TileColor" content="#ffffff">
  <link rel="icon" type="image/x-icon" href="img/favicon.ico">
  <link href="css/github-0f5611c27a5a2a6928dc6e99d63581265b963e34.css" media="all" rel="stylesheet" type="text/css">
  <link href="css/github2-6102d7944435d804d870f38bf20f1e16fe40a4d0.css" media="all" rel="stylesheet" type="text/css">
  <script language="javascript"> 
    function IsDigit(cCheck) 
    { 
    return (('0'<=cCheck) && (cCheck<='9')); 
    } 

    function IsAlpha(cCheck) 
    { 
    return ((('a'<=cCheck) && (cCheck<='z')) || (('A'<=cCheck) && (cCheck<='Z'))) 
    } 

    function IsValid() 
    { 
    var struserName = reg.UserName.value; 
    for (nIndex=0; nIndex<struserName.length; nIndex++) 
    { 
    cCheck = struserName.charAt(nIndex); 
    if (!(IsDigit(cCheck) || IsAlpha(cCheck))) 
    { 
    return false; 
    } 
    } 
    return true; 
    } 
    function chkEmail(str) 
    { 
    return str.search(/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/)==0?true:false 
    }
    function docheck() 
    { 
    if(reg.UserName.value=="") 
        { 
          alert("Please fill in your name"); 
          return false; 
        } 
        else if(!IsValid()) 
        { 
          alert("Username English only"); 
          return false; 
        }
        else if(reg.UserPassword.value=="") 
        { 
        alert("Please fill in your password"); 
        return false; 
        }
        else if(reg.UserPassword.value != reg.CUserPassword.value) 
        { 
          alert("Two passwords do not match"); 
          return false; 
        } 
        else if(reg.Email.value =="") 
        { 
          alert("Please fill in the mailbox"); 
          return false; 
        } 
        else if(!chkEmail(reg.Email.value)) 
        { 
          alert("Please enter a valid Email address"); 
          return false; 
        }
        else 
        { 
          return true; 
        } 
  } 
  </script> 
</head>

<body class="logged_out  env-production windows  signup" style="" screen_capture_injected="true">
<div class="wrapper">
  <div class="header header-logged-out">
    <div class="container clearfix">
      <a class="header-logo-wordmark" href="index.php">
        <span class="mega-octicon octicon-logo-github"><b>GitHub</b></span>
      </a>
      <?php
        include ("session.php");
      ?>
      <div class="command-bar js-command-bar  ">
        <ul class="top-nav">
          <li class="explore"><a href="404.php">Explore</a></li>
          <li class="features"><a href="404.php">Features</a></li>
          <li class="enterprise"><a href="404.php">Enterprise</a></li>
          <li class="blog"><a href="404.php">Blog</a></li>
        </ul>
        <form accept-charset="UTF-8" action="404.php" class="command-bar-form" id="top_search_form" method="get">
          <input type="text" data-hotkey="/ s" name="q" id="js-command-bar-field" placeholder="Search or type a command" tabindex="1" autocapitalize="off" />
          <span class="octicon help tooltipped downwards" original-title="Show command bar help">
            <span class="octicon octicon-question"></span>
          </span>
          <input type="hidden" name="ref" value="cmdform" />
        </form>
      </div>
    </div>
  </div>
  <div class="site clearfix">
    <div id="site-container" class="context-loader-container" data-pjax-container="">
      <div class="setup-wrapper">
        <div class="setup-header setup-org">
          <h1>Join GitHub</h1>
          <p class="lead">The best way to design, build, and ship software.</p>
          <!-- Show steps if user is creating an organiation -->
        </div>
        <div class="setup-main">
          <div class="setup-form-container">
            <noscript>
              &lt;p class="error"&gt;GitHub does not support browsers with JavaScript disabled.&lt;br&gt;
              We promise we'll behave.&lt;/p&gt;
            </noscript>
            <form accept-charset="UTF-8" action="actionregist.php?action=add" autocomplete="off" class="setup-form js-form-signup-detail" id="signup-form" method="post" enctype="multipart/form-data" target="_self" onsubmit="return docheck()" name="reg">
              <div style="margin:0;padding:0;display:inline">
                <input name="authenticity_token" type="hidden" value="Rcdhc2nTlv38jliTa+dmk543WHixlWsb9SJAxGY68MY=">
              </div>
              <h2 class="setup-form-title">
                Create your personal account
              </h2>
              <div class="fieldgroup">
                <div class="fields">
                  <dl class="form">
                    <dt class="input-label">
                      <div class="fieldWithErrors">
                        <label autocapitalize="off" for="user_login" hint="This will be your username — you can enter your organization&#39;s username next" name="UserName">Username
                        </label>
                      </div>
                    </dt>
                    <dd>
                      <div class="fieldWithErrors">
                        <input autocapitalize="off" autofocus="true" id="user_login" name="UserName" size="30" type="text" class="textfield" placeholder="Pick a username">
                      </div>
                      <p class="note">This will be your username — you can enter your organization's username next</p>
                    </dd>
                  </dl>
                  <dl class="form"> 
                    <dt class="input-label">
                      <div class="fieldWithErrors">
                        <label autocapitalize="off" for="user_email" hint="We promise we won't share your email with anyone." name="Email">Email Address</label>
                      </div>
                    </dt> 
                    <dd>
                      <div class="fieldWithErrors">
                       <input autocapitalize="off" id="user_email" size="30" type="text" name="Email" class="textfield" placeholder="We promise we won't share your email with anyone."/>
                      </div>
                      <p class="note">We promise we won't share your email with anyone.</p>
                   </dd>
                  </dl> 
                  <dl class="form"> 
                   <dt class="input-label">
                    <div class="fieldWithErrors">
                     <label data-autocheck-url="/signup_check/password" error="false" for="user_password" hint="Use at least one lowercase letter, one numeral, and seven characters." name="user[password]">Password</label>
                    </div>
                   </dt> 
                   <dd>
                    <div class="fieldWithErrors">
                     <input id="user_password" size="30" type="password" name="UserPassword" class="textfield" placeholder="Use at least one lowercase letter, one numeral, and seven characters."/>
                    </div>
                    <p class="note">Use at least one lowercase letter, one numeral, and seven characters.</p>
                   </dd>
                  </dl> 
                  <dl class="form"> 
                   <dt class="input-label">
                    <div class="fieldWithErrors">
                     <label error="false" for="user_password_confirmation">Confirm your password</label>
                    </div>
                   </dt> 
                   <dd>
                    <div class="fieldWithErrors">
                     <input id="user_password_confirmation" size="30" type="password" name="CUserPassword" placeholder="Confirm your password"/>
                    </div>
                   </dd>
                  </dl>   
                  <input type="hidden" name="source_label" value="Detail Form" /> 
                  <p class="tos-info">By clicking on &quot;Create an account&quot; below, you are agreeing to the <a href="404.php" target="_blank">Terms of Service</a> and the <a href="https://help.github.com/privacy" target="_blank">Privacy Policy</a>.</p> 
                  <div class="form-actions"> 
                   <button type="submit" class="button primary" id="signup_button" data-disable-with="Creating Account…" name="sub">Create an account</button> 
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
        <!-- /.setup-form-container -->  
        <!-- /.setup-main --> 
        <div class="setup-secondary"> 
          <div class="setup-info-module"> 
            <h2>You’ll love GitHub</h2> 
            <ul class="features-list"> 
              <li><strong>Unlimited</strong> collaborators</li> 
              <li><strong>Unlimited</strong> public repositories</li> 
              <li class="list-divider"></li> 
              <li><span class="octicon octicon-check"></span> Great communication</li> 
              <li><span class="octicon octicon-check"></span> Friction-less development</li> 
              <li><span class="octicon octicon-check"></span> Open source community</li> 
            </ul> 
          </div> 
        </div> 
        <!-- /.setup-secondary -->  
        <!-- /.setup-wrapper -->  
        <div class="modal-backdrop"></div>  
        <!-- /.wrapper -->
      </div>
    </div>
  </div>
</div>

<!--页尾-->
<hr width="100%" color="#fff" />
<div class="container">
  <div class="site-footer">
    <ul class="site-footer-links right">
      <li><a href="404.php">Status</a></li>
      <li><a href="404.php">API</a></li>
      <li><a href="404.php">Training</a></li>
      <li><a href="shop.php">Shop</a></li>
      <li><a href="404.php">Blog</a></li>
      <li><a href="404.php">About</a></li>
    </ul>
    <ul class="site-footer-links">
      <li>© 2013 <span title="index.php">GitHub</span>, Inc.</li>
      <li><a href="404.php">Terms</a></li>
      <li><a href="404.php">Privacy</a></li>
      <li><a href="404.php">Security</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="contactContent.php">Content</a></li>
    </ul>
  </div><!-- /.site-footer -->
</div><!-- /.container -->
</body>
</html>