$(function(){
	function init(){
		tabSwitch();
		jumpUrl();
	}
	function tabSwitch(){
		$(document).on('click','.catalog-nav li',function(e){
			var target = $(e.currentTarget);
			$('.catalog-nav li').removeClass('active');
			$(target).addClass('active');
		});
	}
	$(".huaban-share-unit .share-btns .more").mouseover(function(){
		$(".menu").css('display','block');
	});
	$(".huaban-share-unit .share-btns .more").mouseout(function(){
		$(".menu").css('display','none');
	});
    
    $(".catalog-nav>ul>li>a,this").mouseover(function(){
        $(this).next().css("width","100%");
    });
    $(".catalog-nav>ul>li>a,this").mouseout(function(){
        $(this).next().css("width","0");
    });

	var removepowercount = 0;
	function removepower(){
	    if(($("#powerby_sohu .service-wrap-w a").length > 0 
	        && $("#powerby_sohu .service-wrap-w a").html() == '') 
	            || removepowercount >10){
	        return;
	    }
	    removepowercount++;
	    $("#powerby_sohu .service-wrap-w a").html('');
	    setTimeout(removepower,1000);
	}
	
	function jumpUrl() {
		var screenWidth = $(window).width();
		if(screenWidth <= 768){
			window.location.href = "http://m.muzidx.com";
		}
	}
	removepower();
	
	init();

});