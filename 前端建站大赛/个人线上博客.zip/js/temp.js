$(function(){
	$("#preview-contents").css({"width":"860px","margin":"0"});
	$("p").css("text-align","justify");
	var addOutWrap = $("#preview-contents").wrap("<div id='flex' style='display:flex;'></div>");
	var addPre = $("#preview-contents").before("<a href='../diary.html'><img src='../img/back_btn.png' alt='back' style='width:168px;margin:30px;cursor:pointer;'></a>");
});