package com.struts2Login.action;

import com.opensymphony.xwork2.ActionSupport;

/**
 * Created by Super on 2015/5/28.
 */
public class MainAction extends ActionSupport{
    @Override
    public String execute() throws Exception{
        return SUCCESS;
    }
}
