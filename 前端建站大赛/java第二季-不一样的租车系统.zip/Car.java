package com.zuche;

/*
 车              car
 轿车         Salooncar
 客车         Passengercar
 面包车    Minibus
 货车         Truck
 皮卡         Pickup
 商务车    Businesscar

 品牌         carName
 载客量    busload
 载货量    burden
 价格         price
 油耗         oilwear
 车牌号    plateNumber
 编号         number
 */

public class Car {
	private int number;        //编号
	private String carName;    //品牌
	private int busload;    //载客量
	private double burden;     //载货量
	private double oilwear;    //油耗
	private String plateNumber;//车牌号
	private double price;      //价格
	
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public double getBusload() {
		return busload;
	}
	public void setBusload(int busload) {
		this.busload = busload;
	}
	public double getBurden() {
		return burden;
	}
	public void setBurden(double burden) {
		this.burden = burden;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getOilwear() {
		return oilwear;
	}
	public void setOilwear(double oilwear) {
		this.oilwear = oilwear;
	}
	public String getPlateNumber() {
		return plateNumber;
	}
	public void setPlateNumber(String plateNumber) {
		this.plateNumber = plateNumber;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	
}
