package com.zuche;

public class Minibus extends Car {

	// 构造方法
	public Minibus(int number,String carName, int busload, double burden,
			double oilwear, String plateNumber, double price) {
		this.setCarName(carName);
		this.setBusload(busload);
		this.setBurden(burden);
		this.setOilwear(oilwear);
		this.setPlateNumber(plateNumber);
		this.setNumber(number);
		this.setPrice(price);		

	}
}
