<p>/**</p><p>&nbsp;* @ Author: Wing Meng</p><p>&nbsp;* @ Updata: 2015.12.22</p><p>&nbsp;* @ Website: wingmeng.com</p><p>&nbsp;*/</p><p>如有任何使用上的问题、bug，请反馈到我的邮箱：wingmeng@qq.com<br/></p><p>谢谢！</p><p><br/></p><p>Bug fix:&nbsp;</p><p>2015.12.22 增加对滚动图片数量的判断，小于2张不滚动。</p>

