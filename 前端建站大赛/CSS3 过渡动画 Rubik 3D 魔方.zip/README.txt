<p>为了大家下载，样式和脚本全放在了html文件里，所有源码单独放在同级目录下的文件夹里了！</p><p>两个bug</p><p>NO.1&nbsp;&nbsp;&nbsp;&nbsp;div unexpected 拖拽复制;</p><p>NO.2&nbsp;&nbsp;&nbsp;&nbsp;旋转角度累计超过360度的时候会逆向旋转270；(现已修复)</p><p>NO.3&nbsp;&nbsp;&nbsp;&nbsp;连续旋转间隔时间不能太短，否者就╮(╯▽╰)╭，</p><p>图方便，火狐下能运行，自己添加兼容代码好伐</p><p><br/></p>

