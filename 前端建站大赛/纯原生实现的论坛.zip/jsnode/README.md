# jsnode

一个采用node.js服务器的论坛网站

使用了mongodb, redis数据库

使用了nginx做缓存代理服务器

使用了express作为后端框架

前端没有用任何框架

15天完成的，只是一个半成品

访问网址:  http://jsnode.cn    或    http://diujiecao.xyz
