/**
 * Created by xheldon on 15/8/3.
 */
var menu = true;
var self_imessage = true;
$('.menu').on('click',function(e){
    if(menu){
        $('#left-hidden-1').animate({
            'width':'30px'
        },500);
        $('#left-hidden-2').animate({
            'width':'30px'
        },300);
        $('#left-hidden-3').animate({
            'width':'30px'
        },100);
        $('.menu').addClass('menu-change');
        $('.menu-line-1').addClass('menu-line-1-change');
        $('.menu-line-2').addClass('menu-line-2-change');
        $('.menu-line-3').addClass('menu-line-3-change');
        menu = false;
        e.stopPropagation();
    }

});
$('body').on('click',function(){
    $('#left-hidden-1').animate({
        'width':'0px'
    },500);
    $('#left-hidden-2').animate({
        'width':'0px'
    },300);
    $('#left-hidden-3').animate({
        'width':'0px'
    },100);
    $('.menu').removeClass('menu-change');
    $('.menu-line-1').removeClass('menu-line-1-change');
    $('.menu-line-2').removeClass('menu-line-2-change');
    $('.menu-line-3').removeClass('menu-line-3-change');
    menu = true;
});
//$('.menu').on('click',function(){
//    $('#left-hidden-1').animate({
//        'width':'0px'
//    },500);
//    $('#left-hidden-2').animate({
//        'width':'0px'
//    },300);
//    $('#left-hidden-3').animate({
//        'width':'0px'
//    },100);
//    $('.menu').removeClass('menu-change');
//    $('.menu-line-1').removeClass('menu-line-1-change');
//    $('.menu-line-2').removeClass('menu-line-2-change');
//    $('.menu-line-3').removeClass('menu-line-3-change');
//    menu = true;
//});
$('.self-imessage').on('click',function(){
    if(self_imessage){
        $('.model-bg').addClass('model-bg-change');
        $('.model-dialog').addClass('model-dialog-change');
        //本来想用 animate 做关闭按钮
//            $('.dialog-close').animate({
//                width:'30px',
//                height:'30px',
//                borderRadius:'15px',
//                top:'20px',
//                right:'20px',
//            },1000)
        self_imessage = false;
    }
});
$('.dialog-close').on('click',function(){
    $('.model-bg').removeClass('model-bg-change');
    $('.model-dialog').removeClass('model-dialog-change');
//        $('.dialog-close').animate({
//            width:'0px',
//            height:'0px',
//            top:'0px',
//            right:'0px',
//        },1000)
    self_imessage = true;
});