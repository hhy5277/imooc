package com.hcstudio.service;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class HeyClockServiceControl
{
	/**
	 * 获取网络提醒开关状态 -1 表示未设置过
	 * @param context
	 * @return
	 */
	public static int getOpenNetTipFlag(Context context)
	{
		SharedPreferences netSwitch = context.getSharedPreferences("heyclock", 0);
		return netSwitch.getInt("netswitch", -1);
	}
	
	/**
	 * 设置网络提醒开关状态
	 * @param context
	 * @return
	 */
	public static void setOpenNetTipFlag(Context context, int flag)
	{
		SharedPreferences netSwitch = context.getSharedPreferences("heyclock", 0);
		SharedPreferences.Editor editor = netSwitch.edit();
		editor.putInt("netswitch", flag);
		editor.commit();
	}
	
	/**
	 * 获取是否是首次启动
	 * @param context
	 * @return
	 */
	public static int getFirstStartFlag(Context context)
	{
		SharedPreferences netSwitch = context.getSharedPreferences("heyclock", 0);
		return netSwitch.getInt("firststart", -1);
	}
	
	/**
	 * 设置首次启动
	 * @param context
	 * @return
	 */
	public static void setFirstStartFlag(Context context, int flag)
	{
		SharedPreferences netSwitch = context.getSharedPreferences("heyclock", 0);
		SharedPreferences.Editor editor = netSwitch.edit();
		editor.putInt("firststart", flag);
		editor.commit();
	}
	
	/**
	 * 启动网络提醒本地服务
	 * @param context
	 */
    public static void startNetTipService(Context context)
    {
         Intent intent = new Intent(context, HeyClockNetTipLocalService.class);
         context.startService(intent);
    }
    
    /**
	 * 关闭网络提醒本地服务
	 * @param context
	 */
    public static void stopNetTipService(Context context)
    {
         Intent intent = new Intent(context, HeyClockNetTipLocalService.class);
         context.stopService(intent);
    }
}
