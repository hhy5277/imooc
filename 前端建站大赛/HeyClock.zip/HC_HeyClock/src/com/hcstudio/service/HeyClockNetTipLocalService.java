package com.hcstudio.service;

import java.util.Timer;

import com.hcstudio.receiver.HeyClockConnectionChangeReceiver;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Binder;
import android.os.IBinder;

public class HeyClockNetTipLocalService extends Service
{
	/**
	 * 绑定启动服务 - 暂时用不到
	 */
	private IBinder binder = new HeyClockNetTipLocalService.LocalBinder();
	/**
	 * 网络变化监听广播
	 */
	private HeyClockConnectionChangeReceiver mNetworkStateReceiver = new HeyClockConnectionChangeReceiver();  
	@SuppressWarnings("unused")
	///< 预计是用定时器实现网络检测，实际上不需要了，可以通过广播获取网络状态，剩下的就是播放声音的提示了...
	private Timer timer = null; 

	@Override
	public void onCreate() 
	{
		super.onCreate();

		IntentFilter filter = new IntentFilter();  
		filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION); 
		registerReceiver(mNetworkStateReceiver, filter); 

		//		this.onInit();
		//		///< 定时器 
		//		timer.schedule(new TimerTask() 
		//		{  
		//			@Override  
		//			public void run() 
		//			{  
		//				///< TODO
		//			}  
		//		}, 1000, 1000);  
	} 

	//	/** 
	//	 * 相关变量初始化 
	//	 */  
	//	private void onInit()
	//	{  
	//		timer = new Timer();
	//	}  

	//	@Override
	//	@Deprecated
	//	public void onStart(Intent intent, int startId)
	//	{
	//		// TODO Auto-generated method stub
	//		super.onStart(intent, startId);
	//	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		System.out.println("hhh onStartCommand " + flags + " ... " + startId);
		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public IBinder onBind(Intent intent) 
	{
		return binder;
	}

	/**
	 * 定义内容类继承Binder
	 * @author hl
	 *
	 */
	public class LocalBinder extends Binder
	{
		///< 返回本地服务
		HeyClockNetTipLocalService getService()
		{
			return HeyClockNetTipLocalService.this;
		}
	}

	@Override
	public void onDestroy()
	{
		unregisterReceiver(mNetworkStateReceiver);
		//		if (null != timer)
		//		{
		//			timer.cancel();
		//			timer = null;
		//		}
		super.onDestroy();
	}
}
