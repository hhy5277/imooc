package com.hcstudio.adapter;

import com.hcstudio.core.HC_Clock;
import com.hcstudio.core.HC_DbHelper;
import com.hcstudio.heyclock.HeyClockDetailActivity;
import com.hcstudio.heyclock.HeyClockMainActivity;
import com.hcstudio.heyclock.R;
import com.hcstudio.receiver.HeyClockAlarmReceiver;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class HCM_GridviewClickListener implements OnItemClickListener
{
	private Context mContext; 

	public HCM_GridviewClickListener(Context _mContext)
	{
		mContext = _mContext;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) 
	{
		TextView mName = (TextView)view.findViewById(R.id.hcm_grid_name);
		//Toast.makeText(mContext, "name " + mName.getText() + " position " + position + " count " + parent.getCount(), Toast.LENGTH_SHORT).show();
		if (position == (parent.getCount() - 1) && mName.getText().equals("添加闹钟"))
		{
			Intent intent = new Intent();
			intent.setClass(mContext, HeyClockDetailActivity.class);
			///< 顺便把当天天气信息带过去
			intent.putExtra("weatherPng", ((HeyClockMainActivity)mContext).getCurrentWeatherURL());

			mContext.startActivity(intent);
			((Activity) mContext).finish();
			((Activity) mContext).overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
		}
		else
		{
			ImageView mIcon = (ImageView)view.findViewById(R.id.hcm_grid_icon);
			if (0 == ((HCM_GridviewAdapter)parent.getAdapter()).mEnableList.get(position))
			{
				((HCM_GridviewAdapter)parent.getAdapter()).mEnableList.set(position, 1);
				///< set icon   
				mIcon.setBackgroundDrawable(((HCM_GridviewAdapter)parent.getAdapter()).mDrawablePressedList.get(position)); 
				///< 设置宽高 - 需要从适配vallues-xxxx里面去获取尺寸，做适配...
				mIcon.setLayoutParams(new RelativeLayout.LayoutParams(
						((HCM_GridviewAdapter)parent.getAdapter()).itemW, 
						((HCM_GridviewAdapter)parent.getAdapter()).itemW));

				///< 更新数据库信息 - 下次启动的时候便于初始化开启状态
				HC_DbHelper.getInstance(mContext).updateIsOpen(mName.getText().toString().trim(), "1");

				///< 同时设置闹钟
				//				HC_Clock.setClock(mContext, HeyClockAlarmReceiver.class, 
				//						mName.getText().toString().trim(), 
				//						Integer.valueOf(((HCM_GridviewAdapter)parent.getAdapter()).mDateList.get(position).split(" ")[0].split("-")[0]),
				//						Integer.valueOf(((HCM_GridviewAdapter)parent.getAdapter()).mDateList.get(position).split(" ")[0].split("-")[1])-1,
				//						Integer.valueOf(((HCM_GridviewAdapter)parent.getAdapter()).mDateList.get(position).split(" ")[0].split("-")[2]),
				//						Integer.valueOf(((HCM_GridviewAdapter)parent.getAdapter()).mDateList.get(position).split(" ")[1].split(":")[0]),
				//						Integer.valueOf(((HCM_GridviewAdapter)parent.getAdapter()).mDateList.get(position).split(" ")[1].split(":")[1]),
				//						0);
				HC_Clock.setClockBalance(mContext, 
						HeyClockAlarmReceiver.class, 
						mName.getText().toString().trim(), 
						((HCM_GridviewAdapter)parent.getAdapter()).mDateList.get(position));
			}
			else
			{
				((HCM_GridviewAdapter)parent.getAdapter()).mEnableList.set(position, 0);
				///< set icon   
				mIcon.setBackgroundDrawable(((HCM_GridviewAdapter)parent.getAdapter()).mDrawableList.get(position)); 
				///< 设置宽高 - 需要从适配vallues-xxxx里面去获取尺寸，做适配...
				mIcon.setLayoutParams(new RelativeLayout.LayoutParams(
						((HCM_GridviewAdapter)parent.getAdapter()).itemW, 
						((HCM_GridviewAdapter)parent.getAdapter()).itemW));

				///< 更新数据库信息 - 下次启动的时候便于初始化开启状态
				HC_DbHelper.getInstance(mContext).updateIsOpen(mName.getText().toString().trim(), "0");

				///< 同时取消设置闹钟
				HC_Clock.cancelClock(mContext, HeyClockAlarmReceiver.class, mName.getText().toString().trim());
			}
		}
		///< 设置选中项 - 现在没用到
		//((HCM_GridviewAdapter)parent.getAdapter()).setSeclection(position);
		//((HCM_GridviewAdapter)parent.getAdapter()).notifyDataSetChanged();

		//Toast.makeText(mContext, "" + ((HCM_GridviewAdapter)parent.getAdapter()).mEnableList.size(), Toast.LENGTH_SHORT).show();
	}
}
