package com.hcstudio.adapter;

import java.util.List;

import com.hcstudio.core.HC_Screen;
import com.hcstudio.heyclock.R;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class HCM_GridviewPopuGroupAdapter extends BaseAdapter 
{
	private Context context;
	private List<String> list;

	public HCM_GridviewPopuGroupAdapter(Context context, List<String> list)
	{
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount()
	{
		return list.size();
	}

	@Override
	public Object getItem(int position) 
	{

		return list.get(position);
	}

	@Override
	public long getItemId(int position) 
	{
		return position;
	}

	@SuppressLint("InflateParams")
	@Override
	public View getView(int position, View convertView, ViewGroup viewGroup)
	{      
		ViewHolder holder;
		if (null == convertView) 
		{
			convertView = LayoutInflater.from(context).inflate(R.layout.hcm_clock_griv_popu_group_item, null);
			holder = new ViewHolder();
			convertView.setTag(holder);
			holder.groupItem = (TextView) convertView.findViewById(R.id.groupItem);
		}
		else
		{
			holder = (ViewHolder) convertView.getTag();
		}
		
		/*以下为新增部分*/                
		AbsListView.LayoutParams lp = new AbsListView.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT, 
				(int)HC_Screen.REAL_SCREEN_HEIGHT*2/25);
		convertView.setLayoutParams(lp);
		/*以上为新增部分*/
		
		holder.groupItem.setTextColor(Color.BLACK);
		holder.groupItem.setText(list.get(position));
		
		return convertView;
	}

	static class ViewHolder 
	{
		TextView groupItem;
	}
}
