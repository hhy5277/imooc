package com.hcstudio.adapter;

import java.util.ArrayList;

import com.hcstudio.core.HC_Screen;
import com.hcstudio.heyclock.R;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class HCM_GridviewAdapter extends BaseAdapter
{
	@SuppressWarnings("unused")
	private Context mContext; 

	private ArrayList<String> mNameList = new ArrayList<String>(); 
	public ArrayList<String> mDateList = new ArrayList<String>(); 
	public ArrayList<Drawable> mDrawableList = new ArrayList<Drawable>();
	public ArrayList<Drawable> mDrawablePressedList = new ArrayList<Drawable>();
	public ArrayList<Drawable> mDrawableLongPressedList = new ArrayList<Drawable>();
	public ArrayList<Integer> mEnableList = new ArrayList<Integer>();

	@SuppressWarnings("unused")
	private int clickTemp = -1;
	private LayoutInflater mInflater;  
	private LinearLayout.LayoutParams params; 
	@SuppressWarnings("unused")
	private AbsListView.LayoutParams paramConvertView;
	public int itemW;

	public HCM_GridviewAdapter(Context context,
			ArrayList<String> nameList,
			ArrayList<String> dateList, 
			ArrayList<Drawable> drawableList, 
			ArrayList<Drawable> drawablepressedList,
			ArrayList<Drawable> drawableLongpressedList,
			ArrayList<Integer> enableList) 
	{  
		mNameList = nameList;  
		mDateList = dateList;
		mDrawableList = drawableList;
		mDrawablePressedList = drawablepressedList;
		mDrawableLongPressedList = drawableLongpressedList;
		mEnableList = enableList;

		mContext = context;  
		mInflater = LayoutInflater.from(context);  

		params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);  
		params.gravity = Gravity.CENTER;  
		
		itemW = (int) (HC_Screen.REAL_SCREEN_WIDTH - (4 * HC_Screen.Dp2Px(context, 2)))/3;
		paramConvertView = new AbsListView.LayoutParams(itemW, itemW);
	}  

	@Override
	public int getCount()
	{
		return mNameList.size();
	}

	@Override
	public Object getItem(int position) 
	{
		return mNameList.get(position);
	}

	@Override
	public long getItemId(int position) 
	{
		return position;
	}
	
	/**
	 * 标识选中Item
	 * @param position
	 */
	public void setSeclection(int position)
	{
		clickTemp = position;
	}
	
	/**
	 * 删除条目操作
	 * @param position
	 */
	public void remove(int position)
	{
		if (null != mNameList && mNameList.size() > 1)
		{
			mNameList.remove(position);
		}
		if (null != mDateList && mDateList.size() > 1)
		{
			mDateList.remove(position);
		}
		if (null != mDrawableList && mDrawableList.size() > 1)
		{
			mDrawableList.remove(position);
		}
		if (null != mDrawablePressedList && mDrawablePressedList.size() > 1)
		{
			mDrawablePressedList.remove(position);
		}
		if (null != mDrawableLongPressedList && mDrawableLongPressedList.size() > 1)
		{
			mDrawableLongPressedList.remove(position);
		}
		if (null != mEnableList && mEnableList.size() > 1)
		{
			mEnableList.remove(position);
		}
	}

	@SuppressWarnings("deprecation")
	@SuppressLint("InflateParams")
	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		ItemViewTag viewTag;  

		if (convertView == null)  
		{  
			convertView = mInflater.inflate(R.layout.hcm_clock_griv_item, null);  

			///< construct an item tag   
			viewTag = new ItemViewTag((ImageView) convertView.findViewById(R.id.hcm_grid_icon), (TextView) convertView.findViewById(R.id.hcm_grid_name));
			convertView.setTag(viewTag);  
		} 
		else  
		{  
			viewTag = (ItemViewTag) convertView.getTag();  
		}  

		///< set name   
		viewTag.mName.setText(mNameList.get(position));  
		if (position == (mNameList.size() - 1))
		{
			viewTag.mIcon.setBackgroundDrawable(mDrawableList.get(position));
		}
		else
		{
			///< 根据闹钟之前的是否开启，设置是否高亮显示图片
			if (0 == mEnableList.get(position))
			{
				///< set icon   
				viewTag.mIcon.setBackgroundDrawable(mDrawableList.get(position));
			}
			else
			{
				///< set icon   
				viewTag.mIcon.setBackgroundDrawable(mDrawablePressedList.get(position));
			}
		}
		///< 设置宽高 - 需要从适配vallues-xxxx里面去获取尺寸，做适配...
		viewTag.mIcon.setLayoutParams(new RelativeLayout.LayoutParams(itemW, itemW));
		//viewTag.mIcon.setLayoutParams(params); 
		//		viewTag.mName.setBackgroundDrawable(mDrawableList.get(position));
		//		//viewTag.mName.setLayoutParams(params);

		return convertView;  
	}

	class ItemViewTag  
	{  
		protected ImageView mIcon;  
		protected TextView mName;  

		/** 
		 * The constructor to construct a navigation view tag 
		 *  
		 * @param name 
		 *            the name view of the item 
		 * @param size 
		 *            the size view of the item 
		 * @param icon 
		 *            the icon view of the item 
		 */  
		public ItemViewTag(ImageView icon, TextView name)  
		{  
			this.mName = name;  
			this.mIcon = icon;  
		}  
	}  

	public void onDestroy()
	{
		if (null != mNameList)
		{
			mNameList.clear();
			mNameList = null;
		}

		if (null != mDrawableList)
		{
			mDrawableList.clear();
			mDrawableList = null;
		}

		if (null != mDrawablePressedList)
		{
			mDrawablePressedList.clear();
			mDrawablePressedList = null;
		}

		if (null != mEnableList)
		{
			mEnableList.clear();
			mEnableList = null;
		}
	}
}
