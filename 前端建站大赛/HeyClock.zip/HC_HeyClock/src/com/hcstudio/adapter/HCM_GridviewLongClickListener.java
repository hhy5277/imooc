package com.hcstudio.adapter;

import java.util.ArrayList;
import java.util.List;

import com.hcstudio.core.HC_Clock;
import com.hcstudio.core.HC_DbHelper;
import com.hcstudio.core.HC_Screen;
import com.hcstudio.heyclock.HeyClockEditActivity;
import com.hcstudio.heyclock.HeyClockMainActivity;
import com.hcstudio.heyclock.R;
import com.hcstudio.item.HCD_GridviewItem;
import com.hcstudio.receiver.HeyClockAlarmReceiver;
import com.hcstudio.ui.HC_RoundSpinOnItemClickInterface;
import com.hcstudio.ui.HC_RoundSpinView;
import com.hcstudio.ui.HC_RoundSpinView.WHICH_PART;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class HCM_GridviewLongClickListener implements OnItemLongClickListener
{
	/**
	 * 上下文
	 */
	private Context mContext; 

	///< 菜单弹窗
	private HC_RoundSpinView rsv;
	private PopupWindow pop;
	private View view;
	private ListView lv_group;
	private List<String> groups;
	///< 当前选中Icon
	private class CurrentItem
	{
		public ImageView mIcon = null;
		public int flag = -1;
		public int itemW;
		public Drawable drawable;
		public int position;
		public String name;
		public boolean bIsOpen;
	};
	private CurrentItem currentItem = new CurrentItem(); 
	private HCM_GridviewAdapter externHCM_GridviewAdapter = null;

	@SuppressWarnings("unused")
	public HCM_GridviewLongClickListener(Context _mContext)
	{
		mContext = _mContext;
		if (false)	///< 这种效果目前不是很好，暂时抛弃！
		{
			rsv = new HC_RoundSpinView(_mContext,
					-1/*300/2*//*(int)HC_Screen.REAL_SCREEN_WIDTH/2*/, 
					-1/*200/2*//*(int)HC_Screen.REAL_SCREEN_HEIGHT/2*/,
					100,
					0,
					HC_RoundSpinView.WHICH_PART.ALLAREA);

			rsv.setOnItemClickListenner(new HC_RoundSpinOnItemClickInterface() 
			{
				@Override
				public void action(String name, int index) 
				{
					Toast.makeText(mContext, 
							"你点击了  " + name + " " + index,
							Toast.LENGTH_SHORT).show();
				}
			}); 
			// 创建PopupWindow对象 
			pop = new PopupWindow(rsv, rsv.getRWidth(), rsv.getRHeight(), false); 
			// 需要设置一下此参数，点击外边可消失 
			//pop.setBackgroundDrawable(new BitmapDrawable()); 
			pop.setBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.backpop));
			//设置点击窗口外边窗口消失 
			pop.setOutsideTouchable(true); 
			// 设置此参数获得焦点，否则无法点击 
			pop.setFocusable(true);
		}
	}

	@SuppressWarnings({ "unused", "deprecation" })
	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view,
			int position, long id) 
	{
		///< 保存外部适配器 - 本类使用
		externHCM_GridviewAdapter = (HCM_GridviewAdapter)parent.getAdapter();

		TextView mName = (TextView)view.findViewById(R.id.hcm_grid_name);	
		//Toast.makeText(mContext, "name " + mName.getText() + " position " + position + " count " + parent.getCount(), Toast.LENGTH_SHORT).show();
		if (position == (parent.getCount() - 1) && mName.getText().equals("添加闹钟"))
		{

		}
		else
		{
			///< 改变选中的背景
			currentItem.mIcon = (ImageView)view.findViewById(R.id.hcm_grid_icon);
			///< set icon   
			currentItem.mIcon.setBackgroundDrawable(((HCM_GridviewAdapter)parent.getAdapter()).mDrawableLongPressedList.get(position)); 
			///< 设置宽高 - 需要从适配vallues-xxxx里面去获取尺寸，做适配...
			currentItem.mIcon.setLayoutParams(new RelativeLayout.LayoutParams(
					((HCM_GridviewAdapter)parent.getAdapter()).itemW, 
					((HCM_GridviewAdapter)parent.getAdapter()).itemW));

			currentItem.name = mName.getText().toString().trim();
			///< 保存当前选中的条目状态信息 - 便于长按之后恢复
			currentItem.flag = ((HCM_GridviewAdapter)parent.getAdapter()).mEnableList.get(position);
			currentItem.itemW = ((HCM_GridviewAdapter)parent.getAdapter()).itemW;
			if (1 == ((HCM_GridviewAdapter)parent.getAdapter()).mEnableList.get(position))
			{
				currentItem.bIsOpen = true;
				currentItem.drawable = ((HCM_GridviewAdapter)parent.getAdapter()).mDrawablePressedList.get(position);
			}
			else if (0 == ((HCM_GridviewAdapter)parent.getAdapter()).mEnableList.get(position))
			{
				currentItem.bIsOpen = false;
				currentItem.drawable = ((HCM_GridviewAdapter)parent.getAdapter()).mDrawableList.get(position);
			}
			currentItem.position = position;

			///< 长按弹窗
			showWindow(view);

			if (false)	///< 这种效果目前不是很好，暂时抛弃！
			{
				if(pop.isShowing()) 
				{ 
					// 隐藏窗口，如果设置了点击窗口外小时即不需要此方式隐藏 
					pop.dismiss(); 
				} 
				else 
				{ 
					ImageView mIconi = (ImageView)view.findViewById(R.id.hcm_grid_icon);
					int[] location = new int[2];
					mIconi.getLocationOnScreen(location);
					// 显示窗口 
					if (rsv.whichArea.equals(WHICH_PART.LEFTAREA))
					{
						pop.showAtLocation(view, Gravity.NO_GRAVITY, location[0] - rsv.getRWidth(), location[1]);
					}
					else if (rsv.whichArea.equals(WHICH_PART.RIGHTAREA))
					{
						pop.showAtLocation(view, Gravity.NO_GRAVITY, location[0], location[1]);
					}
					else if (rsv.whichArea.equals(WHICH_PART.ALLAREA))
					{
						pop.showAtLocation(view, Gravity.NO_GRAVITY, location[0]- rsv.getRWidth()/2, location[1]- rsv.getHeight()/2);
					}
				} 
			}
			//			ImageView mIcon = (ImageView)view.findViewById(R.id.hcm_grid_icon);
			//			if (0 == ((HCM_GridviewAdapter)parent.getAdapter()).mEnableList.get(position))
			//			{
			//				((HCM_GridviewAdapter)parent.getAdapter()).mEnableList.set(position, 1);
			//				///< set icon   
			//				mIcon.setBackgroundDrawable(((HCM_GridviewAdapter)parent.getAdapter()).mDrawablePressedList.get(position)); 
			//				///< 设置宽高 - 需要从适配vallues-xxxx里面去获取尺寸，做适配...
			//				mIcon.setLayoutParams(new RelativeLayout.LayoutParams(
			//						((HCM_GridviewAdapter)parent.getAdapter()).itemW, 
			//						((HCM_GridviewAdapter)parent.getAdapter()).itemW));
			//			}
			//			else
			//			{
			//				((HCM_GridviewAdapter)parent.getAdapter()).mEnableList.set(position, 0);
			//				///< set icon   
			//				mIcon.setBackgroundDrawable(((HCM_GridviewAdapter)parent.getAdapter()).mDrawableList.get(position)); 
			//				///< 设置宽高 - 需要从适配vallues-xxxx里面去获取尺寸，做适配...
			//				mIcon.setLayoutParams(new RelativeLayout.LayoutParams(
			//						((HCM_GridviewAdapter)parent.getAdapter()).itemW, 
			//						((HCM_GridviewAdapter)parent.getAdapter()).itemW));
			//			}
		}
		///< 设置选中项 - 现在没用到
		//((HCM_GridviewAdapter)parent.getAdapter()).setSeclection(position);
		//((HCM_GridviewAdapter)parent.getAdapter()).notifyDataSetChanged();

		return true;
	}

	/**
	 * Item长按弹窗
	 * @param parent
	 */
	@SuppressWarnings("deprecation")
	@SuppressLint("InflateParams")
	private void showWindow(View parent) 
	{
		if (null == pop) 
		{
			LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			view = layoutInflater.inflate(R.layout.hcm_clock_griv_popu_group_list, null);
			lv_group = (ListView) view.findViewById(R.id.lvGroup);
			///< 加载数据
			groups = new ArrayList<String>();
			groups.add("编辑");
			groups.add("删除");
			groups.add("取消");

			HCM_GridviewPopuGroupAdapter groupAdapter = new HCM_GridviewPopuGroupAdapter(mContext, groups);
			lv_group.setAdapter(groupAdapter);
			///< 创建一个PopuWidow对象
			pop = new PopupWindow(view, 
					(int)HC_Screen.REAL_SCREEN_WIDTH*3/4, 
					(int)HC_Screen.REAL_SCREEN_HEIGHT*1/4);
		}

		///< 使其聚集
		pop.setFocusable(true);
		///< 设置允许在外点击消失
		pop.setOutsideTouchable(true);
		///< 这个是为了点击“返回Back”也能使其消失，并且并不会影响你的背景
		pop.setBackgroundDrawable(new BitmapDrawable());
		///< 设置弹窗动画
		pop.setAnimationStyle(R.style.PopupAnimation);
		//		WindowManager windowManager = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);
		///< 显示的位置为:屏幕的宽度的一半-PopupWindow的高度的一半
		//int xPos = (int) (HC_Screen.REAL_SCREEN_WIDTH / 2 - pop.getWidth() / 2);
		int xPos = (int) (HC_Screen.REAL_SCREEN_WIDTH*3/20)/*(int) (HC_Screen.REAL_SCREEN_WIDTH / 2)*/;
		int yPos = (int) (HC_Screen.REAL_SCREEN_HEIGHT*2/5)/*(int) (HC_Screen.REAL_SCREEN_HEIGHT / 2)*/;
		///< Log.i("coder", "xPos:" + xPos);
		///< 显示位置
		pop.showAtLocation(parent, Gravity.NO_GRAVITY, xPos, yPos);
		//pop.showAsDropDown(parent, xPos, yPos);
		///< 弹窗消失监听事件
		pop.setOnDismissListener(new OnDismissListener() 
		{
			@Override
			public void onDismiss()
			{
				///< 恢复之前的状态
				if (null != currentItem.mIcon && - 1 != currentItem.flag)
				{
					///< set icon   
					currentItem.mIcon.setBackgroundDrawable(currentItem.drawable); 
					///< 设置宽高 - 需要从适配vallues-xxxx里面去获取尺寸，做适配...
					currentItem.mIcon.setLayoutParams(
							new RelativeLayout.LayoutParams(
									currentItem.itemW, 
									currentItem.itemW));
				}
			}
		});
		///< 条目点击事件
		lv_group.setOnItemClickListener(new OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> adapterView, View view,
					int position, long id) 
			{
				//Toast.makeText(mContext, groups.get(position), Toast.LENGTH_SHORT).show();
				TextView mName = (TextView)view.findViewById(R.id.groupItem);


				if (mName.getText().equals("编辑"))
				{
					if (null != pop)
					{
						pop.dismiss();
						pop = null;
					}

					///< 跳转到编辑界面 - 为了代码整洁，就重新开一个页面；
					Cursor cursor = HC_DbHelper.getInstance(mContext).querySingleInf(currentItem.name);
					if (cursor.moveToNext())	///< 理论上只有一个值，不会重复的...
					{
						boolean bIsOpenflag;
						if (1 == Integer.valueOf(cursor.getString(1)))
						{
							bIsOpenflag = true;
						}
						else
						{
							bIsOpenflag = false;
						}
						///< 从数据库获取之前设置的时间，传递到编辑界面
						String currentDate = cursor.getString(0);
						HCD_GridviewItem editTimeIntent = new HCD_GridviewItem(
								Integer.valueOf(currentDate.split(" ")[0].split("-")[0]),
								Integer.valueOf(currentDate.split(" ")[0].split("-")[1]),
								Integer.valueOf(currentDate.split(" ")[0].split("-")[2]),
								Integer.valueOf(currentDate.split(" ")[1].split(":")[0]), 
								Integer.valueOf(currentDate.split(" ")[1].split(":")[1]), 
								currentItem.name,
								null);
						///< 开始做跳转...
						Intent intent = new Intent();
						intent.setClass(mContext, HeyClockEditActivity.class);
						Bundle bundle = new Bundle();
						bundle.putBoolean("bset", bIsOpenflag);	///< 设置上了
						bundle.putSerializable("setintent", editTimeIntent);
						intent.putExtras(bundle);
						mContext.startActivity(intent);
						((HeyClockMainActivity)mContext).finish();
						((HeyClockMainActivity)mContext).overridePendingTransition(
								android.R.anim.slide_in_left,
								android.R.anim.slide_out_right);
					}
				}
				else if (mName.getText().equals("删除"))
				{
					if (null != pop)
					{
						pop.dismiss();
					}
					if (null != externHCM_GridviewAdapter)
					{
						externHCM_GridviewAdapter.remove(currentItem.position);
						externHCM_GridviewAdapter.notifyDataSetChanged();
					}
					if (null != currentItem)
					{
						HC_Clock.deleteClock(
								mContext, 
								HeyClockAlarmReceiver.class, 
								currentItem.name, 
								currentItem.bIsOpen);
					}
				}
				else if (mName.getText().equals("取消"))
				{
					if (null != pop)
					{
						pop.dismiss();
					}
				}

				/*///< 恢复之前的状态 - 放到监听弹窗消失事件里面去了...
				if (null != currentItem.mIcon && - 1 != currentItem.flag)
				{
					///< set icon   
					currentItem.mIcon.setBackgroundDrawable(currentItem.drawable); 
					///< 设置宽高 - 需要从适配vallues-xxxx里面去获取尺寸，做适配...
					currentItem.mIcon.setLayoutParams(
							new RelativeLayout.LayoutParams(
									currentItem.itemW, 
									currentItem.itemW));
				}*/
			}
		});
	}
}
