package com.hcstudio.pull;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * 拉取服务 - 定义为通过开放平台或者自定义平台，获取相关信息；Title表示显示在界面标题栏部分
 * @author hl
 *
 */
public class HeyClockWeatherPullTitle
{
	///< 城市名称  - 【@1.用在天气显示 @2...】
	private static String cityName = "北京市";
	private static final String weatherBDurl = "http://api.map.baidu.com/telematics/v3/weather?location=";
	private static final String ak = "VDhx3NKj6l7uZIHGWf6BK9Uc";
	private static final String mcode = "4B:00:67:EF:4F:6C:77:13:B3:5E:DD:FE:DB:CE:D0:37:50:7B:35:E8;com.hcstudio.heyclock";
	
	/**
	 * 初始化
	 */
	public static void initial()
	{
		cityName = "北京市";
	}
	
	public static void setCity(String _cityName)
	{
		if (null == _cityName || (null != _cityName && _cityName.equals("")))
		{
			initial();
		}
		else
		{
			cityName = _cityName;
		}
	}
	
	/**
	 * 获取AK【百度开发者密钥】
	 * @param pass
	 * @return
	 */
	public static String getAK(String pass)
	{
		if (pass.equals("~!@#$%^&*("))
		{
			return ak;
		}
		return "";
	}
	
	/**
	 * 获取AK【百度开发者安全码】
	 * @param pass
	 * @return
	 */
	public static String getMCode(String pass)
	{
		if (pass.equals("~!@#$%^&*("))
		{
			return mcode;
		}
		return "";
	}
	
	/**
	 * 获取天气请求链接
	 * @param _cityName
	 * @return
	 */
	public static String getWeatherURL() throws UnsupportedEncodingException
	{
		return weatherBDurl + URLEncoder.encode(cityName, "utf-8") + "&ak=" + getAK("~!@#$%^&*(") +
				"&mcode=" + getMCode("~!@#$%^&*(");
	}
	
	/**
	 * 获取天气请求链接
	 * @param _cityName
	 * @return
	 */
	public static String getWeatherURL(String _city) throws UnsupportedEncodingException
	{
		return weatherBDurl + URLEncoder.encode(_city, "utf-8") + "&ak=" + getAK("~!@#$%^&*(") +
				"&mcode=" + getMCode("~!@#$%^&*(");
	}
}
