package com.hcstudio.pull;

import java.util.Timer;
import java.util.TimerTask;

import com.hcstudio.core.HC_Time;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;

public class HeyClockFunctionPullIMGV 
{
	private static HeyClockFunctionPullIMGV heyclcokfpInstance = null;
	@SuppressWarnings("unused")
	private Context context;

	/**
	 * 定时任务，切换幽默图片
	 */
	private Timer timer = new Timer();  
	private TimerTask task = null;  
	/**
	 * 显示图片相关
	 */
	private ImageView imageFI = null;
	private ImageLoader imageLoader = null;
	private DisplayImageOptions options = null;
	private String uriURL = "http://121.42.138.167:8989/examples/";
	private String uriTime = "1988-09-25";
	private int uriIndex = 1;
	private boolean bLoading = false;

	@SuppressLint("HandlerLeak")
	private Handler handler = new Handler() 
	{  
		@SuppressWarnings("unused")
		int id;
		@Override  
		public void handleMessage(Message msg)
		{  
			///< 控件不存在，则不显示
			if (null == imageFI || 
				null == task ||
				null == timer)
			{
				return;
			}
			id = msg.what;
			switch(msg.what)
			{
			case 1:
			case 2:
			case 3:
				imageLoader.displayImage(
						uriURL + uriTime + msg.what + ".png", 
						imageFI, 
						options, new ImageLoadingListener() 
						{
							@Override
							public void onLoadingStarted(String arg0, View arg1) 
							{
								//System.out.println("hhh onLoadingStarted...");
							}
							
							@Override
							public void onLoadingFailed(String arg0, View arg1, FailReason arg2)
							{
								//System.out.println("hhh onLoadingFailed..." + uriURL + uriTime + id + ".png" + " cause" + arg2.getCause().getMessage());
								bLoading = false;
							}
							
							@Override
							public void onLoadingComplete(String arg0, View arg1, Bitmap arg2)
							{
								//System.out.println("hhh onLoadingComplete...");
								bLoading = false;
							}
							
							@Override
							public void onLoadingCancelled(String arg0, View arg1)
							{
								//System.out.println("hhh onLoadingCancelled...");
								bLoading = false;
							}
						});
				break;
			default:
				break;
			}
			super.handleMessage(msg);  
		}  
	}; 

	/**
	 * 获取幽默图片拉取实例化对象
	 * @param _context
	 * @return
	 */
	public static HeyClockFunctionPullIMGV getInstance(Context _context)
	{
		if (null == heyclcokfpInstance)
		{
			heyclcokfpInstance = new HeyClockFunctionPullIMGV(_context);
		}

		return heyclcokfpInstance;
	}

	/**
	 * 构造函数 - 初始化ImageLoader
	 * @param _context
	 */
	private HeyClockFunctionPullIMGV(Context _context)
	{
		this.context = _context;

		/*task = new TimerTask() 
		{  
			@Override  
			public void run() 
			{  
				///< 加载过程中不接收再次加载
				if (bLoading)
				{
					return;
				}
				
				Message message = new Message();  
				//message.what = (int) (3 * Math.random() + 1); 
				message.what = uriIndex++;
				if (uriIndex >= 4)
				{
					uriIndex = 1;
				}
				
				handler.sendMessage(message); 
				bLoading = true;
			}  
		};   */

		///< 默认初始化异步加载框架实例化对象
		imageLoader = ImageLoader.getInstance();
		ImageLoaderConfiguration config = ImageLoaderConfiguration.createDefault(_context);
		imageLoader.init(config);
		options = new DisplayImageOptions.Builder()  
		/*.showImageForEmptyUri(R.drawable.test03)*/  	///< emptyURI时显示的图片  	;这里去掉，效果不好
		/*.showImageOnFail(R.drawable.test03)*/       	///< 不是图片文件 显示图片  		;这里去掉，效果不好
		/*.showImageOnLoading(R.drawable.test03)*/		///< 加载图片的过程中显示的图片	;这里去掉，效果不好
		.delayBeforeLoading(1000)  
		.build(); 
		uriTime = HC_Time.getStrTimeYMD();
		//Toast.makeText(_context, uriTime, Toast.LENGTH_SHORT).show();
	}

	/**
	 *  设置显示控件
	 * @param _imageV
	 */
	public void setImageControl(ImageView _imageV)
	{
		imageFI = _imageV;
		if (null != task)
		{
			task.cancel();
			task = null;
		}
		task = new TimerTask() 
		{
			@Override  
			public void run() 
			{  
				///< 加载过程中不接收再次加载
				if (bLoading)
				{
					return;
				}
				
				Message message = new Message();  
				//message.what = (int) (3 * Math.random() + 1); 
				message.what = uriIndex++;
				if (uriIndex >= 4)
				{
					uriIndex = 1;
				}
				
				handler.sendMessage(message); 
				bLoading = true;
			}  
		};
		if (null == timer)
		{
			timer = new Timer();
		}
		timer.schedule(task, 1000, 6000);	///< 每10s执行一次，首次1秒后执行
	}

	/**
	 * 取消控件显示
	 */
	public void cancelImageControl()
	{
		imageFI = null;

		if (null != timer)
		{
			timer.cancel();
			timer = null;
		}
		if (null != task)
		{
			task.cancel();
			task = null;
		}
	}

	/**
	 * 销毁方法 - 销毁定时器、定时任务、销毁instance对象、重置索引、加载开关
	 */
	public void onDestroy()
	{
		imageFI = null;
		if (null != timer)
		{
			timer.cancel();
			timer = null;
		}
		if (null != task)
		{
			task.cancel();
			task = null;
		}
		
		///< 重置
		uriIndex = 1;
		bLoading = false;
	
		heyclcokfpInstance = null;
		//		if (null != imageLoader)
		//		{
		//			imageLoader.clearMemoryCache();
		//			imageLoader.clearDiskCache();
		//			imageLoader = null;
		//		}
	}
}
