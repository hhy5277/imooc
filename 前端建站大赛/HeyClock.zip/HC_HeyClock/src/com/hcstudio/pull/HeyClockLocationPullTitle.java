package com.hcstudio.pull;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.location.LocationClientOption.LocationMode;

import android.content.Context;

public class HeyClockLocationPullTitle
{
	/**
	 * 定位对象
	 */
	private static HeyClockLocationPullTitle heyclcoklpInstance = null;
	@SuppressWarnings("unused")
	private Context context;
	/**
	 * 百度定位API相关
	 */
	private LocationClient mLocationClient = null;
	private LocationMode tempMode = LocationMode.Hight_Accuracy;
	private String tempcoor = "gcj02";			///< 国测局经纬度
	private HCMLocationListener hcmBDLocationListener = null;

	/**
	 * 获取地理位置拉取实例化对象
	 * @param _context
	 * @return
	 */
	public static HeyClockLocationPullTitle getInstance(Context _context)
	{
		if (null == heyclcoklpInstance)
		{
			heyclcoklpInstance = new HeyClockLocationPullTitle(_context);
		}

		return heyclcoklpInstance;
	}

	/**
	 * 构造函数
	 * @param _context
	 */
	private HeyClockLocationPullTitle(Context _context)
	{
		this.context = _context;

		///< 初始化定位服务
		InitLocation(_context);
	}

	/**
	 * 初始化百度定位服务
	 */
	@SuppressWarnings("unused")
	private void InitLocation(Context _context)
	{
		///< 初始化定位服务
		mLocationClient = new LocationClient(_context);
		hcmBDLocationListener = new HCMLocationListener();
		mLocationClient.registerLocationListener(hcmBDLocationListener);

		LocationClientOption option = new LocationClientOption();
		option.setLocationMode(tempMode);	///< 设置定位模式
		option.setCoorType(tempcoor);		///< 返回的定位结果是百度经纬度，默认值gcj02
		int span = 1000;
		try 
		{
			span = Integer.valueOf("1000");	///< 定位时间间隔
		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		//option.setScanSpan(span);			///< 设置发起定位请求的间隔时间为5000ms
		option.setIsNeedAddress(true);		///< 需要地址
		option.setOpenGps(true);

		mLocationClient.setLocOption(option);
	}

	/**
	 * 实现实位回调监听
	 */
	private class HCMLocationListener implements BDLocationListener 
	{
		@Override
		public void onReceiveLocation(BDLocation location) 
		{
			//Receive Location 
			StringBuffer sb = new StringBuffer(256);
			sb.append("time : ");
			sb.append(location.getTime());
			sb.append("\nerror code : ");
			sb.append(location.getLocType());
			sb.append("\nlatitude : ");
			sb.append(location.getLatitude());
			sb.append("\nlontitude : ");
			sb.append(location.getLongitude());
			sb.append("\nradius : ");
			sb.append(location.getRadius());
			if (location.getLocType() == BDLocation.TypeGpsLocation)
			{
				sb.append("\nspeed : ");
				sb.append(location.getSpeed());
				sb.append("\nsatellite : ");
				sb.append(location.getSatelliteNumber());
				sb.append("\ndirection : ");
				sb.append("\naddr : ");
				sb.append(location.getAddrStr());
				sb.append(location.getDirection());
				sb.append("\ncity code: ");
				sb.append(location.getCity() + " " + location.getCityCode());
				
				///< 设置城市信息 - 天气插件启动时调用
				HeyClockWeatherPullTitle.setCity(location.getCity());
			} 
			else if (location.getLocType() == BDLocation.TypeNetWorkLocation)
			{
				sb.append("\naddr : ");
				sb.append(location.getAddrStr());
				sb.append("\ncity code: ");
				sb.append(location.getCity() + " " + location.getCityCode());
				///< 运营商信息
				sb.append("\noperationers : ");
				if (location.getOperators() == BDLocation.OPERATORS_TYPE_MOBILE)
				{
					sb.append("中国移动运营商");
				}
				else if (location.getOperators() == BDLocation.OPERATORS_TYPE_TELECOMU)
				{
					sb.append("中国电信运营商");
				}
				else if (location.getOperators() == BDLocation.OPERATORS_TYPE_UNICOM)
				{
					sb.append("中国联通运营商");
				}
				else
				{
					sb.append("未知的运营商");
				}
				
				///< 设置城市信息 - 天气插件启动时调用
				HeyClockWeatherPullTitle.setCity(location.getCity());
			}
			else if (location.getLocType() == BDLocation.TypeOffLineLocationNetworkFail)
			{
				sb.append(" 离线缓存结果");
				///< 获取上一次的存储的地理位置，没有的话就设置为北京
				HeyClockWeatherPullTitle.setCity("北京");
			}
			//HC_LOG.console(sb.toString(), "\nxxx");
		}
	}

	/**
	 * 开始定位
	 */
	public void startLocation()
	{
		if (null != mLocationClient)
		{
			mLocationClient.start();
		}
	}

	/**
	 * 停止定位
	 */
	public void stopLocation()
	{
		if (null != mLocationClient)
		{
			mLocationClient.stop();
		}
	}

	/**
	 * 销毁方法 - 销毁instance对象
	 */
	public void onDestroy()
	{
		heyclcoklpInstance = null;
		if (null != mLocationClient)
		{
			mLocationClient.stop();
		}
		mLocationClient = null;
		hcmBDLocationListener = null;
	}
}
