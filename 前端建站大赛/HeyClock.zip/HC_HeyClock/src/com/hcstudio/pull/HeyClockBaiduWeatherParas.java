package com.hcstudio.pull;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

public class HeyClockBaiduWeatherParas 
{
	private static HeyClockBaiduWeatherParasInterface getWeatherXmlInterface = null;
	private static HeyClockBaiduWeatherParasInterface handlerXmlInterface = new HeyClockBaiduWeatherParasInterface()
	{
		@Override
		public void action(String weatherInf) 
		{
			if (weatherInf.equals("MalformedURLException") ||
				weatherInf.equals("IOException"))
			{
				getWeatherXmlInterface.action("获取天气信息失败");
				return;
			}
			
			String buffstr = readStringXml(weatherInf, "");									///< 调用xml解析函数
			if (buffstr.equals("error"))
			{
				getWeatherXmlInterface.action("解析天气失败");
			}
			else if (buffstr.equals("暂无数据"))
			{
				getWeatherXmlInterface.action("暂无天气信息");
			}
			else
			{
				getWeatherXmlInterface.action(buffstr);
			}
		}
	};

	/**
	 * 获取天气信息
	 * @param city
	 * @return
	 */
	public static void GetWeater(String city, HeyClockBaiduWeatherParasInterface _getWeatherXmlInterface) 
	{
		getWeatherXmlInterface = _getWeatherXmlInterface;
		//String buffstr = null;
		try 
		{
			HeyClockWeatherPullTitle.setCity(city);
			/*String xml = */GetXmlCode(HeyClockWeatherPullTitle.getWeatherURL(city));  ///< 设置输入城市的编码，以满足百度天气api需要
			//buffstr = hbp.readStringXml(xml, city);										///< 调用xml解析函数
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		//return  buffstr;
	}

	/**
	 * 获取天气信息
	 * @param city
	 * @return
	 */
	public static void GetWeater(HeyClockBaiduWeatherParasInterface _getWeatherXmlInterface) 
	{
		getWeatherXmlInterface = _getWeatherXmlInterface;
		try 
		{
			GetXmlCode(HeyClockWeatherPullTitle.getWeatherURL());  ///< 设置输入城市的编码，以满足百度天气api需要
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * 请求天气数据
	 * @param requestUrl
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	private static void GetXmlCode(final String requestUrl) throws UnsupportedEncodingException
	{ 
		new Thread(new Runnable() 
		{
			@Override
			public void run()
			{
				StringBuffer buffer = null;  
				///< 建立连接  
				URL url;
				try 
				{
					url = new URL(requestUrl);

					HttpURLConnection httpUrlConn = (HttpURLConnection) url.openConnection();  
					httpUrlConn.setDoInput(true);  
					httpUrlConn.setRequestMethod("GET");  
					///< 获取输入流  
					InputStream inputStream = httpUrlConn.getInputStream();  
					InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");  
					BufferedReader bufferedReader = new BufferedReader(inputStreamReader);  
					///< 读取返回结果  
					buffer = new StringBuffer();  
					String str = null;  
					while ((str = bufferedReader.readLine()) != null)
					{  
						buffer.append(str);  
					}  

					///< 释放资源  
					bufferedReader.close();  
					inputStreamReader.close();  
					inputStream.close();  
					httpUrlConn.disconnect(); 
				}
				catch (MalformedURLException e)
				{
					handlerXmlInterface.action("MalformedURLException");
					return;
				}
				catch (IOException e) 
				{
					handlerXmlInterface.action("IOException");
					return;
				} 
				///< 通知处理数据来的...
				handlerXmlInterface.action(buffer.toString());
			}
		}).start();
	}

	/**
	 * 解析天气数据
	 * @param xml
	 * @param ifcity - 城市名称，暂时不用
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	private static String readStringXml(String xml, String ifcity)
	{
		StringBuffer buff = new StringBuffer();  	///< 用来拼接天气信息的
		Document doc = null;
		List listdate = null;  						///< 用来存放日期
		List listdayPic = null;  					///< 用来存放白天图片路径信息
		List listweather = null;
		List listwind = null;
		List listtem = null;
		try 
		{
			///< 读取并解析XML文档
			///< 下面的是通过解析xml字符串的
			doc = DocumentHelper.parseText(xml); 				///< 将字符串转为XML  
			Element rootElt = doc.getRootElement(); 			///< 获取根节点    
			Iterator iter = rootElt.elementIterator("results"); ///< 获取根节点下的子节点results
			String status = rootElt.elementText("status"); 		///< 获取状态，如果等于success,表示有数据
			if(!status.equals("success"))
			{
				return "暂无数据";  								///< 如果不存在数据，直接返回
			}
			//String date= rootElt.elementText("date");  			///< 获取根节点下的，当天日期
			//buff.append(date+"\n");
			///< 遍历results节点
			while (iter.hasNext())
			{
				Element recordEle = (Element) iter.next();
				Iterator iters = recordEle.elementIterator("weather_data");
				///< 遍历results节点下的weather_data节点
				while (iters.hasNext()) 
				{
					Element itemEle = (Element) iters.next();  
					listdate = itemEle.elements("date");
					///< 将date集合放到listdate中
					listdayPic = itemEle.elements("dayPictureUrl");
					listweather = itemEle.elements("weather");
					listwind = itemEle.elements("wind");
					listtem = itemEle.elements("temperature");
				}
				for(int i = 0; i < listdate.size(); i++)
				{  
					///< 由于每一个list.size都相等，这里统一处理
					Element eledate = (Element)listdate.get(i); ///< 依次取出date
					Element eleday = (Element)listdayPic.get(i);   ///< ...dayPictureUrl
					Element eleweather = (Element)listweather.get(i);
					Element elewind = (Element)listwind.get(i);
					Element eletem = (Element)listtem.get(i);            
					buff.append(eledate.getText()+"==="+eleday.getText()+"==="+eleweather.getText()+"==="+elewind.getText()+"==="+eletem.getText()+"#");  ///< 拼接信息
					//*****************如果想用到微信公众号上，还请自己继续写代码，我只能帮到这了，数据已经分离开了。
					//微信天气处理  省略
				}  
			}
		} 
		catch (DocumentException e) 
		{
			return "error";
		} 
		catch (Exception e)
		{
			return "error";
		}
		return buff.toString();  
	}

	/**
	 * 天气回调接口 - 调用者通过这个接口获得自定义天气拼接字符串
	 * @author hl
	 *
	 */
	public interface HeyClockBaiduWeatherParasInterface 
	{
		public void action(String weatherInf);
	}
}
