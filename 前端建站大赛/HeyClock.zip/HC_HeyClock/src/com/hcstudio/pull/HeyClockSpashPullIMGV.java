package com.hcstudio.pull;

import com.hcstudio.core.HC_Bitmap;
import com.hcstudio.core.HC_FilePath;
import com.hcstudio.heyclock.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.widget.ImageView;

public class HeyClockSpashPullIMGV 
{
	private static HeyClockSpashPullIMGV heyclcokfpInstance = null;
	@SuppressWarnings("unused")
	private Context context;

	/**
	 * 显示图片相关
	 */
	private ImageView imageFI = null;
	private Bitmap bitmap = null;				///< 加载失败时显示的图片
	private ImageLoader imageLoader = null;
	private DisplayImageOptions options = null;
	private String uriURL = "http://121.42.138.167:8989/examples/start.png";

	/**
	 * 获取幽默图片拉取实例化对象
	 * @param _context
	 * @return
	 */
	public static HeyClockSpashPullIMGV getInstance(Context _context, Bitmap _bitmap)
	{
		if (null == heyclcokfpInstance)
		{
			heyclcokfpInstance = new HeyClockSpashPullIMGV(_context, _bitmap);
		}

		return heyclcokfpInstance;
	}

	/**
	 * 构造函数 - 初始化ImageLoader
	 * @param _context
	 */
	@SuppressWarnings("deprecation")
	private HeyClockSpashPullIMGV(Context _context, Bitmap _bitmap)
	{
		this.context = _context;
		bitmap = _bitmap;

		///< 默认初始化异步加载框架实例化对象
		imageLoader = ImageLoader.getInstance();
		ImageLoaderConfiguration config = ImageLoaderConfiguration.createDefault(_context);
		imageLoader.init(config);
		if (null != _bitmap)
		{
			options = new DisplayImageOptions.Builder()  
			/*.showImageForEmptyUri(R.drawable.test03)*/  	///< emptyURI时显示的图片  	;这里去掉，效果不好
			.showImageOnFail(new BitmapDrawable(_bitmap))   ///< 不是图片文件 显示图片  		;这里去掉，效果不好
			/*.showImageOnLoading(R.drawable.test03)*/		///< 加载图片的过程中显示的图片	;这里去掉，效果不好
			/*.cacheOnDisk(false)	*/
			.delayBeforeLoading(1000)  
			.build(); 
		}
		else
		{
			options = new DisplayImageOptions.Builder()  
			/*.showImageForEmptyUri(R.drawable.test03)*/  	///< emptyURI时显示的图片  	;这里去掉，效果不好
			.showImageOnFail(R.drawable.test03)       		///< 不是图片文件 显示图片  		;这里去掉，效果不好
			/*.showImageOnLoading(R.drawable.test03)*/		///< 加载图片的过程中显示的图片	;这里去掉，效果不好
			/*.cacheOnDisk(false)	*/
			.delayBeforeLoading(1000)  
			.build(); 
		}
	}
	
	/**
	 * 获得缓存文件 - 过期方法
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public String getPath()
	{
		return imageLoader.getDiskCache().get(uriURL).getAbsolutePath();
	}

	/**
	 *  设置显示控件
	 * @param _imageV
	 */
	public void setImageControl(ImageView _imageV)
	{
		imageFI = _imageV;
		imageLoader.displayImage(uriURL, imageFI, options, new ImageLoadingListener()
		{
			@Override
			public void onLoadingStarted(String arg0, View arg1) 
			{
				
			}
			
			@Override
			public void onLoadingFailed(String arg0, View arg1, FailReason arg2) 
			{
				
			}
			
			@Override
			public void onLoadingComplete(String arg0, View arg1, Bitmap arg2) 
			{
				///< 拷贝一份目的是保证界面跳转数据仍然可以在线程中使用 - 
				///< 之前本来是想保存Bitmap，但是发现ImageLoader使用了缓存机制，每次得到的图片都是上一次的.
				///< 后来又发现不对啊，原来是手机助手直接打开，每次都是上一次的，坑爹啊。
				final Bitmap bitmap = Bitmap.createBitmap(arg2)/*HC_Bitmap.getBitmapFromRootView(arg1)*/;
				new Thread(new Runnable()
				{
					@Override
					public void run()
					{
						///< 保存图片到外卡中去，开机的时候先加载本地的图片
						HC_Bitmap.writeBitmap(HC_FilePath.spalshIMA_PATH, bitmap);
					}
				}).start();
			}
			
			@Override
			public void onLoadingCancelled(String arg0, View arg1) 
			{
				
			}
		});
	}

	/**
	 * 取消控件显示
	 */
	public void cancelImageControl()
	{
		imageFI = null;
	}

	/**
	 * 销毁方法 - 销毁instance对象、销毁使用过的【用来加载失败设置的或者没有设置的】，但是又曾经实例化过的Bitmap
	 */
	public void onDestroy()
	{
		imageFI = null;
		if (null != imageLoader)
		{
			imageLoader.clearDiskCache();
			imageLoader = null;
		}
		///< 这里可以这样是因为我们的界面已经被销毁了，而之前利用BitmapFactory.decoder给spashImageView设置，现在可以销毁了!
		if (null != bitmap)
		{
			bitmap.recycle();
			bitmap = null;
		}
		heyclcokfpInstance = null;
	}
}
