package com.hcstudio.pull;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.ImageView;

public class HeyClockCommonPullIMGV 
{
	private static HeyClockCommonPullIMGV heyclcokfpInstance = null;
	@SuppressWarnings("unused")
	private Context context;

	/**
	 * 显示图片相关
	 */
	private ImageView imageFI = null;
	private ImageLoader imageLoader = null;
	private DisplayImageOptions options = null;
	private static String uriURL = "";

	/**
	 * 获取幽默图片拉取实例化对象
	 * @param _context
	 * @return
	 */
	public static HeyClockCommonPullIMGV getInstance(Context _context, String urlImg)
	{
		if (null == heyclcokfpInstance)
		{
			heyclcokfpInstance = new HeyClockCommonPullIMGV(_context);
		}
		
		uriURL = urlImg;

		return heyclcokfpInstance;
	}

	/**
	 * 构造函数 - 初始化ImageLoader
	 * @param _context
	 */
	private HeyClockCommonPullIMGV(Context _context)
	{
		this.context = _context;

		///< 默认初始化异步加载框架实例化对象
		imageLoader = ImageLoader.getInstance();
		ImageLoaderConfiguration config = ImageLoaderConfiguration.createDefault(_context);
		imageLoader.init(config);

		options = new DisplayImageOptions.Builder()  
		/*.showImageForEmptyUri(R.drawable.test03)*/  	///< emptyURI时显示的图片  	;这里去掉，效果不好
		/*.showImageOnFail(R.drawable.test03)*/       	///< 不是图片文件 显示图片  		;这里去掉，效果不好
		/*.showImageOnLoading(R.drawable.test03)*/		///< 加载图片的过程中显示的图片	;这里去掉，效果不好
		/*.cacheOnDisk(false)	*/
		.cacheInMemory(true)
		.cacheOnDisk(true)
		.delayBeforeLoading(1000)  
		.build(); 
	}

	/**
	 *  设置显示控件
	 * @param _imageV
	 */
	public void setImageControl(ImageView _imageV)
	{
		imageFI = _imageV;
		imageLoader.displayImage(uriURL, imageFI, options, new ImageLoadingListener()
		{
			@Override
			public void onLoadingStarted(String arg0, View arg1) 
			{
				
			}
			
			@Override
			public void onLoadingFailed(String arg0, View arg1, FailReason arg2) 
			{
				
			}
			
			@Override
			public void onLoadingComplete(String arg0, View arg1, Bitmap arg2) 
			{
				
			}
			
			@Override
			public void onLoadingCancelled(String arg0, View arg1) 
			{
				
			}
		});
	}

	/**
	 * 取消控件显示
	 */
	public void cancelImageControl()
	{
		imageFI = null;
	}

	/**
	 * 销毁方法 - 销毁instance对象、销毁使用过的【用来加载失败设置的或者没有设置的】，但是又曾经实例化过的Bitmap
	 */
	public void onDestroy()
	{
		imageFI = null;
		uriURL = "";
		if (null != imageLoader)
		{
			imageLoader.clearDiskCache();
			imageLoader = null;
		}
		heyclcokfpInstance = null;
	}
}
