package com.hcstudio.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import com.hcstudio.threed.HCS_Renderer;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ConfigurationInfo;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.GLSurfaceView.Renderer;

public class Constant
{	
	/** 
	 * 3D-2D更换界面就需要重制的静态变量
	 * 
	 */
	///< 相机参数
	public static float cx=0; 							///< 摄像机x位置
	public static float cy=0; 							///< 摄像机y位置
	public static float cz=0;							///< 摄像机z位置

	public static float tx=0; 							///< 目标点x位置
	public static float ty=15; 							///< 目标点y位置
	public static float tz=0; 							///< 目标点z位置

	///< 设定摄像机仰角和方位角
	public static float ELEVATION_CAMERA = 0;			///< 摄像机观察点距目标点的仰角
	public static float DIRECTION_CAMERA = 0;			///< 摄像机观察点距目标点的方向角

	///< 摄像机观察点和目标点的距离
	public static float DISTANCE=100;

	///< 点的坐标
	public static float[][] vertices = null;

	///< 法向量坐标
	public static ArrayList<float[]> normals = null;

	///< 模型绕XY轴旋转
	public static float sealAngleX = 0;
	public static float sealAngleY = 0;

	public static void resetMidstMember()
	{	
		///< 设定摄像机仰角和方位角
		ELEVATION_CAMERA = 0;			
		DIRECTION_CAMERA = 0;			

		///< 摄像机观察点和目标点的距离
		DISTANCE=100;
		if (null != vertices)
		{
			vertices = null;
		}

		if (null != normals)
		{
			normals = null;
		}

		///< 模型绕x轴旋转
		sealAngleX = 0;
		sealAngleY = 0;

		System.gc();
	}

	public static void resetFinalMember()
	{
		cx=0; //摄像机x位置
		cy=0; //摄像机y位置
		cz=0;//摄像机z位置

		tx=0; //目标点x位置
		ty=15; //目标点y位置
		tz=0; //目标点z位置

		///< 设定摄像机仰角和方位角
		ELEVATION_CAMERA = 0;			
		DIRECTION_CAMERA = 0;			

		///< 摄像机观察点和目标点的距离
		DISTANCE = 100;

		System.gc();
	}

	/**
	 * 初始化3D场景
	 * @param _context
	 * @param mGLSurfaceView
	 * @param mRenderer
	 */
	public static void init3D(Context _context, 
			GLSurfaceView mGLSurfaceView,
			Renderer mRenderer, boolean bTransparent)
	{
		// Check if the system supports OpenGL ES 2.0.
		final ActivityManager activityManager = (ActivityManager) _context.getSystemService(Context.ACTIVITY_SERVICE);
		final ConfigurationInfo configurationInfo = activityManager.getDeviceConfigurationInfo();
		final boolean supportsEs2 = configurationInfo.reqGlEsVersion >= 0x20000;

		if (supportsEs2) 
		{
			// Request an OpenGL ES 2.0 compatible context.
			mGLSurfaceView.setEGLContextClientVersion(2);
			if (bTransparent)
			{
				///< 实现glsurfaceview透明效果
				mGLSurfaceView.setZOrderOnTop(true);
				mGLSurfaceView.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
				mGLSurfaceView.getHolder().setFormat(PixelFormat.TRANSLUCENT);
			}

			//			final DisplayMetrics displayMetrics = new DisplayMetrics();
			//			getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

			// Set the renderer to our demo renderer, defined below.
			mRenderer = new HCS_Renderer(_context, mGLSurfaceView);
			mGLSurfaceView.setRenderer(mRenderer);
		} 
		else 
		{
			// This is where you could create an OpenGL ES 1.x compatible
			// renderer if you wanted to support both ES 1 and ES 2.
			return;
		}
	}

	/**
	 * 生成纹理的方法
	 * @param r
	 * @param drawableId
	 * @param isMipmap
	 * @return
	 */
	public static int initTexture(Resources r,int drawableId,boolean isMipmap)
	{
		int[] textures = new int[1];
		GLES20.glGenTextures
		(
				1,          ///< 产生的纹理id的数量
				textures,   ///< 纹理id的数组 
				0           ///< 偏移量
				);    
		int textureId=textures[0];    
		GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);

		if(isMipmap)
		{
			///< Mipmap纹理采样过滤参数	
			GLES20.glTexParameteri ( GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR);   
			GLES20.glTexParameteri ( GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_NEAREST);
		}
		else
		{
			///< 非Mipmap纹理采样过滤参数	
			GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_NEAREST);
			GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR);
		}

		GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_REPEAT);
		GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_REPEAT);
		InputStream is = r.openRawResource(drawableId);
		Bitmap bitmapTmp;
		try 
		{
			bitmapTmp = BitmapFactory.decodeStream(is);
		} 
		finally 
		{
			try 
			{
				is.close();
			} 
			catch(IOException e) 
			{
				e.printStackTrace();
			}
		}
		GLUtils.texImage2D
		(
				GLES20.GL_TEXTURE_2D, 	///< 纹理类型
				0,   
				GLUtils.getInternalFormat(bitmapTmp), 
				bitmapTmp, 				///< 纹理图像
				GLUtils.getType(bitmapTmp), 
				0 						///< 纹理边框尺寸
				);   
		///< 自动生成Mipmap纹理
		GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D);

		bitmapTmp.recycle(); 			///< 纹理加载成功后释放图片
		return textureId;
	}	
}