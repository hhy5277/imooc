package com.hcstudio.common;

public class HeyClockScene 
{
	/**
	 * 当然场景是哪个场景
	 */
	private static WHICH_SCENE which_scene = WHICH_SCENE.MAIN_SCENE;
	private enum WHICH_SCENE
	{
		MAIN_SCENE, DETAIL_SCENE, EDIT_SCENE
	}
	
	public static void setMainScene()
	{
		which_scene = WHICH_SCENE.MAIN_SCENE;
	} 
	
	public static void setDetailScene()
	{
		which_scene = WHICH_SCENE.DETAIL_SCENE;
	}
	
	public static void setEditScene()
	{
		which_scene = WHICH_SCENE.EDIT_SCENE;
	}
	
	public static boolean IsMainScene()
	{
		return which_scene.equals(WHICH_SCENE.MAIN_SCENE);
	}
	
	public static boolean IsDetailScene()
	{
		return which_scene.equals(WHICH_SCENE.DETAIL_SCENE);
	}
	
	public static void reset()
	{
		which_scene = WHICH_SCENE.MAIN_SCENE;
	}
}
