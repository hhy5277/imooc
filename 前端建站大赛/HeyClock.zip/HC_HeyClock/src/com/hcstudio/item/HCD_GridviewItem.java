package com.hcstudio.item;

import java.io.Serializable;

public class HCD_GridviewItem implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int year;
	private int month;
	private int day;
	private int hourOfDay;
	private int minute;
	
	private String clockName;
	private boolean[] whenTime;

	public HCD_GridviewItem()
	{

	}

	public HCD_GridviewItem(int hourOfDay, int minute, String clockName,
			boolean[] whenTime)
	{
		super();
		this.hourOfDay = hourOfDay;
		this.minute = minute;
		this.clockName = clockName;
		this.whenTime = whenTime;
	}

	public HCD_GridviewItem(int year, int month, int day,
			int hourOfDay, int minute,  
			String clockName, boolean[] whenTime)
	{
		super();
		this.year = year;
		this.month = month;
		this.day = day;
		this.hourOfDay = hourOfDay;
		this.minute = minute;
		this.clockName = clockName;
		this.whenTime = whenTime;
	}

	public int getHourOfDay()
	{
		return hourOfDay;
	}

	public void setHourOfDay(int hourOfDay) 
	{
		this.hourOfDay = hourOfDay;
	}

	public int getMinute() 
	{
		return minute;
	}

	public void setMinute(int minute) 
	{
		this.minute = minute;
	}

	public String getClockName() 
	{
		return clockName;
	}

	public void setClockName(String clockName)
	{
		this.clockName = clockName;
	}

	public boolean[] getWhenTime() 
	{
		return whenTime;
	}

	public void setWhenTime(boolean[] whenTime) 
	{
		this.whenTime = whenTime;
	}
	
	public int getYear()
	{
		return year;
	}

	public void setYear(int year) 
	{
		this.year = year;
	}

	public int getMonth() 
	{
		return month;
	}

	public void setMonth(int month) 
	{
		this.month = month;
	}

	public int getDay()
	{
		return day;
	}

	public void setDay(int day)
	{
		this.day = day;
	}
}
