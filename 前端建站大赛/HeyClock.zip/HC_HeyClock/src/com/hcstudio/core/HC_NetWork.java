package com.hcstudio.core;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class HC_NetWork 
{

	/**
	 * 判断是否有网络连接 
	 * @param context
	 * @return
	 */
	public static boolean isNetworkConnected(Context context)
	{ 
		if (null != context) 
		{ 
			ConnectivityManager mConnectivityManager = (ConnectivityManager) context 
					.getSystemService(Context.CONNECTIVITY_SERVICE); 
			NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo(); 
			if (null != mNetworkInfo) 
			{
				return mNetworkInfo.isAvailable(); 
			} 
		} 
		return false; 
	}

	/**
	 * 判断WIFI网络是否可用 
	 * @param context
	 * @return
	 */
	public static boolean isWifiConnected(Context context) 
	{ 
		if (null != context)
		{ 
			ConnectivityManager mConnectivityManager = (ConnectivityManager) context 
					.getSystemService(Context.CONNECTIVITY_SERVICE); 
			NetworkInfo mWiFiNetworkInfo = mConnectivityManager 
					.getNetworkInfo(ConnectivityManager.TYPE_WIFI); 
			if (null != mWiFiNetworkInfo) 
			{ 
				return mWiFiNetworkInfo.isAvailable(); 
			} 
		} 
		return false; 
	}

	/**
	 * 判断MOBILE网络是否可用
	 */
	public static boolean isMobileConnected(Context context) 
	{ 
		if (null != context) 
		{ 
			ConnectivityManager mConnectivityManager = (ConnectivityManager) context 
					.getSystemService(Context.CONNECTIVITY_SERVICE); 
			NetworkInfo mMobileNetworkInfo = mConnectivityManager 
					.getNetworkInfo(ConnectivityManager.TYPE_MOBILE); 
			if (null != mMobileNetworkInfo) 
			{ 
				return mMobileNetworkInfo.isAvailable(); 
			} 
		} 
		return false; 
	}

	/**
	 * 获取当前网络连接的类型信息
	 * @param context
	 * @return
	 */
	public static int getConnectedType(Context context) 
	{ 
		if (null != context) 
		{ 
			ConnectivityManager mConnectivityManager = (ConnectivityManager) context 
					.getSystemService(Context.CONNECTIVITY_SERVICE); 
			NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo(); 
			if (null != mNetworkInfo && mNetworkInfo.isAvailable()) 
			{ 
				return mNetworkInfo.getType(); 
			} 
		} 
		return -1; 
	}
}
