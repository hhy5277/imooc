package com.hcstudio.core;

import java.util.Calendar;
import java.util.Date;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * 闹铃储存帮助类
 * @author 
 *
 */
public class HC_DbHelper extends SQLiteOpenHelper
{
	private final static String DB_NAME = "alarm.db";
	private final static int DB_VERSION = 1;
	private SQLiteDatabase database;
	private Cursor cursor;

	/**
	 * 闹铃储存帮助对象
	 */
	private static HC_DbHelper hcDbhelperInstance = null;

	public static HC_DbHelper getInstance(Context context)
	{
		if (null == hcDbhelperInstance)
		{
			hcDbhelperInstance = new HC_DbHelper(context);
		}
		return hcDbhelperInstance;
	}

	/**
	 * 主数据库
	 * 
	 * @param context
	 */
	public HC_DbHelper(Context context)
	{
		super(context, DB_NAME, null, DB_VERSION);
	}

	/**
	 * 闹钟不能重名- ID是唯一键值对【为什么要取一个名字呢？为什么不手动设置一个名字呢？做人不能太懒惰!】
	 */
	@Override
	public void onCreate(SQLiteDatabase db) 
	{
		db.execSQL("CREATE TABLE IF NOT EXISTS " + "ALARM" + "("
				+ "ID VARCHAR(20)," + "DATE TEXT, OPEN CHAR(1), WHENTIME VARCHAR(15), PRIMARY KEY(\"ID\"))");

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) 
	{
		// TODO Auto-generated method stub
	}

	/**
	 * 判断是否存在
	 * 
	 * @param id
	 * @return
	 */
	public boolean isExist(String id)
	{
		database = getReadableDatabase();
		cursor = database.query("ALARM", new String[] { "ID" }, "ID=?"/*"ID like ?"*/,
				new String[] { id }, null, null, null);
		return cursor.moveToNext();
	}

	/**
	 * 查询所有数据
	 * 
	 * @return
	 */
	public Cursor query()
	{
		database = getReadableDatabase();
		cursor = database.query("ALARM", null, null, null, null, null, null);
		return cursor;
	}

	/**
	 * 查询所有数据
	 * 
	 * @return
	 */
	public Cursor querySingleInf(String id)
	{
		database = getReadableDatabase();
		cursor = database.query("ALARM", new String[] { "DATE, OPEN, WHENTIME" }, "ID=?"/*"ID like ?"*/,
				new String[] { id }, null, null, null);
		return cursor;
	}

	/**
	 * 查询所有数据
	 * 
	 * @return
	 */
	public Cursor queryIsOpen()
	{
		database = getReadableDatabase();
		cursor = database.query("ALARM", new String[] { "ID, DATE" }, "OPEN=?", 
				new String[] { "1" }, null, null, null);
		return cursor;
	}

	/**
	 * 删除数据
	 * 
	 * @param id
	 */
	public void delete(String id) 
	{
		database = getWritableDatabase();
		database.delete("ALARM", "ID = ?", new String[] { id });
		closeDatabase();
	}

	/**
	 * 更新第二天闹钟数据 - 更新闹钟是否被启用的字段
	 * 
	 * @param id
	 * @param date
	 */
	public String updateNextDay(String id) 
	{
		database = getReadableDatabase();
		cursor = database.query("ALARM", new String[] { "DATE, OPEN" }, "ID=?"/*"ID like ?"*/,
				new String[] { id }, null, null, null);
		String settingDate = "";
		if (cursor.moveToNext())	///< 理论上只有一个值，不会重复的...
		{
			if (1 == Integer.valueOf(cursor.getString(1)))
			{
				String currentDate = cursor.getString(0);
				try 
				{
					Date date = HC_Time.ConverToDate(currentDate);
					Calendar c = Calendar.getInstance();
					c.setTime(date);  
					c.add(Calendar.DATE, 1);	///< 把日期往后增加一天.整数往后推,负数往前移动 
					date = c.getTime(); 		///< 这个时间就是日期往后推一天的结果

					///< 再转换为字符串，返回出去给外部使用
					settingDate = HC_Time.DateParse(date);
					closeCursor();
					closeDatabase();

					///< 同时更新到数据库
					database = getWritableDatabase();
					ContentValues cv = new ContentValues();
					if (isExist(id)) 
					{
						cv.put("DATE", settingDate);
						database.update("ALARM", cv, "ID=?", new String[] { id });
					} 
					closeDatabase();
				} 
				catch (Exception e)
				{
					return settingDate;
				}
			}
		}

		return settingDate;
	}

	/**
	 * * 更新数据
	 * @param id 		- 目前id就是 clkName TODO【以后】优化利用ID存储
	 * @param oldClkId  - 老的闹钟条目数据ID
	 * @param date
	 * @param whenTime
	 * @param bIsOpen
	 */
	public void updateWithPrimaryKey(String oldClkId, String id, String date, String whenTime, boolean bIsOpen) 
	{
		database = getWritableDatabase();
		ContentValues cv = new ContentValues();
		if (isExist(oldClkId)) 
		{
			cv.put("ID", id);
			cv.put("DATE", date);
			cv.put("WHENTIME", whenTime);
			database.update("ALARM", cv, "ID = ?", new String[] { oldClkId });
			///< 由于无法更新主键【是可以的，之前弄错了】，所以先删除再重新插入
			//delete(oldClkId);
			//insertRename(id, date, whenTime, bIsOpen);
		} 
		else 
		{
			///< 没有此条目 - 理论上不会出错了...【容错】
			insertRename(id, date, whenTime, bIsOpen);
		}
		//		closeDatabase();
	}

	/**
	 * 更新数据 - 更新闹钟是否被启用的字段
	 * 
	 * @param id
	 * @param date
	 */
	public void updateIsOpen(String id, String bIsOpen) 
	{
		database = getWritableDatabase();
		ContentValues cv = new ContentValues();
		if (isExist(id)) 
		{
			cv.put("OPEN", bIsOpen);
			database.update("ALARM", cv, "ID=?", new String[] { id });
		} 
	}

	/**
	 * 添加数据
	 * @param id
	 * @param date
	 * @param when
	 * @return
	 */
	public String insertRename(String id, String date, String when) 
	{
		database = getReadableDatabase();
		cursor = database.query("ALARM", new String[] { "ID" }, "ID like ?",
				new String[] { id + "%" }, null, null, null);
		int likeCount = 0;
		if (cursor.moveToNext())
		{
			likeCount = cursor.getCount();
		}
		closeCursor();
		closeDatabase();

		database = getWritableDatabase();
		ContentValues cv = new ContentValues();
		if (isExist(id)) 
		{
			id = id + (likeCount + 1)/*"_"+ HC_Time.getStrTime()*/;
		} 
		cv.put("ID", id);
		cv.put("DATE", date);
		cv.put("OPEN", "1");
		cv.put("WHENTIME", when);
		database.insert("ALARM", null, cv);
		closeDatabase();

		return id;
	}

	/**
	 * 添加数据
	 * @param id
	 * @param date
	 * @param when
	 * @return
	 */
	public String insertRename(String id, String date, String when, boolean bIsOpen) 
	{
		database = getReadableDatabase();
		cursor = database.query("ALARM", new String[] { "ID" }, "ID like ?",
				new String[] { id + "%" }, null, null, null);
		int likeCount = 0;
		if (cursor.moveToNext())
		{
			likeCount = cursor.getCount();
		}
		closeCursor();
		closeDatabase();

		database = getWritableDatabase();
		ContentValues cv = new ContentValues();
		if (isExist(id)) 
		{
			id = id + (likeCount + 1)/*"_"+ HC_Time.getStrTime()*/;
		} 
		cv.put("ID", id);
		cv.put("DATE", date);
		cv.put("OPEN", ((bIsOpen == true) ? ("1") : ("0")));
		cv.put("WHENTIME", when);
		database.insert("ALARM", null, cv);
		closeDatabase();

		return id;
	}

	public void closeCursor() 
	{
		if (null != cursor) 
		{
			cursor.close();
		}
	}

	public void closeDatabase() 
	{
		if (null != database) 
		{
			this.database.close();
		}
	}
}
