package com.hcstudio.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import android.graphics.Bitmap;
import android.view.View;

public class HC_Bitmap 
{
	/**
	 * Bitmap转byte数组
	 * @param bm
	 * @return
	 */
	public static byte[] Bitmap2Bytes(Bitmap bm)
	{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bm.compress(Bitmap.CompressFormat.PNG, 100, baos);	///< png类型
		return baos.toByteArray();
	}

	/**
	 * 写到sdcard中
	 * @param bs
	 * @throws IOException
	 */
	public static void write(byte[] bs, String filePath) throws IOException
	{
		FileOutputStream out = new FileOutputStream(new File(filePath));
		out.write(bs);
		out.flush();
		out.close();
	}

	/**
	 * 把bitmap写入文件
	 * @param filePath
	 * @param bitmap
	 */
	public static void writeBitmap(String filePath, Bitmap bitmap)
	{
		try
		{
			if (null == bitmap)
			{
				return;
			}
			write(Bitmap2Bytes(bitmap), filePath);
			bitmap.recycle();
			bitmap = null;
		} 
		catch (IOException e)
		{
			///< NOTHING
		}
	}

	/**
	 * 获取view并转换成bitmap图片
	 * @param view
	 * @return
	 */
	public static Bitmap getBitmapFromRootView(View view)
	{
		if (null == view)
		{
			return null;
		}
		view.setDrawingCacheEnabled(true);
		Bitmap bmp = Bitmap.createBitmap(view.getDrawingCache());
		view.setDrawingCacheEnabled(false);
		if(bmp != null) 
		{
			return bmp;
		} 
		else
		{
			return null;
		}
	}
}
