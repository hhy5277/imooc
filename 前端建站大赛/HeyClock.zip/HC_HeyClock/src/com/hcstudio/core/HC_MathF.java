package com.hcstudio.core;

import android.graphics.RectF;

public class HC_MathF 
{
	/**
	 * 判断一个点是否在指定矩形范围内
	 * @param pointX
	 * @param pointY
	 * @param rect
	 * @return
	 */
	public static boolean insideRect(float pointX, float pointY, RectF rect)
	{
		if (pointX > rect.left && pointX < rect.right && 
			pointY > rect.top && pointY < rect.bottom)
		{
			return true;
		}

		return false;
	}
}
