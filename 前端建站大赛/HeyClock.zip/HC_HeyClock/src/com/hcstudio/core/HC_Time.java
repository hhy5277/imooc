package com.hcstudio.core;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class HC_Time 
{
	private static long lastClickTime;
	
	/**
	 * 获得当前时间格式化字符串
	 * @return
	 */
	public static String getStrTime() 
	{
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss", Locale.getDefault());
		return sdf.format(date);
	}
	
	/**
	 * 获得当前时间格式化字符串 - 年月日
	 * @return
	 */
	public static String getStrTimeYMD() 
	{
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
		return sdf.format(date);
	}
	
	/**
	 * 获取当前时间的毫秒数
	 * @return
	 */
	public static long getLongMMM() 
	{
		return System.currentTimeMillis();
	}
	
	/**
	 * 将毫秒数格式化
	 * @param mm yyyy-MM-dd HH-mm-ss
	 * @return
	 */
	public static String timeChange(long mm)
	{
		Date date = new Date(mm);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss", Locale.getDefault());
		return sdf.format(date);
	}
	
	/**
	 * 将花费时间的毫秒数格式化
	 * @param mm
	 * @return
	 */
	public static String expandTime(long mm)
	{
		int h=0;
		int m=0;
		int s=0;
		//long ms=0;
		h = (int) (mm/(1000*60*60));
		m = (int) ((mm%(1000*60*60))/(60*1000));
		s = (int) (((mm%(1000*60*60))%(60*1000))/1000);
		//ms=((mm%(1000*60*60))%(60*1000))%1000;
		StringBuffer buffer=new StringBuffer();
		if (h > 0)
		{
		   buffer.append(h + "小时");
		}
		if (m > 0)
		{
			buffer.append(m + "分");
		}
		if (s > 0)
		{
			buffer.append(s + "秒");
		}
		//		if(ms>0)
		//		{
		//			buffer.append(ms+"毫秒");
		//		}
		return buffer.toString();
	}
	
	/**
	 * 将时间字符串格式化为Date对象
	 * @param strDate
	 * @return
	 * @throws Exception
	 */
	public static Date ConverToDate(String strDate) throws Exception 
	{
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm", Locale.getDefault());
		return df.parse(strDate);
	}
	
	/** 
	 * 将Date对象格式化为字符串 yyyy-MM-dd hh:mm
	 * @param strDate
	 * @return
	 * @throws Exception
	 */
	public static String DateParse(Date date) throws Exception 
	{
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
		return df.format(date);
	}
	
	/**
	 * 判断某个时间是否已经是过去时间
	 * @param time
	 * @return
	 */
	public static boolean TimePassed(String time)
	{
		Date date = new Date(System.currentTimeMillis());
		try 
		{
			if (ConverToDate(time).getTime() <= date.getTime())
			{
				return true;
			}
		} 
		catch (Exception e) 
		{
			return true;
		}
		
		return false;
	}
	
	/**
	 * 由此扩展出来的防止按钮重复点击的方法
	 * @return
	 */
	public static boolean isFastDoubleClick() 
	{
		long time = System.currentTimeMillis();   
		if ( time - lastClickTime < 500) 
		{   
			return true;   
		}   
		lastClickTime = time;   
		
		return false;   
	}
}
