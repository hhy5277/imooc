package com.hcstudio.core;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;

public class HC_Screen
{
	///< 屏幕宽高【About三维】
	public static float SCREEN_HEIGHT = 800;
	public static float SCREEN_WIDTH = 480;
	public static float REAL_SCREEN_HEIGHT = 800;
	public static float REAL_SCREEN_WIDTH = 480;
	public static float ratio_width;
	public static float ratio_height;

	///< 上下文
	private Activity activity;
	///< 实例
	private static HC_Screen uniqueInstance = null;


	public HC_Screen(Activity activity)
	{
		this.activity = activity;
	}

	/**
	 * 获得单例
	 * @param myActivity
	 * @return
	 */
	public static HC_Screen getInstance(Activity myActivity) 
	{
		if (uniqueInstance == null) 
		{
			uniqueInstance = new HC_Screen(myActivity);
		} 
		return uniqueInstance;
	}

	/**
	 * 初始化并设置上下文
	 */
	public void getScreenWH()
	{
		DisplayMetrics dm = new DisplayMetrics();
		activity.getWindowManager().getDefaultDisplay().getMetrics(dm);		///<  获取屏幕分辨率
		int tempHeight = (int) (REAL_SCREEN_HEIGHT = SCREEN_HEIGHT = dm.heightPixels);
		int tempWidth  = (int) (REAL_SCREEN_WIDTH = SCREEN_WIDTH = dm.widthPixels);

		if(tempHeight < tempWidth)   ///< 横屏          
		{
			SCREEN_HEIGHT = tempHeight;
			SCREEN_WIDTH  = tempWidth;
		}	
		else						///< 竖屏
		{
			SCREEN_HEIGHT = tempWidth;
			SCREEN_WIDTH  = tempHeight;
		}

		ratio_height = SCREEN_HEIGHT/480;
		ratio_width = SCREEN_WIDTH/800;
	}
	
	public static int Dp2Px(Context context, float dp) 
	{  
		final float scale = context.getResources().getDisplayMetrics().density;  
		return (int) (dp * scale + 0.5f);  
	}  

	public static int Px2Dp(Context context, float px) 
	{  
		final float scale = context.getResources().getDisplayMetrics().density;  
		return (int) (px / scale + 0.5f);  
	}  
	
	public void onDestroy()
	{
		uniqueInstance = null;
	}
}
