package com.hcstudio.core;

import java.util.Calendar;

import com.hcstudio.receiver.HeyClockAlarmReceiver;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;

public class HC_Clock 
{
	/**
	 * 设置闹钟 - 根据年月日时分分秒
	 * @param packageContext
	 * @param cls
	 * @param clockName
	 * @param year
	 * @param month
	 * @param day
	 * @param hourOfDay
	 * @param minute
	 * @param second
	 */
	public static void setClock(
			Context packageContext,
			Class<?> cls, 
			String clockName, 
			int year, int month, 
			int day, int hourOfDay, 
			int minute, int second)
	{
		///< @a闹钟时间设置
		final Calendar c = Calendar.getInstance();  
		///< @b设置闹铃的时间(年,月,日,时,分,秒)
		c.set(year, month, day, hourOfDay, minute, second);
		///< 指定启动AlarmActivity组件  
		Intent intentClk = new Intent(packageContext, 
				cls); 
		intentClk.setAction(clockName);
		///< 创建PendingIntent对象  
		PendingIntent pi = PendingIntent.getBroadcast(  
				packageContext, 0, intentClk, 0); 
		AlarmManager aManager = (AlarmManager) packageContext.getSystemService(Service.ALARM_SERVICE);
		///< 设置AlarmManager将在Calendar对应的时间启动指定组件  
		aManager.set(AlarmManager.RTC_WAKEUP  ///< POWER_OFF_WAKEUP - 不支持关机闹钟
				, c.getTimeInMillis(), pi); 
		///< 设置闹钟重复时间
		//			aManager.setRepeating(AlarmManager.RTC_WAKEUP,
		//					c.getTimeInMillis(), 10 * 1000, pi);
	}

	/**
	 * 根据闹钟的名称的Action，取消闹钟
	 * @param packageContext
	 * @param cls
	 * @param clockName
	 */
	public static void cancelClock(
			Context packageContext,
			Class<?> cls, 
			String clockName)
	{
		///< 指定启动AlarmActivity组件  
		Intent intentClk = new Intent(packageContext, 
				cls); 
		intentClk.setAction(clockName);
		///< 创建PendingIntent对象  
		PendingIntent pi = PendingIntent.getBroadcast(  
				packageContext, 0, intentClk, 0); 
		AlarmManager aManager = (AlarmManager) packageContext.getSystemService(Service.ALARM_SERVICE);
		///< 取消闹钟  
		aManager.cancel(pi);
	}
	
	/**
	 * 根据闹钟的名称的Action，取消闹钟
	 * @param packageContext
	 * @param cls
	 * @param clockName
	 */
	public static void deleteClock(
			Context packageContext,
			Class<?> cls, 
			String clockName, 
			Boolean bIsOpen)
	{
		///< 从数据库中删除闹钟
		HC_DbHelper.getInstance(packageContext).delete(clockName);
		///< 如果闹钟原来是开着的，取消闹钟
		if (bIsOpen)
		{
			///< 指定启动AlarmActivity组件  
			Intent intentClk = new Intent(packageContext, 
					cls); 
			intentClk.setAction(clockName);
			///< 创建PendingIntent对象  
			PendingIntent pi = PendingIntent.getBroadcast(  
					packageContext, 0, intentClk, 0); 
			AlarmManager aManager = (AlarmManager) packageContext.getSystemService(Service.ALARM_SERVICE);
			///< 取消闹钟  
			aManager.cancel(pi);
		}
	}


	/**
	 * 设置第二天的闹钟 - 根据名字查询数据库信息，看当天的设置，在day上面加一天
	 * @param packageContext
	 * @param cls
	 * @param clockName
	 * @return
	 */
	public static void setNextDayClock(
			Context packageContext,
			String clockName)
	{
		String mDate = HC_DbHelper.getInstance(packageContext).updateNextDay(clockName);
		if (!mDate.equals(""))
		{
			setClock(packageContext, HeyClockAlarmReceiver.class, 
					clockName, 
					Integer.valueOf(mDate.split(" ")[0].split("-")[0]),
					Integer.valueOf(mDate.split(" ")[0].split("-")[1])-1,
					Integer.valueOf(mDate.split(" ")[0].split("-")[2]),
					Integer.valueOf(mDate.split(" ")[1].split(":")[0]),
					Integer.valueOf(mDate.split(" ")[1].split(":")[1]),
					0);
		}
	}
	
	/**
	 * 设置闹钟 - 根据年月日时分分秒 - 并且判断是否过期，如果过期，那么则推后一天
	 * @param packageContext
	 * @param cls
	 * @param clockName
	 * @param year
	 * @param month
	 * @param day
	 * @param hourOfDay
	 * @param minute
	 * @param second
	 */
	public static void setClockBalance(
			Context packageContext,
			Class<?> cls, 
			String clockName, 
			String setTime)
	{
		///< @a闹钟时间设置
		final Calendar c = Calendar.getInstance(); 
		if (HC_Time.TimePassed(setTime))
		{
			///< @b设置闹铃的时间(年,月,日,时,分,秒)
			c.set(Integer.valueOf(setTime.split(" ")[0].split("-")[0]), 
					Integer.valueOf(setTime.split(" ")[0].split("-")[1]) - 1, 
					Integer.valueOf(setTime.split(" ")[0].split("-")[2]) + 1, 
					Integer.valueOf(setTime.split(" ")[1].split(":")[0]), 
					Integer.valueOf(setTime.split(" ")[1].split(":")[1]), 
					0);
		}
		else
		{
			///< @b设置闹铃的时间(年,月,日,时,分,秒)
			c.set(Integer.valueOf(setTime.split(" ")[0].split("-")[0]), 
					Integer.valueOf(setTime.split(" ")[0].split("-")[1]) - 1, 
					Integer.valueOf(setTime.split(" ")[0].split("-")[2]), 
					Integer.valueOf(setTime.split(" ")[1].split(":")[0]), 
					Integer.valueOf(setTime.split(" ")[1].split(":")[1]), 
					0);
		}
		///< 指定启动AlarmActivity组件  
		Intent intentClk = new Intent(packageContext, cls); 
		intentClk.setAction(clockName);
		///< 创建PendingIntent对象  
		PendingIntent pi = PendingIntent.getBroadcast(  
				packageContext, 0, intentClk, 0); 
		AlarmManager aManager = (AlarmManager) packageContext.getSystemService(Service.ALARM_SERVICE);
		///< 设置AlarmManager将在Calendar对应的时间启动指定组件  
		aManager.set(AlarmManager.RTC_WAKEUP  ///< POWER_OFF_WAKEUP - 不支持关机闹钟
				, c.getTimeInMillis(), pi); 
		///< 设置闹钟重复时间
		//			aManager.setRepeating(AlarmManager.RTC_WAKEUP,
		//					c.getTimeInMillis(), 10 * 1000, pi);
	}

	/**
	 * TODO【需要完成重复周期，暂时不考虑，有点复杂】 当闹钟触发之后，计算下一次闹钟的时间，并设置 - 需要根据用户设置的重复的周期决定
	 * @param packageContext
	 * @param cls
	 * @param clockName
	 * @param year
	 * @param month
	 * @param day
	 * @param hourOfDay
	 * @param minute
	 * @param second
	 */
	public static void setRepeatClock(
			Context packageContext,
			Class<?> cls, 
			String clockName, 
			int year, int month, 
			int day, int hourOfDay, 
			int minute, int second)
	{
		///< 首先看闹钟是否开启 - 闹钟开启
		///< 如果没有选择重复周期 - 则默认是下一次触发，之后不重复；当再次启动，更新hourday之后如果时间还是比当前落后，则加一天；
		///< 如果选择了重复周期 - 和今天星期做比较，如果是今天，如果没有过期，则启动今天的闹钟；当响起闹钟的时候，再计算临近的那天，重新更新闹钟时间；

		///< 闹钟未开启
		///< 立即开启，检查重复周期是今天，是否过期； 
		///< 
	}
}
