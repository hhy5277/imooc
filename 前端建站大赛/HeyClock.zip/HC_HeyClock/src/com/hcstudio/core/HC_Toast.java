package com.hcstudio.core;

import java.util.HashMap;

import com.hcstudio.heyclock.R;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class HC_Toast 
{
	/**
	 * 显示位置控制
	 * @author 
	 *
	 */
	public static enum GRAVITY
	{
		LEFT, RIGHT, TOP, BOTTOM, CENTER
	};

	/**
	 * 枚举对应的整型位置类别
	 */
	private static final HashMap<GRAVITY, Integer> position = new HashMap<GRAVITY, Integer>()
			{
				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;

				{
					put(GRAVITY.LEFT, Gravity.LEFT);
					put(GRAVITY.RIGHT, Gravity.RIGHT);
					put(GRAVITY.BOTTOM, Gravity.BOTTOM);
					put(GRAVITY.TOP, Gravity.TOP);
					put(GRAVITY.CENTER, Gravity.CENTER);
				}
			};
	
	/**
	 * 一个带图片的toast
	 * @param context
	 * @param str
	 * @param gravity
	 */
	public static void makeToastPic(Context context, String str, GRAVITY gravity)
	{
		if (!(gravity instanceof GRAVITY))
		{
			return;
		}
		
		Toast toast = Toast.makeText(context, str, Toast.LENGTH_SHORT);
		View toastView = toast.getView();
		ImageView image = new ImageView(context);
		image.setImageResource(R.drawable.ic_launcher);
		LinearLayout ll = new LinearLayout(context);
		ll.addView(image);
		ll.addView(toastView);
		toast.setView(ll);
		toast.setGravity(position.get(gravity), 0, 0);
		toast.show();
	}

	/**
	 * 简单的toast
	 * @param str
	 * @param sel
	 */
	public static void makeToastSimple(Context context, String str, boolean sel, GRAVITY gravity)
	{
		if (!(gravity instanceof GRAVITY))
		{
			return;
		}
		
		Toast toast = Toast.makeText(context, str, sel ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG);	
		toast.setGravity(position.get(gravity), 0, 0);
		toast.show();
	}
}
