package com.hcstudio.core;

import java.io.FileOutputStream;

public class HC_LOG 
{
	private static boolean logSwitch = true;

	public static void closeLog()
	{
		logSwitch = true;
	}

	public static void openLog()
	{
		logSwitch = false;
	}

	public static void console(String msg, String tag)
	{
		if (logSwitch)
		{
			return;
		}
		System.out.print(tag + " " + msg);
	}

	/** 
	 * 写， 读sdcard目录上的文件，要用FileOutputStream， 不能用openFileOutput 
	 * 不同点：openFileOutput是在raw里编译过的，FileOutputStream是任何文件都可以 
	 * @param fileName 
	 * @param message 
	 */  
	/**
	 * 写在/mnt/sdcard/目录下面的文件  
	 * @param fileName
	 * @param message
	 */
	public static void writeLogSdcard(String fileName, String message)
	{  
		try 
		{  
			// FileOutputStream fout = openFileOutput(fileName, MODE_PRIVATE);  
			FileOutputStream fout = new FileOutputStream(fileName);  
			byte[] bytes = message.getBytes();  
			fout.write(bytes);  
			fout.close();  
		}  
		catch (Exception e) 
		{  
			e.printStackTrace();
		}  
	}  
}
