package com.hcstudio.core;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Environment;

public class HC_FilePath
{
	@SuppressLint("SdCardPath")
	public static String SdcardPath = "/sdcard";
	public static String rootPath;
	public static String cachePath;
	public static String spalshIMA_PATH = SdcardPath + "/start.png";

	public HC_FilePath(Context _context, long user_id)
	{					
		if (Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED))	///< 判断sd卡是否存在
		{
			SdcardPath = Environment.getExternalStorageDirectory().toString();					///< 获取根目录
		}

		rootPath = SdcardPath + "/heyclock/";
		cachePath = rootPath + "cache/";
		///< Just设置
		spalshIMA_PATH = cachePath + "start.png";
	}

	public void makeDir()
	{
		List<String> dirs = new ArrayList<String>();
		dirs.add(cachePath);

		for (String s:dirs)
		{
			createDir(s);
		}
	}

	private void createDir(String dirPath)
	{
		File file = new File(dirPath);
		File parent = file.getAbsoluteFile();
		if (parent != null && !parent.exists())
		{ 
			parent.mkdirs(); 
		} 
	}

	/**
	 * 判断文件是否存在
	 * @param filePath
	 * @return
	 */
	public static boolean fileIsExists(String filePath)
	{
		try
		{
			File f=new File(filePath);
			if(!f.exists())
			{
				return false;
			}

		}
		catch (Exception e) 
		{
			return false;
		}
		return true;
	}
}
