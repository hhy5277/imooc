package com.hcstudio.heyclock;

import java.util.Arrays;
import java.util.Calendar;

import com.hcstudio.common.HeyClockScene;
import com.hcstudio.core.HC_Clock;
import com.hcstudio.core.HC_DbHelper;
import com.hcstudio.core.HC_Screen;
import com.hcstudio.core.HC_Time;
import com.hcstudio.core.HC_Toast;
import com.hcstudio.core.HC_Toast.GRAVITY;
import com.hcstudio.item.HCD_GridviewItem;
import com.hcstudio.pull.HeyClockCommonPullIMGV;
import com.hcstudio.receiver.HeyClockAlarmReceiver;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Service;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnMultiChoiceClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.animation.Animation.AnimationListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import roboguice.activity.RoboActivity;
import roboguice.inject.InjectView;

public class HeyClockDetailActivity extends RoboActivity implements OnClickListener
{
	@InjectView(R.id.hcd_settime_btn)		///< 设置时间
	private TextView settime_btn;
	@InjectView(R.id.hcd_detail_when_tv)	///< 何时发生 - 哪天重复 
	private TextView detail_when_tv;
	@InjectView(R.id.hcd_setcancel_btn)		///< 设置取消
	private Button setcancel_btn;
	@InjectView(R.id.hcd_setok_btn)			///< 设置确定
	private Button setok_btn;
	@InjectView(R.id.hcd_detail_name_et)	///< 闹钟名称
	private EditText detail_name_et;
	//	@InjectView(R.id.hcd_titleImg)		///< 标题栏
	//	private ImageView titleImg;			//@InjectView(R.id.hcd_titleImg)		
											//@界面标题栏和ImageView，无法靠以来注入拿到，你懂的...
	private RelativeLayout hcd_tileBar;
	private ImageView titleImg;
	
	/**
	 * 天气预览图 - 滚动播放
	 */
	private Animation translateAnimationLeft;
	private Animation translateAnimationRight;

	/**
	 * 时间对话框相关
	 */
	private int mHour;
	private int mMinute;
	private boolean is24HourView = true;
	private static final int DATE_DIALOG_ID = 0;

	/**
	 * 重复对话框相关
	 */
	private String[] whenStr = new String[] { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
	private ListView whenlv;
	private String detail_when_title = "";
	private HCD_GridviewItem setTimeIntent = null;
	private boolean[] whenTime = null;

	/**
	 * 闹钟相关 - 测试
	 */
	@SuppressWarnings("unused")
	private AlarmManager aManager = null;  
	private String timeStr = "";
	private int year = -1;
	private int month = -1;
	@SuppressWarnings("unused")
	private int week = -1;
	private int day = -1;
	private int realmDay = -1;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		///< 自定义标题
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.activity_hey_clock_detail);
		///< 设置标题为某个layout
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.hey_hcd_titlebar);

		OnInitial();
		registerListener();
		getService();
	}

	/**
	 * 初始化
	 */
	private void OnInitial()
	{
		final Calendar c = Calendar.getInstance();
		if (is24HourView)
		{
			mHour = c.get(Calendar.HOUR_OF_DAY);
		}
		else
		{
			mHour = c.get(Calendar.HOUR);
		}
		mMinute = c.get(Calendar.MINUTE);
		updateDisplay();

		///< 获取抬头
		detail_when_title = detail_when_tv.getText().toString();
		whenTime = new boolean[7];
		Arrays.fill(whenTime, false);
		
		///< 初始化动画
		AnimationInitial();

		///< 设置当前场景为设置详情场景 - 避免首次启动的情况下，会获取intent的无效异常【虽然可以通过try,catch排除】
		HeyClockScene.setDetailScene();

		///< 获取AlarmManager对象  
		aManager = (AlarmManager) getSystemService(Service.ALARM_SERVICE);  
	}
	
	/**
	 * 动画初始化 - 已经在OnInitial()中调用
	 */
	private void AnimationInitial()
	{
		///< 初始化 -功能区菜单向下动动画  ---> getResources().getDimension(R.dimen.px180)表示按钮尺寸，这样做动画的位置才能得到很好的控制
		translateAnimationLeft = new TranslateAnimation(HC_Screen.SCREEN_WIDTH/4, -HC_Screen.SCREEN_WIDTH/4, 0.1f, 0.1f);  
		///< 设置动画时间 
		translateAnimationLeft.setRepeatCount(0);
		translateAnimationLeft.setDuration(8000);  
		translateAnimationLeft.setFillAfter(true); 
		translateAnimationLeft.setAnimationListener(new AnimationListener() 
		{
			@Override
			public void onAnimationStart(Animation animation)
			{
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationRepeat(Animation animation) 
			{
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation) 
			{
				titleImg.startAnimation(translateAnimationRight);
			}
		});
		
		///< 初始化 -功能区菜单向下动动画  ---> getResources().getDimension(R.dimen.px180)表示按钮尺寸，这样做动画的位置才能得到很好的控制
		translateAnimationRight = new TranslateAnimation(-HC_Screen.SCREEN_WIDTH/4, HC_Screen.SCREEN_WIDTH/4, 0.1f, 0.1f);  
		///< 设置动画时间 
		translateAnimationRight.setRepeatCount(0);
		translateAnimationRight.setDuration(8000);  
		translateAnimationRight.setFillAfter(true); 
		translateAnimationRight.setAnimationListener(new AnimationListener() 
		{
			@Override
			public void onAnimationStart(Animation animation)
			{
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationRepeat(Animation animation) 
			{
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation) 
			{
				titleImg.startAnimation(translateAnimationLeft);
			}
		});
	}

	/**
	 * 注册监听事件
	 */
	private void registerListener()
	{
		settime_btn.setOnClickListener(this);
		///< TODO @完善 重复功能以后慢慢添加
		//detail_when_tv.setOnClickListener(this);
		setcancel_btn.setOnClickListener(this);
		setok_btn.setOnClickListener(this);
	}
	
	/**
	 * 处理服务请求
	 */
	private void getService()
	{
		///< 设置当天天气预览图片
		hcd_tileBar = (RelativeLayout) findViewById(R.id.hcd_tileBar);
		titleImg = (ImageView)hcd_tileBar.findViewById(R.id.hcd_titleImg);
		String weatherImgUrl = (String)getIntent().getExtras().get("weatherPng");
		if (!weatherImgUrl.equals(""))
		{
			HeyClockCommonPullIMGV.getInstance(HeyClockDetailActivity.this, weatherImgUrl).setImageControl(titleImg);
			titleImg.startAnimation(translateAnimationLeft);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onClick(View v) 
	{
		///< 设置时间
		if (v.equals(settime_btn))
		{
			/**
			 * 创建对话框 - A原始的方式
			 */
			showDialog(DATE_DIALOG_ID);
		}
		///< 设置哪天发生
		else if (v.equals(detail_when_tv))
		{
			showWhenMultiChoiceItems();
		}
		///< 取消设置
		else if (v.equals(setcancel_btn))
		{
			///< 销毁数据 - 习惯而已
			whenStr = null;
			whenTime = null;

			Intent intent = new Intent();
			intent.setClass(HeyClockDetailActivity.this, HeyClockMainActivity.class);
			Bundle bundle = new Bundle();
			bundle.putBoolean("bset", false);	///< 取消了设置
			intent.putExtras(bundle);
			startActivity(intent);
			finish();
			overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
		}
		///< 确定设置
		else if (v.equals(setok_btn))
		{
			//			setTimeIntent.setClockName(detail_name_et.getText().toString());
			//			setTimeIntent.setHourOfDay(mHour);
			//			setTimeIntent.setMinute(mMinute);
			//			setTimeIntent.setWhenTime(whenTime);
			///< 获得输入闹钟名称 - 没有则获取默认值
			String clkTemp = detail_name_et.getText().toString();
			String clkName = detail_name_et.getText().toString().substring(0, clkTemp.length());
			///< 判断是否输入闹钟名称
			if(null == clkName || clkName.equals(""))
			{
				//HC_Toast.makeToastSimple(this, "请设置不重名的闹钟名称!", true, GRAVITY.CENTER);
				//return;
				clkName = detail_name_et.getHint().toString();
			}
			///< 设置实际发生的那天 - 实际设置过程中，用户可能会设置过去时间
			///< 判断选择的时间是否过期
			if (!bSettimePlausible(mHour, mMinute))
			{
				realmDay += 1;
				//				timeStr = "";
				//				HC_Toast.makeToastSimple(this, "时光倒流了!", true, GRAVITY.CENTER);
				//				return;
			}
			/*TODO【需要完成重复周期，暂时不考虑，有点复杂】 ///< week     1 - 周天  2 - 周一 3 - 周二 。。。。 7  - 周六
			///< week-1   0 - 周天   1 - 周一  2 周二  6 5 周五  6 周六
			if (whenTime[week - 1])	///< 如果当天被选中了
			{
				///< 设置实际发生的那天 - 实际设置过程中，用户可能会设置过去时间
				///< 判断选择的时间是否过期
				if (!bSettimePlausible(mHour, mMinute))
				{
					realmDay += 1;
					//				timeStr = "";
					//				HC_Toast.makeToastSimple(this, "时光倒流了!", true, GRAVITY.CENTER);
					//				return;
				}
			}
			///< 否则计算临近的那一天
			else
			{
				
			}*/

			///< 插入到数据库中
			///< timeStr是判断日期拼接的设置的时间字符串 - 这里将作为数据库条目数据
			if (timeStr.equals(""))
			{
				HC_Toast.makeToastSimple(this, "出错了...", true, GRAVITY.CENTER);
				return;
			}
			///< 闹钟实际的名称
			String realName = HC_DbHelper.getInstance(HeyClockDetailActivity.this).insertRename(clkName, timeStr, getWhenTimeStr(whenTime));
			///< @未封装 - 设置闹钟
			/*///< @a闹钟时间设置
			final Calendar c = Calendar.getInstance();  
			///< @b设置闹铃的时间(年,月,日,时,分,秒)
			c.set(year, month, day, mHour, mMinute, 0);
			///< 指定启动AlarmActivity组件  
			Intent intentClk = new Intent(HeyClockDetailActivity.this, 
					HeyClockAlarmReceiver.class); 
			intentClk.setAction(realName);
			///< 创建PendingIntent对象  
			PendingIntent pi = PendingIntent.getBroadcast(  
					HeyClockDetailActivity.this, 0, intentClk, 0); 

			///< 设置AlarmManager将在Calendar对应的时间启动指定组件  
			aManager.set(AlarmManager.RTC_WAKEUP  ///< POWER_OFF_WAKEUP - 不支持关机闹钟
					, c.getTimeInMillis(), pi); 
			//			///< 设置闹钟重复时间
			//			aManager.setRepeating(AlarmManager.RTC_WAKEUP,
			//					c.getTimeInMillis(), 10 * 1000, pi);*/
			///< @封装 - 设置闹钟   realmDay - 表示如果设置的时间是过去时间，则自动加一天
			HC_Clock.setClock(HeyClockDetailActivity.this, 
					HeyClockAlarmReceiver.class, 
					realName, year, 
					month, realmDay, mHour, 
					mMinute, 0);
			
			///< 调整并携带信息 - 之后改为存到数据库中
			setTimeIntent = new HCD_GridviewItem(
					mHour, 
					mMinute, 
					clkName,
					whenTime);
			Intent intent = new Intent();
			intent.setClass(HeyClockDetailActivity.this, HeyClockMainActivity.class);
			Bundle bundle = new Bundle();
			bundle.putBoolean("bset", true);	///< 设置上了
			bundle.putSerializable("setintent", setTimeIntent);
			intent.putExtras(bundle);
			startActivity(intent);
			finish();
			overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
		}
	}

	/**
	 * 更新显示的时间视图
	 */
	private void updateDisplay()
	{
		StringBuilder strB = new StringBuilder();
		if (is24HourView)
		{
			if (mHour < 10)
			{
				strB.append("0" + mHour).append(":");
			}
			else
			{
				strB.append(mHour).append(":");
			}
			if (mMinute < 10)
			{
				strB.append("0" + mMinute);
			}
			else
			{
				strB.append(mMinute);
			}
			settime_btn.setText(strB);
		}
		else
		{

		}
	}

	/**
	 * 时间选择框
	 */
	private TimePickerDialog.OnTimeSetListener mDateSetListener = new TimePickerDialog.OnTimeSetListener() 
	{
		@Override
		public void onTimeSet(TimePicker view, int hourOfDay, int minute) 
		{
			mHour = hourOfDay;
			mMinute = minute;
			updateDisplay();
		}        
	};

	/**
	 * 创建对话框 - A原始的方式
	 */
	protected Dialog onCreateDialog(int id) 
	{    
		switch (id)
		{    
		case DATE_DIALOG_ID:       
			return new TimePickerDialog(this, mDateSetListener, mHour, mMinute, is24HourView);
		}    
		return null;
	}

	/**
	 * 何时发生对话框
	 */
	private void showWhenMultiChoiceItems()
	{
		AlertDialog builder = new AlertDialog.Builder(this)
		.setTitle("请选择重复的日子")
		.setMultiChoiceItems(whenStr,
				new boolean[] { false, false, false, false, false , false, false},
				new OnMultiChoiceClickListener()
		{

			@Override
			public void onClick(DialogInterface dialog,
					int which, boolean isChecked)
			{

			}
		})
		.setPositiveButton("确定", new DialogInterface.OnClickListener()
		{

			@Override
			public void onClick(DialogInterface dialog, int which)
			{
				///< 获取哪些天被设置了
				//whenTime = whenlv.getCheckedItemPositions();
				if (null == whenTime)
				{
					whenTime = new boolean[7];
					Arrays.fill(whenTime, false);
				}
				for (int i = 0; i < whenlv.getCheckedItemPositions().size(); ++i)
				{
					whenTime[i] = whenlv.getCheckedItemPositions().get(i);
				}

				///< Everyday
				if (whenlv.getCheckedItemPositions().size() == 7)
				{
					detail_when_tv.setText(detail_when_title + "\n" + "每天");
				}
				///< 工作日
				else if (whenlv.getCheckedItemPositions().size() == 5 && !whenlv.getCheckedItemPositions().get(5) && !whenlv.getCheckedItemPositions().get(6))
				{
					detail_when_tv.setText(detail_when_title + "\n" + "工作日");
				}
				///< 周末
				else if (whenlv.getCheckedItemPositions().size() == 2 && whenlv.getCheckedItemPositions().get(5) && whenlv.getCheckedItemPositions().get(6))
				{
					detail_when_tv.setText(detail_when_title + "\n" + "周末");
				}
				///< 什么都不做
				else if (whenlv.getCheckedItemPositions().size() <= 0)
				{

				}
				///< 选择了其它
				else 
				{
					String s = "";
					///< 扫描所有的列表项，如果当前列表项被选中，将列表项的文本追加到s变量中。
					for (int i = 0; i < whenStr.length; i++)
					{
						if (whenlv.getCheckedItemPositions().get(i))
						{
							s  += whenlv.getAdapter().getItem(i) + " ";
						}
					}
					detail_when_tv.setText(detail_when_title + "\n" + s);
				}
				///< 网上的demo
				//				String s = "您选择了：";
				//				///< 扫描所有的列表项，如果当前列表项被选中，将列表项的文本追加到s变量中。
				//				for (int i = 0; i < whenStr.length; i++)
				//				{
				//					if (whenlv.getCheckedItemPositions().get(i))
				//					{
				//						s += i + ":" + whenlv.getAdapter().getItem(i) + " ";
				//					}
				//				}
				//
				//				///< 用户至少选择了一个列表项
				//				if (whenlv.getCheckedItemPositions().size() > 0)
				//				{
				//					new AlertDialog.Builder(HeyClockDetailActivity.this)
				//					.setMessage(s).show();
				//					System.out.println(whenlv.getCheckedItemPositions().size());
				//				}
				//
				//				///< 用户未选择任何列表项
				//				else if(whenlv.getCheckedItemPositions().size() <= 0 )
				//				{
				//					new AlertDialog.Builder(HeyClockDetailActivity.this)
				//					.setMessage("您未选择任何省份").show();
				//				}
			}
		}).setNegativeButton("取消", null).create();

		whenlv = builder.getListView();
		builder.show();
	}

	//	/**
	//	 * 监听Back键按下事件,方法1:
	//	 * 注意:
	//	 * super.onBackPressed()会自动调用finish()方法,关闭
	//	 * 当前Activity.
	//	 * 若要屏蔽Back键盘,注释该行代码即可
	//	 */ 
	//	@Override 
	//	public void onBackPressed() 
	//	{ 
	//		super.onBackPressed(); 
	//		Intent intent = new Intent();
	//		intent.setClass(HeyClockDetailActivity.this, HeyClockMainActivity.class);
	//		finish();
	//		overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
	//	} 

	/**
	 * 监听Back键按下事件,方法2:
	 * 注意:
	 * 返回值表示:是否能完全处理该事件
	 * 在此处返回false,所以会继续传播该事件.
	 * 在具体项目中此处的返回值视情况而定.
	 */ 
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	{
		if ((keyCode == KeyEvent.KEYCODE_BACK))
		{ 
			Intent intent = new Intent();
			intent.setClass(HeyClockDetailActivity.this, HeyClockMainActivity.class);
			Bundle bundle = new Bundle();
			bundle.putBoolean("bset", false);	///< 取消了设置
			intent.putExtras(bundle);
			startActivity(intent);
			finish();
			overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
			return true; 
		}
		return super.onKeyDown(keyCode, event); 
	}

	/***
	 * 判断设置的闹钟时间是否合理
	 * @param _mHour
	 * @param _mMinute
	 * @return
	 */
	private boolean bSettimePlausible(int _mHour, int _mMinute)
	{
		final Calendar c = Calendar.getInstance();
		///< 获取到当前的时间，目的是判断一下设置的闹钟时间是不是已经是过去时间
		year = c.get(Calendar.YEAR);
		month = c.get(Calendar.MONTH);
		realmDay = day = c.get(Calendar.DATE);
		week = c.get(Calendar.DAY_OF_WEEK);
		timeStr = year + "-" + (month+1) + "-" + day + " " + _mHour + ":"
				+ _mMinute;
		if (HC_Time.TimePassed(timeStr))
		{
			///< 重新调整闹钟时间
			timeStr = year + "-" + (month + 1) + "-" + (day + 1) + " " + _mHour + ":"
					+ _mMinute;
			return false;
		}
		return true;
	}

	/**
	 * 把重复周期转换为字符串存储到数据库中
	 * @return
	 */
	private String getWhenTimeStr(boolean[] _whenTime)
	{
		String whenStr = "";
		for (int i = 0; i < _whenTime.length; ++i)
		{
			if (i == (_whenTime.length - 1))
			{
				whenStr += _whenTime[i] ? 1 : 0;
			}
			else
			{
				whenStr += (_whenTime[i] ? (1 + "#"): (0 + "#"));
			}
		}

		return whenStr;
	}

	@Override
	protected void onDestroy() 
	{
		super.onDestroy();
		///< 把来回反复调用的动画停止下来
		if (null != titleImg)
		{
			titleImg.clearAnimation();
		}
	}
}
