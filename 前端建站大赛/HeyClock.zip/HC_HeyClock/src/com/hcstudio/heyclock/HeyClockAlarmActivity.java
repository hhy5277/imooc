package com.hcstudio.heyclock;

import com.iflytek.cloud.RecognizerListener;
import com.iflytek.cloud.RecognizerResult;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechRecognizer;
import com.iflytek.cloud.SpeechUtility;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;

public class HeyClockAlarmActivity extends Activity
{
	protected static final String TAG = null;
	/**
	 * MediaPlayer - 播放响铃
	 */
	private MediaPlayer alarmMusic;
	/**
	 * 监听逻辑
	 */
	private boolean bIsGetResult = false;

	/**
	 * 语音识别模块
	 */
	private SpeechRecognizer malt = null;
	@SuppressWarnings("unused")
	private SpeechRecognizer mAsr = null;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		///< 加载指定音乐，并为之创建MediaPlayer对象
		alarmMusic = MediaPlayer.create(this, R.raw.complete);
		alarmMusic.setLooping(true);
		///< 播放音乐
		alarmMusic.start();

		/**
		 * 启动语音服务
		 */
		///< 初始化【科大讯飞】语音配置对象
		SpeechUtility.createUtility(this, SpeechConstant.APPID +"=550a4c81");
		OnInitial();
		
		///< 创建一个对话框
		new AlertDialog.Builder(HeyClockAlarmActivity.this)
		.setTitle("闹钟")
		.setCancelable(false)
		.setMessage("闹钟响了," + getIntent().getExtras().getString("name"))
		.setPositiveButton(
				"确定" ,
				new OnClickListener()
				{
					@Override
					public void onClick(DialogInterface dialog , int which)
					{
						///< 停止音乐
						alarmMusic.stop();
						///< 停止监听
						if (null != malt)
						{
							malt.stopListening();
							malt = null;
						}
						///< 结束该Activity
						HeyClockAlarmActivity.this.finish();
					}
				}).show();
	}
	
	/**
	 * 初始化
	 */
	private void OnInitial()
	{
		///< 1.创建SpeechRecognizer对象，第二个参数： 本地听写时传InitListener
		malt = SpeechRecognizer.createRecognizer(this, null);
		///< 2.设置听写参数，详见《科大讯飞MSC API手册(Android)》 SpeechConstant类
		malt.setParameter(SpeechConstant.DOMAIN, "iat"); 	 	///< 设置应用领域
		malt.setParameter(SpeechConstant.LANGUAGE, "zh_cn"); 	///< 设置返回结果的语言 en_us
		malt.setParameter(SpeechConstant.ACCENT, "mandarin ");	///< 用于设置语言区域
		malt.startListening(mRecoListener);
		//mAsr.startListening(mRecoListener);
		//Toast.makeText(this, "start listener", Toast.LENGTH_SHORT).show();
		
		//		///< 1.创建 SpeechRecognizer 对象，需传入初始化监听器
		//		mAsr = SpeechRecognizer.createRecognizer(this, mInitListener);
		//		///< 	初始化监听器，只有在使用本地语音服务时需要监听（即安装讯飞语音+，通过语音+提供本地
		//		///< 	服务）， 初始化成功后才可进行本地操作。
		//
		//		///< 2.构建语法（本地识别引擎目前仅支持 BNF 语法）， 同在线语法识别 请参照 Demo。
		//		///< 3.开始识别,设置引擎类型为本地
		//		mAsr.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_LOCAL);
		//		///< 	设置本地识别使用语法 id(此 id 在语法文件中定义)、 门限值
		//		mAsr.setParameter(SpeechConstant.LOCAL_GRAMMAR, "call");
		//		mAsr.setParameter(SpeechConstant.MIXED_THRESHOLD, "30"); 
	}
	
	/**
	 * 听写监听器
	 */
	private RecognizerListener mRecoListener = new RecognizerListener()
	{
		//听写结果回调接口(返回Json格式结果，用户可参见附录12.1)；
		//一般情况下会通过onResults接口多次返回结果，完整的识别内容是多次结果的累加；
		//关于解析Json的代码可参见MscDemo中JsonParser类；
		//isLast等于true时会话结束。
		public void onResult(RecognizerResult results, boolean isLast)
		{
			Log.i(TAG, "HHH rrr "+ results.getResultString ());
			if (results.getResultString ().contains("黑") ||
					results.getResultString ().contains("嘿"))
			{
				//Toast.makeText(HeyClockAlarmActivity.this, "识别到hei发音 ", Toast.LENGTH_SHORT).show();
				bIsGetResult = true;
				
				if (null != malt)
				{
					malt.stopListening();
					malt = null;
				}
				///< 停止音乐
				alarmMusic.stop();
				///< 结束该Activity
				HeyClockAlarmActivity.this.finish();
			}
			//Toast.makeText(HeyClockAlarmActivity.this, "" + results.getResultString (), Toast.LENGTH_SHORT).show();
		}

		///< 会话发生错误回调接口
		public void onError(SpeechError error) 
		{
			Log.i(TAG, "HHH -1-1-1 onError ");
			//Toast.makeText(HeyClockAlarmActivity.this, "" + error.getErrorDescription(), Toast.LENGTH_SHORT).show();
			error.getPlainDescription(true); 
		}

		///< 开始录音
		public void onBeginOfSpeech() 
		{
			Log.i(TAG, "HHH 000 onBeginOfSpeech ");
		}

		///< 音量值0~30
		public void onVolumeChanged(int volume)
		{
			//Log.i(TAG, "HHH 111 onVolumeChanged " + volume);
		}

		///< 结束录音
		public void onEndOfSpeech() 
		{
			Log.i(TAG, "HHH 222 onEndOfSpeech ");
			if (!bIsGetResult)
			{
				if (null != malt)
				{
					malt.stopListening();
					malt = null;
				}
				///< 1.创建SpeechRecognizer对象，第二个参数： 本地听写时传InitListener
				malt = SpeechRecognizer.createRecognizer(HeyClockAlarmActivity.this, null);
				///< 2.设置听写参数，详见《科大讯飞MSC API手册(Android)》 SpeechConstant类
				malt.setParameter(SpeechConstant.DOMAIN, "iat"); 	 	///< 设置应用领域
				malt.setParameter(SpeechConstant.LANGUAGE, "zh_cn"); 	///< 设置返回结果的语言 en_us
				malt.setParameter(SpeechConstant.ACCENT, "mandarin ");	///< 用于设置语言区域
				malt.startListening(mRecoListener);
			}
		}

		///<扩展用接口
		public void onEvent(int eventType, int arg1, int arg2, Bundle obj) 
		{}
	};
}