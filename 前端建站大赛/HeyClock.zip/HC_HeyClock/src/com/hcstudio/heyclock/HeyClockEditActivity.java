package com.hcstudio.heyclock;

import java.util.Arrays;
import java.util.Calendar;

import com.hcstudio.common.HeyClockScene;
import com.hcstudio.core.HC_Clock;
import com.hcstudio.core.HC_DbHelper;
import com.hcstudio.core.HC_Time;
import com.hcstudio.core.HC_Toast;
import com.hcstudio.core.HC_Toast.GRAVITY;
import com.hcstudio.item.HCD_GridviewItem;
import com.hcstudio.receiver.HeyClockAlarmReceiver;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Service;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnMultiChoiceClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import roboguice.activity.RoboActivity;
import roboguice.inject.InjectView;

public class HeyClockEditActivity extends RoboActivity implements OnClickListener
{
	@InjectView(R.id.hcd_settime_btn)		///< 设置时间
	private TextView settime_btn;
	@InjectView(R.id.hcd_detail_when_tv)	///< 何时发生 - 哪天重复 
	private TextView detail_when_tv;
	@InjectView(R.id.hcd_setcancel_btn)		///< 设置取消
	private Button setcancel_btn;
	@InjectView(R.id.hcd_setok_btn)			///< 设置确定
	private Button setok_btn;
	@InjectView(R.id.hcd_detail_name_et)	///< 闹钟名称
	private EditText detail_name_et;

	/**
	 * 时间对话框相关
	 */
	private int mHour;
	private int mMinute;
	private boolean is24HourView = true;
	private static final int DATE_DIALOG_ID = 0;
	/**
	 * 从主界面过来的
	 * true - 用户修改过时间以后需要重新设置时间，取消之前的闹钟，重新设置，同时更新数据库；
	 * false - 用户如果之前就没有设置过闹钟，那么直接更新数据库就行；
	 */
	private boolean bset;	
	/**
	 * 从主界面过来的 - 闹钟信息
	 */
	private HCD_GridviewItem user = null;

	/**
	 * 重复对话框相关
	 */
	private String[] whenStr = new String[] { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
	private ListView whenlv;
	private String detail_when_title = "";
	private HCD_GridviewItem setTimeIntent = null;
	private boolean[] whenTime = null;

	/**
	 * 闹钟相关 - 测试
	 */
	@SuppressWarnings("unused")
	private AlarmManager aManager = null;  
	private String timeStr = "";
	private int year = -1;
	private int month = -1;
	@SuppressWarnings("unused")
	private int week = -1;
	private int day = -1;
	private int realmDay = -1;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		///< 自定义标题
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.activity_hey_clock_detail);
		///< 设置标题为某个layout
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.hey_common_titlebar);

		OnInitial();
		registerListener();
	}

	/**
	 * 初始化
	 */
	private void OnInitial()
	{
		Intent intent = this.getIntent(); 
		bset =  (boolean) intent.getExtras().get("bset");
		///< 如果用户设置了闹钟，则会增加一个新的条目 - 退出的时候添加到数据库，避免每次都从数据库里面查询【不知道是不是这样的性能细节???】
		user = (HCD_GridviewItem)intent.getSerializableExtra("setintent");

		///< 显示用户之前设置的时间
		mHour = user.getHourOfDay();
		mMinute = user.getMinute();
		updateDisplay();

		///< 初始化闹钟名称
		detail_name_et.setText(user.getClockName());

		///< 获取抬头
		detail_when_title = detail_when_tv.getText().toString();
		whenTime = new boolean[7];
		Arrays.fill(whenTime, false);

		///< 设置当前场景为设置编辑场景 - 以后再看有没有用
		HeyClockScene.setEditScene();

		///< 获取AlarmManager对象  
		aManager = (AlarmManager) getSystemService(Service.ALARM_SERVICE);  
	}

	/**
	 * 注册监听事件
	 */
	private void registerListener()
	{
		settime_btn.setOnClickListener(this);
		///< TODO @完善 重复功能以后慢慢添加
		//detail_when_tv.setOnClickListener(this);
		setcancel_btn.setOnClickListener(this);
		setok_btn.setOnClickListener(this);
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onClick(View v) 
	{
		///< 设置时间
		if (v.equals(settime_btn))
		{
			/**
			 * 创建对话框 - A原始的方式
			 */
			showDialog(DATE_DIALOG_ID);
		}
		///< 设置哪天发生
		else if (v.equals(detail_when_tv))
		{
			showWhenMultiChoiceItems();
		}
		///< 取消设置
		else if (v.equals(setcancel_btn))
		{
			///< 销毁数据 - 习惯而已
			whenStr = null;
			whenTime = null;

			Intent intent = new Intent();
			intent.setClass(HeyClockEditActivity.this, HeyClockMainActivity.class);
			Bundle bundle = new Bundle();
			bundle.putBoolean("bset", false);	///< 取消了设置
			intent.putExtras(bundle);
			startActivity(intent);
			finish();
			overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
		}
		///< 确定设置
		else if (v.equals(setok_btn))
		{
			//			setTimeIntent.setClockName(detail_name_et.getText().toString());
			//			setTimeIntent.setHourOfDay(mHour);
			//			setTimeIntent.setMinute(mMinute);
			//			setTimeIntent.setWhenTime(whenTime);
			///< 获得输入闹钟名称 - 没有则获取默认值
			String clkTemp = detail_name_et.getText().toString();
			String clkName = detail_name_et.getText().toString().substring(0, clkTemp.length());
			///< 判断是否输入闹钟名称
			if(null == clkName || clkName.equals(""))
			{
				//HC_Toast.makeToastSimple(this, "请设置不重名的闹钟名称!", true, GRAVITY.CENTER);
				//return;
				clkName = detail_name_et.getHint().toString();
			}
			///< 设置实际发生的那天 - 实际设置过程中，用户可能会设置过去时间
			///< 判断选择的时间是否过期
			if (!bSettimePlausible(mHour, mMinute))
			{
				realmDay += 1;
				//				timeStr = "";
				//				HC_Toast.makeToastSimple(this, "时光倒流了!", true, GRAVITY.CENTER);
				//				return;
			}
			/*TODO【需要完成重复周期，暂时不考虑，有点复杂】 ///< week     1 - 周天  2 - 周一 3 - 周二 。。。。 7  - 周六
			///< week-1   0 - 周天   1 - 周一  2 周二  6 5 周五  6 周六
			if (whenTime[week - 1])	///< 如果当天被选中了
			{
				///< 设置实际发生的那天 - 实际设置过程中，用户可能会设置过去时间
				///< 判断选择的时间是否过期
				if (!bSettimePlausible(mHour, mMinute))
				{
					realmDay += 1;
					//				timeStr = "";
					//				HC_Toast.makeToastSimple(this, "时光倒流了!", true, GRAVITY.CENTER);
					//				return;
				}
			}
			///< 否则计算临近的那一天
			else
			{

			}*/

			///< 插入到数据库中
			///< timeStr是判断日期拼接的设置的时间字符串 - 这里将作为数据库条目数据
			if (timeStr.equals(""))
			{
				HC_Toast.makeToastSimple(this, "出错了...", true, GRAVITY.CENTER);
				return;
			}

			///< @未封装 - 设置闹钟
			/*///< @a闹钟时间设置
			final Calendar c = Calendar.getInstance();  
			///< @b设置闹铃的时间(年,月,日,时,分,秒)
			c.set(year, month, day, mHour, mMinute, 0);
			///< 指定启动AlarmActivity组件  
			Intent intentClk = new Intent(HeyClockDetailActivity.this, 
					HeyClockAlarmReceiver.class); 
			intentClk.setAction(realName);
			///< 创建PendingIntent对象  
			PendingIntent pi = PendingIntent.getBroadcast(  
					HeyClockDetailActivity.this, 0, intentClk, 0); 

			///< 设置AlarmManager将在Calendar对应的时间启动指定组件  
			aManager.set(AlarmManager.RTC_WAKEUP  ///< POWER_OFF_WAKEUP - 不支持关机闹钟
					, c.getTimeInMillis(), pi); 
			//			///< 设置闹钟重复时间
			//			aManager.setRepeating(AlarmManager.RTC_WAKEUP,
			//					c.getTimeInMillis(), 10 * 1000, pi);*/
			///<  如果用户之前是设置过时间的，那么依然遵从用户的选择；同时需要更新数据库
			if (bset)
			{
				///< 取消之前的闹钟
				HC_Clock.cancelClock(HeyClockEditActivity.this, 
						HeyClockAlarmReceiver.class,
						user.getClockName());
				///< @封装 - 设置闹钟   realmDay - 表示如果设置的时间是过去时间，则自动加一天
				HC_Clock.setClock(HeyClockEditActivity.this, 
						HeyClockAlarmReceiver.class, 
						clkName, year, 
						month, realmDay, mHour, 
						mMinute, 0);
				///< 更新数据库-闹钟实际的名称
				HC_DbHelper.getInstance(HeyClockEditActivity.this).
				updateWithPrimaryKey( 
						user.getClockName(),
						clkName,
						timeStr, 
						getWhenTimeStr(whenTime),
						bset);
			}
			else
			{
				///< 如果用户之前没有设置过闹钟，就什么都不做；只是更新数据库
				///< 闹钟实际的名称
				HC_DbHelper.getInstance(HeyClockEditActivity.this).
				updateWithPrimaryKey(
						user.getClockName(),
						clkName,
						timeStr, 
						getWhenTimeStr(whenTime),
						bset);
			}

			///< 调整并携带信息 - 之后改为存到数据库中 - 暂时用不到
			setTimeIntent = new HCD_GridviewItem(
					mHour, 
					mMinute, 
					clkName,
					whenTime);
			Intent intent = new Intent();
			intent.setClass(HeyClockEditActivity.this, HeyClockMainActivity.class);
			Bundle bundle = new Bundle();
			bundle.putBoolean("bset", true);	///< 设置上了
			bundle.putSerializable("setintent", setTimeIntent);
			intent.putExtras(bundle);
			startActivity(intent);
			finish();
			overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
		}
	}

	/**
	 * 更新显示的时间视图
	 */
	private void updateDisplay()
	{
		StringBuilder strB = new StringBuilder();
		if (is24HourView)
		{
			if (mHour < 10)
			{
				strB.append("0" + mHour).append(":");
			}
			else
			{
				strB.append(mHour).append(":");
			}
			if (mMinute < 10)
			{
				strB.append("0" + mMinute);
			}
			else
			{
				strB.append(mMinute);
			}
			settime_btn.setText(strB);
		}
		else
		{

		}
	}

	/**
	 * 时间选择框
	 */
	private TimePickerDialog.OnTimeSetListener mDateSetListener = new TimePickerDialog.OnTimeSetListener() 
	{
		@Override
		public void onTimeSet(TimePicker view, int hourOfDay, int minute) 
		{
			mHour = hourOfDay;
			mMinute = minute;
			updateDisplay();
		}        
	};

	/**
	 * 创建对话框 - A原始的方式
	 */
	protected Dialog onCreateDialog(int id) 
	{    
		switch (id)
		{    
		case DATE_DIALOG_ID:       
			return new TimePickerDialog(this, mDateSetListener, mHour, mMinute, is24HourView);
		}    
		return null;
	}

	/**
	 * 何时发生对话框
	 */
	private void showWhenMultiChoiceItems()
	{
		AlertDialog builder = new AlertDialog.Builder(this)
		.setTitle("请选择重复的日子")
		.setMultiChoiceItems(whenStr,
				new boolean[] { false, false, false, false, false , false, false},
				new OnMultiChoiceClickListener()
		{

			@Override
			public void onClick(DialogInterface dialog,
					int which, boolean isChecked)
			{

			}
		})
		.setPositiveButton("确定", new DialogInterface.OnClickListener()
		{

			@Override
			public void onClick(DialogInterface dialog, int which)
			{
				///< 获取哪些天被设置了
				//whenTime = whenlv.getCheckedItemPositions();
				if (null == whenTime)
				{
					whenTime = new boolean[7];
					Arrays.fill(whenTime, false);
				}
				for (int i = 0; i < whenlv.getCheckedItemPositions().size(); ++i)
				{
					whenTime[i] = whenlv.getCheckedItemPositions().get(i);
				}

				///< Everyday
				if (whenlv.getCheckedItemPositions().size() == 7)
				{
					detail_when_tv.setText(detail_when_title + "\n" + "每天");
				}
				///< 工作日
				else if (whenlv.getCheckedItemPositions().size() == 5 && !whenlv.getCheckedItemPositions().get(5) && !whenlv.getCheckedItemPositions().get(6))
				{
					detail_when_tv.setText(detail_when_title + "\n" + "工作日");
				}
				///< 周末
				else if (whenlv.getCheckedItemPositions().size() == 2 && whenlv.getCheckedItemPositions().get(5) && whenlv.getCheckedItemPositions().get(6))
				{
					detail_when_tv.setText(detail_when_title + "\n" + "周末");
				}
				///< 什么都不做
				else if (whenlv.getCheckedItemPositions().size() <= 0)
				{

				}
				///< 选择了其它
				else 
				{
					String s = "";
					///< 扫描所有的列表项，如果当前列表项被选中，将列表项的文本追加到s变量中。
					for (int i = 0; i < whenStr.length; i++)
					{
						if (whenlv.getCheckedItemPositions().get(i))
						{
							s  += whenlv.getAdapter().getItem(i) + " ";
						}
					}
					detail_when_tv.setText(detail_when_title + "\n" + s);
				}
				///< 网上的demo
				//				String s = "您选择了：";
				//				///< 扫描所有的列表项，如果当前列表项被选中，将列表项的文本追加到s变量中。
				//				for (int i = 0; i < whenStr.length; i++)
				//				{
				//					if (whenlv.getCheckedItemPositions().get(i))
				//					{
				//						s += i + ":" + whenlv.getAdapter().getItem(i) + " ";
				//					}
				//				}
				//
				//				///< 用户至少选择了一个列表项
				//				if (whenlv.getCheckedItemPositions().size() > 0)
				//				{
				//					new AlertDialog.Builder(HeyClockDetailActivity.this)
				//					.setMessage(s).show();
				//					System.out.println(whenlv.getCheckedItemPositions().size());
				//				}
				//
				//				///< 用户未选择任何列表项
				//				else if(whenlv.getCheckedItemPositions().size() <= 0 )
				//				{
				//					new AlertDialog.Builder(HeyClockDetailActivity.this)
				//					.setMessage("您未选择任何省份").show();
				//				}
			}
		}).setNegativeButton("取消", null).create();

		whenlv = builder.getListView();
		builder.show();
	}

	//	/**
	//	 * 监听Back键按下事件,方法1:
	//	 * 注意:
	//	 * super.onBackPressed()会自动调用finish()方法,关闭
	//	 * 当前Activity.
	//	 * 若要屏蔽Back键盘,注释该行代码即可
	//	 */ 
	//	@Override 
	//	public void onBackPressed() 
	//	{ 
	//		super.onBackPressed(); 
	//		Intent intent = new Intent();
	//		intent.setClass(HeyClockDetailActivity.this, HeyClockMainActivity.class);
	//		finish();
	//		overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
	//	} 

	/**
	 * 监听Back键按下事件,方法2:
	 * 注意:
	 * 返回值表示:是否能完全处理该事件
	 * 在此处返回false,所以会继续传播该事件.
	 * 在具体项目中此处的返回值视情况而定.
	 */ 
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	{
		if ((keyCode == KeyEvent.KEYCODE_BACK))
		{ 
			Intent intent = new Intent();
			intent.setClass(HeyClockEditActivity.this, HeyClockMainActivity.class);
			Bundle bundle = new Bundle();
			bundle.putBoolean("bset", false);	///< 取消了设置
			intent.putExtras(bundle);
			startActivity(intent);
			finish();
			overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
			return true; 
		}
		return super.onKeyDown(keyCode, event); 
	}

	/***
	 * 判断设置的闹钟时间是否合理
	 * @param _mHour
	 * @param _mMinute
	 * @return
	 */
	private boolean bSettimePlausible(int _mHour, int _mMinute)
	{
		//		final Calendar c = Calendar.getInstance();
		///< 获取到当前的时间，目的是判断一下设置的闹钟时间是不是已经是过去时间
		//		year = c.get(Calendar.YEAR);
		//		month = c.get(Calendar.MONTH);
		//		realmDay = day = c.get(Calendar.DATE);
		//		week = c.get(Calendar.DAY_OF_WEEK);
		year = user.getYear();
		month = user.getMonth() - 1;
		realmDay = day = user.getDay();
		timeStr = year + "-" + (month + 1) + "-" + day + " " + _mHour + ":"
				+ _mMinute;
		if (HC_Time.TimePassed(timeStr))
		{
			final Calendar c = Calendar.getInstance();
			///< 获取到当前的时间; 如果用户编辑的闹钟已经过期了，那么以当前时间作为最新的时间...
			year = c.get(Calendar.YEAR);
			month = c.get(Calendar.MONTH);
			realmDay = day = c.get(Calendar.DATE);
			///< 重新调整闹钟时间
			timeStr = year + "-" + (month + 1) + "-" + day + " " + _mHour + ":"
					+ _mMinute;
			///< 如果还过期，再加一天； 【容错，处理实时性问题】
			if (HC_Time.TimePassed(timeStr))
			{
				timeStr = year + "-" + (month + 1) + "-" + (day + 1) + " " + _mHour + ":"
						+ _mMinute;
				return false;
			}
			else
			{
				return true;
			}
		}
		return true;
	}

	/**
	 * 把重复周期转换为字符串存储到数据库中
	 * @return
	 */
	private String getWhenTimeStr(boolean[] _whenTime)
	{
		String whenStr = "";
		for (int i = 0; i < _whenTime.length; ++i)
		{
			if (i == (_whenTime.length - 1))
			{
				whenStr += _whenTime[i] ? 1 : 0;
			}
			else
			{
				whenStr += (_whenTime[i] ? (1 + "#"): (0 + "#"));
			}
		}

		return whenStr;
	}

	@Override
	protected void onDestroy() 
	{
		super.onDestroy();
	}
}
