package com.hcstudio.heyclock;

import java.util.ArrayList;
import java.util.Calendar;

import com.baidu.mobstat.StatService;
import com.hcstudio.adapter.HCM_GridviewAdapter;
import com.hcstudio.adapter.HCM_GridviewClickListener;
import com.hcstudio.adapter.HCM_GridviewLongClickListener;
import com.hcstudio.common.HeyClockScene;
import com.hcstudio.core.HC_DbHelper;
import com.hcstudio.core.HC_LOG;
import com.hcstudio.core.HC_Screen;
import com.hcstudio.item.XSL_Sentence;
import com.hcstudio.pull.HeyClockBaiduWeatherParas;
import com.hcstudio.pull.HeyClockFunctionPullIMGV;
import com.hcstudio.pull.HeyClockLocationPullTitle;
import com.hcstudio.pull.HeyClockBaiduWeatherParas.HeyClockBaiduWeatherParasInterface;
import com.hcstudio.service.HeyClockServiceControl;
import com.hcstudio.ui.XSL_VerticalScrollTextView;
import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.RecognizerListener;
import com.iflytek.cloud.RecognizerResult;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechRecognizer;

import roboguice.activity.RoboActivity;
import roboguice.inject.InjectView;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.app.AlarmManager;
import android.app.Service;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

public class HeyClockMainActivity extends RoboActivity implements OnClickListener 
{
	protected static final String TAG = "HeyClock";

	/*@InjectView(R.id.editText)
	private EditText edit;*/
	/*@InjectView(R.id.button_start)
	private Button start;*/
	/*@InjectView(R.id.button_settime)
	private Button settime;*/
	@InjectView(R.id.hcm_clock_griV)		///< 闹钟条目
	private GridView clock_griV;
	@InjectView(R.id.hcm_menu_btn)			///< 菜单按钮
	private Button menu_btn;
	@InjectView(R.id.hcm_nettip_btn)		///<   --网络提醒
	private Button nettip_btn;
	@InjectView(R.id.hcm_function_btns)		///< 功能区按钮
	private LinearLayout function_btns;
	@InjectView(R.id.hcm_menu_relayout)		///< 功能区布局
	private RelativeLayout menu_relayout;	
	@InjectView(R.id.hcm_function_image)	///< 功能区图片功能 - 用作推送幽默图片
	private ImageView function_image;
	//	@InjectView(R.id.hcm_tileBar)		/// 界面标题栏和ScrollTextView，无法靠以来注入拿到，你懂的...
	private RelativeLayout tileBar;
	private com.hcstudio.ui.XSL_VerticalScrollTextView titleSTv;

	/**
	 * UI动画相关
	 */
	private boolean bmenu_btnOpen = true;
	private Animation translateAnimationDown;
	private Animation translateAnimationUp;
	private AlphaAnimation animationIn;
	private AlphaAnimation animationOut;
	private RotateAnimation rotate360;
	private RotateAnimation rrotate360;

	/**
	 * 闹钟条目
	 */
	private HCM_GridviewAdapter hcmGriVAdatper = null;
	private ArrayList<String> hcmNameList = new ArrayList<String>();
	private ArrayList<String> hcmDateList = new ArrayList<String>();
	private ArrayList<Drawable> hcmDrawableList = new ArrayList<Drawable>();
	private ArrayList<Drawable> hcmDrawablePressedList = new ArrayList<Drawable>();
	private ArrayList<Drawable> hcmDrawableLongPressedList = new ArrayList<Drawable>();
	private ArrayList<Integer> hcmEnable = new ArrayList<Integer>();

	/**
	 * 监听逻辑
	 */
	//	private boolean bIsStart = true;
	private boolean bIsGetResult = false;

	/**
	 * 语音识别模块
	 */
	private SpeechRecognizer malt = null;
	@SuppressWarnings("unused")
	private SpeechRecognizer mAsr = null;

	/**
	 * 闹钟模块
	 */
	@SuppressWarnings("unused")
	private Calendar currentTime = Calendar.getInstance();
	@SuppressWarnings("unused")
	private AlarmManager aManager = null;  
	
	/**
	 * 天气模块
	 */
	///< 天气模块图片链接、当天、明天、后天
	private String[] weatherPng = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		///< 自定义标题
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.activity_hey_clock_main);
		///< 设置标题为某个layout
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.hey_hcm_titlebar);

		OnInitial();
		resetLayout();
		registerListener();
		getServiceData();
	}

	/**
	 * 获取由服务提供 - 解析得到的数据【原始是registerService for 注册百度统计服务的，挪到application中去了...】
	 */
	private void getServiceData()
	{
		/*///< 设置Appkey - 放到Application里面去....
		StatService.setAppKey("fe6475b938");
		StatService.setAppChannel(HeyClockMainActivity.this, "HCSTUDIO", true);
		StatService.setSessionTimeOut(30);
		StatService.setOn(HeyClockMainActivity.this, StatService.EXCEPTION_LOG);
		StatService.setLogSenderDelayed(10);
		StatService.setSendLogStrategy(HeyClockMainActivity.this, SendStrategyEnum.APP_START, 1, false);
		StatService.setDebugOn(true);*/
		tileBar = (RelativeLayout) findViewById(R.id.hcm_tileBar);
		//		android.view.ViewGroup.LayoutParams pp = tileBar.getLayoutParams();
		//		tileBar.getLayoutParams();
		//		pp.height = 180;
		//		tileBar.setLayoutParams(pp);
		titleSTv = (XSL_VerticalScrollTextView) tileBar.findViewById(R.id.hcm_titleSTv);
		
		///< 定位后获取天气
		HeyClockBaiduWeatherParas.GetWeater(new HeyClockBaiduWeatherParasInterface()
		{
			@Override
			public void action(String weatherInf) 
			{
				HC_LOG.openLog();
				HC_LOG.console(weatherInf, "\n天气");
				HC_LOG.closeLog();
				
				ArrayList<XSL_Sentence> lst = new ArrayList<XSL_Sentence>();
				if (weatherInf.equals("解析天气失败"))
				{
					XSL_Sentence sen = new XSL_Sentence(0, "解析天气失败");
					lst.add(0, sen);
					titleSTv.setList(lst);
					titleSTv.updateUI();
					return;
				}
				else if (weatherInf.equals("暂无天气信息"))
				{
					XSL_Sentence sen = new XSL_Sentence(0, "暂无天气信息");
					lst.add(0, sen);
					titleSTv.setList(lst);
					titleSTv.updateUI();
					return;
				}
				else if (weatherInf.equals("获取天气信息失败"))
				{
					XSL_Sentence sen = new XSL_Sentence(0, "获取天气信息失败");
					lst.add(0, sen);
					titleSTv.setList(lst);
					titleSTv.updateUI();
					return;
				}
				
				String[] tmpF = weatherInf.split("#");
				
				///< 根据实际查询到的预报天数分配空间，当然默认是预报三天，但是考虑程序兼容性
				weatherPng = new String[tmpF.length];
				
				for (int j = 0, k = 0; j < 20; ++j)
				{
					for (int i = 0; i < tmpF.length; ++i)
					{
						String[] tmpS = tmpF[i].split("===");
						XSL_Sentence sen = new XSL_Sentence(k, tmpS[0] + " " + tmpS[2] + " " + tmpS[3] + " " + tmpS[4]);
						lst.add(k++, sen);
						
						///< 存储下天气信息图片链接，三天的
						weatherPng[i] = tmpS[1];
					}
				}
				
				titleSTv.setList(lst);
				titleSTv.updateUI();
			}
		});
	}

	/**
	 * 重置布局【自适应】
	 */
	private void resetLayout()
	{
		///< 由于无法设置按钮的宽高、所以这里如果动态设置了，按钮不知道怎么办【除非按钮是动态添加的】？所以还是通过不同的values-xxxx进行xml的配置
		//		LinearLayout.LayoutParams lp_menu_relayout = new LinearLayout.LayoutParams(
		//				ViewGroup.LayoutParams.MATCH_PARENT,
		//				(int) (HC_Screen.SCREEN_HEIGHT/4) - 3);
		//		menu_relayout.setLayoutParams(lp_menu_relayout);
		///< @1 根据用户设置，【重置】网络提醒按钮的背景颜色 - 类似布局
		if (1 == HeyClockServiceControl.getOpenNetTipFlag(HeyClockMainActivity.this))
		{
			nettip_btn.setBackgroundResource(R.drawable.hcm_menu_btnshape_selector_pressed);
		}
		///< @1.1 这里可以不用管，节省一些开支
		//		///< 如果之前未开启，则设置背景为未选中的背景状态
		//		else if (0 == HeyClockServiceControl.getOpenFlag(HeyClockMainActivity.this))
		//		{
		//			nettip_btn.setBackgroundResource(R.drawable.hcm_menu_btnshape_selector);
		//		}
	}

	/**
	 * 初始化
	 */
	private void OnInitial()
	{
		///< 1.创建SpeechRecognizer对象，第二个参数： 本地听写时传InitListener
		malt = SpeechRecognizer.createRecognizer(this, null);
		///< 2.设置听写参数，详见《科大讯飞MSC API手册(Android)》 SpeechConstant类
		malt.setParameter(SpeechConstant.DOMAIN, "iat"); 	 	///< 设置应用领域
		malt.setParameter(SpeechConstant.LANGUAGE, "zh_cn"); 	///< 设置返回结果的语言 en_us
		malt.setParameter(SpeechConstant.ACCENT, "mandarin ");	///< 用于设置语言区域

		//		///< 1.创建 SpeechRecognizer 对象，需传入初始化监听器
		//		mAsr = SpeechRecognizer.createRecognizer(this, mInitListener);
		//		///< 	初始化监听器，只有在使用本地语音服务时需要监听（即安装讯飞语音+，通过语音+提供本地
		//		///< 	服务）， 初始化成功后才可进行本地操作。
		//
		//		///< 2.构建语法（本地识别引擎目前仅支持 BNF 语法）， 同在线语法识别 请参照 Demo。
		//		///< 3.开始识别,设置引擎类型为本地
		//		mAsr.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_LOCAL);
		//		///< 	设置本地识别使用语法 id(此 id 在语法文件中定义)、 门限值
		//		mAsr.setParameter(SpeechConstant.LOCAL_GRAMMAR, "call");
		//		mAsr.setParameter(SpeechConstant.MIXED_THRESHOLD, "30");

		///< 获取AlarmManager对象  
		aManager = (AlarmManager) getSystemService(Service.ALARM_SERVICE); 

		///< 初始化动画
		AnimationInitial();

		///< 初始化屏幕信息 - 之后会放到开机动画中
		HC_Screen.getInstance(this).getScreenWH();

		///< 设置当前场景为主界面场景
		HeyClockScene.setMainScene();

		///< @本地测试 闹钟测试数据
		/*///< 页眉
		hcmNameList.add("test1");
		hcmNameList.add("test1");
		hcmNameList.add("test1");
		hcmNameList.add("test1");
		hcmNameList.add("test1");
		hcmNameList.add("test1");
		hcmNameList.add("test1");
		hcmNameList.add("test1");
		hcmNameList.add("test1");
		hcmNameList.add("test1");
		hcmEnable.add(0);
		hcmEnable.add(1);
		hcmEnable.add(0);
		hcmEnable.add(0);
		hcmEnable.add(1);
		hcmEnable.add(0);
		hcmEnable.add(1);
		hcmEnable.add(1);
		hcmEnable.add(0);
		hcmEnable.add(1);
		//hcmNameList.add("添加闹钟");
		hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
		hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
		hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
		hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
		hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
		hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
		hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
		hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
		hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
		hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
		hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
		hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
		hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
		hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
		hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
		hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
		hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
		hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
		hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
		hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
		//hcmDrawableList.add(getResources().getDrawable(R.drawable.hcmgrv_add));

		///< 只有从设置详情场景过来，才会走这里
		if (HeyClockScene.IsDetailScene())
		{
			Intent intent = this.getIntent(); 
			boolean bset =  (boolean) intent.getExtras().get("bset");
			///< 如果用户设置了闹钟，则会增加一个新的条目 - 退出的时候添加到数据库，避免每次都从数据库里面查询【不知道是不是这样的性能细节???】
			if (bset)
			{
				HCD_GridviewItem user = (HCD_GridviewItem)intent.getSerializableExtra("setintent");
				///< 页心
				hcmNameList.add(user.getClockName());
				hcmEnable.add(0);
				hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
				hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
				Toast.makeText(this, "" + user.getClockName() + user.getHourOfDay() + user.getMinute() + user.getWhenTime().length, Toast.LENGTH_SHORT).show();
			}
			else
			{
				Toast.makeText(this, "取消设置", Toast.LENGTH_SHORT).show();
			}
		}

		///< 页脚
		hcmNameList.add("添加闹钟");
		hcmDrawableList.add(getResources().getDrawable(R.drawable.hcmgrv_add));
		hcmGriVAdatper = new HCM_GridviewAdapter(HeyClockMainActivity.this, hcmNameList, hcmDrawableList, hcmDrawablePressedList, hcmEnable);
		clock_griV.setAdapter(hcmGriVAdatper);*/

		///< 查询闹钟数据库信息，获取设置的闹钟条目
		Cursor cursor = HC_DbHelper.getInstance(HeyClockMainActivity.this).query();
		while (cursor.moveToNext())
		{
			//			String timerName = cursor.getString(0);
			//			String dateStr = cursor.getString(1);
			//			String Open = cursor.getString(2);
			//			String WHENTIME = cursor.getString(3);
			//			String tdow = timerName + " " + dateStr + " " + Open + " " + WHENTIME;
			//			Toast.makeText(this, tdow, Toast.LENGTH_SHORT).show();

			hcmNameList.add(cursor.getString(0));
			hcmDateList.add(cursor.getString(1));
			hcmEnable.add(Integer.valueOf(cursor.getString(2)));
			hcmDrawableList.add(getResources().getDrawable(R.drawable.test01));
			hcmDrawablePressedList.add(getResources().getDrawable(R.drawable.test01_pressed));
			hcmDrawableLongPressedList.add(getResources().getDrawable(R.drawable.test01_longpress));
		}
		HC_DbHelper.getInstance(HeyClockMainActivity.this).closeCursor();
		HC_DbHelper.getInstance(HeyClockMainActivity.this).closeDatabase();

		///< 页脚
		hcmNameList.add("添加闹钟");
		hcmDrawableList.add(getResources().getDrawable(R.drawable.hcmgrv_add));
		hcmGriVAdatper = new HCM_GridviewAdapter(HeyClockMainActivity.this, 
				hcmNameList, hcmDateList, 
				hcmDrawableList, hcmDrawablePressedList, 
				hcmDrawableLongPressedList, hcmEnable);
		clock_griV.setAdapter(hcmGriVAdatper);
		///< 去除掉点击时的黄色背景
		clock_griV.setSelector(new ColorDrawable(Color.TRANSPARENT));

		///< 启动幽默图片拉取机制
		HeyClockFunctionPullIMGV.getInstance(HeyClockMainActivity.this).setImageControl(function_image);
	}

	/**
	 * 动画初始化 - 已经在OnInitial()中调用
	 */
	private void AnimationInitial()
	{
		///< 初始化 -功能区菜单向下动动画  ---> getResources().getDimension(R.dimen.px180)表示按钮尺寸，这样做动画的位置才能得到很好的控制
		translateAnimationDown = new TranslateAnimation(0.1f, 0.1f, 0.1f, getResources().getDimension(R.dimen.px180));  
		///< 设置动画时间                
		translateAnimationDown.setDuration(1000);  
		translateAnimationDown.setFillAfter(true); 
		translateAnimationDown.setAnimationListener(new AnimationListener() 
		{
			@Override
			public void onAnimationStart(Animation animation)
			{
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationRepeat(Animation animation) 
			{
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation) 
			{
				///< 控件旋转，暂时不用，效果不好
				/*Animation rotateAnimation = new RotateAnimation(0f, 180f, menu_btn.getWidth()/2, menu_btn.getHeight()/2);  
                rotateAnimation.setDuration(1000);  
                rotateAnimation.setFillAfter(true);
                menu_relayout.startAnimation(rotateAnimation);*/

				///< 动态添加组件 - 暂时不用，麻烦！ 还是提交做好，到时候只需要做动画移动过来就行
				/*ImageView btn1 = new ImageView(HeyClockMainActivity.this);
				btn1.setImageResource(R.drawable.test01);
				btn1.setScaleType(ImageView.ScaleType.FIT_XY);

				//定义一个RelativeLayout组件
				RelativeLayout.LayoutParams lp1 = new RelativeLayout.LayoutParams(menu_relayout.getWidth() - menu_btn.getWidth() - 10, menu_btn.getHeight() - 10);
				//与父组件顶部对齐
				lp1.addRule(RelativeLayout.RIGHT_OF, R.id.hcm_menu_btn);
				//横向居中，是
				//lp1.addRule(RelativeLayout.CENTER_HORIZONTAL);
				//靠右
				lp1.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
				menu_relayout.addView(btn1, lp1);*/
				/** 设置透明度渐变动画 */ 
				function_image.startAnimation(animationOut);
				function_image.setVisibility(View.VISIBLE);
			}
		});

		///< 初始化 -功能区菜单向上移动动画
		translateAnimationUp = new TranslateAnimation(0.1f, 0.1f, getResources().getDimension(R.dimen.px180), 0.1f);  
		///< 设置动画时间                
		translateAnimationUp.setDuration(1000);  
		///< 做完动画后不恢复原位置
		translateAnimationUp.setFillAfter(true);

		/** 设置透明度渐变动画 */ 
		animationOut = new AlphaAnimation(0.2f, 0.8f); 
		animationOut.setDuration(2000);	///< 设置动画持续时间

		/** 设置透明度渐变动画 */ 
		animationIn = new AlphaAnimation(0.8f, 0.2f); 
		animationIn.setDuration(2000);	///< 设置动画持续时间 
		animationIn.setAnimationListener(new AnimationListener()
		{

			@Override
			public void onAnimationStart(Animation animation) 
			{
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationRepeat(Animation animation)
			{
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation)
			{
				// TODO Auto-generated method stub
				function_image.setVisibility(View.GONE);
			}
		});

		/** 设置旋转动画 */ 
		rotate360 = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		rotate360.setDuration(2000);	///< 设置动画持续时间 
		rotate360.setFillAfter(true);

		/** 设置反向旋转动画 */ 
		rrotate360 = new RotateAnimation(0, -360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		rrotate360.setDuration(2000);	///< 设置动画持续时间 
		rrotate360.setFillAfter(true);
	}

	/**
	 * 本地监听+讯飞语音+
	 */
	@SuppressWarnings("unused")
	private InitListener mInitListener = new InitListener()
	{
		public void onInit(int code)
		{
			if (code == ErrorCode.SUCCESS) 
			{
				Toast.makeText(HeyClockMainActivity.this, "success", Toast.LENGTH_SHORT).show();
			}
		}
	};

	/**
	 * 注册监听事件
	 */
	private void registerListener()
	{
		//		start.setOnClickListener(this);
		//settime.setOnClickListener(this);

		///< 闹钟条目监听事件
		clock_griV.setOnItemClickListener(new HCM_GridviewClickListener(HeyClockMainActivity.this));
		clock_griV.setOnItemLongClickListener(new HCM_GridviewLongClickListener(HeyClockMainActivity.this));
		menu_btn.setOnClickListener(this);
		nettip_btn.setOnClickListener(this);
	}

	/**
	 * 点击事件处理
	 */
	@Override
	public void onClick(View v) 
	{
		//		///<  开始按钮监听事件
		//		if (v.equals(start))
		//		{
		//			if (bIsStart)
		//			{
		//				bIsStart = false;
		//				///< 3.开始听写 mIat.startListening(mRecoListener);
		//				malt.startListening(mRecoListener);
		//				//mAsr.startListening(mRecoListener);
		//				Toast.makeText(this, "start listener", Toast.LENGTH_SHORT).show();
		//			}
		//			else
		//			{
		//				bIsStart = true;
		//				malt.stopListening();
		//				//mAsr.stopListening();
		//				Toast.makeText(this, "stop listener", Toast.LENGTH_SHORT).show();
		//			}
		//		}
		///< 菜单按钮事件
		if (v.equals(menu_btn))
		{
			if (bmenu_btnOpen)
			{
				bmenu_btnOpen = false;
				menu_btn.startAnimation(rotate360);
				function_btns.startAnimation(translateAnimationDown);
			}
			else
			{
				bmenu_btnOpen = true;
				///< 幽默图片预览消失 - 再还原功能区按钮
				function_image.startAnimation(animationIn);
				menu_btn.startAnimation(rrotate360);
				function_btns.startAnimation(translateAnimationUp);
			}
		}
		///< --网络提醒
		else if (v.equals(nettip_btn))
		{
			///< 如果是首次那么开启网络提醒功能
			if (-1 == HeyClockServiceControl.getOpenNetTipFlag(HeyClockMainActivity.this))
			{
				HeyClockServiceControl.setOpenNetTipFlag(HeyClockMainActivity.this, 1);
				HeyClockServiceControl.startNetTipService(HeyClockMainActivity.this);
				nettip_btn.setBackgroundResource(R.drawable.hcm_menu_btnshape_selector_pressed);

				///< 统计点击了多少次网络提醒
				StatService.onEvent(HeyClockMainActivity.this, "NetTip", "首次开启网络提醒", 1);
			}
			///< 如果之前已经开启，则关闭网络提醒功能
			else if (1 == HeyClockServiceControl.getOpenNetTipFlag(HeyClockMainActivity.this))
			{
				HeyClockServiceControl.setOpenNetTipFlag(HeyClockMainActivity.this, 0);
				HeyClockServiceControl.stopNetTipService(HeyClockMainActivity.this);
				nettip_btn.setBackgroundResource(R.drawable.hcm_menu_btnshape_selector);
			}
			///< 如果之前已经关闭，则开启网络提醒功能
			else if (0 == HeyClockServiceControl.getOpenNetTipFlag(HeyClockMainActivity.this))
			{
				HeyClockServiceControl.setOpenNetTipFlag(HeyClockMainActivity.this, 1);
				HeyClockServiceControl.startNetTipService(HeyClockMainActivity.this);
				nettip_btn.setBackgroundResource(R.drawable.hcm_menu_btnshape_selector_pressed);

				///< 统计点击了多少次网络提醒
				StatService.onEvent(HeyClockMainActivity.this, "NetTip", "开启网络提醒", 1);
			}
		}
		///< 设置时间
		/*else if (v.equals(settime))
		{
			currentTime = Calendar.getInstance(); 
			new TimePickerDialog(this, 0, new OnTimeSetListener()
			{
				@Override
				public void onTimeSet(TimePicker view, int hourOfDay, int minute) 
				{
					///< 指定启动AlarmActivity组件  
					Intent intent = new Intent(HeyClockMainActivity.this, 
							HeyClockAlarmReceiver.class);  
					///< 创建PendingIntent对象  
					PendingIntent pi = PendingIntent.getBroadcast(  
							HeyClockMainActivity.this, 0, intent, 0); 
					Calendar c = Calendar.getInstance();  
					c.setTimeInMillis(System.currentTimeMillis());
					///< 根据用户选择时间来设置Calendar对象  
					c.set(Calendar.HOUR_OF_DAY , hourOfDay);  
					c.set(Calendar.MINUTE , minute); 
					///< 设置AlarmManager将在Calendar对应的时间启动指定组件  
					aManager.set(AlarmManager.RTC_WAKEUP  ///< POWER_OFF_WAKEUP - 不支持关机闹钟
							, c.getTimeInMillis(), pi);   
					///< 显示闹铃设置成功的提示信息  
					Toast.makeText(HeyClockMainActivity.this ,   
							"闹铃设置成功啦", Toast.LENGTH_SHORT).show(); 
				}
			}, 
			currentTime.get(Calendar.HOUR_OF_DAY), 
			currentTime.get(Calendar.MINUTE), 
			true).show();
		}*/
	}
	
	/**
	 * 获取当天的天气信息预览图片
	 * @return
	 */
	public String getCurrentWeatherURL()
	{
		return ((weatherPng == null) ? "" : weatherPng[0]);
	}

	/**
	 * 听写监听器
	 */
	@SuppressWarnings("unused")
	private RecognizerListener mRecoListener = new RecognizerListener()
	{
		///< 听写结果回调接口(返回Json格式结果，用户可参见附录12.1)；
		///< 一般情况下会通过onResults接口多次返回结果，完整的识别内容是多次结果的累加；
		///< 关于解析Json的代码可参见MscDemo中JsonParser类；
		///< isLast等于true时会话结束。
		public void onResult(RecognizerResult results, boolean isLast)
		{
			Log.i(TAG, "HHH rrr "+ results.getResultString ());
			if (results.getResultString ().contains("黑") ||
					results.getResultString ().contains("嘿"))
			{
				Toast.makeText(HeyClockMainActivity.this, "识别到hei发音 ", Toast.LENGTH_SHORT).show();
				bIsGetResult = true;
			}
			Toast.makeText(HeyClockMainActivity.this, "" + results.getResultString (), Toast.LENGTH_SHORT).show();
		}

		///< 会话发生错误回调接口
		public void onError(SpeechError error) 
		{
			Log.i(TAG, "HHH -1-1-1 onError ");
			Toast.makeText(HeyClockMainActivity.this, "" + error.getErrorDescription(), Toast.LENGTH_SHORT).show();
			error.getPlainDescription(true); 
		}

		///< 开始录音
		public void onBeginOfSpeech() 
		{
			Log.i(TAG, "HHH 000 onBeginOfSpeech ");
		}

		///< 音量值0~30
		public void onVolumeChanged(int volume)
		{
			//Log.i(TAG, "HHH 111 onVolumeChanged " + volume);
		}

		///< 结束录音
		public void onEndOfSpeech() 
		{
			Log.i(TAG, "HHH 222 onEndOfSpeech ");
			if (!bIsGetResult)
			{
				if (null != malt)
				{
					malt.stopListening();
					malt = null;
				}
				///< 1.创建SpeechRecognizer对象，第二个参数： 本地听写时传InitListener
				malt = SpeechRecognizer.createRecognizer(HeyClockMainActivity.this, null);
				///< 2.设置听写参数，详见《科大讯飞MSC API手册(Android)》 SpeechConstant类
				malt.setParameter(SpeechConstant.DOMAIN, "iat"); 	 	///< 设置应用领域
				malt.setParameter(SpeechConstant.LANGUAGE, "zh_cn"); 	///< 设置返回结果的语言 en_us
				malt.setParameter(SpeechConstant.ACCENT, "mandarin ");	///< 用于设置语言区域
				malt.startListening(mRecoListener);
			}
		}

		///<扩展用接口
		public void onEvent(int eventType, int arg1, int arg2, Bundle obj) 
		{}
	};

	@Override
	protected void onDestroy()
	{
		super.onDestroy();

		///< 销毁适配器所有的数据
		if (null != hcmGriVAdatper)
		{
			hcmGriVAdatper.onDestroy();
			hcmGriVAdatper = null;
		}

		///< 销毁语音监听器
		if (null != malt)
		{
			malt.stopListening();
			malt = null;
		}
		
		///< 销毁天气信息链表
		if (null != titleSTv)
		{
			titleSTv.onDestroy();
		}
		
		///< 销毁天气图片链接数组
		if (null != weatherPng)
		{
			weatherPng = null;
		}

		///< 销毁幽默图片拉取模块
		HeyClockFunctionPullIMGV.getInstance(HeyClockMainActivity.this).onDestroy();

		///< 销毁定位模块
		HeyClockLocationPullTitle.getInstance(HeyClockMainActivity.this).onDestroy();
	}
}
