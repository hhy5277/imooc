package com.hcstudio.heyclock;

import com.baidu.mobstat.SendStrategyEnum;
import com.baidu.mobstat.StatService;
import com.hcstudio.pull.HeyClockLocationPullTitle;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechUtility;

import android.app.Application;

public class HeyClockApplication extends Application 
{
	@Override
	public void onCreate() 
	{
		// TODO Auto-generated method stub
		super.onCreate();

		///< 初始化【科大讯飞】语音配置对象
		SpeechUtility.createUtility(this, SpeechConstant.APPID +"=550a4c81");

		///< 初始化百度统计SDK服务
		StatService.setAppKey("fe6475b938");
		StatService.setAppChannel(this, "HCSTUDIO", true);
		StatService.setSessionTimeOut(30);
		StatService.setOn(this, StatService.EXCEPTION_LOG);
		StatService.setLogSenderDelayed(10);
		StatService.setSendLogStrategy(this, SendStrategyEnum.APP_START, 1, false);
		StatService.setDebugOn(true);

		///< 初始化百度定位SDK服务
		HeyClockLocationPullTitle.getInstance(this).startLocation();
	}
}
