package com.hcstudio.exsplash;

public interface ExOnViewChangeListener 
{
	public void onViewChange(int view);
}
