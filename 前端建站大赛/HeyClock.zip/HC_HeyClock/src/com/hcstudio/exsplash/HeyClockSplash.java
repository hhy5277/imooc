package com.hcstudio.exsplash;

import roboguice.activity.RoboActivity;

import com.hcstudio.core.HC_Time;
import com.hcstudio.heyclock.HeyClockMainActivity;
import com.hcstudio.pull.HeyClockSpashPullIMGV;
import com.hcstudio.service.HeyClockServiceControl;

import android.content.Intent;
import android.os.Bundle;

public abstract class HeyClockSplash extends RoboActivity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		new Thread(new Runnable() 
		{
			@Override
			public void run()
			{
				///< 动态计算开机画面显示的时间...
				long start = HC_Time.getLongMMM();
				long sleepTime = 1000;
				action();
				if (Math.abs(HC_Time.getLongMMM() - start) <= 1000)
				{
					sleepTime = 2000;
				}
				else if (Math.abs(HC_Time.getLongMMM() - start) > 1000 && Math.abs(HC_Time.getLongMMM() - start) <= 1500)
				{
					sleepTime = 1000;
				}
				else if (Math.abs(HC_Time.getLongMMM() - start) > 1500 && Math.abs(HC_Time.getLongMMM() - start) <= 2000)
				{
					sleepTime = 500;
				}
				else
				{
					sleepTime = 0;
				}
				try 
				{
					Thread.sleep(sleepTime);
				} 
				catch (InterruptedException e)
				{
					///< NOTHING...
				}
				
				///< 如果已经启动过了，则线程初始化完毕后直接跳转...
				if (1 == HeyClockServiceControl.getFirstStartFlag(HeyClockSplash.this))
				{
					Intent intent = new Intent();
					intent.setClass(HeyClockSplash.this, HeyClockMainActivity.class);
					HeyClockSplash.this.startActivity(intent);
					finish();
					
					///< 销毁异步加载图片对象
					HeyClockSpashPullIMGV.getInstance(HeyClockSplash.this, null).onDestroy();
				}
			}
		}).start();
	}

	/**
	 * 初始化事件
	 */
	public abstract void action();
}
