package com.hcstudio.exsplash;

import com.hcstudio.core.HC_FilePath;
import com.hcstudio.heyclock.R;
import com.hcstudio.pull.HeyClockSpashPullIMGV;
import com.hcstudio.service.HeyClockServiceControl;
import com.hcstudio.threed.HCS_GameView;
import com.hcstudio.threed.HCS_Renderer;
import com.hcstudio.util.Constant;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * 开机滑动界面版本归网络作者yanbin所有!
 * @author hl
 *
 */
public class ExSplashActivity extends HeyClockSplash
{
	/** Called when the activity is first created. */
	private ExSwitchLayout switchLayout;	///< 自定义的控件
	private LinearLayout linearLayout;
	private int mViewCount;					///< 自定义控件中子控件的个数
	private ImageView mImageView[];			///< 底部的imageView
	private int mCurSel;					///< 当前选中的imageView

	/**
	 * 3DUI
	 */
	/** Hold a reference to our GLSurfaceView */
	private HCS_GameView mGLSurfaceView = null;
	public HCS_Renderer mRenderer = null;

	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);

		///< 这里不做UI初始化了，等着父亲做跳转...
		if (1 == HeyClockServiceControl.getFirstStartFlag(ExSplashActivity.this))
		{
			///< 去掉标题栏 
			this.requestWindowFeature(Window.FEATURE_NO_TITLE);
			getWindow().setFormat(PixelFormat.RGBA_8888);  
			setContentView(R.layout.hcs_splash_load); 
			///< 非首次开机展示图片
			ImageView startIMG = (ImageView)findViewById(R.id.startIMG_igv);	
			Bitmap bitMap = null;
			///< 再新的图片未加载完成前，先使用之前缓存的图片-保证体验性...
			if (HC_FilePath.fileIsExists(HC_FilePath.spalshIMA_PATH))
			{
				startIMG.setImageBitmap((bitMap = BitmapFactory.decodeFile(HC_FilePath.spalshIMA_PATH, null)));
			}
			HeyClockSpashPullIMGV.getInstance(ExSplashActivity.this, bitMap).setImageControl(startIMG);
			return;
		}

		///< 自定义标题
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.hcs_exsplash_main);
		///< 设置标题为某个layout
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.hcs_splash_titlebar);
		init();
	}

	/**
	 * 初始化一些耗时的操作，并且不是全局上下文的那种
	 */
	@Override
	public void action()
	{
		///< 初始化目录结构——暂时无用户-1
		new HC_FilePath(ExSplashActivity.this, -1).makeDir();
	}

	/**
	 * 初始化线程做事情
	 */
	private void init() 
	{
		switchLayout = (ExSwitchLayout) findViewById(R.id.switchLayoutID);
		linearLayout = (LinearLayout) findViewById(R.id.linerLayoutID);

		///< 得到子控件的个数
		mViewCount = switchLayout.getChildCount();
		mImageView = new ImageView[mViewCount];
		///< 设置imageView
		for(int i = 0; i < mViewCount; i++)
		{
			///< 得到LinearLayout中的子控件
			mImageView[i] = (ImageView) linearLayout.getChildAt(i);
			mImageView[i].setEnabled(true);//控件激活
			mImageView[i].setOnClickListener(new MOnClickListener());
			mImageView[i].setTag(i);//设置与view相关的标签
		}
		///< 设置第一个imageView不被激活
		mCurSel = 0;
		mImageView[mCurSel].setEnabled(false);
		switchLayout.setOnViewChangeListener(new MOnViewChangeListener());

		///<  3DUI初始化 - 封装之后放到哪里都可以，顶多就是无效的3D
		mGLSurfaceView = (HCS_GameView) findViewById(R.id.gl_surface_view);
		Constant.init3D(this, mGLSurfaceView, mRenderer, false);
		///< 封装起来，用上面的替换掉
		//		mGLSurfaceView = (HCS_GameView) findViewById(R.id.gl_surface_view);
		//
		//		// Check if the system supports OpenGL ES 2.0.
		//		final ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		//		final ConfigurationInfo configurationInfo = activityManager.getDeviceConfigurationInfo();
		//		final boolean supportsEs2 = configurationInfo.reqGlEsVersion >= 0x20000;
		//
		//		if (supportsEs2) 
		//		{
		//			// Request an OpenGL ES 2.0 compatible context.
		//			mGLSurfaceView.setEGLContextClientVersion(2);
		//			///< 实现glsurfaceview透明效果
		//			mGLSurfaceView.setZOrderOnTop(true);
		//			mGLSurfaceView.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
		//			mGLSurfaceView.getHolder().setFormat(PixelFormat.TRANSLUCENT);
		//
		//			//			final DisplayMetrics displayMetrics = new DisplayMetrics();
		//			//			getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
		//
		//			// Set the renderer to our demo renderer, defined below.
		//			mRenderer = new HCS_Renderer(this, mGLSurfaceView);
		//			mGLSurfaceView.setRenderer(mRenderer);
		//		} 
		//		else 
		//		{
		//			// This is where you could create an OpenGL ES 1.x compatible
		//			// renderer if you wanted to support both ES 1 and ES 2.
		//			return;
		//		}	
	}

	/**
	 * 点击事件的监听器
	 * @author Administrator
	 *
	 */
	private class MOnClickListener implements OnClickListener
	{
		@Override
		public void onClick(View v) 
		{
			int pos = (Integer) v.getTag();
			//System.out.println("pos:--" + pos);
			///< 设置当前显示的ImageView
			setCurPoint(pos);
			///< 设置自定义控件中的哪个子控件展示在当前屏幕中
			switchLayout.snapToScreen(pos);
		}
	}

	/**
	 * 设置当前显示的ImageView
	 * @param pos
	 */
	private void setCurPoint(int pos) 
	{
		if(pos < 0 || pos > mViewCount -1 || mCurSel == pos)
		{
			return;
		}
		///< 当前的imgaeView将可以被激活
		mImageView[mCurSel].setEnabled(true);
		///< 将要跳转过去的那个imageView变成不可激活
		mImageView[pos].setEnabled(false);
		mCurSel = pos;
	}

	/**
	 * 自定义控件中View改变的事件监听
	 * @author hl
	 *
	 */
	private class MOnViewChangeListener implements ExOnViewChangeListener
	{
		@Override
		public void onViewChange(int view)
		{
			//System.out.println("view:--" + view);
			if(view < 0 || mCurSel == view)
			{
				return ;
			}
			else if(view > mViewCount - 1)
			{
				///< 当滚动到第五个的时候activity会被关闭
				//System.out.println("finish activity");
				finish();
			}
			setCurPoint(view);
		}
	}
	
	@Override
	protected void onResume()
	{
		super.onResume();
		if (null != mGLSurfaceView)
		{
			mGLSurfaceView.onResume();
		}
	}

	@Override
	protected void onPause() 
	{
		super.onPause();
		if (null != mGLSurfaceView)
		{
			mGLSurfaceView.onPause();
		}
	}

	@Override
	protected void onDestroy() 
	{
		super.onDestroy();
		if (null != mGLSurfaceView)
		{
			mGLSurfaceView.destroyDrawingCache();
			mGLSurfaceView = null;
		}
	}
}