package com.hcstudio.ui;

import java.util.HashMap;

import com.hcstudio.core.HC_MathF;
import com.hcstudio.heyclock.R;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * 圆盘式的view
 * @author hl
 *
 */
public class HC_RoundSpinView extends View 
{
	/**
	 * 哪部分区域
	 * @author Administrator
	 *
	 */
	public static enum WHICH_PART
	{
		LEFTAREA, RIGHTAREA, ALLAREA
	};
	public WHICH_PART whichArea;

	/**
	 * 画笔
	 */
	private Paint mPaint = new Paint();

	/**
	 * stone列表
	 */
	private BigStone[] mStones;
	private static final int STONE_COUNT = 6;

	/**
	 * 圆心坐标、半径 、每两个点间隔的角度
	 */
	private int mPointX = 0, mPointY = 0;
	private int mRadius = 0;
	private int mDegreeDelta;

	/**
	 * offsetN 为正 - 逆时针偏移一定角度   为负 - 顺时针偏移一定角度   0 - 不做偏移
	 */
	private int offsetN = 0; 

	///< 0 - 45、 1 - 135、2 - 180、3 - 225、4 - 315、5 - 360
	@SuppressLint("UseSparseArrays")
	@SuppressWarnings("serial")
	private HashMap<Integer, String> angleName = 
	new HashMap<Integer, String>()
	{
		{
			put(1, "详情");
			put(2, "删除");
			put(3, "编辑");
			put(4, "编辑");
			put(5, "删除");
			put(0, "详情");
		}
	};
	@SuppressLint("UseSparseArrays")
	@SuppressWarnings("serial")
	private HashMap<Integer, Integer> angleDrawable = 
	new HashMap<Integer, Integer>()
	{
		{
			put(1, R.drawable.detail);
			put(2, R.drawable.delete);
			put(3, R.drawable.edit);
			put(4, R.drawable.edit);
			put(5, R.drawable.delete);
			put(0, R.drawable.detail);
		}
	};
	@SuppressLint("UseSparseArrays")
	@SuppressWarnings("serial")
	private HashMap<Integer, Integer> angleDrawablePressed = 
	new HashMap<Integer, Integer>()
	{
		{
			put(1, R.drawable.detail_pressed);
			put(2, R.drawable.delete_pressed);
			put(3, R.drawable.edit_pressed);
			put(4, R.drawable.edit_pressed);
			put(5, R.drawable.delete_pressed);
			put(0, R.drawable.detail_pressed);
		}
	};
	///< 当前被点击的图片
	private BigStone currentbstone = null;
	private HC_RoundSpinOnItemClickInterface actionEvent;

	/**
	 * 初始化构造函数
	 * @param context
	 * @param px - 圆形中心坐标X - 不要传输
	 * @param py - 圆形中心坐标Y - 不要传输
	 * @param radius 	- 圆形半径
	 * @param offsetN	- 旋转偏移  为正 - 逆时针偏移一定角度   为负 - 顺时针偏移一定角度   0 - 不做偏移
	 * @param _area		- 显示区域  LEFTAREA - 左半部分  RIGHTAREA - 右半部分 
	 */
	public HC_RoundSpinView(Context context, 
			int px, int py, int radius, 
			int _offsetN,
			WHICH_PART _area) 
	{
		super(context);
		mPaint.setColor(Color.RED);
		mPaint.setStrokeWidth(2);
		//setBackgroundResource(R.drawable.menubkground);

		offsetN = _offsetN;
		whichArea = _area;

		//		mPointX = px;
		//		mPointY = py;
		///< 重新计算位置【不再从外部传入绘制坐标，根据图标大小动态计算】
		mPointX = radius;
		mPointY = radius;
		
		mRadius = radius;

		setupStones();
		computeCoordinates();
	}

	/** 逆时针
	 * 初始化每个点  0 60 120 180 240 300
	 * 修改为：索引 0 - 45、 1 - 135、2 - 180、3 - 225、4 - 315、5 - 360
	 *      右半部分：4、5、0   左半部分：1、2、3
	 */
	private void setupStones() 
	{
		mStones = new BigStone[STONE_COUNT];
		BigStone stone;
		int angle = 0;
		mDegreeDelta = 360/(STONE_COUNT + 2);

		int index = 0;
		for(int i = 0; i < (STONE_COUNT + 2); i++) 
		{
			angle += mDegreeDelta;
			///< Y轴方向上不绘制图标按钮
			if (90 == angle || 270 == angle)
			{
				continue;
			}
			stone = new BigStone();
			stone.angle = angle + offsetN;
			stone.index = index;
			stone.name = angleName.get(index);
			stone.bitmap = BitmapFactory.decodeResource(getResources(), angleDrawable.get(index));			
			stone.action = new ActionEvent()
			{
				@Override
				public void action(BigStone _stone)
				{
					///< 只有注册了监听器才能监听到按钮点击事件
					if (null != actionEvent)
					{
						actionEvent.action(_stone.name, _stone.index);
					}
					//					Toast.makeText(RoundSpinView.this.getContext(), 
					//							"你点击了我 ! " + _stone.name, 
					//							Toast.LENGTH_SHORT).show();
				}
			};
			mStones[index++] = stone;
		}

		///< 重新计算位置【根据图片属性动态计算】 - 之后计算坐标也会用到这个中心点所以....搁在图片初始化完或最保险
		mPointX = mRadius + mStones[2].bitmap.getWidth()/2 + 5;
		mPointY = mRadius + mStones[4].bitmap.getHeight()/2 - mStones[0].bitmap.getHeight()/4;
		
		///< 根据区域选择性的设置显示某些图标 - 初始化时也可以用作判断，省去初始化一些资源；【由于资源不是很大，我就没有考虑所有的地方都判断】
		if (whichArea.equals(WHICH_PART.LEFTAREA))
		{
			mPointX = (mRadius + mStones[2].bitmap.getWidth()/2);
			mStones[1].isVisible = true;
			mStones[2].isVisible = true;
			mStones[3].isVisible = true;
			mStones[4].isVisible = false;
			mStones[5].isVisible = false;
			mStones[0].isVisible = false;
		}
		else if (whichArea.equals(WHICH_PART.RIGHTAREA))
		{
			mPointX = 0;
			mStones[1].isVisible = false;
			mStones[2].isVisible = false;
			mStones[3].isVisible = false;
			mStones[4].isVisible = true;
			mStones[5].isVisible = true;
			mStones[0].isVisible = true;
		}
		else if (whichArea.equals(WHICH_PART.ALLAREA))
		{
			mStones[1].isVisible = true;
			mStones[2].isVisible = true;
			mStones[3].isVisible = true;
			mStones[4].isVisible = true;
			mStones[5].isVisible = true;
			mStones[0].isVisible = true;
		}
	}

	//	/**
	//	 * 重新计算每个点的角度
	//	 */
	//	private void resetStonesAngle(float x, float y) 
	//	{
	//		int angle = computeCurrentAngle(x, y);
	//		Log.d("RoundSpinView", "angle:"+angle);
	//		for(int index=0; index<STONE_COUNT; index++) 
	//		{			
	//			mStones[index].angle = angle;		
	//			angle += mDegreeDelta;
	//		}
	//	}

	/**
	 * 计算每个点的坐标
	 */
	private void computeCoordinates() 
	{
		BigStone stone;
		for(int index = 0; index < STONE_COUNT; index++) 
		{
			stone = mStones[index];
			stone.x = mPointX + (float)(mRadius * Math.cos(stone.angle*Math.PI/180));
			stone.y = mPointY + (float)(mRadius * Math.sin(stone.angle*Math.PI/180));
			stone.rectF = new RectF(
					stone.x - stone.bitmap.getWidth()/2, 
					stone.y - stone.bitmap.getHeight()/2, 
					stone.x + stone.bitmap.getWidth()/2, 
					stone.y + stone.bitmap.getHeight()/2);
			//System.out.println("RoundSpinView "+ "x:"+stone.x+",y:"+stone.y);
		}
	}

	//	/**
	//	 * 计算第一个点的角度
	//	 * @param x
	//	 * @param y
	//	 * @return
	//	 */
	//	private int computeCurrentAngle(float x, float y)
	//	{		
	//		float distance = (float)Math.sqrt(((x-mPointX)*(x-mPointX) + (y-mPointY)*(y-mPointY)));
	//		int degree = (int)(Math.acos((x-mPointX)/distance)*180/Math.PI);
	//		if(y < mPointY) 
	//		{
	//			degree = -degree;
	//		}
	//
	//		Log.d("RoundSpinView", "x:"+x+",y:"+y+",degree:"+degree);
	//		return degree;
	//	}

	//	@Override
	//	public boolean dispatchTouchEvent(MotionEvent event)
	//	{
	//		resetStonesAngle(event.getX(), event.getY());
	//		computeCoordinates();
	//		invalidate();
	//		return true;
	//	}

	/**
	 * 返回点击的mStone
	 * @param touch_x
	 * @param touch_y
	 * @return
	 */
	private BigStone OnClickStone(float touch_x, float touch_y)
	{
		for(BigStone bs : mStones)
		{
			///< 不可见的方块不考虑点击事件
			if (!bs.isVisible)
			{
				continue;
			}
			if (HC_MathF.insideRect(touch_x, touch_y, bs.rectF))
			{
				return bs;
			}
		}
		return null;
	}

	/**
	 * 触摸事件、利用触摸事件：可以计算出绘制的按钮哪个被点击上了...
	 */
	@Override  
	public boolean dispatchTouchEvent(MotionEvent event) 
	{

		switch (event.getAction())
		{
		case MotionEvent.ACTION_DOWN:
		{
			///< 求出点属于那个按钮区域
			currentbstone = OnClickStone(event.getX(), event.getY());
			///< 点击状态图片
			if (null != currentbstone)
			{
				currentbstone.isVisible = false;
				if (null != currentbstone.bitmap)
				{
					currentbstone.bitmap.recycle();
					currentbstone.bitmap = null;
				}
				currentbstone.bitmap = BitmapFactory.decodeResource(getResources(), 
						angleDrawablePressed.get(currentbstone.index));
				currentbstone.isVisible = true;
				invalidate();
			}
		}
		break;
		case MotionEvent.ACTION_MOVE:
		{
			///< 暂时不用
		}
		break;
		case MotionEvent.ACTION_UP:
		{
			///< 松手状态图片
			if (null != currentbstone)
			{
				currentbstone.isVisible = false;
				if (null != currentbstone.bitmap)
				{
					currentbstone.bitmap.recycle();
					currentbstone.bitmap = null;
				}
				currentbstone.bitmap = BitmapFactory.decodeResource(getResources(), 
						angleDrawable.get(currentbstone.index));
				currentbstone.isVisible = true;
				invalidate();
			}
			///< 再次比较是否是同一个方块
			BigStone bitS = OnClickStone(event.getX(), event.getY());
			if (null != bitS && bitS.equals(currentbstone))
			{
				currentbstone.action.action(currentbstone); 
			}
		}
		break;
		}

		return true;
	}

	/**
	 * 绘制图标按钮事件 - 只有设置为可见[isVisible】的按钮才被绘制
	 */
	@Override
	public void onDraw(Canvas canvas) 
	{
		//canvas.drawPoint(mPointX, mPointY, mPaint);

		for(int index = 0; index < STONE_COUNT; index++) 
		{
			if(!mStones[index].isVisible) 
			{
				continue;
			}
			drawInCenter(canvas, 
					mStones[index].bitmap, 
					mStones[index].x, 
					mStones[index].y);
			//不想有红线，就注掉下面这句
			//canvas.drawLine(mPointX, mPointY, mStones[index].x, mStones[index].y, mPaint);
		}
	}

	/**
	 * 按钮触发事件  - 按钮触发调用RoundSpinOnItemClickInterface通知使用者...
	 * @author Administrator
	 *
	 */
	interface ActionEvent
	{
		public void action(BigStone stone);
	}

	/**
	 * 设置监听器接口、使用者传入监听器接口
	 * @param _actionEvent
	 */
	public void setOnItemClickListenner(HC_RoundSpinOnItemClickInterface _actionEvent)
	{
		actionEvent = _actionEvent;
	}

	/**
	 * 把中心点放到中心处
	 * @param canvas
	 * @param bitmap
	 * @param left
	 * @param top
	 */
	void drawInCenter(Canvas canvas, Bitmap bitmap, float left, float top)
	{
		///< 方法一
		//canvas.drawPoint(left, top, mPaint);
		//		canvas.drawBitmap(bitmap, 
		//				left-bitmap.getWidth()/2, 
		//				top-bitmap.getHeight()/2, 
		//				null);

		///< 方法二 - 精确计算
		Rect src = new Rect();					///< 图片 >>原矩形   
		src.left = 0;
		src.top = 0;
		src.right = bitmap.getWidth();
		src.bottom = bitmap.getHeight();

		RectF dst = new RectF();				///< 屏幕 >>目标矩形
		dst.left = left-bitmap.getWidth()/2;
		dst.top = top-bitmap.getHeight()/2;
		dst.right = dst.left + bitmap.getWidth();
		dst.bottom = dst.top + bitmap.getHeight();
		canvas.drawBitmap(bitmap, src, dst, null);
	}	

	public int getRWidth()
	{
		if (whichArea.equals(WHICH_PART.LEFTAREA))
		{
			return ((mRadius*2 + mStones[0].bitmap.getWidth()/2 + mStones[4].bitmap.getWidth()/2) + 10)/2;
		}
		else if (whichArea.equals(WHICH_PART.RIGHTAREA))
		{
			return ((mRadius*2 + mStones[0].bitmap.getWidth()/2 + mStones[4].bitmap.getWidth()/2) + 10)/2;
		}
		else
		{
			return (mRadius*2 + mStones[0].bitmap.getWidth()/2 + mStones[4].bitmap.getWidth()/2) + 10;
		}
	}

	public int getRHeight()
	{
		return (mRadius*2 + mStones[5].bitmap.getHeight()/2 + mStones[2].bitmap.getHeight()/2) - mStones[0].bitmap.getHeight()/2;
	}

	class BigStone 
	{
		///< 名称
		public String name;

		///< 索引
		public int index;

		///< 图片
		public Bitmap bitmap;

		///< 角度
		public int angle;

		///< x坐标
		public float x;

		///< y坐标
		public float y;

		///< 矩形区域坐标
		public RectF rectF;

		///< 是否可见
		public boolean isVisible = true;

		///< 点击事件
		public ActionEvent action;
	}

	/**
	 * 销毁方法
	 */
	public void onDestroy()
	{
		for(BigStone bs : mStones)
		{
			if (null != bs.bitmap)
			{
				bs.bitmap.recycle();
				bs.bitmap = null;
				bs = null;
			}
		}
	}
}
