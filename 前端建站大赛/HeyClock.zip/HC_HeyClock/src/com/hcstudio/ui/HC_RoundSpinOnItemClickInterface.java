package com.hcstudio.ui;

public interface HC_RoundSpinOnItemClickInterface 
{
	public void action(String name, int index);
}
