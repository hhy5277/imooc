package com.hcstudio.threed;

import com.hcstudio.util.Constant;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.util.AttributeSet;

public class HCS_GameView extends GLSurfaceView 
{	
	//	///<  Offsets for touch events	 
	//	private final float TOUCH_SCALE_FACTOR = 0.5f;	///< 角度缩放比例
	//    private final int NONE = 0;   
	//    private final int DRAG = 1;   
	//    private final int ZOOM = 2;   
	//    private int mode = NONE;  
	//    private PointF startPoint = new PointF(); 
	//    private float oldDistance; 

	public HCS_GameView(Context context) 
	{
		super(context);		
	}

	public HCS_GameView(Context context, AttributeSet attrs) 
	{
		super(context, attrs);		
	}

	//	@SuppressLint("ClickableViewAccessibility")
	//	@Override
	//	public boolean onTouchEvent(MotionEvent event) 
	//	{
	//		if (event != null)
	//		{			
	//			//获取触控的点数  
	//	        //int pointCount = event.getPointerCount();  
	//
	//	        switch (event.getAction() & MotionEvent.ACTION_MASK)
	//	        {
	//	            case MotionEvent.ACTION_DOWN: 
	//	            	startPoint.set(event.getX(), event.getY()); 
	//	            	mode = DRAG;
	//	            	break;
	//	            case MotionEvent.ACTION_POINTER_DOWN: 
	//	            	oldDistance = (float) Math.sqrt((event.getX(0) - event.getX(1)) 
	//	            			* (event.getX(0) - event.getX(1)) + (event.getY(0) - event.getY(1)) 
	//	            			* (event.getY(0) - event.getY(1)));
	//	            	if (oldDistance > 10f)
	//	            	{
	//	            		mode = ZOOM;
	//	            	}
	//	            	break;
	//		        case MotionEvent.ACTION_MOVE:
	//		        	//拖拽模式
	//		        	if (mode == DRAG) 
	//		        	{
	//		        		float x = event.getX();
	//		        		float y = event.getY();
	//		        		float dx = x - startPoint.x;///< 计算触控笔X位移
	//		        		float dy = y - startPoint.y;///< 计算触控笔Y位移
	//		        		if(Math.abs(dx)<7f && Math.abs(dy)<7f)			///< 不超过阈值不移动摄像机
	//			            {
	//			            	break;
	//			            } 
	//				        ///< 设置沿y轴旋转角度
	//				        Constant.DIRECTION_CAMERA=(Constant.DIRECTION_CAMERA - dx * TOUCH_SCALE_FACTOR)%360;
	//
	//				        ///< 设置沿x轴旋转角度
	//				        Constant.ELEVATION_CAMERA=(Constant.ELEVATION_CAMERA + dy * TOUCH_SCALE_FACTOR)%360;
	//			            setCameraPostion();								///< 设置摄像机的位置
	//			            startPoint.x = x;
	//			            startPoint.y = y;
	//		        	}
	//		        	//缩放模式
	//		        	else if (mode == ZOOM)
	//		        	{
	//		        		float newDist =  (float) Math.sqrt((event.getX(0) - event.getX(1)) 
	//		        				* (event.getX(0) - event.getX(1)) + (event.getY(0) - event.getY(1)) 
	//		        				* (event.getY(0) - event.getY(1))); 
	//		        		if(Math.abs(newDist - oldDistance)>10)
	//		        		{
	//			        	    if (newDist > 10f)
	//			        	    {     
	//			        	    	float scale = newDist / oldDistance;
	//			        	    	if(scale>1)
	//			        	    	{
	//			        	    		Constant.DISTANCE -= 1;
	//			        	    		Constant.DISTANCE = Math.max(Constant.DISTANCE, 60);
	//			        	    	}
	//			        	    	else
	//			        	    	{
	//			        	    		Constant.DISTANCE += 1;
	//			        	    		Constant.DISTANCE = Math.min(Constant.DISTANCE, 150);
	//			        	    	}		        		
	//			        	    }
	//		        		}
	//		        	    setCameraPostion();								///< 设置摄像机的位置
	//		        	}            
	//		            break;
	//		        //有手指抬起，将模式设为NONE
	//		        case MotionEvent.ACTION_UP: 
	//		        case MotionEvent.ACTION_POINTER_UP: 
	//		         mode = NONE; 
	//		         break; 
	//	        }	
	//			return true;
	//		}
	//		else
	//		{
	//			return super.onTouchEvent(event);
	//		}		
	//	}
	//
	/**
	 * 设置摄像机位置的方法
	 */
	public void setCameraPostion() 
	{
		///< 计算摄像机的位置
		Constant.cx=(float)(Constant.tx+Math.cos(Math.toRadians(Constant.ELEVATION_CAMERA))*Math.sin(Math.toRadians(Constant.DIRECTION_CAMERA))*Constant.DISTANCE);//摄像机x坐标 
		Constant.cz=(float)(Constant.tz+Math.cos(Math.toRadians(Constant.ELEVATION_CAMERA))*Math.cos(Math.toRadians(Constant.DIRECTION_CAMERA))*Constant.DISTANCE);//摄像机z坐标 
		Constant.cy=(float)(Constant.ty+Math.sin(Math.toRadians(Constant.ELEVATION_CAMERA))*Constant.DISTANCE);//摄像机y坐标
	}

	/**
	 * Hides superclass method.
	 * @param renderer
	 */
	public void setRenderer(HCS_Renderer renderer) 
	{
		super.setRenderer(renderer);
	}
}
