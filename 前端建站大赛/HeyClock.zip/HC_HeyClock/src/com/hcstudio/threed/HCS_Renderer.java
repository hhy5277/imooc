package com.hcstudio.threed;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import com.hcstudio.util.Constant;
import com.hcstudio.util.MatrixState;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

/**
 * This class implements our custom renderer. Note that the GL10 parameter passed in is unused for OpenGL ES 2.0
 * renderers -- the static class GLES20 is used instead.
 */
public class HCS_Renderer implements GLSurfaceView.Renderer 
{	
	/** Thread executor for generating cube data in the background. */
	//private final ExecutorService mSingleThreadedExecutor = Executors.newSingleThreadExecutor();
	@SuppressWarnings("unused")
	private Context context;
	private final GLSurfaceView mGlSurfaceView;
	
	///< 摄像机移动
	private float[] fa=new float[16];
	private float[] resultUp=new float[4];  
	private float[] YB=new float[4];

	/**
	 * Initialize the model data.
	 */
	public HCS_Renderer(final Context _context, final GLSurfaceView glSurfaceView) 
	{
		this.context = _context;
		this.mGlSurfaceView = glSurfaceView;
	}

	@Override
	public void onSurfaceCreated(GL10 glUnused, EGLConfig config) 
	{
		///< 设置屏幕背景色RGBA
		GLES20.glClearColor(0.0f,0.0f,0.0f,0.0f);
		///< 打开深度检测
		GLES20.glEnable(GLES20.GL_DEPTH_TEST);
		///< 打开背面剪裁
		GLES20.glEnable(GLES20.GL_CULL_FACE);
		///< 重新设置初始化矩阵
		MatrixState.setInitStack();
	}	

	@Override
	public void onSurfaceChanged(GL10 glUnused, int width, int height) 
	{
		///< 设置视窗大小及位置 
		GLES20.glViewport(0, 0, width, height); 
		///< 计算GLSurfaceView的宽高比
		float ratio = (float) width / height;
		///< 调用此方法计算产生透视投影矩阵
		MatrixState.setProjectFrustum(-ratio, ratio, -1, 1, 1, 1000);
		///< 初始化光源位置
		MatrixState.setLightLocation(10, 40, 10);   
		///< 重置摄像机的位置
		((HCS_GameView)mGlSurfaceView).setCameraPostion();
		///< 调用此方法产生摄像机9参数位置矩阵
		MatrixState.setCamera(Constant.cx, Constant.cy, Constant.cz, Constant.tx, Constant.ty, Constant.tz, 0, 1, 0);
	}	

	@Override
	public void onDrawFrame(GL10 glUnused) 
	{
		///< 清除深度缓冲与颜色缓冲
		GLES20.glClear( GLES20.GL_DEPTH_BUFFER_BIT | GLES20.GL_COLOR_BUFFER_BIT);
	
		Matrix.setRotateM(fa, 0, Constant.DIRECTION_CAMERA, 0, 1, 0);	///< 得到旋转矩阵
		YB[0]=(float) (Math.sin(Math.toRadians(-0)));
		YB[1]=(float) (Math.cos(Math.toRadians(-0))* Math.cos(Math.toRadians(-Constant.ELEVATION_CAMERA)));
		YB[2]=(float) (Math.cos(Math.toRadians(-0))* Math.sin(Math.toRadians(-Constant.ELEVATION_CAMERA)));
		YB[3]=1;
		Matrix.multiplyMV(resultUp, 0, fa, 0, YB, 0);
		///< 设置摄像头位置
		MatrixState.setCamera(Constant.cx, Constant.cy, Constant.cz, Constant.tx, Constant.ty, Constant.tz,
				resultUp[0],resultUp[1],resultUp[2]);					///< 设置摄像机的位置
		
		///< 重新设置初始化矩阵
		MatrixState.setInitStack();
	}	
}
