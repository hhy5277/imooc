package com.hcstudio.receiver;

import com.hcstudio.core.HC_NetWork;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.widget.Toast;

public class HeyClockConnectionChangeReceiver extends BroadcastReceiver
{
	@Override
	public void onReceive(Context context, Intent intent)
	{
		///< 网络管理器
		@SuppressWarnings("unused")
		ConnectivityManager connManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

		///< 过滤掉系统的那一次检测 - 只关注服务注册的那次广播
		if (!context.getClass().getName().equals("com.hcstudio.service.HeyClockNetTipLocalService"))
		{
			return;
		}

		///< 如果网络断开，则播放“网络已经断开”；
		///< 如果网络连接上，则播放“网络已经连接上->如果是手机网络，提示当前使用的是手机网络，注意流量!，其它则提示网络已经连接”；
		///< ...
		///< @a 网络不可用
		if (!HC_NetWork.isNetworkConnected(context))
		{
			Toast.makeText(context, "网络已经断开!", Toast.LENGTH_SHORT).show();
		}
		else
		{
			if (HC_NetWork.isWifiConnected(context))
			{
				Toast.makeText(context, "Wifi已经连接", Toast.LENGTH_SHORT).show();
			}
			else if (HC_NetWork.isMobileConnected(context))
			{
				Toast.makeText(context, "手机网络已经连接，请注意流量消耗!", Toast.LENGTH_SHORT).show();
			}
			else
			{
				Toast.makeText(context, "网络已经连接!", Toast.LENGTH_SHORT).show();
			}
		}

		//		System.out.println("contex -1-1 " + intent.getAction());
		//		System.out.println("contex 00 " + context.getClass().getName());
		//		System.out.println("contex 11 " + connManager);
		//		System.out.println("contex 网络类型 " + HC_NetWork.getConnectedType(context)); ///< -1 没网络 1 wifi 2 - wap
		//		System.out.println("contex 33 " + HC_NetWork.isNetworkConnected(context));
		//		System.out.println("contex 44 " + HC_NetWork.isWifiConnected(context));
		//		System.out.println("contex 55 " + HC_NetWork.isMobileConnected(context));

		///< 废弃方法，未做null处理
		//		//State state = connManager.getActiveNetworkInfo().getState();
		//		///< 获取WIFI网络连接状态     
		//	    State state = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();     
		//	    ///< 判断是否正在使用WIFI网络      
		//	    if (State.CONNECTED == state)
		//	    {    
		//	    	success = true;     
		//	    }     
		//	    Toast.makeText(context, "WIFI " + state, Toast.LENGTH_SHORT).show();     
		//	    ///< 获取GPRS网络连接状态      
		//	    state = connManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState();    
		//	    ///< 判断是否正在使用GPRS网络      
		//	    if (State.CONNECTED != state) 
		//	    {     
		//	    	success = true;     
		//	    }  
		//	    Toast.makeText(context, "GPRS " + state, Toast.LENGTH_SHORT).show();
		//	    if (!success) 
		//	    {     
		//	        Toast.makeText(context, "没有网络了", Toast.LENGTH_SHORT).show();     
		//	    }  
	}
}
