package com.hcstudio.receiver;

import com.hcstudio.core.HC_Clock;
import com.hcstudio.core.HC_DbHelper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.widget.Toast;

public class HeyClockAlarmInitReceiver extends BroadcastReceiver 
{
	@Override
	public void onReceive(Context context, Intent intent) 
	{
		String action = intent.getAction();
		///< 如果是开机广播的话就重新设计闹铃
		if (action.equals(Intent.ACTION_BOOT_COMPLETED)) 
		{
			Toast.makeText(context, "初始化闹钟", Toast.LENGTH_SHORT).show();
			///< 查询数据库所有条目信息，如果是设置开启的状态的闹钟，则重新设置闹钟
			///< 查询闹钟数据库信息，获取设置的闹钟条目
			Cursor cursor = HC_DbHelper.getInstance(context).queryIsOpen();
			while (cursor.moveToNext())
			{
				//			String timerName = cursor.getString(0);
				//			String dateStr = cursor.getString(1);
				//			String Open = cursor.getString(2);
				//			String WHENTIME = cursor.getString(3);
				//			String tdow = timerName + " " + dateStr + " " + Open + " " + WHENTIME;
				//			Toast.makeText(this, tdow, Toast.LENGTH_SHORT).show();
				
				HC_Clock.setClockBalance(context, HeyClockAlarmReceiver.class, cursor.getString(0), cursor.getString(1));
			}
			HC_DbHelper.getInstance(context).closeCursor();
			HC_DbHelper.getInstance(context).closeDatabase();
		}
	}

}
