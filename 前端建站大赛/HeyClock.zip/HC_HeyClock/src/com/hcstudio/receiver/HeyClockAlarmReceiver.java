package com.hcstudio.receiver;

import com.hcstudio.core.HC_Clock;
import com.hcstudio.heyclock.HeyClockAlarmActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class HeyClockAlarmReceiver extends BroadcastReceiver 
{
	@Override
	public void onReceive(Context context, Intent intent)
	{
		/**
		 * TODO 情况1：每天都重复的情况 ---> 启动下一次闹钟
		 */
		HC_Clock.setNextDayClock(context, intent.getAction());
		
		Intent i = new Intent(context, HeyClockAlarmActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra("name", intent.getAction());
        context.startActivity(i);
	}
}
