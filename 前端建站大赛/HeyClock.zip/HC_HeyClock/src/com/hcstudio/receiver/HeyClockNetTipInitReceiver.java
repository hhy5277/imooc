package com.hcstudio.receiver;

import com.hcstudio.service.HeyClockServiceControl;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class HeyClockNetTipInitReceiver extends BroadcastReceiver 
{
	@Override
	public void onReceive(Context context, Intent intent) 
	{
		String action = intent.getAction();
		///< 如果是开机广播的话就重新初始化网络提醒功能
		if (action.equals(Intent.ACTION_BOOT_COMPLETED)) 
		{
			Toast.makeText(context, "初始化网络提醒", Toast.LENGTH_SHORT).show();
			///< 如果用户设置开启了网络提醒，则重新初始化该功能
			if (1 == HeyClockServiceControl.getOpenNetTipFlag(context))
			{
				///< 开启服务 - 由服务去启动检测网络的功能
				HeyClockServiceControl.startNetTipService(context);
			}
		}
	}

}
