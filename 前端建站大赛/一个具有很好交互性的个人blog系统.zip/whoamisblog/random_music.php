<?php

$d=[
	'code'=>200,
	'msg'=>'ok',
	'type'=>3,
	'data'=>[
	['music_name'=>'CountingStars','music_url'=>'http://7xs7oc.com1.z0.glb.clouddn.com/music%2FJason%20Chen%20-%20Counting%20Stars.mp3'],
	]
];
echo json_encode($d);


?>