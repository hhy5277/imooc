package controllers;

import play.*;
import play.mvc.*;
import utils.DButil;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.sql.PreparedStatement;

import net.sf.json.JSONObject;
import models.*;

public class Application extends Controller {

    public static void index() throws Exception {

		Connection con = DButil.getCon();
		PreparedStatement prep = con.prepareStatement("select * from notes");
		ResultSet set = prep.executeQuery();

		JSONObject json = null;
		
		List<JSONObject> list = new ArrayList<JSONObject>();

		while (set.next()) {
			long id = set.getLong("id");
			String title = set.getString("title");
			json = new JSONObject();
			json.put("id",id);
			json.put("title", title);
			json.put("time", new Date(id).toLocaleString());
			list.add(json);
		}

		System.out.println(list);

		render(list);
	}

	public static void addNote(String title, String content) throws Exception {

		if (title == null || content == null) {
			render();
		} else {

			Connection con = DButil.getCon();
			PreparedStatement prep = con
					.prepareStatement("insert into notes(id,title,content) values(?,?,?)");

			prep.setString(1, new Date().getTime()+"");
			prep.setString(2, title);
			prep.setString(3, content);

			prep.executeUpdate();

			index();
		}

	}

	public static void note(String id,String flag) throws Exception {
		
		System.out.println(id);
		
		Connection con = DButil.getCon();
		PreparedStatement prep = con.prepareStatement("select * from notes where id=?");
		prep.setString(1, id);
		ResultSet set = prep.executeQuery();
		set.next();
		String title = set.getString("title");
		String content = set.getString("content");
		JSONObject json = new JSONObject();
		json.put("id",id);
		json.put("title", title);
		json.put("content", content);
		
		if(flag != null && flag.equals("modify")){
			render("Application/modifyNote.html",json);
		}else{
			render(json);
		}
	}
	
	public static void modifyNote(String id,String title, String content) throws Exception {

		if (id == null) {
			index();
		} else {

			Connection con = DButil.getCon();
			PreparedStatement prep = con
					.prepareStatement("update notes set title=?,content=? where id=?");

			prep.setString(1, title);
			prep.setString(2, content);
			prep.setString(3, id);

			prep.executeUpdate();

			index();
		}

	}

}

