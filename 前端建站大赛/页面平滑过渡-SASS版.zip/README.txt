<p>根据&nbsp;<a href="http://t.imooc.com/learn/252" target="_blank">http://t.imooc.com/learn/252</a> 视频实现的SASS版</p><p>css文件夹下的main.scss文件是主要文件,main.css文件是编译后的css文件</p><p>使用 koala 进行编译.</p><p>效果:</p><p><img src="http://img.mukewang.com/561e896d00019ade05000268.jpg" alt="http://img.mukewang.com/561e896d00019ade13620728.jpg"/></p>

