<?php
/**
 * Created by PhpStorm.
 * User: 43559
 * Date: 2016/2/19
 * Time: 16:34
 */

namespace Admin\Model;
use Think\Model;

class ArticleModel extends Model
{
    protected $trueTableName='article_new_list';
    protected $_validate=array(
        array('article_type','文章类型','请选择文章类型!',1,'notequal',3),
        array('article_type_url','require','请输入文章源地址!'),
        array('article_title','require','文章标题必须!'),
        array('article_title','','文章标题已经存在!','1','unique',1),
        array('article_category','请选择所属分类','请选择所属分类名称!',1,'notequal',3),
        array('article_attribute','请选择文章属性','请选择文章属性名称!',1,'notequal',3),
        array('article_content','require','文章内容必须!'),
        array('article_picture_path','require','文章图片必须!'),
    );
}