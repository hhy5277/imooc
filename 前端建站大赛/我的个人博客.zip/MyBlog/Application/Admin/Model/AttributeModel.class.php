<?php
namespace Admin\Model;
use Think\Model;
/**
 * Created by PhpStorm.
 * User: 43559
 * Date: 2016/2/17
 * Time: 16:32
 */
class AttributeModel extends Model
{
    protected $trueTableName = 'article_attribute_list';
    protected $_validate=array(
        array('attribute_name','require','属性名称必须'),
        array('attribute_name','','该属性名称已经存在！',1,'unique',1),
        array('attribute_color','require','属性名称必须！'),
        array('attribute_color','*****请选择颜色*****','请选择颜色！',1,'notequal'),
    );
}