<?php
/**
 * Created by PhpStorm.
 * User: 43559
 * Date: 2016/2/24
 * Time: 20:27
 */

namespace Admin\Model;
use Think\Model;

class LoginModel extends Model
{
    public $trueTableName='user';
    public function judge($name,$password){
       $result=$this->select();
        foreach($result as $item){
            if($item['user_name']===$name)
            {
                if($item['user_password']===$password){
                    session('user_name',$name);
                    session('user_password',$password);
                    return true;
                }
            }
        }
        return false;
    }

}