<?php
/**
 * Created by PhpStorm.
 * User: 43559
 * Date: 2016/2/24
 * Time: 17:46
 */

namespace Admin\Controller;
use Think\Controller;
use Think\Model;
header("Content-Type:text/html;charset='utf-8'");

class LoginController extends Controller
{
    public function index(){
        $this->display('back_stage_login');
    }
    public function judge(){
        $dataGet['user_name']=I('post.username','');
        $dataGet['user_password']=I('post.password','');
        $myModel=D('Login');
        $state=$myModel->judge($dataGet['user_name'],$dataGet['user_password']);
        if($state==true){
            $this->redirect('Index/index');
        }
        else{
            $this->error('用户名或者密码错误！','',1);
            $this->redirect('index');
        }
    }
}