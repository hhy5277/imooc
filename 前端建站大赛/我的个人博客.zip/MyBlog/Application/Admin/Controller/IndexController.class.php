<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Page;
header("Content-Type:text/html; charset=utf-8");
class IndexController extends Controller {
    public function _initialize(){
        if(session('user_name')==''){
            $this->redirect('Login/index');
        }
    }
    public function index(){
//        $this->display('back_stage_article_inspect');
//        $this->articleList();
        $this->display('WebSiteInfo/webSite_info');
    }
    public function articleList(){
        $data=M('list','article_new_');
        $count=$data->count();
        $page=new Page($count,12);
        $page->setConfig('header','<span class="rows">共 %TOTAL_ROW% 条记录 %NOW_PAGE%/%TOTAL_PAGE%页</span>');
        $page->setConfig('prev','上一页');
        $page->setConfig('next','下一页');
        $page->setConfig('first','首页');
        $page->setConfig('last','末尾');
        $page->setConfig('theme','%HEADER% %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%');
        $show=$page->show();

        $result=$data->order('article_time desc')->limit($page->firstRow.','.$page->listRows)->select();
        $this->assign('pageInfo',$show);
        $this->assign('result',$result);
        $this->display('back_stage_article_list');
    }
    public function articleAdd(){
        $typeList=M('list','article_type_');
        $type=$typeList->select();
        $categoryList=M('list','article_category_');
        $category=$categoryList->select();//分类列表
        $attributeList=M('list','article_attribute_');
        $attribute=$attributeList->select();//属性列表
        $this->assign('type',$type);
        $this->assign('category',$category);
        $this->assign('attribute',$attribute);
        $this->display('back_stage_article_add');
    }
    public function articleRubbish(){
        $this->display('back_stage_article_rubbish');
    }
    public function insert(){
        $data=I('post.','',false);
        $list=D('Article');
        if($list->create($data)) {
            $result = $list->add();
            if ($result) {
                $this->success('数据添加成功！');
            } else {
                $this->error('数据添加错误！');
            }
        }
        else{
            $this->error($list->getError());
        }
    }
    public function article_delete(){
        $list=M('list','article_new_');
        $art_id['article_id']=I('get.article_id');
        $result=$list->where($art_id)->delete();
        if($result)
        {
            $this->success('成功删除！');
            $this->redirect('articleList');
        }
        else
        {
            $this->error('删除失败！');
        }
    }
    public function article_inspect(){
        $articleId=I('get.article_id','');
        $articleNewID=I('get.article_new_id','');
        $minus=0;
        if($articleNewID!='')
        {
            $minus=$articleNewID-$articleId;
            $articleId=$articleNewID;
        }
        $list=M('list','article_new_');


        $minID=$list->where('article_id>=0')->min('article_id');
        $maxID=$list->where('article_id>=0')->max('article_id');

        if($articleId>$maxID)
        {
            $articleId=$minID;
        }
        else if($articleId<$minID)
        {
            $articleId=$maxID;
        }
        $result=null;
        if($articleNewID!='' && $minus==1)
        {
            $dataGet['article_id']=array('egt',$articleId);
            $result=$list->where($dataGet)->order('article_time asc')->select();
            $articleId=$result[0]['article_id'];
        }
        else if($articleNewID!='' && $minus==-1){
            $dataGet['article_id']=array('elt',$articleId);
            $result=$list->where($dataGet)->order('article_time desc')->select();
            $articleId=$result[0]['article_id'];
        }
        else if($articleNewID==''){
            $dataGet['article_id']=array('eq',$articleId);
            $result=$list->where($dataGet)->select();
        }
        $articlePreName='';
        $articleNextName='';
        if($articleId>$minID && $articleId<$maxID){
            $dataGet['article_id']=array('lt',$articleId);
            $preRes=$list->where($dataGet)->order('article_time desc')->select();
            $articlePreName=$preRes[0]['article_title'];
            $dataGet['article_id']=array('gt',$articleId);
            $nextRes=$list->where($dataGet)->order('article_time asc')->select();
            $articleNextName=$nextRes[0]['article_title'];
        }
        else if($articleId-1<$minID)
        {
            $articlePreName='[尾篇]'.($list->getFieldByArticle_id($maxID,'article_title'));
            if($articleId+1==$maxID)
            {
                $articleNextName=$articlePreName;
            }
            else{
                $dataGet['article_id']=array('gt',$articleId);
                $nextRes=$list->where($dataGet)->order('article_time asc')->select();
                $articleNextName=$nextRes[0]['article_title'];            }
        }
        else if($articleId+1>$maxID){
            $articleNextName='[首篇]'.($list->getFieldByArticle_id($minID,'article_title'));
            if($articleId-1==$minID)
            {
                $articlePreName=$articleNextName;
            }
            else{
                $dataGet['article_id']=array('lt',$articleId);
                $preRes=$list->where($dataGet)->order('article_time desc')->select();
                $articlePreName=$preRes[0]['article_title'];
            }
        }


        $this->assign('list',$result[0]);
        $this->assign('preName',$articlePreName);
        $this->assign('nextName',$articleNextName);
        $this->display('Index/back_stage_article_inspect');
    }
    public function articleUpdateShow(){
        $dataGet['article_id']=I('get.article_id');
        $list=M('list','article_new_');
        $result=$list->where($dataGet)->select();

        $typeList=M('list','article_type_');
        $type=$typeList->select();
        $this->assign('type',$type);

        $categoryList=M('list','article_category_');
        $category=$categoryList->select();//分类列表
        $attributeList=M('list','article_attribute_');
        $attribute=$attributeList->select();//属性列表
        $this->assign('category',$category);
        $this->assign('attribute',$attribute);

        $this->assign('articleRes',$result[0]);
        $this->display('Index/back_stage_article_update');
    }
    public function articleUpdate(){
        $dataArray=I('post.','',false);
        $articleID['article_id']=I('post.article_id');
        $list=D('Article');
        if($list->create($dataArray,2))
        {
            $result=$list->where($articleID)->save($dataArray);
            if($result){
                $this->success('文章修改成功!');
                $this->redirect('Index/articleList');
            }
            else{
                $this->error('文章修改失败!');
            }
        }
        else{
            $this->error($list->getError());
        }
    }
    public function logout(){
        session('user_name',null);
        $this->redirect('Login/index');
    }
}