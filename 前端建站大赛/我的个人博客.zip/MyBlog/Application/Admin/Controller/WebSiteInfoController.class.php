<?php
/**
 * Created by PhpStorm.
 * User: 43559
 * Date: 2016/3/12
 * Time: 12:07
 */

namespace Admin\Controller;


use Think\Controller;

class WebSiteInfoController extends Controller
{
    public function index(){
        $this->display('webSite_info');
    }
}