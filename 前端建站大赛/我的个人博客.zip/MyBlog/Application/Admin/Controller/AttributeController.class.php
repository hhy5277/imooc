<?php
/**
 * Created by PhpStorm.
 * User: 43559
 * Date: 2016/2/17
 * Time: 12:09
 */

namespace Admin\Controller;
use Think\Controller;
header("content-type:text/html;charset=utf-8");
class AttributeController extends Controller
{
    public function _initialize(){
        if(session('user_name')==''){
            $this->redirect('Login/index');
        }
    }
    public function attribute(){
        $this->attributeList();
    }
    public function attributeList(){
        $list=M('list','article_attribute_');
        $result=$list->order('attribute_id')->select();
        $this->assign('result',$result);
        $this->display('back_stage_attribute_list');
    }
    public function attributeAdd(){
        $list=M('list','article_attribute_');
        $resultColor=$list->field('attribute_color')->select();
        $this->assign('resultColor',$resultColor);
        $this->display('back_stage_attribute_add');
    }
    public function attributeRubbish(){
        $this->display('back_stage_attribute_rubbish');
    }
    public function attributeUpdateShow(){
        $data['attrID']=I('get.attribute_id');
        $data['attrName']=I('get.attribute_name');
        $data['attrColor']=I('get.attribute_color');
        $this->assign('data',$data);
        $this->display('back_stage_attribute_update');
    }
    public function attributeInsert(){
        $data['attribute_name']=I('post.attribute_name');
        $data['attribute_color']=I('post.attribute_color');
        $list=D('Attribute');
        if($list->create($data)){
            $result=$list->add($data);
            if($result){
                $this->success("属性添加成功！");
            }
            else{
                $this->error("属性添加失败！");
            }
        }
        else{
            $this->error($list->getError());
        }
    }
    public function attributeDelete(){

        $list=M('list','article_attribute_');
        $attrID=I('get.attribute_id');
        $result=$list->where('attribute_id='.$attrID)->delete();
        if($result)
        {
            $this->success('删除成功！');
            $this->redirect('attributeList');
        }
        else{
            $this->error('删除失败！');
        }
    }
    public function attributeUpdate(){
        $data['attribute_id']=I('post.attribute_id');
        $data['attribute_name']=I('post.attribute_name');
        $data['attribute_color']=I('post.attribute_color');
        $list=D('Attribute');
        if($list->create($data,4)){
            $result=$list->where('attribute_id='.$data['attribute_id'])->save($data);
            if($result){
                $this->success("属性修改成功！");
                $this->redirect('attributeList');
            }
            else{
                $this->error("属性修改失败！");
            }
        }
        else{
            $this->error($list->getError());
        }

    }
}