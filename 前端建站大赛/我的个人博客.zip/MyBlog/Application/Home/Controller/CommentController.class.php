<?php
/**
 * Created by PhpStorm.
 * User: 43559
 * Date: 2016/2/22
 * Time: 15:07
 */

namespace Home\Controller;
use Think\Controller;
header("content-type:text/html;charset=utf-8");

class CommentController extends Controller
{
    public function index(){
        $this->commentShow();
    }
    public function comment(){
        $this->commentShow();
    }
    public function commentShow(){
        $this->assign('comment_info','留言板');
        $this->display('comment_board');
    }

}