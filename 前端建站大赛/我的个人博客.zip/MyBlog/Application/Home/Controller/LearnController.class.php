<?php
/**
 * Created by PhpStorm.
 * User: 43559
 * Date: 2016/3/8
 * Time: 13:03
 */

namespace Home\Controller;
use Think\Controller;
use Think\Page;
header("content-type:text/html;charset=utf-8");

class LearnController extends Controller
{
    public function index(){
        $this->learnShow();
    }
    public function learnShow(){
        $list=M('list','article_new_');
        $count=$list->count();
        $page=new Page($count,10);
        $page->setConfig('header','<span class="rows">共 %TOTAL_ROW% 条记录 %NOW_PAGE%/%TOTAL_PAGE%页</span>');
        $page->setConfig('prev','上一页');
        $page->setConfig('next','下一页');
        $page->setConfig('first','首页');
        $page->setConfig('last','末尾');
        $page->setConfig('theme','%HEADER% %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%');
        $show=$page->show();
        $this->assign('pageInfo',$show);
        $dateGet['article_category']=array(array('neq','其他'),array('neq','常用工具'));
        $articleCategoryList=$list->where($dateGet)->order('article_time desc')->limit($page->firstRow.','.$page->listRows)->select();
        $this->assign('articleCategory',$articleCategoryList);//左边显示文章列表

        $dateGet1['article_attribute']='精华';
        $dateGet1['article_category']=array(array('neq','其他'),array('neq','常用工具'));
        $articleNewList=$list->where($dateGet1)->order('article_time desc')->limit(12)->select();//精品筛选列表
        $this->assign('articleNew',$articleNewList);

        $dateGet2['article_category']=array(array('neq','其他'),array('neq','常用工具'));
        $articleRankList=$list->where($dateGet2)->order('article_seen_num desc')->limit(12)->select();//点击排行
        $this->assign('articleRank',$articleRankList);
        $this->display('learn_no_limit');
    }
    public function articleCategory(){
        $flag=I('category_name','',false);
        if($flag=='')
        {
            $flag=I('article_category','',false);
        }
        $dataGet['article_category']=$flag;
        $list=M('list','article_new_');
        $count=$list->where($dataGet)->count();
        $page=new Page($count,10);
        $page->setConfig('header','<span class="rows">共 %TOTAL_ROW% 条记录 %NOW_PAGE%/%TOTAL_PAGE%页</span>');
        $page->setConfig('prev','上一页');
        $page->setConfig('next','下一页');
        $page->setConfig('first','首页');
        $page->setConfig('last','末尾');
        $page->setConfig('theme','%HEADER% %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%');
        $show=$page->show();
        $this->assign('pageInfo',$show);

        $this->assign('categoryInfo',$dataGet['article_category']);

        $articleCategoryList=$list->where($dataGet)->order('article_time desc')->limit($page->firstRow.','.$page->listRows)->select();
//        echo dump($articleCategoryList);die;
        $this->assign('articleCategory',$articleCategoryList);

        $articleNewList=$list->order('article_time desc')->limit(12)->select();//最新文章列表
        $this->assign('articleNew',$articleNewList);

        $articleRankList=$list->order('article_seen_num desc')->limit(12)->select();//阅读排行
        $this->assign('articleRank',$articleRankList);
        $this->display('article_show_category');
    }

}