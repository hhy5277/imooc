<?php
/**
 * Created by PhpStorm.
 * User: 43559
 * Date: 2016/3/6
 * Time: 14:41
 */

namespace Home\Controller;
use Think\Controller;

class AboutMeController extends Controller
{
    public function index(){
        $this->display('about_me');
    }
}