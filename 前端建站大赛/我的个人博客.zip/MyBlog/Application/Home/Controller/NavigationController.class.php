<?php
/**
 * Created by PhpStorm.
 * User: 43559
 * Date: 2016/3/4
 * Time: 20:01
 */

namespace Home\Controller;
use Think\Controller;

class NavigationController extends Controller
{
    public function index(){
        $this->showTimeLife();
    }
    public function showTimeLife(){
        $list=M('timelife','person_');
        $result=$list->order('create_time desc')->select();
        $this->assign('lifeList',$result);
        $this->display('person_timelife');
    }
    public function setInfoInc(){
        $list=M('timelife','person_');
        $list->where('id='.I('get.id'))->setInc(I('get.add'),1);
        $this->redirect('index');
    }
}