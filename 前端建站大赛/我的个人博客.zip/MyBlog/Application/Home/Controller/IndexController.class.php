<?php
namespace Home\Controller;
use Think\Controller;
use Think\Page;
header("content-type:text/html;charset=utf-8");

class IndexController extends Controller {
    public function index(){
        $this->mainShow();
//        $this->redirect('Navigation/index');
//        $this->redirect('Learn/index');
    }
    public function mainShow(){
        $list=M('list','article_new_');
        $dataTop['article_attribute']='置顶';
        $dataRecommend['article_attribute']='推荐';
        $dataEssence['article_attribute']='精华';
        $top=$list->where($dataTop)->order('article_time desc')->select();
        $recommend=$list->where($dataRecommend)->order('rand()')->limit(8)->select();
        $essence=$list->where($dataEssence)->limit(12)->select();
        $this->assign('topList',$top);
        $this->assign('recommendList',$recommend);
        $this->assign('essenceList',$essence);
        $categoryList=M('list','article_category_');
        $categoryRes=$categoryList->select();
        $this->assign('category',$categoryRes);
        $this->display('main_one');
    }
    public function articleShow(){

    }

    public function article_pre_next_page(){
        $judgeId['article_id']=I('get.article_id','');
        $judgeNewId=I('get.article_new_id','');
        $minus=$judgeNewId-$judgeId['article_id'];
        $judgeAttr['article_attribute']=I('get.article_attribute','');
        $judgeCategory['article_category']=I('get.article_category','',false);
        if($judgeCategory['article_category']!='')
        {
            $judgeAttr['article_category']=$judgeCategory['article_category'];
            unset($judgeAttr['article_attribute']);
        }
        $list=M('list','article_new_');
        $resultArray=$list->where($judgeAttr)->order('article_time desc')->select();
//        echo dump($resultArray);die;
        $listLength=count($resultArray);
        $index=$this->getArrayIndex($resultArray,$listLength,$judgeId);
        if($index==-1)
        {
            echo '数组下标不能为-1';die;
        }
        $judgeId['article_id']=$resultArray[$this->getRealIndex($index-$minus,$listLength)]['article_id'];
        if($judgeCategory['article_category']!=''){
            $this->article_inspect($judgeId,$judgeAttr,1);
        }
        else{
            $this->article_inspect($judgeId,$judgeAttr);
        }
    }

    public function article_current_page(){
        $judgeId['article_id']=I('get.article_id','');
        $judgeAttr['article_attribute']=I('get.article_attribute','');
        $judgeCategory['article_category']=I('get.article_category','',false);
        if($judgeCategory['article_category']!='')
        {
            $judgeAttr=$judgeCategory;
            $this->article_inspect($judgeId,$judgeAttr,1);
        }
        else{
            $this->article_inspect($judgeId,$judgeAttr);
        }
    }
    public function article_inspect($judgeId,$judgeAttr,$flag=0){
        $list=M('list','article_new_');
        $list->where($judgeId)->setInc('article_seen_num',1);//点击增加浏览量

        $articleCurList=$list->where($judgeId)->select();//查找当前文章信息
        $this->assign('list',$articleCurList[0]);

        $articleNewList=$list->order('article_time desc')->limit(12)->select();//最新文章列表
        $this->assign('articleNew',$articleNewList);

        $articleRankList=$list->order('article_seen_num desc')->limit(12)->select();//阅读排行
        $this->assign('articleRank',$articleRankList);

        $articlePreNextName=$this->getArticlePreNextName($judgeId,$judgeAttr);//上下篇信息
        $this->assign('preName',$articlePreNextName['preName']);
        $this->assign('nextName',$articlePreNextName['nextName']);
        if($flag!=0)
        {
            $this->display('Index/article_show_category_content');
        }
        else{
            $this->display('Index/article_show');
        }
    }
    public function getArrayIndex($resultArray,$listLength,$articleId){

        for($i=0;$i<$listLength;$i++)
        {
            if($resultArray[$i]['article_id']==$articleId['article_id']){
                return $i;
            }
        }
        return -1;
    }
    public function getRealIndex($n,$listLength){
        if($n<0){
            return $listLength-1;
        }
        else if($n>$listLength-1)
        {
            return 0;
        }
        else
        {
            return $n;
        }
    }
    public function getArticlePreNextName($articleId,$articleAttr){
        $list=M('list','article_new_');
        $resultArray=$list->where($articleAttr)->order('article_time desc')->select();
        $listLength=count($resultArray);
        $index=$this->getArrayIndex($resultArray,$listLength,$articleId);
        if($index==-1)
        {
            echo '数组下标不能为-1';die;
        }
        $articlePreNext['preName']=$resultArray[$this->getRealIndex($index+1,$listLength)]['article_title'];
        $articlePreNext['nextName']=$resultArray[$this->getRealIndex($index-1,$listLength)]['article_title'];
        return $articlePreNext;
    }

    public function article_inspect_normal(){
        $articleId=I('get.article_id','');
        $articleNewID=I('get.article_new_id','');
        $minus=0;
        $articleIdJudge['article_id']=$articleId;
        if($articleNewID!='')
        {
            $minus=$articleNewID-$articleId;
            $articleId=$articleNewID;
        }
        $list=M('list','article_new_');
        $list->where($articleIdJudge)->setInc('article_seen_num',1);//点击增加浏览量
        $articleNewList=$list->order('article_time desc')->limit(12)->select();//最新文章列表
        $this->assign('articleNew',$articleNewList);

        $articleRankList=$list->order('article_seen_num desc')->limit(12)->select();//阅读排行
        $this->assign('articleRank',$articleRankList);

        $minID=$list->where('article_id>=0')->min('article_id');
        $maxID=$list->where('article_id>=0')->max('article_id');

        if($articleId>$maxID)
        {
            $articleId=$minID;
        }
        else if($articleId<$minID)
        {
            $articleId=$maxID;
        }
        $result=null;
        if($articleNewID!='' && $minus==1)
        {
            $dataGet['article_id']=array('egt',$articleId);
            $result=$list->where($dataGet)->order('article_time asc')->select();
            $articleId=$result[0]['article_id'];
//            echo dump($minus);
//            echo dump($result);die;
        }
        else if($articleNewID!='' && $minus==-1){
            $dataGet['article_id']=array('elt',$articleId);
            $result=$list->where($dataGet)->order('article_time desc')->select();
            $articleId=$result[0]['article_id'];
//            echo dump($minus);
//            echo dump($result);die;
        }
        else if($articleNewID==''){
            $dataGet['article_id']=array('eq',$articleId);
            $result=$list->where($dataGet)->select();
        }

        $articlePreName='';
        $articleNextName='';
        if($articleId>$minID && $articleId<$maxID){
            $dataGet['article_id']=array('lt',$articleId);
            $preRes=$list->where($dataGet)->order('article_time desc')->select();
            $articlePreName=$preRes[0]['article_title'];
            $dataGet['article_id']=array('gt',$articleId);
            $nextRes=$list->where($dataGet)->order('article_time asc')->select();
            $articleNextName=$nextRes[0]['article_title'];
        }
        else if($articleId-1<$minID)
        {
            $articlePreName='[尾篇]'.($list->getFieldByArticle_id($maxID,'article_title'));
            if($articleId+1==$maxID)
            {
                $articleNextName=$articlePreName;
            }
            else{
                $dataGet['article_id']=array('gt',$articleId);
                $nextRes=$list->where($dataGet)->order('article_time asc')->select();
                $articleNextName=$nextRes[0]['article_title'];            }
        }
        else if($articleId+1>$maxID){
            $articleNextName='[首篇]'.($list->getFieldByArticle_id($minID,'article_title'));
            if($articleId-1==$minID)
            {
                $articlePreName=$articleNextName;
            }
            else{
                $dataGet['article_id']=array('lt',$articleId);
                $preRes=$list->where($dataGet)->order('article_time desc')->select();
                $articlePreName=$preRes[0]['article_title'];
            }
        }
        $this->assign('list',$result[0]);
        $this->assign('preName',$articlePreName);
        $this->assign('nextName',$articleNextName);
        $this->display('Index/article_show_normal');
    }
    public function articleCategory(){
        $flag=I('category_name','',false);
        if($flag=='')
        {
            $flag=I('article_category','',false);
        }
        $dataGet['article_category']=$flag;
        $list=M('list','article_new_');
        $count=$list->where($dataGet)->count();
        $page=new Page($count,10);
        $page->setConfig('header','<span class="rows">共 %TOTAL_ROW% 条记录 %NOW_PAGE%/%TOTAL_PAGE%页</span>');
        $page->setConfig('prev','上一页');
        $page->setConfig('next','下一页');
        $page->setConfig('first','首页');
        $page->setConfig('last','末尾');
        $page->setConfig('theme','%HEADER% %FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END%');
        $show=$page->show();
        $this->assign('pageInfo',$show);

        $this->assign('categoryInfo',$dataGet['article_category']);

        $articleCategoryList=$list->where($dataGet)->order('article_time desc')->limit($page->firstRow.','.$page->listRows)->select();
//        echo dump($articleCategoryList);die;
        $this->assign('articleCategory',$articleCategoryList);

        $articleNewList=$list->order('article_time desc')->limit(12)->select();//最新文章列表
        $this->assign('articleNew',$articleNewList);

        $articleRankList=$list->order('article_seen_num desc')->limit(12)->select();//阅读排行
        $this->assign('articleRank',$articleRankList);
        $this->display('article_show_category');
    }

}