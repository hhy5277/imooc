<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF8">
    <title>Xiewq's Blog</title>
    <link href="/MyBlog/Public/css/font-awesome.min.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/jquery-1.8.2.js"></script>
    <link href="/MyBlog/Public/css/back_stage/back_stage.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/back_stage/back_stage.js"></script>
    <link href="/MyBlog/Public/css/back_stage/back_stage_article_add.css" rel="stylesheet">

    <script type="text/javascript" src="/MyBlog/Data/Ueditor/ueditor.config.js"></script>
    <script type="text/javascript" src="/MyBlog/Data/Ueditor/ueditor.all.min.js"></script>
    <script>
        function selectChange(){
            var selectType=$('#article_add_type select').val();
            if(selectType=='转载')
            {
                $('.article_type_url_label,.article_type_url').show();
                $('.article_type_url').removeAttr('disabled');
            }
            else{
                $('.article_type_url_label,.article_type_url').hide();
                $('.article_type_url').attr({disabled:'disabled'});
            }
        }
        $(function(){
            $('.article_type_url_label,.article_type_url').hide();
            $('.article_type_url').attr({disabled:'disabled'});
            var sel=$('#article_add_type select').val();
            if(sel=='转载')
            {
                $('.article_type_url_label,.article_type_url').show();
                $('.article_type_url').removeAttr('disabled');
            }
        });
    </script>
    <script type="text/javascript">
        window.UEDITOR_HOME_URL='/MyBlog/Data/Ueditor/';
        window.UEDITOR_CONFIG.initialFrameWidth=600;
        window.UEDITOR_CONFIG.initialFrameHeight=240;
        window.onload = function(){

            var myUe=UE.getEditor('myEditor',{toolbars:[['fullscreen', 'source', 'undo', 'redo','bold', 'italic','paragraph', 'fontfamily', 'fontsize','simpleupload', 'insertimage','emotion','insertcode'] ],autoHeightEnabled: true,
                autoFloatEnabled: true,autoHeightEnabled:false});
            var contentPre='';
            myUe.addListener('beforeInsertImage', function (t,arg)
            {
                contentPre=myUe.getContent();
            });
            myUe.addListener('afterInsertImage', function (t,arg)
            {
                $('#article_add_picture .article_picture').val(arg[0].src);
                myUe.setContent(contentPre);
            });
        }
    </script>



</head>
<body>

<header>
    <div class="back_logo"></div>
    <nav>
        <ul>
            <li><a href="#">后台首页</a></li>
            <li><a href="#">网站信息</a></li>
            <li><a href="#">修改密码</a></li>
            <li><a href="<?php echo U('Index/logout',true);?>">安全退出</a></li>
        </ul>
    </nav>
</header>
<div id="back_content">
    <div class="back_left">
        <div class="first_menu"><i class="icon-edit"></i>文章管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="<?php echo U('articleList');?>">文章列表</a></li>
                <li><a href="<?php echo U('articleAdd');?>">添加文章</a></li>
                <li><a href="#">草稿箱</a></li>
                <li><a href="<?php echo U('articleRubbish');?>">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-file-alt"></i>日志管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">日志列表</a></li>
                <li><a href="#">添加日志</a></li>
                <li><a href="#">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-asterisk"></i>属性管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="<?php echo U('Attribute/attribute');?>">属性列表</a></li>
                <li><a href="<?php echo U('Attribute/attributeAdd');?>">添加属性</a></li>
                <li><a href="<?php echo U('Attribute/attributeRubbish');?>">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-list"></i>评论管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">评论列表</a></li>
                <li><a href="#">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-qrcode"></i>分类管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">分类列表</a></li>
                <li><a href="#">添加分类</a></li>
                <li><a href="#">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-hdd"></i>图片管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">图片列表</a></li>
                <li><a href="#">图片分类</a></li>
                <li><a href="#">添加图片</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-eye-open"></i>信息浏览</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">数据统计</a></li>
                <li><a href="#">个人信息</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-cogs"></i>网站设置</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">前台设置</a></li>
                <li><a href="#">后台设置</a></li>
                <li><a href="#">个人设置</a></li>
            </ul>
        </div>
    </div>
    <div class="back_right">
        <div class="back_right_position_tip">
            <p><span><i class="icon-home"></i>当前位置：</span>文章管理<<span><a href="#">文章列表<</a></span><span><a href="#">修改文章</a></span></p>
        </div>
        <div class="back_right_title">
            <h2><span>修改</span><span>文章</span></h2>
        </div>
        <form action="<?php echo U('articleUpdate',true);?>" method="post">
            <div class="article_add_content">
                <div id="article_add_type">
                    <label for="article_add_type">文章类型:</label>
                    <select name="article_type" onchange="selectChange()">
                        <option><?php echo ($articleRes["article_type"]); ?></option>
                        <?php if(is_array($type)): foreach($type as $key=>$typeList): ?><option><?php echo ($typeList["article_type"]); ?></option><?php endforeach; endif; ?>
                    </select>
                    <label class="article_type_url_label">源址:</label>
                    <input type="text" class="article_type_url" name="article_type_url" value="<?php echo ($articleRes['article_type_url']); ?>" placeholder="转载源地址"/>
                </div>
                <div>
                    <label for="article_add_title">文章标题:</label><input name="article_title" id="article_add_title" type="text" placeholder="please input article title" value="<?php echo ($articleRes["article_title"]); ?>"/>
                </div>
                <div>
                    <label for="article_add_child_title">文章子标题:</label><input name="article_child_title" id="article_add_child_title" type="text" placeholder="please input child title" value="<?php echo ($articleRes["article_child_title"]); ?>"/>
                </div>
                <div>
                    <label for="article_add_category">所属分类:</label>
                    <select name="article_category" id="article_add_category">
                        <option><?php echo ($articleRes["article_category"]); ?></option>
                        <option>请选择所属分类</option>
                        <?php if(is_array($category)): foreach($category as $key=>$vo): ?><option style="color:<?php echo ($vo["category_color"]); ?>;"><?php echo ($vo["category_name"]); ?></option><?php endforeach; endif; ?>

                    </select>
                </div>
                <div id="article_add_attribute">
                    <label>文章属性:</label>
                    <select name="article_attribute">
                        <option><?php echo ($articleRes["article_attribute"]); ?></option>
                        <option>请选择文章属性</option>
                        <?php if(is_array($attribute)): foreach($attribute as $key=>$att): ?><option style="color:<?php echo ($att["attribute_color"]); ?>;"><?php echo ($att["attribute_name"]); ?></option><?php endforeach; endif; ?>
                    </select>
                </div>

                <div id="article_add_textarea">
                    <label>文章内容:</label>
                    <textarea name="article_content" id="myEditor" placeholder="please input article title"><?php echo ($articleRes["article_content"]); ?></textarea>
                </div>
                <div id="article_add_picture">
                    <label>图片路径:</label><input type="text" name="article_picture_path" class="article_picture" value="<?php echo ($articleRes["article_picture_path"]); ?>" placeholder="请选择文章图片!(自动加载图片路径!不可编辑!)" readonly="true"/>
                </div>
                <input type="hidden" name="article_id" value="<?php echo ($articleRes["article_id"]); ?>">
                <div>
                    <!-- onclick="location.href='<?php echo U(submit);?>'"-->
                    <button type="submit">保存修改</button>
                    <!--<input type="submit" value="发布文章" />-->
                    <button>返回列表</button>
                </div>
            </div>
        </form>

    </div>

</div>
</body>
</html>