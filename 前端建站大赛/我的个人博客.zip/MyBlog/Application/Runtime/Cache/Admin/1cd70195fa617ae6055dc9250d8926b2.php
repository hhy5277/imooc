<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Xiewq's Blog</title>
    <link href="/MyBlog/Public/css/font-awesome.min.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/jquery-1.8.2.js"></script>
    <link href="/MyBlog/Public/css/back_stage/back_stage.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/back_stage/webSite_info.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/back_stage/back_stage.js"></script>
    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?557e02ccc9b200688a5eb41d4d1d6ec7";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>

</head>
<body>
<header>
    <div class="back_logo"></div>
    <nav>
        <ul>
            <li><a href="#">后台首页</a></li>
            <li><a href="#">网站信息</a></li>
            <li><a href="#">修改密码</a></li>
            <li><a href="<?php echo U('Index/logout',true);?>">安全退出</a></li>
        </ul>
    </nav>
</header>
<div id="back_content">
    <div class="back_left">
        <div class="first_menu"><i class="icon-edit"></i>文章管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="<?php echo U('articleList');?>">文章列表</a></li>
                <li><a href="<?php echo U('articleAdd');?>">添加文章</a></li>
                <li><a href="#">草稿箱</a></li>
                <li><a href="<?php echo U('articleRubbish');?>">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-file-alt"></i>日志管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">日志列表</a></li>
                <li><a href="#">添加日志</a></li>
                <li><a href="#">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-asterisk"></i>属性管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="<?php echo U('Attribute/attribute');?>">属性列表</a></li>
                <li><a href="<?php echo U('Attribute/attributeAdd');?>">添加属性</a></li>
                <li><a href="<?php echo U('Attribute/attributeRubbish');?>">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-list"></i>评论管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">评论列表</a></li>
                <li><a href="#">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-qrcode"></i>分类管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">分类列表</a></li>
                <li><a href="#">添加分类</a></li>
                <li><a href="#">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-hdd"></i>图片管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">图片列表</a></li>
                <li><a href="#">图片分类</a></li>
                <li><a href="#">添加图片</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-eye-open"></i>信息浏览</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">数据统计</a></li>
                <li><a href="#">个人信息</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-cogs"></i>网站设置</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">前台设置</a></li>
                <li><a href="#">后台设置</a></li>
                <li><a href="#">个人设置</a></li>
            </ul>
        </div>
    </div>
    <div class="back_right">
        <div class="back_right_position_tip">
            <p><span><i class="icon-home"></i>当前位置：</span>信息浏览<<span><a href="#">网站信息统计</a></span><span><a href="#"></a></span></p>
        </div>
        <div class="back_right_title">
            <h2><span>网站</span><span>信息统计</span></h2>
        </div>
        <div class="info_content">
            <div class="info_content_up">
                <p class="block_title"><span>一、网站</span><span>点击量</span></p>
                <div class="today_info">
                    <p><i class="icon-desktop"></i><span>今日访问量：</span><span></span></p>
                </div>
                <div class="detailed_info">
                    <div>
                        <p class="all_click"><i class="icon-star"></i><span>网站总访问量：</span><span></span><button>重置计数</button></p>
                    </div>
                    <div>
                        <p><i class="icon-bar-chart"></i><span>各主网页详细访问量：</span></p>
                        <ul>
                            <li><i class="icon-home"></i><span>主页：</span><span></span></li>
                            <li><i class="icon-user"></i><span>个人简介：</span><span></span></li>
                            <li><i class="icon-book"></i><span>学无止境：</span><span></span></li>
                            <li><i class="icon-fire"></i><span>青春岁月：</span><span></span></li>
                            <li><i class="icon-edit"></i><span>个人日志：</span><span></span></li>
                            <li><i class="icon-folder-open-alt"></i><span>模板文库：</span><span></span></li>
                            <li><i class="icon-comment"></i><span>留言板：</span><span></span></li>
                        </ul>
                    </div>
                </div>
                <div class="history_info">
                    <p><i class="icon-calendar"></i><span>历史访问量列表：</span></p>
                    <ul>
                        <li><span><i class="icon-time"></i>时间：</span><span><i class=" icon-bar-chart"></i>访问量：</span></li>
                    </ul>
                </div>

            </div>
            <div class="info_content_down">
                <p class="block_title"><span>二、网站</span><span>评论</span></p>

            </div>
        </div>
    </div>
</div>
</body>
</html>