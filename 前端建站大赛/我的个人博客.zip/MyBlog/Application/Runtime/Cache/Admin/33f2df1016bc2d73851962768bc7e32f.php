<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>博客后台登陆入口</title>
<link href="/MyBlog/Public/css/back_stage/back_stage_login.css" rel="stylesheet">
</head>

<body class="b">
<div class="lg">
<form action="<?php echo U('Login/judge',true);?>" method="post">
    <div class="lg_top"></div>
    <div class="lg_main">
        <div class="lg_m_1">
        	<input name="username" placeholder="username" value="" class="ur" />
        	<input name="password" type="password" placeholder="password" value="" class="pw" />
        </div>
    </div>
    <div class="lg_foot">
    <input type="submit" value="Login In" class="bn" /></div>
</form>
</div>

</body>
</html>