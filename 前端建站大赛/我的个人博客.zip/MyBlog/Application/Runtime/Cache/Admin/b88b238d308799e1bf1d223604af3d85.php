<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Xiewq's Blog</title>
    <link href="/MyBlog/Public/css/font-awesome.min.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/jquery-1.8.2.js"></script>
    <link href="/MyBlog/Public/css/back_stage/back_stage.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/back_stage/back_stage_article_list.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/back_stage/back_stage.js"></script>
    <link href="/MyBlog/Public/css/page.css" rel="stylesheet">
    <script>
        function deleteConfirm(){
            if(window.confirm("确认删除?")){
                window.location.href= "<?php echo U('article_delete?article_id='.($list_item['article_id']),true);?>";
             }
            else{
                return "<?php echo U('index',true);?>";
            }

        }
    </script>
</head>
<body>
<header>
    <div class="back_logo"></div>
    <nav>
        <ul>
            <li><a href="#">后台首页</a></li>
            <li><a href="#">网站信息</a></li>
            <li><a href="#">修改密码</a></li>
            <li><a href="<?php echo U('Index/logout',true);?>">安全退出</a></li>
        </ul>
    </nav>
</header>
<div id="back_content">
    <div class="back_left">
        <div class="first_menu"><i class="icon-edit"></i>文章管理</div>
            <div class="sec_menu">
                <ul>
                    <li><a href="<?php echo U('articleList');?>">文章列表</a></li>
                    <li><a href="<?php echo U('articleAdd');?>">添加文章</a></li>
                    <li><a href="#">草稿箱</a></li>
                    <li><a href="<?php echo U('articleRubbish');?>">回收站</a></li>
                </ul>
            </div>
        <div class="first_menu"><i class="icon-file-alt"></i>日志管理</div>
            <div class="sec_menu">
                <ul>
                    <li><a href="#">日志列表</a></li>
                    <li><a href="#">添加日志</a></li>
                    <li><a href="#">回收站</a></li>
                </ul>
            </div>
        <div class="first_menu"><i class="icon-asterisk"></i>属性管理</div>
            <div class="sec_menu">
                <ul>
                    <li><a href="<?php echo U('Attribute/attribute');?>">属性列表</a></li>
                    <li><a href="<?php echo U('Attribute/attributeAdd');?>">添加属性</a></li>
                    <li><a href="<?php echo U('Attribute/attributeRubbish');?>">回收站</a></li>
                </ul>
            </div>
        <div class="first_menu"><i class="icon-list"></i>评论管理</div>
            <div class="sec_menu">
                <ul>
                    <li><a href="#">评论列表</a></li>
                    <li><a href="#">回收站</a></li>
                </ul>
        </div>
        <div class="first_menu"><i class="icon-qrcode"></i>分类管理</div>
             <div class="sec_menu">
                  <ul>
                      <li><a href="#">分类列表</a></li>
                      <li><a href="#">添加分类</a></li>
                      <li><a href="#">回收站</a></li>
                  </ul>
            </div>
        <div class="first_menu"><i class="icon-hdd"></i>图片管理</div>
            <div class="sec_menu">
            <ul>
                <li><a href="#">图片列表</a></li>
                <li><a href="#">图片分类</a></li>
                <li><a href="#">添加图片</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-eye-open"></i>信息浏览</div>
            <div class="sec_menu">
            <ul>
                <li><a href="#">数据统计</a></li>
                <li><a href="#">个人信息</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-cogs"></i>网站设置</div>
            <div class="sec_menu">
                <ul>
                    <li><a href="#">前台设置</a></li>
                    <li><a href="#">后台设置</a></li>
                    <li><a href="#">个人设置</a></li>
                 </ul>
         </div>
    </div>
    <div class="back_right">
        <div class="back_right_position_tip">
            <p><span><i class="icon-home"></i>当前位置：</span>文章管理<<span><a href="#">文章列表</a></span><span><a href="#"></a></span></p>
        </div>
        <div class="back_right_title">
            <span>文章</span><span>列表</span>
        </div>
        <div class="article_list_content">
            <table>
                <tr>
                    <th>文章编号</th>
                    <th>发布时间</th>
                    <th>文章标题</th>
                    <th>所属分类</th>
                    <th>文章属性</th>
                    <th>文章操作</th>
                </tr>
                <?php if(is_array($result)): foreach($result as $key=>$list_item): ?><tr>
                        <td><?php echo ($list_item["article_id"]); ?></td>
                        <td><?php echo ($list_item["article_time"]); ?></td>
                        <td><?php echo ($list_item["article_title"]); ?></td>
                        <td><?php echo ($list_item["article_category"]); ?></td>
                        <td><?php echo ($list_item["article_attribute"]); ?></td>
                        <td>[<a href="<?php echo U('Index/article_inspect',array('article_id'=>$list_item['article_id']),true);?>">查看</a>][<a href="<?php echo U('Index/articleUpdateShow',array('article_id'=>$list_item['article_id']),true);?>">修改</a>][<a href="<?php echo U('article_delete?article_id='.($list_item['article_id']),true);?>">删除</a>]</td>
                    </tr><?php endforeach; endif; ?>
            </table>
            <div class="scott"><?php echo ($pageInfo); ?></div>
        </div>
    </div>
</div>
</body>
</html>