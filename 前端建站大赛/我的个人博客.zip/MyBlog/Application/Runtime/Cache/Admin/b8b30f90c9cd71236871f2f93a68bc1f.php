<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Xiewq's Blog</title>
    <link href="/MyBlog/Public/css/font-awesome.min.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/jquery-1.8.2.js"></script>
    <link href="/MyBlog/Public/css/back_stage/back_stage.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/back_stage/back_stage_attribute_add.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/back_stage/back_stage.js"></script>
    <!--<link href="/MyBlog/Data/ColorPicker/css/colorpicker.css" rel="stylesheet" />-->
    <!--<script src="/MyBlog/Data/ColorPicker/js/colorpicker.js"></script>-->
    <link href="/MyBlog/Data/spectrum/spectrum.css" rel="stylesheet" />
    <script src="/MyBlog/Data/spectrum/spectrum.js"></script>
    <script>
        $(function(){
            $("#mycolorpicker").spectrum({
                color: '#e29931',
                showInitial:true,
                showAlpha:true,
                preferredFormat: "hex3",
                showInput: true,
                showPalette:true,
                palette: [["red", "rgba(0, 255, 0, .5)", "rgb(0, 0, 255)"]],
                showSelectionPalette:true,
                change: function(color) {
                    var cuColor=color.toHexString();
                    $('.item_color').append("<option style='background-color:"+cuColor+" ;'>"+cuColor+"</option>");
                }
            });

        });
    </script>
</head>
<body>
<div id="back_top">
    <div class="back_logo"></div>
    <ul>
        <li><a href="#">后台首页</a></li>
        <li><a href="#">网站信息</a></li>
        <li><a href="#">修改密码</a></li>
        <li><a href="#">安全退出</a></li>
    </ul>
</div>
<div id="back_content">
    <div class="back_left">
        <div class="first_menu"><i class="icon-edit"></i>文章管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="<?php echo U('articleList');?>">文章列表</a></li>
                <li><a href="<?php echo U('articleAdd');?>">添加文章</a></li>
                <li><a href="#">草稿箱</a></li>
                <li><a href="<?php echo U('articleRubbish');?>">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-file-alt"></i>日志管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">日志列表</a></li>
                <li><a href="#">添加日志</a></li>
                <li><a href="#">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-asterisk"></i>属性管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="<?php echo U('Attribute/attribute');?>">属性列表</a></li>
                <li><a href="<?php echo U('Attribute/attributeAdd');?>">添加属性</a></li>
                <li><a href="<?php echo U('Attribute/attributeRubbish');?>">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-list"></i>评论管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">评论列表</a></li>
                <li><a href="#">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-qrcode"></i>分类管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">分类列表</a></li>
                <li><a href="#">添加分类</a></li>
                <li><a href="#">回收站</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-hdd"></i>图片管理</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">图片列表</a></li>
                <li><a href="#">图片分类</a></li>
                <li><a href="#">添加图片</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-eye-open"></i>信息浏览</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">数据统计</a></li>
                <li><a href="#">个人信息</a></li>
            </ul>
        </div>
        <div class="first_menu"><i class="icon-cogs"></i>网站设置</div>
        <div class="sec_menu">
            <ul>
                <li><a href="#">前台设置</a></li>
                <li><a href="#">后台设置</a></li>
                <li><a href="#">个人设置</a></li>
            </ul>
        </div>
    </div>
    <div class="back_right">
        <div class="back_right_position_tip">
            <p><span><i class="icon-home"></i>当前位置：</span>属性管理<<span><a href="#">添加属性</a></span><span><a href="#"></a></span></p>
        </div>
        <div class="back_right_title">
            <h2><span>添加属性</span></h2>
        </div>
        <form action="<?php echo U('Attribute/attributeInsert',true);?>" method="post">
            <div class="back_right_item">
                <div class="item_text">
                    <span>属性名称:</span>
                    <input name="attribute_name" type="text" class="item_name">
                </div>
                <div class="item_text">
                    <span>标题颜色:</span>
                    <select class="item_color" name="attribute_color">
                        <option>*****请选择颜色*****</option>
                        <?php if(is_array($resultColor)): foreach($resultColor as $key=>$colorItem): ?><option style='color:<?php echo ($colorItem["attribute_color"]); ?>;'><?php echo ($colorItem["attribute_color"]); ?></option><?php endforeach; endif; ?>
                    </select>
                    <input type='text' id="mycolorpicker" />
                </div>
                <input type="submit" class="item_save" value="保存添加">
                <input type="button" class="item_close" value="关闭">
            </div>
        </form>
        <!--此处添加属性内容-->
    </div>
</div>
</body>
</html>