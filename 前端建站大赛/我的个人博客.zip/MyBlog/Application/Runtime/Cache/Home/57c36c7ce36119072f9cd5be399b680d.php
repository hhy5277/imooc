<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="/MyBlog/Public/css/font-awesome.min.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/main_one/main_style.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/main_one/comment_board_style.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/jquery-1.8.2.js"></script>
    <script src="/MyBlog/Public/js/main_one/main_all.js"></script>

</head>
<body>
    <header>
        <div class="header_logo"><h2>Xiewq<span>'s</span> <span>Blog</span></h2></div>
        <nav>
            <ul>
                <li><a href="<?php echo U('Index/index');?>">首页</a></li>
                <li><a href="<?php echo U('AboutMe/index');?>">个人简介</a></li>
                <li><a href="<?php echo U('Learn/index');?>">学无止境</a></li>
                <li><a href="<?php echo U('Navigation/index');?>">青春岁月</a></li>
                <li><a href="#">个人日志</a></li>
                <li><a href="#">模板文库</a></li>
                <li><a href="<?php echo U('Comment/comment',true);?>">留言板</a></li>
            </ul>
        </nav>
    </header>
    <div class="board_content">
        <div class="board_position_tip">
            <span><a href="<?php echo U('Index/index');?>"><i class="icon-home"></i> 网站首页 </a></span>>><span><a href="<?php echo U('Comment/comment',true);?>">留言板</a></span>
        </div>
        <div class="board_left">
            <div class="board_show">
                <div class="board_show_title">留言板</div>
                <div class="board_show_content">
                    <p><span>留言轻语：</span><strong>Welcome To My Blog！</strong>欢迎你的来访，你的留言是对我的最好的支持和鼓励！</p>
                    <p>由于本人实力有限，还在继续学习中，希望大家看到有问题的地方能多多包涵，多多提出你们宝贵的意见，我定当认真吸取各位的意见。如果大家有刚学习前端后台的，有不懂得问题，对本网站有任何疑问或者想借鉴我的一些技术的都可以给我<b>留言</b>或者直接加我<b>QQ</b>，或者给我发<b>邮件</b>，我们一起探讨学习，共同进步。</p>
                    <p>鉴于博客刚刚成立，对于<b>交换友情链接</b>的问题，凡在我的博客<b>留言</b>的或者<b>提出宝贵意见</b>的朋友，如果不嫌弃本站，都可进入我的友情链接。<b>申请方式</b>可以<b>直接留言</b>，或者发<b>博客链接</b>到我的邮箱，<b>注明</b>你的<b>个人信息</b>。</p>
                </div>
            </div>
            <div class="board_write">
                <!-- 多说评论框 start -->
                <div class="ds-thread" data-thread-key="<?php echo ($comment_info); ?>" data-title="<?php echo ($comment_info); ?>" data-url="http://localhost/MyBlog/"></div>
                <!-- 多说评论框 end -->
                <!-- 多说公共JS代码 start (一个网页只需插入一次) -->
                <script type="text/javascript">
                    var duoshuoQuery = {short_name:"xwq2016"};
                    (function() {
                        var ds = document.createElement('script');
                        ds.type = 'text/javascript';ds.async = true;
                        ds.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//static.duoshuo.com/embed.js';
                        ds.charset = 'UTF-8';
                        (document.getElementsByTagName('head')[0]
                        || document.getElementsByTagName('body')[0]).appendChild(ds);
                    })();
                </script>
                <!-- 多说公共JS代码 end -->
            </div>
        </div>
        <div class="board_right">
            <div class="personal_profile">
                <div class="profile_title"><p><i class="icon-user"></i><span>个人</span><span>简介</span></p></div>
                <div class="profile_content">
                    <p>网名：xx</p>
                    <p>姓名：谢文奇</p>
                    <p>籍贯：湖北省-随州市</p>
                    <p>现居：黑龙江省-哈尔滨市</p>
                    <p>职业：网站设计、Android开发</p>
                    <p>喜欢的书：《基督山伯爵》</p>
                    <p>QQ：435598045</p>
                </div>
            </div>
            <div class="friend_link">
                <div class="profile_title"><p><i class="icon-link"></i><span>友情</span><span>链接</span></p></div>
                <ul>
                    <li><div>1</div><a href="#">张三的个人博客</a> </li>
                    <li><div>2</div><a href="#">李四的个人博客</a></li>
                    <li><div>3</div><a href="#">王五的个人博客</a></li>
                </ul>
            </div>
        </div>
    </div>
    <footer>
        <h5>Design by Xiewq <a href="http://www.miitbeian.gov.cn/" target="_blank">鄂ICP备6859888号-001</a></h5>
    </footer>
</body>
</html>