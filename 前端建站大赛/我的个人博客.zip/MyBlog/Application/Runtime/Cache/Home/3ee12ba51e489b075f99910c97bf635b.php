<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en" xmlns:>
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="/MyBlog/Public/css/font-awesome.min.css" rel="stylesheet"/>
    <link href="/MyBlog/Public/css/main_one/main_one_style.css" rel="stylesheet"/>
    <script src="/MyBlog/Public/js/jquery-1.8.2.js"></script>
    <script src="/MyBlog/Public/js/main_one/main_one.js"></script>
    <script src="/MyBlog/Public/js/main_one/main_all.js"></script>
</head>
<body>
    <header>
        <div class="header_logo"><h2>Xiewq<span>'s</span> <span>Blog</span></h2></div>
        <nav>
            <ul>
                <li><a href="<?php echo U('Index/index');?>">首页</a></li>
                <li><a href="<?php echo U('AboutMe/index');?>">个人简介</a></li>
                <li><a href="<?php echo U('Learn/index');?>">学无止境</a></li>
                <li><a href="<?php echo U('Navigation/index');?>">青春岁月</a></li>
                <li><a href="#">个人日志</a></li>
                <li><a href="#">模板文库</a></li>
                <li><a href="<?php echo U('Comment/comment',true);?>">留言板</a></li>
            </ul>
        </nav>
    </header>
    <div id="main_banner">
        <div class="banner_content">
            <ul>
                <li>喝一杯苦咖啡，为了和生活相遇</li>
                <li>咖啡飘散过香味，剩苦涩陪着我</li>
                <li>其实，真正的咖啡，本身就是一种心情，一种品位</li>
            </ul>
            <ul>
                <li>时光飞逝</li>
                <li>机会就在我们眼前</li>
                <li>我们需要智慧和勇气去把握机会</li>
            </ul>
            <ul>
                <li>人一简单就快乐</li>
                <li>一世故就变老</li>
                <li>一个人总要走陌生的路</li>
            </ul>
            <ul>
                <li>只要你肯为我流一滴眼泪</li>
                <li>我就可以为而你活下去</li>
                <li>幸福不是努力去爱，而是安心的生活</li>
            </ul>
        </div>
        <div class="banner_mb">
            <ul>
                <li><a href="#">等一个人的咖啡</a>
                <li><a href="#">时光匆匆地流过</a>
                <li><a href="#">每一天美好心情</a>
                <li><a href="#">属于你的我的爱</a></li>
            </ul>
        </div>
        <div class="banner_index">
            <ul>
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>
            </ul>
        </div>
    </div>
    <div id="content">
        <div class="main_view"></div>
        <div class="main_content">
            <div class="content_title">
                <h2><span>文章</span><span>推荐</span></h2>
            </div>
            <article class="content_left">
                <?php if(is_array($recommendList)): foreach($recommendList as $key=>$recommendItem): ?><article>
                        <div class="article_title"><p><?php echo ($recommendItem["article_title"]); ?></p></div>
                        <figure>
                            <figcaption>

                            </figcaption>
                            <div><img src="<?php echo ($recommendItem["article_picture_path"]); ?>" ></div>
                        </figure>
                        <div class="figure_content">
                            <p><?php echo ($recommendItem["article_child_title"]); ?></p>
                            <div><a href="<?php echo U('Index/article_current_page',array('article_attribute'=>$recommendItem['article_attribute'],'article_id'=>$recommendItem['article_id']),true);?>">阅读全文>></a></div>
        </div>
                        <div class="figure_end">
                            <p> <span> <i class="icon-user"></i> 作者：<?php echo ($recommendItem["article_author"]); ?></span> <span><i class="icon-edit"></i> 个人博客：[<a href="<?php echo U('Index/articleCategory',array('article_category'=>$recommendItem['article_category']),true);?>"><?php echo ($recommendItem["article_category"]); ?></a>]</span><span><i class="icon-time"></i> 时间:<?php echo ($recommendItem["article_time"]); ?></span></p>
                        </div>
                    </article><?php endforeach; endif; ?>
            </article>
            <div class="content_right">
                <div class="content_clock">

                    <iframe allowtransparency="true" frameborder="0" width="257" height="100" scrolling="no" src="http://tianqi.2345.com/plugin/widget/index.htm?s=1&z=3&t=1&v=0&d=1&bd=1&k=c0c0c0&f=&q=1&e=0&a=1&c=50953&w=257&h=100&align=center"></iframe>
                </div>
                <div class="good_article">
                    <div class="good_article_title">
                        <h3>文章<span>精选</span></h3>
                    </div>
                    <ul>
                        <?php if(is_array($essenceList)): foreach($essenceList as $key=>$essenceItem): ?><li><i class="icon-book"></i><a href="<?php echo U('Index/article_current_page',array('article_id'=>$essenceItem['article_id'],'article_attribute'=>$essenceItem['article_attribute']),true);?>"><?php echo ($essenceItem["article_title"]); ?></a></li><?php endforeach; endif; ?>
                    </ul>
                </div>
                <div class="content_classify">
                    <div class="content_classify_title">
                        <h3>干货<span>分类</span></h3>
                    </div>
                    <ul>
                        <?php if(is_array($category)): foreach($category as $key=>$categoryItem): ?><li style="background-color:<?php echo ($categoryItem['category_color']); ?>;"><a href="<?php echo U('articleCategory',array('category_name'=>$categoryItem['category_name']),true);?>"><?php echo ($categoryItem['category_name']); ?></a></li><?php endforeach; endif; ?>

                    </ul>
                </div>
                <div class="self_info">
                    <div class="self_info_title">
                        <h3><span>个人信息</span><span>链接</span></h3>
                    </div>
                    <div class="self_info_img">
                        <img src="/MyBlog/Public/image/main_one/xwqweixinchat.jpg">
                    </div>
                    <div class="info_content_share">
                        <div class="bdsharebuttonbox"><a href="#" class="bds_more" data-cmd="more"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a></div>
                        <script>window._bd_share_config={"common":{"bdSnsKey":{"tqq":"www.hao123.com"},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"32"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
                    </div>
                </div>
                <div class="friendly_link">
                    <div class="friendly_link_title">
                        <h3><span>友情</span><span>链接</span></h3>
                    </div>
                    <div class="friendly_link_content">
                        <ul>
                            <li><a href="#">张三的个人博客</a></li>
                            <li><a href="#">李四的个人博客</a></li>
                            <li><a href="#">王五的个人博客</a></li>
                            <li><a href="#">杨六的个人博客</a></li>
                            <li><a href="#">朱七的个人博客</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer>
        <h5>Design by Xiewq <a href="http://www.miitbeian.gov.cn/" target="_blank">鄂ICP备6859888号-001</a></h5>
    </footer>
</body>
</html>