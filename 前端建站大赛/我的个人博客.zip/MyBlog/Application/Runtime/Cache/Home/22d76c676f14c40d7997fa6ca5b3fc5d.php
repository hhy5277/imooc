<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="/MyBlog/Public/css/font-awesome.min.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/main_one/main_style.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/main_one/learn_no_limit.css" rel="stylesheet">
    <script src="/MyBlog/Data/Ueditor/third-party/SyntaxHighlighter/shCore.js"></script>
    <link href="/MyBlog/Data/Ueditor/third-party/SyntaxHighlighter/shCoreDefault.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/page.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/jquery-1.8.2.js"></script>
    <script src="/MyBlog/Public/js/main_one/main_all.js"></script>
    <script>
        SyntaxHighlighter.all();
    </script>
</head>
<body>
    <header>
        <div class="header_logo"><h2>Xiewq<span>'s</span> <span>Blog</span></h2></div>
        <nav>
            <ul>
                <li><a href="<?php echo U('Index/index');?>">首页</a></li>
                <li><a href="<?php echo U('AboutMe/index');?>">个人简介</a></li>
                <li><a href="<?php echo U('Learn/index');?>">学无止境</a></li>
                <li><a href="<?php echo U('Navigation/index');?>">青春岁月</a></li>
                <li><a href="#">个人日志</a></li>
                <li><a href="#">模板文库</a></li>
                <li><a href="<?php echo U('Comment/comment',true);?>">留言板</a></li>
            </ul>
        </nav>
    </header>
    <div class="board_content">
        <div class="board_position_tip">
            <a href="<?php echo U('Index/index');?>"><i class="icon-home"></i> 网站首页</a>>><span><a href="#">学无止境</a></span>
        </div>
        <div class="board_left">
            <?php if(is_array($articleCategory)): foreach($articleCategory as $key=>$categoryItem): ?><article>
                <div class="article_title"><p><?php echo ($categoryItem["article_title"]); ?><span>[<span><?php echo ($categoryItem["article_attribute"]); ?></span>]</span></p></div>
                <figure>
                    <figcaption>

                    </figcaption>
                    <div><img src="<?php echo ($categoryItem["article_picture_path"]); ?>" ></div>
                </figure>
                <div class="figure_content">
                    <p><?php echo ($categoryItem["article_child_title"]); ?></p>
                    <div><a href="<?php echo U('Index/article_inspect_normal',array('article_id'=>$categoryItem['article_id']),true);?>">阅读全文>></a></div>
                </div>
                <div class="figure_end">
                    <p> <span> <i class="icon-user"></i> 作者：<?php echo ($categoryItem["article_author"]); ?></span> <span><i class="icon-edit"></i> 个人博客：[<a href="#"><?php echo ($categoryItem["article_category"]); ?></a>]</span><span><i class="icon-time"></i> 时间:<?php echo ($categoryItem["article_time"]); ?></span></p>
                </div>
            </article><?php endforeach; endif; ?>
            <div class="scott"><?php echo ($pageInfo); ?></div>
        </div>
        <div class="board_right">
            <div class="board_right_title">
                <div><span><i class="icon-tags"></i></span><span>网站</span><span>导航</span></div>
            </div>
            <div class="board_right_navigation">
                <ul>
                    <li><a href="<?php echo U('Index/index',true);?>">网站首页</a></li>
                    <li><a href="<?php echo U('AboutMe/index',true);?>">个人简介</a></li>
                    <li><a href="#">建站教程</a></li>
                    <li><a href="<?php echo U('Comment/index',true);?>">留言板</a></li>
                </ul>
            </div>
            <div class="board_right_navigation">
                <ul>
                    <li><a href="<?php echo U('Index/index',true);?>">网站首页</a></li>
                    <li><a href="<?php echo U('AboutMe/index',true);?>">个人简介</a></li>
                    <li><a href="#">建站教程</a></li>
                    <li><a href="<?php echo U('Comment/index',true);?>">留言板</a></li>
                </ul>
            </div>
            <div class="board_right_new_article">
                <div class="board_right_title">
                    <div><span><i class="icon-list"></i></span><span>精品</span><span>筛选</span></div>
                </div>
                <ul>
                    <?php if(is_array($articleNew)): foreach($articleNew as $key=>$articleNewItem): ?><li><i class="icon-book"></i><a href="<?php echo U('Index/article_current_page',array('article_id'=>$articleNewItem['article_id'],'article_attribute'=>$articleNewItem['article_attribute']),true);?>"><?php echo ($articleNewItem["article_title"]); ?></a></li><?php endforeach; endif; ?>
                </ul>
            </div>
            <div class="board_right_article_rank">
                <div class="board_right_title">
                    <div><span><i class="icon-heart"></i></span><span>点击</span><span>排行</span></div>
                </div>
                <ul>
                    <?php if(is_array($articleRank)): foreach($articleRank as $key=>$articleRankItem): ?><li><i class="icon-book"></i><a href="<?php echo U('Index/article_inspect_normal',array('article_id'=>$articleRankItem['article_id']),true);?>"><?php echo ($articleRankItem["article_title"]); ?></a></li><?php endforeach; endif; ?>
                </ul>
            </div>
            <div class="board_right_comment_hot">
                <div class="board_right_title">
                    <div><span><i class="icon-user"></i></span><span>最近</span><span>访客</span></div>
                </div>
                <ul class="ds-recent-visitors"></ul>
            </div>
        </div>
    </div>
    <footer>
        <h5>Design by Xiewq <a href="http://www.miitbeian.gov.cn/" target="_blank">鄂ICP备6859888号-001</a></h5>
    </footer>
</body>
</html>