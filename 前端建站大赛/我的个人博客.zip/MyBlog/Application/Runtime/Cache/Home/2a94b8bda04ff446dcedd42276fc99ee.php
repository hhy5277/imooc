<?php if (!defined('THINK_PATH')) exit();?> <html>
 <head>
     <title>hello <?php echo ($name); ?></title>
 </head>
 <body>
    hello,<?php echo ($name); ?>!
    id=<?php echo ($result["id"]); ?>
    data=<?php echo ($result["data"]); ?>
 </body>
 </html>