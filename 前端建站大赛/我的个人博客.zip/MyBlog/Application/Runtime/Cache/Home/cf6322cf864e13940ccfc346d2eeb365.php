<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="/MyBlog/Public/css/font-awesome.min.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/main_one/main_style.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/main_one/about_me.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/csshake.min.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/jquery-1.8.2.js"></script>
    <script src="/MyBlog/Public/js/main_one/main_all.js"></script>
</head>
<body>
<header>
    <div class="header_logo"><h2>Xiewq<span>'s</span> <span>Blog</span></h2></div>
    <nav>
        <ul>
            <li><a href="<?php echo U('Index/index');?>">首页</a></li>
            <li><a href="<?php echo U('AboutMe/index');?>">个人简介</a></li>
            <li><a href="<?php echo U('Learn/index');?>">学无止境</a></li>
            <li><a href="<?php echo U('Navigation/index');?>">青春岁月</a></li>
            <li><a href="#">个人日志</a></li>
            <li><a href="#">模板文库</a></li>
            <li><a href="<?php echo U('Comment/comment',true);?>">留言板</a></li>
        </ul>
    </nav>
</header>
<div class="about_con">
    <div class="about_menu">
        <span><i class="icon-home"></i><a href="<?php echo U('Index/index');?>">网站首页</a></span><<<span><a href="<?php echo U('AboutMe/index');?>">个人简介</a></span>
    </div>

    <div class="about_left">
        <div class="about_show">
            <h2>Personal Profile</h2>
            <div>
                <p>大家好！<span>l'm</span> <b>谢文奇</b>，一名<b>90</b>后的大学<b>本科生</b>，马上就要<i>毕业了</i>，时光飞快，不知不觉已经<b>大三</b>了，大学期间修读的是<b>计算机专业</b>，由于从小就对计算机感兴趣，虽然那时候对计算机的理解很懵懂，但是心中还是满怀憧憬之情，以至于最后选择了这个行业。</p>
                <p>虽然跟想象中的有点不一样，但是在迷茫中经历一番探索之后，在老师和师哥师姐的帮助下，让我对这个专业越来越感兴趣了，虽然这个专业很难，但是在强大的兴趣爱好面前，这些已经微不足道了。</p>
                <p>因为喜欢所以自学了很多<b>互联网</b>技术，在学习过程中不断实践，做出了很多我喜欢的小作品，每一个小成果都会让我兴奋一阵子，也许这就是我能坚持到现在的主要原因，在学校的基础理论之上，成热打铁，进入与之相关的技术领域。</p>
                <p>从最开始的<span>C语言</span>到现在的平台技术的学习，过去的那一幕幕仍会在我眼前展现，作为大学期间所有的专业中最难的课也最多的专业之一，每天满满的课，每周都会有很多实验上机课，当突然轻松下来时，发现已经快毕业了，人们常说大学是最轻松的。吃喝玩乐谈恋爱，这才是最有意义的大学生活。。说没有挂科的大学是不完整的，没有谈恋爱的大学是不完美的，，现在蓦然回首才发现这些话已经不是对我来说的了，因为我的大学生活已经快结束了。</p>
                <p>从面向过程的<span>C语言</span>到面向对象的<span>C++</span>、<span>Java</span>，通过这几个最基本的语言学习，和后期<b>操作系统</b>的学习，对<span>windows</span>，<span>linux</span>系统的了解，顺着学习了<span>android</span>平台的开发技术，用<span>android</span>开发了很多小东西，也训练过大作业，通过<span>j2ee</span>课程的学习，让我深入了解了<span>web</span>开发原理，服务器端的工作机理以及浏览器客户端的请求实现等知识，对脚本<span>jsp</span>的学习和训练，在此基础运用设计模式<span>MVC</span>作出了一个小项目。由于之前对<span>php</span>比较感兴趣，假期顺着前面对<span>web</span>前端后台的理解，专门学习了<span>html</span>，<span>css</span>，<span>js</span>还有<span>jquery</span>，分别训练了静态页面和动态页面，由于之前的一系列良好语言基础，学习<span>php</span>显得很容易，而且很快就掌握了基本内容，然后自己做了些<span>php</span>简单的编程训练，在训练的过程中发现了<span>php</span>能开发微信公众账号，于是又开始了对微信公众账号的学习并且成功开发出自己的第一个微信公众账号。</p>
                <p>在实习期间利用前面自己自学的<span>web</span>前端知识和老师所教的，和我的项目组小伙伴们合作共同开发开发了一个旅游网的前端界面，并成功通过答辩。最后就到了综合训练的时候了，实习结束后，通过前端的学习和后台脚本的学习，为了方便快速建立网站，我又专门学习了<span>php</span>框架知识，运用框架和所学知识开始了我的第一个个人博客的开发。</p>
                <p>学习<b>永无止境</b>，也许我说了太多自己学习的过程，缺少生活的介绍，但是我觉得我的性格各方面都已经在我叙述学习的过程中展现出来了。</p>
            </div>
            <h2>About My Blog</h2>
            <div>
                <p><i class="icon-globe"></i>域名：<span>www.xiewq.com</span><span><a href="http://www.xiewq.com">我的主页</a></span></p>
                <p><i class="icon-cloud"></i>服务器：新浪<span>SAE</span>云服务器<span><a href="http://sae.sina.com.cn/">开通SAE云服务器</a></span></p>
                <p><i class="icon-eye-open"></i>前端程序：<span>html、css、javascript、jquery</span><span><a href="http://www.w3school.com.cn/">前端学习中心</a></span></p>
                <p><i class="icon-cog"></i>后端程序：<span>php、thinkphp</span>框架<span><a href="http://www.thinkphp.cn/">进入thinkphp框架学习</a></span></p>
                <p><i class="icon-time"></i>博客开通时间：<span>2016-03-06</span></p>
            </div>
            <div>
                <p class="shake shake-slow">“业精于勤而荒于嬉，行成于思而毁于随”，谨献此句与大家共勉之！</p>
            </div>
        </div>
    </div>
    <div class="about_right">
        <div class="title_block"><h3><i class="icon-user"></i><span>个人</span><span>简介</span></h3></div>
        <div class="myInfo">
            <p>网名：xx</p>
            <p>姓名：谢文奇</p>
            <p>籍贯：湖北省-随州市</p>
            <p>现居：黑龙江省-哈尔滨市</p>
            <p>身份：在校本科生</p>
            <p>职业：网站设计、Android开发</p>
            <p>喜欢的书：《基督山伯爵》</p>
            <p>喜欢的歌曲：《黑板情书》</p>
            <p>邮箱：435598045@qq.com</p>
        </div>
        <div class="picture_show">
        </div>
        <div class="weixin_chat">
            <div class="title_block"><h3><i class="icon-search"></i><span>我的</span><span>微信</span></h3></div>
            <img src="/MyBlog/Public/image/main_one/xwqweixinchat.jpg">
        </div>

    </div>
</div>
<footer>
    <h5>Design by Xiewq <a href="http://www.miitbeian.gov.cn/" target="_blank">鄂ICP备6859888号-001</a></h5>
</footer>
</body>
</html>