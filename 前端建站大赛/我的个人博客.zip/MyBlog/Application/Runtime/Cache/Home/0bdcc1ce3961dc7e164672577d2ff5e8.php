<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="/MyBlog/Public/css/font-awesome.min.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/main_one/main_style.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/main_one/article_show_style.css" rel="stylesheet">
    <script src="/MyBlog/Data/Ueditor/third-party/SyntaxHighlighter/shCore.js"></script>
    <link href="/MyBlog/Data/Ueditor/third-party/SyntaxHighlighter/shCoreDefault.css" rel="stylesheet">
    <script src="/MyBlog/Public/js/jquery-1.8.2.js"></script>
    <script src="/MyBlog/Public/js/main_one/main_all.js"></script>
    <script>
        SyntaxHighlighter.all();
    </script>
</head>
<body>
    <header>
        <div class="header_logo"><h2>Xiewq<span>'s</span> <span>Blog</span></h2></div>
        <nav><!--html5导航标签-->
            <ul>
                <li><a href="<?php echo U('Index/index');?>">首页</a></li>
                <li><a href="<?php echo U('AboutMe/index');?>">个人简介</a></li>
                <li><a href="<?php echo U('Learn/index');?>">学无止境</a></li>
                <li><a href="<?php echo U('Navigation/index');?>">青春岁月</a></li>
                <li><a href="#">个人日志</a></li>
                <li><a href="#">模板文库</a></li>
                <li><a href="<?php echo U('Comment/comment',true);?>">留言板</a></li>
            </ul>
        </nav>
    </header>
    <div class="board_content">
        <div class="board_position_tip">
            <a href="<?php echo U('Index/index');?>"><i class="icon-home"></i> 网站首页 </a>>><span><a href="#">文章阅读</a></span>
        </div>
        <div class="board_left">
            <div class="article_title">
                <span><?php echo ($list['article_title']); ?></span>
            </div>
            <div class="article_tip">
                <span><i class="icon-time"></i>发布时间:</span><span><?php echo ($list["article_time"]); ?></span><span><i class="icon-user"></i>作者:</span><span><?php echo ($list["article_author"]); ?></span><span><i class="icon-folder-open"></i>文章分类:</span><span><a href="#"><?php echo ($list["article_category"]); ?></a></span><span><i class="icon-eye-open"></i>文章浏览量:</span><span><?php echo ($list["article_seen_num"]); ?></span>
            </div>
            <div class="article_content">
                <?php echo ($list['article_content']); ?>
            </div>
            <div class="article_type_url">
                <span>文章类型:</span><span><?php echo ($list['article_type']); ?></span><span>来源:<a href="<?php echo ($list['article_type_url']); ?>"><?php echo ($list['article_type_url']); ?></a></span>
            </div>
            <div class="article_page_info">
                <div>上一篇:<a href="<?php echo U('article_inspect_normal',array('article_id'=>$list['article_id'],'article_new_id'=>$list['article_id']-1),true);?>"><?php echo ($preName); ?></a></div>
                <div>下一篇:<a href="<?php echo U('article_inspect_normal',array('article_id'=>$list['article_id'],'article_new_id'=>$list['article_id']+1),true);?>"><?php echo ($nextName); ?></a></div>
                <div><i class="icon-list"></i><a href="<?php echo U('index');?>">返回主页</a></div>
            </div>
            <div class="article_comment">
                <!-- 多说评论框 start -->
                <div class="ds-thread" data-thread-key="<?php echo ($list['article_id']); ?>" data-title="<?php echo ($list['article_title']); ?>" data-url="http://localhost/MyBlog/"></div>
                <!-- 多说评论框 end -->
                <!-- 多说公共JS代码 start (一个网页只需插入一次) -->
                <script type="text/javascript">
                    var duoshuoQuery = {short_name:"xwq2016"};
                    (function() {
                        var ds = document.createElement('script');
                        ds.type = 'text/javascript';ds.async = true;
                        ds.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//static.duoshuo.com/embed.js';
                        ds.charset = 'UTF-8';
                        (document.getElementsByTagName('head')[0]
                        || document.getElementsByTagName('body')[0]).appendChild(ds);
                    })();
                </script>
                <!-- 多说公共JS代码 end -->
            </div>
        </div>
        <div class="board_right">
            <div class="board_right_title">
                <div><span><i class="icon-tags"></i></span><span>网站</span><span>导航</span></div>
            </div>
            <div class="board_right_navigation">
                <ul>
                    <li><a href="<?php echo U('Index/index');?>">网站首页</a></li>
                    <li><a href="<?php echo U('Learn/index');?>">文章列表</a></li>
                    <li><a href="#">建站教程</a></li>
                    <li><a href="<?php echo U('Comment/comment',true);?>">留言板</a></li>
                </ul>
            </div>
            <div class="board_right_navigation">
                <ul>
                    <li><a href="<?php echo U('Index/index');?>">网站首页</a></li>
                    <li><a href="<?php echo U('Learn/index');?>">文章列表</a></li>
                    <li><a href="#">建站教程</a></li>
                    <li><a href="<?php echo U('Comment/comment',true);?>">留言板</a></li>
                </ul>
            </div>
            <div class="board_right_new_article">
                <div class="board_right_title">
                    <div><span><i class="icon-list"></i></span><span>最新</span><span>文章</span></div>
                </div>
                <ul>
                    <?php if(is_array($articleNew)): foreach($articleNew as $key=>$articleNewItem): ?><li><i class="icon-book"></i><a href="<?php echo U('article_inspect_normal',array('article_id'=>$articleNewItem['article_id']),true);?>"><?php echo ($articleNewItem["article_title"]); ?></a></li><?php endforeach; endif; ?>
                </ul>
            </div>
            <div class="board_right_article_rank">
                <div class="board_right_title">
                    <div><span><i class="icon-heart"></i></span><span>阅读</span><span>排行</span></div>
                </div>
                <ul>
                    <?php if(is_array($articleRank)): foreach($articleRank as $key=>$articleRankItem): ?><li><i class="icon-book"></i><a href="<?php echo U('article_inspect_normal',array('article_id'=>$articleRankItem['article_id']),true);?>"><?php echo ($articleRankItem["article_title"]); ?></a></li><?php endforeach; endif; ?>
                </ul>
            </div>
            <div class="board_right_comment_hot">
                <div class="board_right_title">
                    <div><span><i class="icon-user"></i></span><span>最近</span><span>访客</span></div>
                </div>
                <ul class="ds-recent-visitors"></ul>
            </div>
        </div>
    </div>
    <footer>
        <h5>Design by Xiewq <a href="http://www.miitbeian.gov.cn/" target="_blank">鄂ICP备6859888号-001</a></h5>
    </footer>
</body>
</html>