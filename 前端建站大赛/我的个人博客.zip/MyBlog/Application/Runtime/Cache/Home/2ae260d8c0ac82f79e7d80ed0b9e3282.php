<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="/MyBlog/Public/js/jquery-1.8.2.js"></script>
    <link href="/MyBlog/Public/css/font-awesome.min.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/main_one/main_style.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/main_one/person_timelife_style.css" rel="stylesheet">
    <script src="/MyBlog/Data/Ueditor/third-party/SyntaxHighlighter/shCore.js"></script>
    <link href="/MyBlog/Data/Ueditor/third-party/SyntaxHighlighter/shCoreDefault.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/page.css" rel="stylesheet">
    <link href="/MyBlog/Public/css/csshake.min.css" rel="stylesheet">
    <script type="text/javascript" src="/MyBlog/Public/js/main_one/person_timelife.js"></script>
    <script src="/MyBlog/Public/js/main_one/main_all.js"></script>
    <script>
        SyntaxHighlighter.all();
    </script>
</head>
<body>
    <header>
        <div class="header_logo"><h2>Xiewq<span>'s</span> <span>Blog</span></h2></div>
        <nav>
            <ul>
                <li><a href="<?php echo U('Index/index');?>">首页</a></li>
                <li><a href="<?php echo U('AboutMe/index');?>">个人简介</a></li>
                <li><a href="<?php echo U('Learn/index');?>">学无止境</a></li>
                <li><a href="<?php echo U('Navigation/index');?>">青春岁月</a></li>
                <li><a href="#">个人日志</a></li>
                <li><a href="#">模板文库</a></li>
                <li><a href="<?php echo U('Comment/comment',true);?>">留言板</a></li>
            </ul>
        </nav>
    </header>
    <div class="board_content">
        <div class="board_position_tip">
            <a href="<?php echo U('Index/index');?>"><i class="icon-home"></i> 网站首页</a>>><span><a href="#"><?php echo ($categoryInfo); ?>青春岁月</a></span>
        </div>
        <div class="board_top_banner">
            <div class="board_top_img">
                <img src="/MyBlog/Public/image/main_one/person_timelife_top.jpg">
            </div>
            <div class="board_top_info">
                <div>轻语岁月-浅释流年</div>
                <ul>
                    <li><i class="icon-eye-open"></i>时光匆匆，往事不堪回首，，，</li>
                    <li><i class="icon-eye-open"></i>当一个人感觉心累的时候，别太为难自己</li>
                    <li><i class="icon-eye-open"></i>理智的放下一些纠结，人只有一双手，终究不能抓住所有美好</li>
                    <li><i class="icon-eye-open"></i>很多事情就是一种选择，适合自己的才是最好的</li>
                    <li><i class="icon-eye-open"></i>人生路漫漫，适当的放下一些沉重的包袱</li>
                    <li><i class="icon-eye-open"></i>轻装前行，相信每一天都会有精彩在前方等着你</li>
                </ul>

            </div>
        </div>

        <div class="board_content_list">
            <?php if(is_array($lifeList)): foreach($lifeList as $key=>$listItem): ?><div class="content_item" >
                    <div class="content_main">
                        <div class="life_title">
                            <div><i class="icon-time"></i><?php echo (substr($listItem['create_time'],0,10)); ?></div>
                        </div>
                        <div class="life_content">
                            <div>
                                <img src="<?php echo ($listItem["picture_url"]); ?>"/>
                            </div>
                            <section>
                                <?php echo ($listItem["content"]); ?>
                            </section>
                        </div>
                        <div class="life_info">
                            <span><i class="icon-eye-open"></i><?php echo ($listItem["seen"]); ?></span>
                            <span><a href="<?php echo U('setInfoInc',array('id'=>$listItem['id'],'add'=>'thumbs_up'));?>"><i class="icon-thumbs-up"></i></a><?php echo ($listItem["thumbs_up"]); ?></span>
                            <span><a href="<?php echo U('setInfoInc',array('id'=>$listItem['id'],'add'=>'thumbs_down'));?>"><i class="icon-thumbs-down"></i></a><?php echo ($listItem["thumbs_down"]); ?></span>
                            <span><a href="<?php echo U('setInfoInc',array('id'=>$listItem['id'],'add'=>'collection'));?>"><i class="icon-heart"></i></a><?php echo ($listItem["collection"]); ?></span>
                        </div>
                    </div>
                    <div class="content_triangle">

                    </div>
                    <div class="content_circle">

                    </div>
                </div><?php endforeach; endif; ?>
        </div>
    </div>
    <footer>
        <h5>Design by Xiewq <a href="http://www.miitbeian.gov.cn/" target="_blank">鄂ICP备6859888号-001</a></h5>
    </footer>
</body>
</html>