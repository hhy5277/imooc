/**
 * Created by 43559 on 2016/3/5.
 */
$(function(){
    $('.board_content .content_item .content_main').mouseenter(function(){
        var index=$(this).parent().index();
        $('.board_content .content_item .life_info').eq(index).stop(true,false).animate({'bottom':'0px'},800);
    });
    $('.board_content .content_item .content_main').mouseleave(function(){
        $('.board_content .content_item .life_info').stop(true,false).animate({'bottom':'-25px'},800);
    });
});