/**
 * Created by 43559 on 2016/3/12.
 */
$(function(){
    $('header nav ul li:nth-child(5),header nav ul li:nth-child(6)').click(function(){
        alert('sorry!该板块正在开发中。。0.0');
    });
});
