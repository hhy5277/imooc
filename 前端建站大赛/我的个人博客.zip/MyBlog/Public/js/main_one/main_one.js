/**
 * Created by 43559 on 2016/2/9.
 */
$(function(){
    var index=0;
    $("#main_banner .banner_index").show();
    $("#main_banner").mouseenter(function(){
        $("#main_banner .banner_index").stop(true,false).fadeOut(200);
        $("#main_banner .banner_mb").stop(true,false).animate({"bottom":"0px"});
    });
    $("#main_banner").mouseleave(function(){
        $("#main_banner .banner_mb").stop(true,false).animate({"bottom":"-30px"});
        $("#main_banner .banner_index").fadeIn();
    });
    $("#main_banner .banner_mb ul li").click(function(){
        var mb_index=$(this).index();
        index=mb_index;
        $("#main_banner .banner_content ul").hide();
        $("#main_banner").css({"background-image":"url(/MyBlog/Public/image/main_one/header_bg_00"+index+".jpg)"});
        $("#main_banner .banner_mb li").css({"background-color":"#362e3a","color":"#fff","opacity":"0.7"});
        $("#main_banner .banner_mb li").eq(index).css({"background-color":"#785675","color":"#fff","opacity":"1"});
    });
    $("#main_banner .banner_mb ul li").mouseenter(function(){
        var mb_index=$(this).index();
        index=mb_index;
        $("#main_banner .banner_content ul").hide();
        $("#main_banner").css({"background-image":"url(/MyBlog/Public/image/main_one/header_bg_00"+index+".jpg)"});
        $("#main_banner .banner_mb li").css({"background-color":"#362e3a","color":"#fff","opacity":"0.7"});
        $("#main_banner .banner_mb li").eq(index).css({"background-color":"#785675","color":"#fff","opacity":"1"});
    });
    function banner_content_show(){
        $("#main_banner").css({"background-image":"url(/MyBlog/Public/image/main_one/header_bg_00"+index+".jpg)"});
        $("#main_banner .banner_content ul").hide();
        $("#main_banner .banner_content ul li").hide();
        if(index==1)
        {
            $("#main_banner .banner_content").css({"left":"680px"});
        }
        else if(index==2 || index==0)
        {
            $("#main_banner .banner_content").css({"left":"80px","top":"80px"});
        }
        else if(index==3)
        {
            $("#main_banner .banner_content").css({"left":"380px","top":"20px"});

        }
        $("#main_banner .banner_content ul").eq(index).show(function(){
            $("#main_banner .banner_content ul li:nth-child(1)").fadeIn(1500,function(){
                $("#main_banner .banner_content ul li:nth-child(2)").fadeIn(1500,function(){
                    $("#main_banner .banner_content ul li:nth-child(3)").fadeIn(2000,function(){
                        $("#main_banner .banner_content ul li").fadeOut(2000);

                    });
                });
            });
        });

        $("#main_banner .banner_mb li").css({"background-color":"#362e3a","color":"#fff","opacity":"0.7"});
        $("#main_banner .banner_mb li").eq(index).css({"background-color":"#785675","color":"#fff","opacity":"1"});
        $("#main_banner .banner_index li").css({"background-color":"#362e3a","color":"#fff","opacity":"0.7"});
        $("#main_banner .banner_index li").eq(index).css({"background-color":"#c85309","color":"#fff","opacity":"1"});

        ++index;
        if(index==4)
        {
            index=0;
        }
    }
    banner_content_show();
    setInterval(function(){
        banner_content_show();
    },8000);
});