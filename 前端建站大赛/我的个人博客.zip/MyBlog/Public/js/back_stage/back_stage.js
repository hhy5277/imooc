/**
 * Created by 43559 on 2016/2/11.
 */
$(function(){
    $(".first_menu").click(function(){
        $(this).next("div").slideToggle("slow").siblings(".sec_menu:visible").slideUp("slow");
    });
});