#include<stdio.h>
#include<malloc.h>
#include<string.h>
#include"queue.h"
void Init() {
    int temLength;
	p_Head = NULL;
	p_Tail = p_Head;
	puts("输入队列的长度：");
	scanf("%d", &temLength);
	Length = temLength;
}
bool isFull() {
	return countNode == Length;
}
bool isEmpty() {
	return countNode == 0;
}
bool addNode(Item item) {
	Node* temNode=NULL;
	if (isFull()) {
		puts("The queue is Full");
		return false;
	}
	temNode = (Node*)malloc(sizeof(Node));
	if ( temNode == NULL) {
		puts("Error,applying to the memery!");
		return false;
	}
	if (p_Tail == NULL) {                       //队列为空的情况
		temNode->pNext = NULL;        
		temNode->item= item;
		
		p_Tail = temNode;
		p_Head = p_Tail;
	}
	else {
		temNode->item = item;
		temNode->pNext = NULL;                   //队列不为空
		p_Tail->pNext = temNode;
		p_Tail = temNode;
	}
	countNode++;
	return true;
}
bool deleteNode() {
	if (isEmpty()) {
		puts("The queue is Empty!");
		return false;
	}
	Node* temNode;
	temNode = p_Head;
	p_Head = p_Head->pNext;
	temNode->pNext = NULL;
	free(temNode);
	countNode--;
	return true;
}
//不是一个通用方法
void listQueue() {
	if (isEmpty()) {
		puts("The queue is Empty!");
		exit(1);
	}
	int i = 0;
	Node* temNode;
	temNode = p_Head;
	for (i = 0; i < countNode; i++) {
		printf("%d %s\n", temNode->item.num, temNode->item.name);
		temNode = temNode->pNext;
	}
}
//按从头到尾的顺序修改节点值，并返回修改后的节点值,头结点为第0个
Node changeNode(int positionNum,Item item) {
	if (positionNum > countNode) {
		puts("要顺序修改的节点不在此队列中");
		return *p_Tail;
	}
	int i = 0;
	Node* temNode;
	temNode = p_Head;
	for (i = 0; i < countNode; i++) {
		if (i == positionNum) {
			temNode->item = item;
			return *temNode;
		}
		temNode = temNode->pNext;
	}	
}
//清空队列
void clearQueue() {
	while (p_Head != NULL) {
		deleteNode();
	}
}
Item buildItem(int num, char* name) {
	Item item;
	item.num = num;
	strcpy(item.name,name);
	return item;
}

  

