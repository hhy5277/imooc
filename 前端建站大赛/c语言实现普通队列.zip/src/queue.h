#ifndef QUEUE_H
#define QUEUE_H
#include<stdbool.h>
//队列节点的数据结构，可以根据不同需求进行改造
typedef struct NodeInfo{
    int num;
	char name[3];
}Item;
//队列节点内容，包括数据结构与指向下一个节点的指针
typedef struct Node
{
	Item item;
	struct Node* pNext;
}Node;
static Node* p_Head, *p_Tail;//指向队列的头指针，尾指针
static int Length;        //队列长度
static int countNode = 0;
//初始化，生成一个空队列
void Init();
//在队列尾部添加节点
bool addNode();
//在队列头部删除节点
bool deleteNode();
//判断队列是否为空
bool isEmpty();
//判断队列是否为满
bool isFull();
//遍历队列
void listQueue();
//修改任意位置节点值,传入该节点的顺序位置编号
Node changeNode(int positionNum,Item item);
//队列数据结构生成函数
Item buildItem(int num, char* name);
#endif

  

