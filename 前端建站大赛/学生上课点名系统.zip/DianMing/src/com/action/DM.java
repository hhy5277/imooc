package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.db.ConnDB;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class DM extends HttpServlet {
	private static final long serialVersionUID = 1L;  
	private static String sign = "0";
	private static Date d = null;
	private static String Tm = "";
	private static String pi;
	private static String sno;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stuget
		//����action
		String action = request.getParameter("action");
		System.out.println("��ȡ�Ĳ�ѯ�ַ�����" + action);
		if (action == null || "".equals(action)) {
			System.out.println("that's too bad!");
		} else if ("dm".equals(action)) {// ��actionֵΪloginʱ������managerLogin()������֤����Ա����
			try {
				DMstu(request,response);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if ("teacher".equals(action)) {
				DMteacher(request,response);
		}
	}

	private void DMteacher(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		if(request.getParameter("flag").equals("1")) {
			sign = "1";
		}
		System.out.println(sign);
		request.setCharacterEncoding("UTF-8");
		response.setHeader("content-type","text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		HttpSession session=request.getSession();
		d = (Date)session.getAttribute("time");
		Tm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(d);
		out.println("<script>alert('����ѧ��ǩ��Ȩ�޳ɹ�������');history.go(-1);</script>");
	}

	private void DMstu(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ParseException {
		request.setCharacterEncoding("UTF-8");
		response.setHeader("content-type","text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		HttpSession session=request.getSession();
		if(sign.equals("1")) {
			Date now1 = new Date();
			SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String now = a.format(now1);
			if(this.compare_date(now,Tm)==1&&((now1.getTime()-d.getTime())/(1000*60)<=10)) {
				if(!request.getRemoteAddr().equals(pi)||!((String)session.getAttribute("id")).equals(sno)) {
					String Sno = (String)session.getAttribute("id");
					sno = Sno;
					String ip = request.getRemoteAddr();
					pi = ip;
					String week1 = request.getParameter("week"); 
					int week = Integer.parseInt(week1);
					String id = (String)session.getAttribute("id");
					String CN = request.getParameter("CN");
					byte b[]=CN.getBytes("ISO-8859-1");
				    CN = new String(b,"UTF-8");
					String TN = request.getParameter("TN");
					byte b1[]=TN.getBytes("ISO-8859-1");
				    TN = new String(b1,"UTF-8");
				    String place = request.getParameter("place");
				    byte b2[]=place.getBytes("ISO-8859-1");
				    place = new String(b2,"UTF-8");
					String jieci = request.getParameter("jieci");
					String zhouji1 = request.getParameter("zhouji");
					int zhouji = Integer.parseInt(zhouji1);
					String state = "�ѵ�";
					String sql = "insert into QD values('"+Sno+"','"+CN+"',"+week+",'"+jieci+"','"+TN+"','"+ip+"','"+state+"','"+now+"',"+zhouji+")";
					int flag1 = (new ConnDB()).executeUpdate(sql);
				    out.println("<script>alert('�����ɹ���`(*��_��*)��');history.back(-1);</script>");
				    String temp[] = {CN,week1,jieci,TN};
				    session.setAttribute("CN", CN);
				    session.setAttribute("week", week1);
				    session.setAttribute("jieci", jieci);
				    session.setAttribute("TN", TN);
				}else {
					out.println("<script>alert('����ǩ������');history.back(-1);</script>");
				}
			}	
		} else {
			out.println("<script>alert('����ʱ��δ������ȵȣ���');history.back(-1);</script>");
		}   
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}
	
	public static int compare_date(String date1, String date2) 
	{           
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
               Date d1 = df.parse(date1);
               Date d2 = df.parse(date2);
               if (d1.getTime() > d2.getTime())
                  {
                       
                        return 1;
                  }
               else if (d1.getTime() < d2.getTime()) 
                 {
                      
                        return -1;
                 } 
               else 
               {
                        return 0;
                }
        } catch (Exception exception) {
                exception.printStackTrace();
        }
        return 0;

	  }

}

