package com.action;
import com.actionForm.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.dao.LoginDao;
public class logincheck extends HttpServlet {
    
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			checklogin(request,response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void checklogin(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		LoginDao loginDao = new LoginDao();
		String a = request.getParameter("name");
		String b = request.getParameter("pwd");
		int ret = loginDao.checklogin(a,b);
		String[] info = loginDao.checktype(a, b);
		if(ret==0) {
			Student stu = new Student();
			stu.setId(b);
			stu.setName(info[1]);
			stu.setType(info[0]);
			HttpSession session=request.getSession();
            session.setAttribute("manager",stu.getName());
            session.setAttribute("type",stu.getType());
            session.setAttribute("id",stu.getId());
            request.getRequestDispatcher("stu/menu.jsp").forward(request, response);
		}
		else if(ret==1) {
			Teacher tech = new Teacher();
			tech.setId(b);
			tech.setName(info[1]);
			tech.setType(info[0]);
			HttpSession session=request.getSession();
            session.setAttribute("manager",tech.getName());
            session.setAttribute("type",tech.getType());
            session.setAttribute("id",tech.getId());
            request.getRequestDispatcher("teacher/menu.jsp").forward(request, response);
		}
		else if(ret==2) {
			Admin admin = new Admin();
			admin.setId(b);
			admin.setName(info[1]);
			admin.setType(info[0]);
			HttpSession session=request.getSession();
            session.setAttribute("manager",admin.getName());
            session.setAttribute("type",admin.getType());
            session.setAttribute("id",admin.getId());
            request.getRequestDispatcher("admin/menu.jsp").forward(request, response);
		}
		else if(ret==3) {
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('�û���������������������롣');history.back(-1);</script>");
		}
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 doPost(request,response);
	}
}
