package com.dao;

import com.db.*;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDao {
	
	public String[] checktype(String name,String psd) throws SQLException {
		ConnDB db = new ConnDB();
		String[] info = {};
		String sql = "select name,role from login where id = '"+name+"'and password = '"+psd+"'";
		ResultSet rs = db.executeQuery(sql);
		while(rs.next()) {
			String a = rs.getString("role");
			String b = rs.getString("name");
			String[] flag = {a,b};
			info = flag;
		}
		return info;
	}
	
	public int checklogin(String name,String psd) {
		int flag = 0;
		try 
		{
			
			ConnDB db = new ConnDB();
			String sql = "select count(id) as flag from login where id = '"+name+"'and password = '"+psd+"'";
			ResultSet rs = db.executeQuery(sql);
			if(rs!=null) 
			{   
				rs.next();
				String flag1 = rs.getString("flag");
				if(flag1.equals("1")) {
					String[] mark = this.checktype(name, psd);
					if(mark[0].equals("stu")) { flag = 0; }
					else if(mark[0].equals("teacher")) { flag = 1; }
					else if(mark[0].equals("admin")) { flag = 2; }
				}
				else if(flag1.equals("0")) {
					flag = 3;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
    }
}
