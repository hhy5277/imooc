package com.xinlan.rocketship.screen;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Screen;
import com.xinlan.rocketship.RocketApp;

public class DefautScreen implements Screen {
    public RocketApp game;

    public DefautScreen(RocketApp game){
        this.game = game;
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float v) {

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
