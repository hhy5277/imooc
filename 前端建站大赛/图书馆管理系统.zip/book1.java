package booksystem;

public class book1 {
	//图书类
	public String aut;
	public String name;
	public int num;
	public int count;
	public int price;
	
public book1(String aut,String name,int num, int count,int price){
		this.aut=aut;
		this.name=name;
		this.num=num;
		this.count=count;
		this.price=price;
		
			}

}


