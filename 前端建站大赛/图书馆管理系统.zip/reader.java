package booksystem;

import java.util.HashSet;
import java.util.Set;

//学生类
public class reader{
	String id;
	String name;
	public Set book1;
	public reader(String id,String name){
		this.id=id;
		this.name=name;
		this.book1=new HashSet();
	}

}
