$(document).ready(function()
{
    var boy = BoyWalk()
	var girl = {
        elem: $('.girl'),
        getHeight: function() {
            return this.elem.height()
        },
        rotate: function() {
            this.elem.addClass('girl-rotate')
        },
        setOffset: function() {
            this.elem.css({
                left: visualWidth / 2,
                top: bridgeY - this.getHeight()
            })
        },
        getOffset: function() {
            return this.elem.offset();
        },
        getWidth: function() {
            return this.elem.width()
        }
    };

    girl.setOffset();
    function Hmlt5Audio(url, isloop) {
        var audio = new Audio(url);
        audio.autoPlay = true
        audio.loop = isloop || false;
        audio.play();
        return {
            end: function(callback) {
                audio.addEventListener('ended', function() {
                    callback()
                }, false);
            }
        }
    }
    var snowflakeURl = [
        'imgs/snowflake/snowflake1.png',
        'imgs/snowflake/snowflake2.png',
        'imgs/snowflake/snowflake3.png',
        'imgs/snowflake/snowflake4.png',
        'imgs/snowflake/snowflake5.png',
        'imgs/snowflake/snowflake6.png'
    ]

    function snowflake() {
        var $flakeContainer = $('#snowflake');

        function getImagesName() {
            return snowflakeURl[[Math.floor(Math.random() * 6)]]
        };
        function createSnowBox() {
            var url = getImagesName()
            return $('<div class="snowbox" />').css({
                'width': 41,
                'height': 41,
                'position': 'absolute',
                'backgroundSize': 'cover',
                'zIndex': 100000,
                'top': '-41px',
                'backgroundImage': 'url(' + url + ')'
            }).addClass('snowRoll')
        }
        setInterval(function() {
            var startPositionLeft = Math.random() * visualWidth - 100,
                startOpacity    = 1,
                endPositionTop  = visualHeight - 40,
                endPositionLeft = startPositionLeft - 100 + Math.random() * 500,
                duration        = visualHeight * 10 + Math.random() * 5000;

            var randomStart = Math.random()
            randomStart = randomStart < 0.5 ? startOpacity : randomStart

            var $flake = createSnowBox();

            $flake.css({
                left: startPositionLeft,
                opacity : randomStart
            });

            $flakeContainer.append($flake);

            $flake.transition({
                top: endPositionTop,
                left: endPositionLeft,
                opacity: 0.7
            }, duration, 'ease-out', function() {
                $(this).remove() 
            })
            
        }, 200);
    }

    function startRun() {
		$("#sun").addClass('rotation')
        $(".cloud:first").addClass('cloud1Anim')
        $(".cloud:last").addClass('cloud2Anim')
        boy.walkTo(2000, 0.2)
            .then(function() {
                scrollTo(7000, 1)
            }).then(function() {
                return boy.walkTo(7000, 0.5)
            }).then(function() {
                boy.stopWalk()
            })
            .then(function() {
                return openDoor();
            })
            .then(function() {
                lamp.bright()
            })
            .then(function() {
                return boy.toShop(2000)
            }).then(function(){
                return boy.talkFlower()
            }).then(function() {
                bird.fly()
            }).then(function() {
                return boy.outShop(2000)
            }).then(function() {
                lamp.dark()
            }).then(function() {
				scrollTo(2800, 1.4)
                return boy.walkTo(2800, 0.5)
            }).then(function() {
				boy.pushFlolerWalk()
			}).then(function() {
				boy.walkTo(3200, 0.15)
                scrollTo(3200, 2)
            }).then(function() {
                return boy.walkTo(1500, 0.25, (bridgeY - girl.getHeight()) / visualHeight)
            })
            .then(function() {
				boy.setFlolerWalk()
                var proportionX = (girl.getOffset().left - boy.getWidth() + girl.getWidth() / 5) / visualWidth;
                return boy.walkTo(1500, proportionX)
            }).then(function() {
                boy.resetOriginal();
				boy.setFlolerWalk();
            }).then(function() {
                setTimeout(function() {
                    girl.rotate();
                    boy.rotate(function() {
                        logo.run()
						snowflake()
                    });
                }, 1000)
            });
    }
	setTimeout(function() {startRun()},1000)

});
var container = $("#content");
var swipe = Swipe(container);
var visualWidth = container.width();
var visualHeight = container.height();
var getValue = function(className) {
	var $elem = $('' + className + '')
	return {
		height: $elem.height(),
		top: $elem.position().top
	}
}
function scrollTo(time, proportionX) {
   var distX = visualWidth * proportionX
   swipe.scrollTo(distX, time)
}
var bridgeY = function() {
	var data = getValue('.c_background_middle')
	return data.top
}()
var bird = {
	elem: $(".bird"),
	fly: function() {
		this.elem.addClass('birdFly')
		this.elem.transition({
			right: container.width()
		}, 15000, 'linear');
	}
}
var animationEnd = (function() {
   var explorer = navigator.userAgent;
   if (~explorer.indexOf('WebKit')) {
	   return 'webkitAnimationEnd'
   }
   return 'animationend'
})();
var lamp = {
	elem: $('.b_background'),
	bright: function() {
		this.elem.addClass('lamp-bright')
	},
	dark: function() {
		this.elem.removeClass('lamp-bright')
	}
}
var logo = {
	elem: $('.logo'),
	run: function() {
		this.elem.addClass('logolightSpeedIn')
			.on(animationEnd, function() {
				$(this).addClass('logoshake').off();
			})
	}
}

function doorAction(left, right, time) {
	var $door = $('.door');
	var doorLeft = $('.door-left');
	var doorRight = $('.door-right')
	var defer = $.Deferred();
	var count = 2;
	var complete = function() {
		if (count == 1) {
			defer.resolve();
			return;
		}
		count--
	}
	doorLeft.transition({
		'left': left
	}, time, complete)
	doorRight.transition({
		'left': right
	}, time, complete)
	return defer
}

function openDoor() {
	return doorAction('-50%', '100%', 2000)
}

function shutDoor() {
	return doorAction('0%', '50%', 2000)
}

var instanceX;

function BoyWalk() {

	var container = $("#content");
	var visualWidth = container.width()
	var visualHeight = container.height()

	var pathY = function() {
		var data = getValue('.a_background_middle')
		return data.top + data.height / 2
	}()
	var $boy = $("#boy");
	var boyHeight = $boy.height();
	$boy.css({
		top: pathY - boyHeight + 25
	})


	var boyWidth = $boy.width();
	var boyHeight = $boy.height();

	$boy.css({
		top: pathY - boyHeight + 25
	})

	function pauseWalk() {
		$boy.addClass('pauseWalk')
	}

	function restoreWalk() {
		$boy.removeClass('pauseWalk')
	}

	function slowWalk() {
		$boy.addClass('slowWalk')
	}

	function stratRun(options, runTime) {
		var dfdPlay = $.Deferred();
		restoreWalk();
		$boy.transition(
			options,
			runTime,
			'linear',
			function() {
				dfdPlay.resolve(); 
			});
		return dfdPlay;
	}

	function walkRun(time, dist, disY) {
		time = time || 3000;
		slowWalk();
		var d1 = stratRun({
			'left': dist + 'px',
			'top': disY ? disY : undefined
		}, time);
		return d1;
	}

	function talkFlower() {
		var defer = $.Deferred();
		setTimeout(function() {
			$boy.addClass('slowFlolerWalk')
			defer.resolve()
		}, 1000)
		return defer
	}
	function walkToShop(runTime) {
		var defer = $.Deferred();
		var doorObj = $('.door')
		var offsetDoor = doorObj.offset();
		var doorOffsetLeft = offsetDoor.left;
		var offsetBoy     = $boy.offset();
		var boyOffetLeft = offsetBoy.left;

		instanceX = (doorOffsetLeft + doorObj.width() / 2) - (boyOffetLeft + $boy.width() / 2);

		var walkPlay = stratRun({
			transform: 'translateX(' + instanceX + 'px),scale(0.3,0.3)',
			opacity: 0.1
		}, 2000);
		walkPlay.done(function() {
			$boy.css({
				opacity: 0
			})
			defer.resolve();
		})
		return defer;
	}

	function walkOutShop(runTime) {
		var defer = $.Deferred();
		restoreWalk();
		var walkPlay = stratRun({
			transform: 'translateX(' + instanceX + 'px),scale(1,1)',
			opacity: 1
		}, runTime)
		walkPlay.done(function() {
		defer.resolve();
		})
		return defer;   
	}

	function calculateDist(direction, proportion) {
		return (direction == "x" ?
			visualWidth : visualHeight) * proportion;
	}

	return {
		walkTo: function(time, proportionX, proportionY) {
			var distX = calculateDist('x', proportionX)
			var distY = calculateDist('y', proportionY)
			return walkRun(time, distX, distY);
		},
		toShop: function() {
			return walkToShop.apply(null, arguments);
		},
		outShop: function() {
			return walkOutShop.apply(null, arguments);
		},
		stopWalk: function() {
			pauseWalk();
		},
		setColoer: function(value) {
			$boy.css('background-color', value)
		},
		talkFlower: function() {
			return talkFlower()
		},
		getWidth: function() {
			return $boy.width();
		},
		resetOriginal: function() {
			this.stopWalk();
			$boy.removeClass('slowWalk slowFlolerWalk').addClass('boyOriginal')
		},
		setFlolerWalk:function(){
			 $boy.addClass('slowFlolerWalk')
		},
		pushFlolerWalk:function(){
			 $boy.removeClass('slowFlolerWalk')
		},
		rotate: function(callback) {
			   restoreWalk()
			   $boy.addClass('boy-rotate')
			   if (callback) {
				   $boy.on(animationEnd, function() {
					   callback()
					   $(this).off();
				   })
			   }
		   },
	}
}

