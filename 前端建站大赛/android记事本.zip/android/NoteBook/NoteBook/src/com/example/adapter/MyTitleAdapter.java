package com.example.adapter;

import java.util.List;

import com.example.notebook.R;
import com.example.notebook.R.id;
import com.example.notebook.R.layout;

import android.content.Context;
import android.graphics.Shader.TileMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MyTitleAdapter extends BaseAdapter {

	private Context context;
	private List<String> titles;

	public MyTitleAdapter(Context context, List<String> titles) {
		this.context = context;
		this.titles = titles;
	}

	@Override
	public int getCount() {
		if (titles != null) {
			return titles.size();
		} else {
			return 0;
		}

	}

	@Override
	public Object getItem(int index) {
		if (titles != null) {
			return titles.get(index);
		}
		return null;
	}

	@Override
	public long getItemId(int index) {
		if (titles != null) {
			return index;
		}
		return 0;
	}

	@Override
	public View getView(int postion, View convertView, ViewGroup parent) {

		ViewHolder holder = null;

		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(
					R.layout.list_item, null);

			holder = new ViewHolder();

			holder.title = (TextView) convertView.findViewById(R.id.title);

			convertView.setTag(holder);// ��ViewHolder����
		} else {
			holder = (ViewHolder) convertView.getTag();// ȡ��ViewHolder���� }
		}

		holder.title.setText(titles.get(postion));

		return convertView;
	}

	/* ��ſؼ� */
	public final class ViewHolder {
		public TextView title;

	}

}
