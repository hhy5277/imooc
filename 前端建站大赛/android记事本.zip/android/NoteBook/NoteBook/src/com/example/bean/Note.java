package com.example.bean;

/**
 * ���±�����
 */
public class Note {
	
	private int code;//���ݱ��
	private String title;//����
	private String context;//����
	
	public Note(int code, String title, String context) {
		super();
		this.code = code;
		this.title = title;
		this.context = context;
	}
	@Override
	public String toString() {
		return "Note [code=" + code + ", title=" + title + ", context="
				+ context + "]";
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	
	

}
