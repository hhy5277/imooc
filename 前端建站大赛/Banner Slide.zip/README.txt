<h3>最终效果图如下所示：</h3><p><img src="http://img.mukewang.com/55ed0a16000156ea05000176.jpg" alt="http://img.mukewang.com/55ed0a16000156ea14390505.jpg"/></p><h3>将以上代码嵌入wordpress</h3><p>1、css文件的嵌入<br/></p><p>将css文件拷贝至style.css用一下代码调用</p><pre class="brush:html;toolbar:false">&lt;link&nbsp;rel=&quot;stylesheet&quot;&nbsp;href=&quot;&lt;?php&nbsp;bloginfo(&#39;stylesheet_url&#39;);&nbsp;?&gt;&quot;&nbsp;type=&quot;text/css&quot;&nbsp;media=&quot;screen&quot;&nbsp;/&gt;</pre><p>2、js文件的嵌入<br/></p><pre class="brush:html;toolbar:false">&lt;script&nbsp;type=&quot;text/javascript&quot;&nbsp;src=&quot;&lt;?php&nbsp;echo&nbsp;get_template_directory_uri();&nbsp;?&gt;/js/jquery.SuperSlide.2.1.1.js&quot;&gt;&lt;/script&gt;</pre><p>3、banner文件的嵌入<br/></p><pre class="brush:php;toolbar:false">&lt;?php
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$arr&nbsp;=&nbsp;array(
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;meta_key&#39;&nbsp;=&gt;&nbsp;&#39;_thumbnail_id&#39;,
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;showposts&#39;&nbsp;=&gt;&nbsp;3,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;显示3个特色图像
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;posts_per_page&#39;&nbsp;=&gt;&nbsp;3,&nbsp;&nbsp;&nbsp;//&nbsp;显示3个特色图像
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;orderby&#39;&nbsp;=&gt;&nbsp;&#39;date&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;按发布时间先后顺序获取特色图像，可选：&#39;title&#39;、&#39;rand&#39;、&#39;comment_count&#39;等
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;ignore_sticky_posts&#39;&nbsp;=&gt;&nbsp;1,
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;post_type&#39;&nbsp;=&gt;&nbsp;array(&nbsp;&#39;post&#39;,&nbsp;&#39;page&#39;&nbsp;),
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;order&#39;&nbsp;=&gt;&nbsp;&#39;ASC&#39;);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$slideshow&nbsp;=&nbsp;new&nbsp;WP_Query($arr);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;($slideshow-&gt;have_posts())&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$postCount&nbsp;=&nbsp;0;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;while&nbsp;($slideshow-&gt;have_posts())&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$slideshow-&gt;the_post();
?&gt;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;li&gt;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;a&nbsp;href=&quot;&lt;?php&nbsp;the_permalink();&nbsp;?&gt;&quot;&nbsp;title=&quot;&lt;?php&nbsp;the_title();&nbsp;?&gt;&quot;&gt;
&lt;?php
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;获取特色图像的地址
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$timthumb_src&nbsp;=&nbsp;wp_get_attachment_image_src(&nbsp;get_post_thumbnail_id(get_the_ID())&nbsp;);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;&#39;&lt;img&nbsp;border=&quot;0&quot;&nbsp;alt=&quot;&#39;&nbsp;.&nbsp;get_the_title()&nbsp;.&nbsp;&#39;&quot;&nbsp;src=&quot;&#39;&nbsp;.&nbsp;$timthumb_src[0]&nbsp;.&nbsp;&#39;&quot;&nbsp;/&gt;&nbsp;&#39;;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;?&gt;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/a&gt;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/li&gt;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;?php
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;//&nbsp;endwhile
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;wp_reset_postdata();
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;//&nbsp;endif
?&gt;</pre><p>以上代码输出的html格式为</p><pre class="brush:html;toolbar:false">&lt;li&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&lt;a&nbsp;href=&quot;#&quot;&nbsp;title=&quot;&quot;&gt;&lt;img&nbsp;border=&quot;0&quot;&nbsp;alt=&quot;&quot;&nbsp;src=&quot;images/bn4.jpg&quot;&nbsp;/&gt;&lt;/a&gt;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;/li&gt;</pre><p>4、让wordpress支持特色图片<br/></p><pre class="brush:php;toolbar:false">//功能集成&nbsp;|&nbsp;设置特色图片
add_theme_support(&nbsp;&#39;post-thumbnails&#39;&nbsp;);</pre>

