<?php
    define('PATH',str_replace( '\\','/',dirname(__FILE__)).'/');

  

