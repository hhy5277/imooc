<!doctype html> 
    <html> 
    <head> 
        <meta charset="utf-8"> 
        <title></title> 
    </head>
    <body>
        <h1></h1>
        <form action="Updo.php" method="post" enctype="multipart/form-data">
                选择文件:
                <input type="file" name="file" />
                <input type="submit" value="上传文件" />
            </form>
    </body>
 	</html>

