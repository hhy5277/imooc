/**
 * 
 * @authors zhangxu (zhangxu9@leju.com)
 * @date    2015-06-25 21:48:43
 * @version 0.1.0
 */
;;(function(){
	function Star(opts){
		this.opts = opts;
		this.obj = document.getElementById(this.opts.id);
		this.defaults = {
			count: 5,
			score: true,
			pattern: 'blue',
			fn: function(score){
				console.log(score);
			}
		};
		this.num = 0;
		this.util.extend(this.defaults, this.opts);
		this.init();
	}
	var sProto = Star.prototype;
	// 初始化
	sProto.init = function(){
		for(var i = 0; i < this.defaults.count; i++){
			this.obj.appendChild(this.util.createEle('span'));
		}
		this.addCss();
		this.changeStar(this.defaults.pattern);
		this.mouseOver();
		this.mouseOut();
		this.mouseClick();
		if(this.defaults.score == true){
			this.showScore();
		}
	};
	// 改变星星的风格
	sProto.changeStar = function(pattern){
		for(var i = 0; i < this.defaults.count; i++){
			this.obj.children[i].style.backgroundImage = 'url(images/'+ pattern +'.png)';
		}
	};

	sProto.mouseOver = function(){
		var _this = this;
		for(var i = 0; i < this.obj.children.length; i++){
			this.obj.children[i].index = i;
			this.obj.children[i].onmouseover = function(){
				for(var i = 0; i < _this.obj.children.length; i++){
					if(i <= this.index){
						_this.obj.children[i].className = 'on';	
					}else{
						_this.obj.children[i].className = '';
					}
					if(_this.oScore != undefined){
						_this.oScore.innerHTML = this.index + 1 + ' 分';
					}
				}
			};
		}
	};

	sProto.mouseOut = function(){
		// console.log(6)
		var _this = this;
		for(var i = 0; i < this.obj.children.length; i++){
			this.obj.children[i].index = i;
			this.obj.children[i].onmouseout = function(){
			   	if(_this.num == 0){
			   		for( var i = 0; i < _this.obj.children.length; i++){
			   			_this.obj.children[i].className = '';
			   		}
			   	}else if(_this.num == 1){
			   		for( var i = 1; i < _this.obj.children.length; i++){
			   			_this.obj.children[i].className = '';
			   		}
			   	}else{
			   		for( var i = _this.num ; i < _this.obj.children.length; i++){
			   			_this.obj.children[i].className = '';
			   		}
			   		for( var i = 0 ; i < _this.num; i++){
			   			_this.obj.children[i].className = 'on';
			   		}
			   	}
			   	if(_this.oScore != undefined){
					_this.oScore.innerHTML = _this.num + ' 分';
				}
			};
		}
	};
	
	sProto.mouseClick = function(){
		var _this = this;
		for(var i = 0; i < this.obj.children.length; i++){
			this.obj.children[i].index = i;
			this.obj.children[i].onclick = function(){
				_this.num = this.index + 1;
				for(var i = 0;i<this.index;i++){
					_this.obj.children[i].className = 'on';
				}
				_this.defaults.fn && _this.defaults.fn(_this.num);
			};
		}
	};
	// 显示星星后面的分数
	sProto.showScore = function(){
		var oSco = this.util.createEle('div');
		oSco.style.display = 'none';
		oSco.className = 'score';
		oSco.innerHTML = '0 分';
		this.util.insertAfter(oSco, this.obj);
		this.oScore = this.util.getNextEle(this.obj);
		this.oScore.style.display = 'inline-block';
	};
	// 创建元素
	sProto.createEle = function(obj){
		return document.createElement(obj);
	}
	// 添加外部css文件
	sProto.addCss = function(){
		var oHead = document.getElementsByTagName('head')[0];
		var oLink = this.util.createEle('link');
		oLink.rel='stylesheet';
		oLink.type='text/css';
		oLink.href='css/zstar.css';
		oHead.appendChild(oLink);
	};
	// 工具函数
	sProto.util = {
		getNextEle: function(obj){
			return obj.nextElementSibling || obj.nextSibling;
		},
		extend: function (target, source){
		    for(var p in source){
		        if(source.hasOwnProperty(p)){
		         	target[p] = source[p];
		        }
		    }
		    return target;
		},
		insertAfter: function(newEle, targetEle){ 
			var parent = targetEle.parentNode; 
			if(parent.lastChild == targetEle){ 
				parent.appendChild(newEle);
			}
			else{
				parent.insertBefore(newEle, this.getNextEle(targetEle));
			}
		},
		createEle: function(obj){
			return document.createElement(obj);
		}
	};
	window.zConfig = function(opt){
		return new Star(opt);
	};
})();