p <- seq(0, 1, length = 1000)
plot(p, p * (1 - p), frame = FALSE, type = "l", lwd = 3)
