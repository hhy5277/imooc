---
layout: post
title: Logo Entry No. 8 - Stefano Asili
author: P. Taylor Goetz
---

![Storm Brand](/images/logocontest/sasili/storm_logo.png)



