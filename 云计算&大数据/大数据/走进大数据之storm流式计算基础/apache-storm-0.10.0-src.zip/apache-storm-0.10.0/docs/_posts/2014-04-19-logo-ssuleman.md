---
layout: post
title: Logo Entry No. 3- Shaan Shiv Suleman
author: P. Taylor Goetz
---


![Storm Brand](/images/logocontest/ssuleman/storm_logo.png)