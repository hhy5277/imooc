---
layout: post
title: Logo Entry No. 2 - Samuel Quiñones
author: P. Taylor Goetz
---

![Storm Brand](/images/logocontest/squinones/storm_logo1.png)

![Storm Brand](/images/logocontest/squinones/storm_logo.png)