---
layout: post
title: Logo Entry No. 5 - Ziba Sayari
author: P. Taylor Goetz
---

![Storm Brand](/images/logocontest/zsayari/storm_logo.png)


