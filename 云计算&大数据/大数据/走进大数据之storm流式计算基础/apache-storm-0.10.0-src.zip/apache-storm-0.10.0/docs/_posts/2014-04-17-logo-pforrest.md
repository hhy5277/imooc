---
layout: post
title: Logo Entry No. 1 - Patricia Forrest
author: P. Taylor Goetz
---

![Storm Brand](/images/logocontest/pforrest/storm1.png)

![Storm Brand](/images/logocontest/pforrest/storm_logo_composite.png)

