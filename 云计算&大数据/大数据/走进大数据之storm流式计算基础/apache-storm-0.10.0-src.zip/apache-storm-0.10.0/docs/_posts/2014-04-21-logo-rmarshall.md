---
layout: post
title: Logo Entry No. 4 - Richard Brownlie-Marshall
author: P. Taylor Goetz
---

![Storm Brand](/images/logocontest/rmarshall/StormLogo_Square.png)

![Storm Brand](/images/logocontest/rmarshall/StormLogo_Horizontal.png)

![Storm Brand](/images/logocontest/rmarshall/StormLogo_Horizontal_NoColour.png)

