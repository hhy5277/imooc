---
layout: post
title: Logo Entry No. 7 - Calum Boustead
author: P. Taylor Goetz
---

![Storm Brand](/images/logocontest/cboustead/storm_logo1.png)

![Storm Brand](/images/logocontest/cboustead/storm_logo.png)



