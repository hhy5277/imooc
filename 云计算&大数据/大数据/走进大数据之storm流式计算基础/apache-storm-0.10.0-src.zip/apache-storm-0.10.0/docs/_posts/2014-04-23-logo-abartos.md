---
layout: post
title: Logo Entry No. 6 - Alec Bartos
author: P. Taylor Goetz
---

![Storm Brand](/images/logocontest/abartos/storm_logo.png)

![Storm Brand](/images/logocontest/abartos/storm_logo2.png)

![Storm Brand](/images/logocontest/abartos/storm_logo3.png)

![Storm Brand](/images/logocontest/abartos/stationery_mockup.jpg)


