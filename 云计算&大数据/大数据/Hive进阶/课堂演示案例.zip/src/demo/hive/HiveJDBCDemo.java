package demo.hive;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import demo.utils.JDBCUtils;

public class HiveJDBCDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		String sql = "select * from emp";
		try {
			//��ȡ����
			conn = JDBCUtils.getConnection();
			//�������л���
			st = conn.createStatement();
			//����HQL
			rs = st.executeQuery(sql);
			//��������
			while(rs.next()){
				//ȡ��Ա����������нˮ
				String name = rs.getString(2);
				double sal = rs.getDouble(6);
				System.out.println(name+"\t"+sal);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			JDBCUtils.release(conn, st, rs);
		}
	}

}









