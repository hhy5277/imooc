package demo.hive;

import java.util.List;

import org.apache.hadoop.hive.service.HiveClient;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TSocket;

public class HiveThriftClient {

	public static void main(String[] args) throws Exception{
		//����Socket������
		final TSocket tSocket = new TSocket("192.168.56.31", 10000);
		
		//����һ��Э��
		final TProtocol tProtcal = new TBinaryProtocol(tSocket);
		
		//����Hive Client
		final HiveClient client = new HiveClient(tProtcal);
		
		//��Socket
		tSocket.open();
		
		//ִ��HQL
		client.execute("desc emp");
		//�������
		List<String> columns = client.fetchAll();
		for(String col:columns){
			System.out.println(col);
		}
		
		//�ͷ���Դ
		tSocket.close();
	}

}











